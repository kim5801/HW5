#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26386"

/** Maximum word length */
#define WORD_LIMIT 26

/** Semaphore for thread mutual exclusion */
sem_t lock;

/** Array to represent board state */
int boardWidth;
int boardHeight;
char *board;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  free( board );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *arg ) {
  // Cast void pointer to int
  int sock = *(int *)arg;

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    // Ensure mutual exclusion
    sem_wait( &lock );   

    // Parse and run command
    if ( strcmp( cmd, "across" ) == 0 ) {
      // Parse arguments
      bool validCommand = true;
      int r, c;
      char word[ 28 ]; // no more than 26 characters, leave space for one extra char and the null terminator
      int ret1 = fscanf( fp, "%d", &r );
      int ret2 = fscanf( fp, "%d", &c );
      int ret3 = fscanf( fp, "%27s", word ); // protect against buffer overflow by specifying field width
      if ( ret1 != 1 || ret2 != 1 || ret3 != 1 || strlen( word ) + c > boardWidth || r >= boardHeight || strlen( word ) > 26 ) {
        fprintf( fp, "Invalid command\n" );
        validCommand = false;
      }

      if ( validCommand ) {
        // Check word validity
        for ( int i = c; i < c + strlen( word ); i++ ) {
          char wordChar = word[ i - c ];
          char boardChar = board[ (r * boardWidth) + i ];
          if ( wordChar < 97 || wordChar > 122 || ( boardChar != 0 && boardChar != wordChar ) ) {
            fprintf( fp, "Invalid command\n" );
            validCommand = false;
            break;
          }
        }

        if ( validCommand ) {
          // Command and word are valid, fill in board state
          for ( int i = c; i < c + strlen( word ); i++ ) {
            board[ (r * boardWidth) + i ] = word[ i - c ];
          }
        }
      }
    } else if ( strcmp( cmd, "down" ) == 0 ) {
      // Parse arguments
      bool validCommand = true;
      int r, c;
      char word[ 28 ]; // no more than 26 characters, leave space for one extra char and the null terminator
      int ret1 = fscanf( fp, "%d", &r );
      int ret2 = fscanf( fp, "%d", &c );
      int ret3 = fscanf( fp, "%27s", word ); // protect against buffer overflow by specifying field width
      if ( ret1 != 1 || ret2 != 1 || ret3 != 1 || strlen( word ) + r > boardHeight || c >= boardWidth || strlen( word ) > 26 ) {
        fprintf( fp, "Invalid command\n" );
        validCommand = false;
      }

      if ( validCommand ) {
        // Check word validity
        for ( int i = r; i < r + strlen( word ); i++ ) {
          char wordChar = word[ i - r ];
          char boardChar = board[ (i * boardWidth) + c ];
          if ( wordChar < 97 || wordChar > 122 || ( boardChar != 0 && boardChar != wordChar ) ) {
            fprintf( fp, "Invalid command\n" );
            validCommand = false;
            break;
          }
        }

        if ( validCommand ) {
          // Command and word are valid, fill in board state
          for ( int i = r; i < r + strlen( word ); i++ ) {
            board[ (i * boardWidth) + c ] = word[ i - r ];
          }
        }
      }
    } else if ( strcmp( cmd, "board" ) == 0 ) {
      // Print top line
      fprintf( fp, "+" );
      for ( int i = 0; i < boardWidth; i++ ) {
        fprintf( fp, "-" );
      }
      fprintf( fp, "+\n" );
     
      // Print row by row
      for ( int i = 0; i < boardHeight; i++ ) {
        // Print border
        fprintf( fp, "|" );
        
        // Print row
        for ( int j = 0; j < boardWidth; j++ ) {
          char boardChar = board[ ( i * boardWidth) + j ];
          if ( boardChar == 0 ) {
            fprintf( fp, " " );
          } else {
            fprintf( fp, "%c", board[ ( i * boardWidth) + j ] );
          }
        }

        // Print border
        fprintf( fp, "|\n" );
      }

      // Print bottom line
      fprintf( fp, "+" );
      for ( int i = 0; i < boardWidth; i++ ) {
        fprintf( fp, "-" );
      }
      fprintf( fp, "+\n" );
    } else {
      fprintf( fp, "Invalid command\n" );
    }

    // Release semaphore
    sem_post( &lock ); 

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Parse command line args
  if ( argc != 3 ) { fail( "usage: scrabbleServer <rows> <cols>" ); }
  int r, c;
  r = atoi( argv[1] );
  c = atoi( argv[2] );
  if ( r < 1 || c < 1 ) {
    fail( "usage: scrabbleServer <rows> <cols>" );
  }

  // Allocate and initialize board state
  board = malloc( ( r * c ) * sizeof( char ) );
  boardWidth = c;
  boardHeight = r;

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  // Initialize semaphore
  sem_init( &lock, 0, 1 );

  while ( true  ) {
    // Accept a client connection.
    int *sock = malloc( sizeof( int* ) );
    *sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen );

    // Create a new thread for this client
    pthread_t thread;
    if ( !pthread_create( &thread, NULL, handleClient, sock ) ) {

      // detach thread
      pthread_detach( thread );
    }
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
