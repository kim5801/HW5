#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26084"

/** Maximum word length */
#define WORD_LIMIT 26

/** Number of rows */
int rows;

/** Number of columns */
int cols;

/** Our scrabbled board */
char **board;

/** Our semaphore that prevent a board race condition */
sem_t race;

/**
* @param c the string being converted to an int
* @return c as an integer value
*/
int stringToInt( char c[] ) {
    int retVal = 0;
    for( int i = 0; c[i] != '\0'; i++ ) {
        if(c[i] > '9' || c[i] < '0') {
            return -1;
        }
        retVal = ( retVal * 10 ) + c[i] - '0';
    }
    return retVal;
}


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Function that responds to the "board" command and prints out our board.
void printBoard() {
    
}

/**
* Places a word across the board at row, col
* @param row the row where the word starts
* @param col the column where the word starts
* @return -1 if its an invalid command and 1 if its valid.
*/
int across( int row, int col, char *word ) {
    // ERROR CHECKING
    int len = strlen( word );
    //printf("%s\n", word);
    //printf("%d\n", row);
    //printf("%d\n", col);
    // Too long word
    if( ( ( len + col ) > cols ) || len > WORD_LIMIT ) {
        return -1;
    } 
    // Invalid rows or columns
    else if( ( row > rows || row < 0 ) || ( col > cols || col < 0 ) ) {
        return -1;
    }
    // Check for all lowercase
    else {
        for( int i = 0; i < len; i++ ) {
            if( !islower( word[ i ] ) ) {
                return -1;
            }
        }
    }
    // Check for valid sequence in relation to what else is on board
    int j = 0;
    for( int i = col; i < ( col + len ); i++ ) {
        if( board[ row ][ i ] != ' ' ) {
            if( board[ row ][ i ] != word[ j ] ) {
                return -1;
            }
        }
        j++;
    }
    // Finally...place the word on the board.
    j = 0;
    for( int i = col; i < ( col + len ); i++ ) {
        board[ row ][ i ] = word[ j ]; 
        j++;
    }
    return 1;
}

/**
* Places a word down the board at row, col
* @param row the row where the word starts
* @param col the column where the word starts
* @return -1 if its an invalid command and 1 if its valid.
*/
int down( int row, int col, char *word ) {
    // ERROR CHECKING
    int len = strlen( word );
    // Too long word
    if( ( ( len + row ) > rows ) || len > WORD_LIMIT ) {
        return -1;
    } 
    // Invalid rows or columns
    else if( ( row > rows || row < 0 ) || ( col > cols || col < 0 ) ) {
        return -2;
    }
    // Check for all lowercase
    else {
        for( int i = 0; i < len; i++ ) {
            if( !islower( word[ i ] ) ) {
                return -3;
            }
        }
    }
    // Check for valid sequence in relation to what else is on board
    int j = 0;
    for( int i = row; i < ( row + len ); i++ ) {
        if( board[ i ][ col ] != ' ' ) {
            if( board[ i ][ col ] != word[ j ] ) {
                printf("%c\n", 'h');
                return -4;
            }
        }
        j++;
    }
    // Finally...place the word on the board.
    j = 0;
    for( int i = row; i < ( row + len ); i++ ) {
        board[ i ][ col ] = word[ j ]; 
        j++;
    }
    return 1;
}

/** handle a client connection, close it when we're done. */
void *handleClient( void * arg ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int sock = *( ( int * ) arg );
  FILE *fp = fdopen( sock, "a+" );
  free( arg );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  int argCount = 0;

  // Command actions
  char commandName[20];
  char localRow[20];
  char localCol[20];
  char word[28];

  // Temporary values for parsing commands.
  char cmd[ 100 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 && strcmp( cmd, "quit" ) != 0 ) {
   
    if( argCount == 0 ) {
        strcpy( commandName, cmd );
        argCount++;
        if( strcmp( commandName, "across" ) == 0 || strcmp( commandName, "down" ) == 0 ) {
            continue;
        }
    } else if( argCount == 1 ) {
        strcpy( localRow, cmd );
        argCount++;
        continue;
    } else if( argCount == 2 ) {
        strcpy( localCol, cmd );
        argCount++;
        continue;
    } else if( argCount == 3 ) {
        strcpy( word, cmd );
        argCount++;
    }
    // Did we get across as our command?
    if( strcmp( commandName, "across" ) == 0 && argCount == 4 ) {
        // Semaphore wait
        sem_wait( &race );
        // Convert our rows and cols to integers.
        int testDigitX = stringToInt( localRow );
        int testDigitY = stringToInt( localCol );
        int x = -1;
        // If valid, throw them into our helper method.
        if( testDigitX >= 0 && testDigitY >= 0 ) {
            x = across( testDigitX, testDigitY, word );
        }
        // Once again, if across returns invalid then print error.
        if( x < 0 ) {
            fprintf( fp, "%s\n", "Invalid command" );
        }
        // Don't forget the semaphore
        sem_post( &race );
        
    } 
    // Same thing but for the down command
    else if( strcmp( commandName, "down" ) == 0 && argCount == 4 ) {
        //Semaphore
        sem_wait( &race );
        // rows and cols to ints
        int testDigitX = stringToInt( localRow );
        int testDigitY = stringToInt( localCol );
        int x = -1;
        // Error checking
        if( testDigitX >= 0 && testDigitY >= 0 ) {
            x = down( testDigitX, testDigitY, word );
        }
        // Error checking again
        if( x < 0 ) {
            fprintf( fp, "%s\n", "Invalid command");
        }
        sem_post( &race );
        
    }
    // Did we get a board command?
    else if( strcmp( commandName, "board" ) == 0 && argCount == 1 ) {
        //Semaphore
        sem_wait( &race );
        //Print the board out!
        // Board header
        fprintf( fp, "%c", '+');
        for(int i = 0; i < cols; i++) {
            fprintf( fp, "%c", '-');
        }
        fprintf( fp, "%c\n", '+');
        // Board contents
        for( int i = 0; i < rows; i++ ) {
            fprintf( fp, "%c", '|');
            for( int j = 0; j < cols; j++ ) {
                fprintf( fp, "%c", board[ i ][ j ] );
            }
            fprintf( fp, "%c", '|');
            fprintf( fp, "%c", '\n');
        }
        // Board bottom (same as header)
        fprintf( fp, "%c", '+');
        for(int i = 0; i < cols; i++) {
            fprintf( fp, "%c", '-');  
        }
        fprintf( fp, "%c\n", '+');
        sem_post( &race );
    } 
    // Otherwise we probably just got a bad command.
    else {
    
        fprintf( fp, "%s\n", "Invalid commandx" );
        
    }
    
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
    argCount = 0;
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  // Error checking on arguments
  if( argc != 3 ) {
    fail( "usage: scrabbleServer <rows> <cols>");
  } else {
    rows = stringToInt( argv[ 1 ] );
    cols = stringToInt( argv[ 2 ] );
    if( rows < 0 || cols < 0 ) {
      fail( "usage: scrabbleServer <rows> <cols>");
    }
  }
  
  // Initialize semaphore
  sem_init( &race, 0, 1 );
  
  // Initializes the board
  board = malloc( rows * sizeof( char * ) );
  for(int i = 0; i < rows; i++ ) {
    board[ i ] = malloc( cols * sizeof( char * ) );
  }
  // Initialize board values
  for( int i = 0; i < rows; i++ ) {
    for( int j = 0; j < cols; j++ ) {
        board[ i ][ j ] = ' ';
    }
  }
  //Everything else goes here
  
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);
  while ( true  ) {
    // Accept a client connection.
    int *argToPass = malloc(sizeof(*argToPass));
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_t tId;
    *argToPass = sock;
    pthread_create( &tId, NULL, handleClient, argToPass );
    pthread_detach( tId );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  // Free allocated memory
  free( board );
  
  return 0;
}
