/**
   @file scrabbleServer.c
   @author Natalie Kerkado nykerkad
    This progrma imitates the game of scrabble thorugh a client-server interaction
    NOTE: all error checking works with only one client, it only doesnt work when multi-thread code was applied and more than one host/client is used
  */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26416"

/** Maximum word length */
#define WORD_LIMIT 26

// Set a max amount of space for the board.
#define GRID_SIZE 1024

char **board;
int rows = 0;
int columns = 0;
bool firstDown = true;
sem_t changeBoard;


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void * arg ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int sock = *(int *)arg;
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    // if the command is across
    if( strcmp( cmd, "across" ) == 0 ) {
      int row;
      int column;
      char word[rows + 1];
      fscanf( fp, "%d", &row );
      fscanf( fp, "%d", &column );
      fscanf( fp, "%s", word );
      int size = strlen(word);
      bool valid = false;
      
      sem_wait( &changeBoard );
      //check if word is more than 26 char
      if(size > WORD_LIMIT ) {
        printf("Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }
      //check if word would go over board
      if(row >= rows || row < 0 || column < 0) {
          printf("Invalid command\n");
      }
      //check if it will go over the board
      for(int i = column; i <= column + size; i++ ) {
        int tempColumn = column;
        if( column > columns ){
          printf("Invalid command\n");
          fprintf( fp, "cmd> " );
          continue;
        }
        tempColumn++;
      }
      sem_post( &changeBoard );
      
      //if the word is not the first word on the board, check for matching letters
      if(!firstDown) {
        sem_wait( &changeBoard );
        int tempColumn = column;
        for(int i = 0; i < size; i++ ) {
          if(board[row][tempColumn] != word[i]) {
            if( board[row][tempColumn] == ' ') {
              valid = true;
            }
            else {
              valid = false;
            }
          }
          else {
            valid = true;
            break;
          }
          tempColumn++;
        }
        if(!valid) {
          printf("Invalid command\n");
          fprintf( fp, "cmd> " );
          continue;
        }
        sem_post( &changeBoard );
      
      }
      //place it on the correct row
      sem_wait( &changeBoard );
      for(int i = 0; i < size; i++ ) {
        firstDown = false;
        board[row][column] = word[i];
        column++;
        
      }
      sem_post( &changeBoard );
    }
    //takes care of the down command
    if(strcmp( cmd, "down" ) == 0 ) {
      int row;
      int column;
      char word[columns + 1];
      fscanf( fp, "%d", &row );
      fscanf( fp, "%d", &column );
      fscanf( fp, "%s", word );
      int size = strlen(word);
      bool valid = false;
      sem_wait( &changeBoard );
      //check if word is more than 26 char
      if(size > WORD_LIMIT ) {
        printf("Invalid command\n");
      }
      //check if word would go over board
      if(column >= columns || row < 0 || column < 0) {
          printf("Invalid command\n");
          fprintf( fp, "cmd> " );
          continue;
      }
      for(int i = row; i <= row + size; i++ ) {
        int tempRow = row;
        if( row > rows ){
          printf("Invalid command\n");
          fprintf( fp, "cmd> " );
          continue;
        }
        tempRow++;
      }
      sem_post( &changeBoard );
      //if the word is not the first word on the board, check for matching letters
      if(!firstDown) {
        sem_wait( &changeBoard );
        for(int i = 0; i < size; i++ ) {
          int tempRow = row;
          if(board[tempRow][column] != word[i]) {
            if( board[tempRow][column] == ' ') {
              valid = true;
            }
            else {
              valid = false;
            }
          }
          else {
            valid = true;
            break;
          }
          tempRow++;
        }
        if(!valid ) {
          printf("Invalid command\n");
          fprintf( fp, "cmd> " );
          continue;
        }
        sem_post( &changeBoard );
      }
      
      //place it on the correct row
      sem_wait( &changeBoard );
      for(int i = 0; i < size; i++ ) {
        firstDown = false;
        board[row][column] = word[i];
        row++;
      }
      sem_post( &changeBoard );
    }
    sem_wait( &changeBoard );
    if(strcmp( cmd, "board" ) == 0 ) {
      printf("+");
      for(int i = 1; i < columns + 1; i++ ) {
        printf("-");
      }
      printf("+");
      printf("\n");
      for(int i = 0; i < rows; i++) {
        for(int j = 0; j <= columns + 1; j++) {
          if(j == 0 ) {
            printf("|");
          } 
          printf("%c", board[i][j]);
           if(j == columns + 1) {
             printf("|");
           }
        }
        printf("\n");
      }
      printf("+");
      for(int i = 1; i < columns + 1; i++ ) {
        printf("-");
      }
      printf("+");
      printf("\n");
      
    }
    sem_post( &changeBoard );

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  sem_init( &changeBoard, 0, 1 );

  long r = strtol(argv[1], NULL, 10);
  long c = strtol(argv[2], NULL, 10);
  
  rows = r;
  columns = c;
  
  if( rows <= 0 || columns <= 0) {
    fail("usage: scrabbleServer <rows> <cols>");
  } 
  
 //memory for the board
 board = (char **) calloc( rows, sizeof(char *));
 for(int i = 0; i < rows; i++ ) {
   board[i] = (char *)calloc(columns, sizeof(char));
 }
 for(int i = 0; i < rows; i++) {
    for(int j = 0; j < columns; j++) {
      board[i][j] = ' ';
    }
  }
  
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);
  
  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    pthread_t thread;
    if(pthread_create(&thread, NULL, handleClient, (void *)&sock) != 0) {
      fail("cannot make thread");
    }
    pthread_detach(thread);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  free(board);
  
  return 0;
}
