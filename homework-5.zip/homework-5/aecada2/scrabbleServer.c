#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netdb.h>
#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <semaphore.h>

// #define scrabbleBoard2D ((char(*)[sBoard->cols]) sBoard->board)

/** Port number used by my server */
#define PORT_NUMBER "26272"

/** Maximum word length */
#define WORD_LIMIT 26

struct scrabbleBoard
{
    int rows;
    int cols;
    char *board;
};

// a node to contain all the strings
typedef struct Node
{
    // Value in our list
    char *word;

    // Pointer to the next node.
    struct Node *next;
} Node;

// Representation for a list, with a head pointer.
typedef struct
{
    // Head pointer for the list.
    Node *head;

} List;

// Representation for the args to be passed into p_thread_create
typedef struct
{
    int socket;

    struct scrabbleBoard *sBoard;

} args;

// dictionary to check against contains all words hashed by word length
static List *dict[WORD_LIMIT] = {};

// parallel data structure to the dictionary to hold current indices/lengths of
// the dictionary's sub arrays
// static int dictidxs[WORD_LIMIT] = {};

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(EXIT_FAILURE);
}
// Print out a usage message, then exit.
static void usage()
{
    printf("usage: scrabbleServer <rows> <cols>\n");
    exit(1);
}

static char *boardToString(struct scrabbleBoard *sBoard, char *str)
{
    for (size_t i = 0; i < sBoard->rows + 2; i++) // run for the number of rows + number of header/footer lines
    {
        if (i == 0 || i == sBoard->rows + 1) // if you are on the first or last line concat the header or footer
        {
            strncat(str, "+", 1);
            for (size_t i = 0; i < sBoard->cols; i++)
            {
                strncat(str, "-", 1);
            }
            strncat(str, "+\n", 2);
        }
        else
        {
            // concat the first char
            strncat(str, "|", 1);
            // concat the board line
            strncat(str, &(sBoard->board[(i - 1) * sBoard->cols]),
                    sBoard->cols);
            // concat the last char
            strncat(str, "|\n", 2);
        }
    }
    // add the last null terminator
    str[(sBoard->rows + 2) * (sBoard->cols + 3)] =
        '\0'; // sets the null terminator of the string
    return str;
}

/** handle a client connection, close it when we're done. */
void *handleClient(void *passed_arguments)
{
    // unpacks the arguments from the passed struct
    args *arguments = passed_arguments;
    int sock = arguments->socket;
    struct scrabbleBoard *sBoard = arguments->sBoard;

    // Here's a nice trick, wrap a C standard IO FILE around the
    // socket, so we can communicate the same way we would read/write
    // a file.
    FILE *fp = fdopen(sock, "a+");

    // Prompt the user for a command.
    fprintf(fp, "cmd> ");

    // Temporary values for parsing commands.
    char cmd[11];
    // cppcheck-suppress IOWithoutPositioning
    while (fscanf(fp, "%10s", cmd) == 1 &&
           strcmp(cmd, "quit") !=
               0)
    {

        int row = -1, col = -1;
        char word[WORD_LIMIT + 1] = {};
        // checks if the command is across, then checks if the next input is a
        // number for row which is in valid bounds, then checks if the next input
        // is a number for column which is in valid bounds, finally checks if the
        // next input is a word that wont exceed the size of the board.
        if (strcmp(cmd, "across") == 0 && fscanf(fp, "%d", &row) == 1 &&
            row >= 0 && row < sBoard->rows && fscanf(fp, "%d", &col) == 1 &&
            col >= 0 && col < sBoard->cols && fscanf(fp, "%26s", word) == 1 &&
            strlen(word) + col <= sBoard->cols)
        {

            // checks if the word is in the dictionary and outputs invalid
            // command if not
            bool wordValid = false;
            {
                Node **current = &(dict[strlen(word)]->head);
                while (*current != NULL)
                {
                    if (strcmp((*current)->word, word) == 0)
                    {
                        wordValid = true;
                        break;
                    }
                    current = &((*current)->next);
                }
            }
            if (!wordValid)
            {
                fprintf(fp, "Invalid command\n");
                goto nextInput;
            }

            // gets a snapshot of the board before it starts being edited to be potentially reverted to
            char *old_board =
                (char *)malloc(sBoard->rows * sBoard->cols * sizeof(char));
            memcpy(old_board, sBoard->board, sBoard->rows * sBoard->cols * sizeof(char));

            // for each letter in the word
            for (size_t i = 0; i < strlen(word); i++)
            {
                // if the letter at the location it would be on the board is not
                // a space and it is not the same letter it is not valid
                char *boardLetter =
                    &sBoard->board[sBoard->cols * row + col + i];
                char wordLetter = word[i];
                if (*boardLetter != wordLetter && *boardLetter != ' ')
                {
                    // then it is not a valid command
                    memcpy(sBoard->board, old_board,
                           sBoard->rows * sBoard->cols * sizeof(char));
                    fprintf(fp, "Invalid command\n");
                    goto nextInput;
                }

                // Now add the letter to the board (and check if words
                // above/below are valid)
                *boardLetter = wordLetter;

                char word_to_check[WORD_LIMIT + 1] = {};

                // validate through checking every row in the board that the column contains only valid words after placing the letter
                for (size_t j = 0; j < sBoard->rows; j++)
                {
                    // get the next character in that column to potentially add to the word to check
                    char new_char_from_board =
                        sBoard->board[(sBoard->cols * j) + col + i];

                    // if you just found a space or are at the end, check if your word is valid
                    if ((new_char_from_board == ' ' || j == sBoard->rows - 1) &&
                        strlen(word_to_check) != 0 && strlen(word_to_check) != 1)
                    {

                        // edge case in case you are at the end of the board you should add the last character to the word to check
                        if (j == sBoard->rows - 1)
                        {
                            strncat(word_to_check, &new_char_from_board, 1);
                        }
                        bool word_found_in_dict = false;

                        // checks through the dictionary if your word is valid
                        int len_to_check = 1;
                        Node **current = &(dict[len_to_check]->head);
                        while ((current != NULL && *current != NULL) || len_to_check <= WORD_LIMIT)
                        {
                            // cppcheck-suppress oppositeInnerCondition
                            if (current == NULL || *current == NULL)
                            {
                                current = &(dict[++len_to_check]->head);
                                continue;
                            }
                            // if (strcmp(word, "no") == 0 && strcmp(word_to_check, "on") == 0)
                            // {
                            //     printf("len_to_check: %d, current word: %s\n", len_to_check, (*current)->word);
                            // }

                            if (strcmp((*current)->word, word_to_check) == 0)
                            {
                                word_found_in_dict = true;
                                break;
                            }
                            current = &((*current)->next);
                        }

                        // if your word to check is not valid then revert the board and error out
                        if (!word_found_in_dict)
                        {
                            memcpy(sBoard->board, old_board,
                                   sBoard->rows * sBoard->cols * sizeof(char));
                            fprintf(fp, "Invalid command\n");
                            goto nextInput;
                        }
                        // reset the word to check after finding a full word
                        memset(word_to_check, 0, WORD_LIMIT + 1);
                    }
                    // if you did not find a space concat the next char to the word
                    else if (new_char_from_board != ' ')
                    {
                        strncat(word_to_check, &new_char_from_board, 1);
                    }
                    else
                    {
                        // make sure the word gets reset so it doesnt contain erroneous chars
                        memset(word_to_check, 0, WORD_LIMIT + 1);
                    }
                }
            }

            // performs the same purpose as above but checks inline with the placed word instead of cross-wise to insure that the word placed has not created invalid words
            char word_to_check[WORD_LIMIT + 1] = {};
            for (size_t j = 0; j < sBoard->cols; j++)
            {
                char new_char_from_board =
                    sBoard->board[(sBoard->cols * row) + j];

                if ((new_char_from_board == ' ' || j == sBoard->cols - 1) &&
                    strlen(word_to_check) != 0 && strlen(word_to_check) != 1)
                {
                    if (j == sBoard->cols - 1)
                    {
                        strncat(word_to_check, &new_char_from_board, 1);
                    }
                    bool word_found_in_dict = false;

                    int len_to_check = 1;
                    Node **current = &(dict[len_to_check]->head);
                    while ((current != NULL && *current != NULL) || len_to_check <= WORD_LIMIT)
                    {
                        // cppcheck-suppress oppositeInnerCondition
                        if (current == NULL || *current == NULL)
                        {
                            current = &(dict[++len_to_check]->head);
                            continue;
                        }
                        // if (strcmp(word, "no") == 0 && strcmp(word_to_check, "on") == 0)
                        // {
                        //     printf("len_to_check: %d, current word: %s\n", len_to_check, (*current)->word);
                        // }

                        if (strcmp((*current)->word, word_to_check) == 0)
                        {
                            word_found_in_dict = true;
                            break;
                        }
                        current = &((*current)->next);
                    }

                    if (!word_found_in_dict)
                    {
                        memcpy(sBoard->board, old_board,
                               sBoard->rows * sBoard->cols * sizeof(char));
                        fprintf(fp, "Invalid command\n");
                        goto nextInput;
                    }
                    memset(word_to_check, 0, WORD_LIMIT + 1);
                }
                else if (new_char_from_board != ' ')
                {
                    strncat(word_to_check, &new_char_from_board, 1);
                }
                else
                {
                    memset(word_to_check, 0, WORD_LIMIT + 1);
                }
            }
        }        
        // checks if the command is down, then checks if the next input is a
        // number for row which is in valid bounds, then checks if the next input
        // is a number for column which is in valid bounds, finally checks if the
        // next input is a word that wont exceed the size of the board.
        else if (strcmp(cmd, "down") == 0 && fscanf(fp, "%d", &row) == 1 &&
                 row >= 0 && row < sBoard->rows &&
                 fscanf(fp, "%d", &col) == 1 && col >= 0 &&
                 col < sBoard->cols && fscanf(fp, "%26s", word) == 1 &&
                 strlen(word) + row <= sBoard->rows)
        {

            // checks if the word is in the dictionary and outputs invalid
            // command if not
            bool wordValid = false;
            {
                Node **current = &(dict[strlen(word)]->head);
                while (*current != NULL)
                {
                    if (strcmp((*current)->word, word) == 0)
                    {
                        wordValid = true;
                        break;
                    }
                    current = &((*current)->next);
                }
            }
            if (!wordValid)
            {
                fprintf(fp, "Invalid command\n");
                goto nextInput;
            }

            // gets a snapshot of the board before it starts being edited to be potentially reverted to
            char *old_board =
                (char *)malloc(sBoard->rows * sBoard->cols * sizeof(char));
            memcpy(old_board, sBoard->board, sBoard->rows * sBoard->cols * sizeof(char));

            // for each letter in the word
            for (size_t i = 0; i < strlen(word); i++)
            {
                // if the letter at the location it would be on the board is not
                // a space or the same letter it is not valid
                char *boardLetter =
                    &sBoard->board[sBoard->cols * (row + i) + col];
                char wordLetter = word[i];
                if (*boardLetter != wordLetter && *boardLetter != ' ')
                {
                    // then it is not a valid command
                    memcpy(sBoard->board, old_board,
                           sBoard->rows * sBoard->cols * sizeof(char));
                    fprintf(fp, "Invalid command\n");
                    goto nextInput;
                }

                // Now add the letter to the board (and check if words
                // above/below are valid)
                *boardLetter = wordLetter;

                char word_to_check[WORD_LIMIT + 1] = {};

                // validate through checking every column in the board that the row contains only valid words after placing the letter
                for (size_t j = 0; j < sBoard->cols; j++)
                {
                    // get the next character in that row to potentially add to the word to check
                    char new_char_from_board = sBoard->board[sBoard->cols * (row) + j];

                    // printf("new_char_from_board: %c\n", new_char_from_board);

                    // if you just found a space or are at the end, check if your word is valid
                    if ((new_char_from_board == ' ' || j == sBoard->cols - 1) &&
                        strlen(word_to_check) != 0 && strlen(word_to_check) != 1)
                    {

                        // edge case in case you are at the end of the board you should add the last character to the word to check
                        if (j == sBoard->cols - 1)
                        {
                            strncat(word_to_check, &new_char_from_board, 1);
                        }
                        bool word_found_in_dict = false;

                        // checks through the dictionary if your word is valid
                        int len_to_check = 1;
                        Node **current = &(dict[len_to_check]->head);
                        while ((current != NULL && *current != NULL) || len_to_check <= WORD_LIMIT)
                        {
                            // cppcheck-suppress oppositeInnerCondition
                            if (current == NULL || *current == NULL)
                            {
                                current = &(dict[++len_to_check]->head);
                                continue;
                            }

                            // if (strcmp(word, "happy") == 0 && len_to_check == 5)
                            // {
                            //     fprintf(fp, "len_to_check: %d, current->word: %s, word: %s, strcmp((*current)->word, word): %d\n", len_to_check, (*current)->word, word, strcmp((*current)->word, word));
                            // }

                            if (strcmp((*current)->word, word_to_check) == 0)
                            {
                                word_found_in_dict = true;
                                break;
                            }
                            current = &((*current)->next);
                        }

                        // if your word to check is not valid then revert the board and error out
                        if (!word_found_in_dict)
                        {
                            memcpy(sBoard->board, old_board,
                                   sBoard->rows * sBoard->cols * sizeof(char));
                            fprintf(fp, "Invalid command\n");
                            goto nextInput;
                        }
                        // reset the word to check after finding a full word
                        memset(word_to_check, 0, WORD_LIMIT + 1);
                    }
                    // if you did not find a space concat the next char to the word
                    else if (new_char_from_board != ' ')
                    {
                        strncat(word_to_check, &new_char_from_board, 1);
                    }
                    else
                    {
                        // make sure the word gets reset so it doesnt contain erroneous chars
                        memset(word_to_check, 0, WORD_LIMIT + 1);
                    }
                }
            }

            // performs the same purpose as above but checks inline with the placed word instead of cross-wise to insure that the word placed has not created invalid words
            char word_to_check[WORD_LIMIT + 1] = {};
            for (size_t j = 0; j < sBoard->rows; j++)
            {
                char new_char_from_board =
                    sBoard->board[(sBoard->cols * j) + col];
                // printf("new_char_from_board: %c\n", new_char_from_board);

                if ((new_char_from_board == ' ' || j == sBoard->rows - 1) &&
                    strlen(word_to_check) != 0 && strlen(word_to_check) != 1)
                {
                    if (j == sBoard->rows - 1)
                    {
                        strncat(word_to_check, &new_char_from_board, 1);
                    }
                    bool word_found_in_dict = false;

                    int len_to_check = 1;
                    Node **current = &(dict[len_to_check]->head);
                    while ((current != NULL && *current != NULL) || len_to_check <= WORD_LIMIT)
                    {
                        // cppcheck-suppress oppositeInnerCondition
                        if (current == NULL || *current == NULL)
                        {
                            current = &(dict[++len_to_check]->head);
                            continue;
                        }
                        // if (strcmp(word, "no") == 0 && strcmp(word_to_check, "on") == 0)
                        // {
                        //     printf("len_to_check: %d, current word: %s\n", len_to_check, (*current)->word);
                        // }

                        if (strcmp((*current)->word, word_to_check) == 0)
                        {
                            word_found_in_dict = true;
                            break;
                        }
                        current = &((*current)->next);
                    }

                    if (!word_found_in_dict)
                    {
                        memcpy(sBoard->board, old_board,
                               sBoard->rows * sBoard->cols * sizeof(char));
                        fprintf(fp, "Invalid command\n");
                        goto nextInput;
                    }
                    memset(word_to_check, 0, WORD_LIMIT + 1);
                }
                else if (new_char_from_board != ' ')
                {
                    strncat(word_to_check, &new_char_from_board, 1);
                }
                else
                {
                    memset(word_to_check, 0, WORD_LIMIT + 1);
                }
            }
        }        
        // checks if the command is board
        else if (strcmp(cmd, "board") == 0)
        {
            //creates a string to print out that the string form of the board will reside in
            char boardStr[(sBoard->rows + 2) * (sBoard->cols + 3) + 1];
            // sets the boardStr to 0s
            memset(boardStr, 0, (sBoard->rows + 2) * (sBoard->cols + 3) + 1);
            //gets the board in the string
            boardToString(sBoard, boardStr);
            //prints the board
            fprintf(fp, "%s", boardStr);
        }
        //else fails
        else
        {
            // fprintf(fp,
            //         "row: %d, col: %d, word: %s, strlen(word) + row: %d, "
            //         "sBoard->rows: %d, sBoard->cols: %d, strcmp(cmd, "
            //         "\"across\"): %d\n",
            //         row, col, word, strlen(word) + row, sBoard->rows,
            //         sBoard->cols, strcmp(cmd, "across"));
            fprintf(fp, "Invalid command\n");
        }

    // Prompt the user for the next command.
    nextInput:
        fprintf(fp, "cmd> ");
    }

    // Close the connection with this client.
    fclose(fp);
    return NULL;
}

int main(int argc, char *argv[])
{
    // Read into a hash map where the hash is the length of the word
    // all the words in the dictionary
    FILE *fwords = fopen("./words", "r");
    if (fwords == NULL)
    {
        perror("failed to open words file");
    }

    // makes dict: a hashmap where the words are hashed to the index of their string length and the value is a linked list of the words of that length
    char *word = malloc((WORD_LIMIT + 1) * sizeof(char));
    while (fscanf(fwords, "%26s", word) == 1)
    {
        int wordLen = strlen(word);
        if (dict[wordLen] == NULL)
        {
            dict[wordLen] = malloc(sizeof(List));
            dict[wordLen]->head = malloc(sizeof(Node));
            dict[wordLen]->head->next = NULL;
            dict[wordLen]->head->word = malloc(wordLen * sizeof(char));
            strcpy(dict[wordLen]->head->word, word);
        }
        else
        {
            Node *new_node = malloc(sizeof(Node));
            new_node->word = malloc(wordLen * sizeof(char));
            new_node->next = dict[wordLen]->head;
            strcpy(new_node->word, word);
            dict[wordLen]->head = new_node;
        }
    }
    free(word);

    // create the board this all resides in
    int rows = -1, cols = -1;
    struct scrabbleBoard *sBoard = malloc(sizeof(*sBoard));

    // Make sure server is run correctly
    if (argc != 3 || sscanf(argv[1], "%d", &rows) != 1 ||
        sscanf(argv[2], "%d", &cols) != 1 || rows <= 0 || cols <= 0)
        usage();
    else
    {
        // set up the board struct
        sBoard->rows = rows;
        sBoard->cols = cols;
        sBoard->board = malloc(rows * cols * sizeof(char) + 1);
        memset(sBoard->board, ' ', rows * cols * sizeof(char));
        sBoard->board[rows * cols] = '\0';
        // printf("char = %c\n", scrabbleBoard2D[1][1]);
    }

    // Prepare a description of server address criteria.
    struct addrinfo addrCriteria;
    memset(&addrCriteria, 0, sizeof(addrCriteria));
    addrCriteria.ai_family = AF_INET;
    addrCriteria.ai_flags = AI_PASSIVE;
    addrCriteria.ai_socktype = SOCK_STREAM;
    addrCriteria.ai_protocol = IPPROTO_TCP;

    // Lookup a list of matching addresses
    struct addrinfo *servAddr;
    if (getaddrinfo(NULL, PORT_NUMBER, &addrCriteria, &servAddr))
        fail("Can't get address info");

    // Try to just use the first one.
    if (servAddr == NULL)
        fail("Can't get address");

    // Create a TCP socket
    int servSock = socket(servAddr->ai_family, servAddr->ai_socktype,
                          servAddr->ai_protocol);
    if (servSock < 0)
        fail("Can't create socket");

    // Bind to the local address
    if (bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0)
        fail("Can't bind socket");

    // Tell the socket to listen for incoming connections.
    if (listen(servSock, 5) != 0)
        fail("Can't listen on socket");

    // Free address list allocated by getaddrinfo()
    freeaddrinfo(servAddr);

    // Fields for accepting a client connection.
    struct sockaddr_storage clntAddr; // Client address
    socklen_t clntAddrLen = sizeof(clntAddr);

    // make a struct to pass the args of the function in as
    args *arguments = malloc(sizeof(args));
    // make the cleint thread
    pthread_t client;
    // make the semaphor to lock access to accessing the board simultaneously
    sem_t lock;
    sem_init(&lock, 1, 1);

    while (true)
    {
        // Accept a client connection.
        int sock = accept(servSock, (struct sockaddr *)&clntAddr, &clntAddrLen);
        arguments->socket = sock;
        arguments->sBoard = sBoard;

        // locks the board
        sem_wait(&lock);
        if (pthread_create(&client, NULL, handleClient, (void *)arguments) != 0)
        {
            perror("cant make client thread");
        }
        // detaches the from the client
        pthread_detach(client);
        // unlocks the board
        sem_post(&lock);
    }

    // Stop accepting client connections (never reached).
    close(servSock);

    free(sBoard->board);
    free(sBoard);
    free(arguments);
    for (size_t i = 0; i < WORD_LIMIT; i++)
    {
        while (dict[i]->head != NULL)
        {
            Node *temp = dict[i]->head;
            dict[i]->head = dict[i]->head->next;
            free(temp->word);
            free(temp);
        }
        free(dict[i]->head);
        free(dict[i]);
    }

    return 0;
}
