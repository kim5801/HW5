/**
 * @file scrabbleServer.c
 * @author Eduardo Martinez (elmarti4)
 * @brief This program creates a server that allows one or more
 *        clients to edit a scrabble board simultaneously.
 * 
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26140"

/** Maximum word length */
#define WORD_LIMIT 26

/** Value by which a memory allocated variable is multiplicatively increased */
#define DOUBLE_LIST 2

// Monitor to prevent undefined behavior
pthread_mutex_t mon;

// Board used to contain Scrabble data
char **boardList;

// Rows of boardlist
int rows;

// Columns of boardList
int columns;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/**
 * @brief Reads a line from a file input. Uses
 *        a dynamically expanding string to read any line.
 *        This is a slightly modified line reader I used 
 *        for my CSC 230 projects throughout the class.
 * 
 * @param fp File pointer that line is read from
 * @return the fully read line as a string
 */
char *readLine( FILE *fp )
{
    int capacity = 1;
    int ch;
    if ( ( ch = fgetc( fp ) ) == EOF ) {
        return NULL;
    }
    char *line = (char *)malloc( capacity * sizeof( char ) ) ;
    int len = 0;
    while ( ch != '\n' ) {
        if ( ( len + 1 ) >= capacity ) {
            capacity *= DOUBLE_LIST;
            line = (char *)realloc( line, capacity * sizeof( char ) );
        }
        line[ len++ ] = ch;
        ch = getc( fp );
    }
    if ( len > 1024 ) {
        return NULL;
    }
    line[ len ] = '\0';
    return line;    
}

/**
 * @brief parseCommand splits the initial command String into various Strings for a 2D array
 *        Taken from homework 0
 * 
 * @param line Initial single String
 * @param words 2D array containing the words
 * @return the amount of words discovered 
 */
int parseCommand( char *line, char *words[] ) {
    int length = strlen( line );
    int wordCount = 0;
    int len = 0;
    int capacity = 1;
    bool whiteSpace = false;
    words[ wordCount ] = (char *) malloc( capacity * sizeof( char ) ) ;
    for( int i = 0; i < length; i++ ) {
        words[ wordCount ][ len++ ] = line[ i ];
        if ( ( len + 1 ) >= capacity ) {
            capacity *= DOUBLE_LIST;
            words[ wordCount ] = (char *) realloc( words[ wordCount ], capacity * sizeof( char ) );
        }
        if ( line[ i ] == ' ' && whiteSpace == false ) {
            words[ wordCount ][ len - 1 ] = '\0';
            if ( len < capacity ) {
              for ( int i = len; i < capacity; i++ ) {
                words[ wordCount ][ i ] = '\0';
              }
            }
            whiteSpace = true;
            len = 0;
            capacity = 1;
            wordCount++;
            words[ wordCount ] = (char *) malloc( capacity * sizeof( char ) ) ;
        }
        if ( line[ i ] != ' ' ) {
            whiteSpace = false;
        }
    }
    if ( len < capacity ) {
      for ( int i = len; i < capacity; i++ ) {
        words[ wordCount ][ i ] = '\0';
      }
    }
    return wordCount + 1;
}

/**
 * @brief Print a valid word across the scrabble board
 * 
 * @param row Chosen row
 * @param col Chosen columns to be printed across
 * @param word Provided word
 */
void across( int row, int col, char *word ) {
  for ( int i = 0; i < strlen( word ); i++ ) {
    boardList[ row ][ col + i ] = word[ i ];
  }
}

/**
 * @brief Print a valid word down the scrabble board
 * 
 * @param row Chosen rows to be printed down
 * @param col Chosen column
 * @param word Provided word
 */
void down( int row, int col, char *word ) {
  for ( int i = 0; i < strlen( word ); i++ ) {
    boardList[ i + row ][ col ] = word[ i ];
  }
}

/**
 * @brief Convert a provided string into an integer
 * 
 * @param str Provided string
 * @return String turned Integer
 */
int convertStrToInt( char* str ) {;
  int num = 0;
  int n = strlen( str );
  for (int i = 0; i < n; i++) {
    if ( str[ i ] < '0' || str[ i ] > '9' ) {
      return -1;
    }
    num = num * 10 + ( str[ i ] - '0' );
  }
  return num;
}

/** 
 * @brief Handle a client connection, close it when we're done. 
 * 
 * @param socket Socket being used by client
 */
void *handleClient( void *socket ) {
  int sock = *((int*) socket);
  free( socket );
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  int wordCount = NULL;

  while ( true ) {
    // Grab a command from the provided file
    char *cmd = readLine( fp );
    // Check if a valid cmd was returned
    if ( cmd != NULL ) {
      char *words[ 5 ];
      wordCount = parseCommand( cmd, words );
      if ( strcmp( words[ 0 ], "quit" ) == 0 ) {
        free( cmd );
        for ( int i = 0; i < wordCount; i++) {
          free( words[ i ] );
        }
        break;
      }

      // Begin checking if a valid command has been given
      // Valid Commands: across, down, board, and quit
      if ( strcmp( words[ 0 ], "across" ) == 0 && wordCount == 4 ) {
        // Get the row and column values provided by the command
        int rowScrabble = convertStrToInt( words[ 1 ] );
        int colScrabble = convertStrToInt( words[ 2 ] );
        
        // Get the length of the scrabble word
        int strLen = strlen( words[ 3 ] );

        // Go through a series of tests
        if ( strLen > WORD_LIMIT ) {
          fprintf( fp, "Invalid command11\n" );
        } else if ( rowScrabble == -1 || colScrabble == -1 ) {
          fprintf( fp, "Invalid command12\n" );
        } else if ( rowScrabble > rows || rowScrabble < 0 ) {
          fprintf( fp, "Invalid command13\n" );
        } else if ( colScrabble + strLen > columns || colScrabble < 0 ) {
          fprintf( fp, "Invalid command14\n" );
        } else {
          // Check that the word does not write over existing letters, or contains invalid values          
          bool fail = false;

          pthread_mutex_lock( &mon );

          for ( int i = 0; i < strLen; i++ ) {
            if ( boardList[ rowScrabble ][ i + colScrabble ] != ' ' && boardList[ rowScrabble ][ i + colScrabble ] != words[ 3 ][ i ] ) {
              fail = true;
              break;
            }
            if ( words[ 3 ][ i ] < 'a' || 'z' < words[ 3 ][ i ] ) {
              fail = true;
              break;
            }
          }
          if ( fail ) {
            fprintf( fp, "Invalid command\n" );
          } else {
            across( rowScrabble, colScrabble, words[ 3 ] );
          }
        }
      } else if ( strcmp( words[ 0 ], "down" ) == 0 && wordCount == 4 ) {
        // Get the row and column values provided by the command
        int rowScrabble = convertStrToInt( words[ 1 ] );
        int colScrabble = convertStrToInt( words[ 2 ] );

        // Get the length of the scrabble word
        int strLen = strlen( words[ 3 ] );

        // Go through a series of tests
        if ( strLen > WORD_LIMIT ) {
          fprintf( fp, "Invalid command21\n" );
        } else if ( rowScrabble == -1 || colScrabble == -1 ) {
          fprintf( fp, "Invalid command22\n" );
        } else if ( rowScrabble + strLen > rows || rowScrabble < 0 ) {
          fprintf( fp, "Invalid command23\n" );
        } else if ( colScrabble > columns || colScrabble < 0 ) {
          fprintf( fp, "Invalid command24\n" );
        } else {
          // Check that the word does not write over existing letters, or contains invalid values
          bool fail = false;

          pthread_mutex_lock( &mon );

          for ( int i = 0; i < strLen; i++ ) {
            if ( boardList[ i + rowScrabble ][ colScrabble ] != ' ' && boardList[ i + rowScrabble ][ colScrabble ] != words[ 3 ][ i ] ) {
              fail = true;
              break;
            }
            if ( words[ 3 ][ i ] < 'a' || 'z' < words[ 3 ][ i ] ) {
              fail = true;
              break;
            }
          }
          if ( fail ) {
            fprintf( fp, "Invalid command\n" );
          } else {
            down( rowScrabble, colScrabble, words[ 3 ] );
          }
        }
      } else if ( strcmp( words[ 0 ], "board" ) == 0 && wordCount == 1 ) {
        pthread_mutex_lock( &mon );

        // Print current board
        fprintf( fp, "+" );
        for ( int i = 0; i < columns; i++ ) {
          fprintf( fp, "-" );
        }
        fprintf( fp, "+\n" );
        for ( int i = 0; i < rows; i++ ) {
          fprintf( fp, "|" );
          for ( int j = 0; j < columns; j++ ) {
            fprintf( fp, "%c", boardList[ i ][ j ] );
          }
          fprintf( fp, "|\n" );
        }
        fprintf( fp, "+" );
        for ( int i = 0; i < columns; i++ ) {
          fprintf( fp, "-" );
        }
        fprintf( fp, "+\n" );
      } else {
        fprintf( fp, "Invalid command\n" );
      }

      pthread_mutex_unlock( &mon );

      // Just echo the command back to the client for now.
      // fprintf( fp, "%s\n", cmd );
      // Free word parser
      for ( int i = 0; i < wordCount; i++) {
        free( words[ i ] );
      }

      // Prompt the user for the next command.
      fprintf( fp, "cmd> " );
    }
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

/**
 * @brief Starting point for the program is involved in the creation of servers and clients
 * 
 * @param argc Amount of arguments provided
 * @param argv Arguments provided
 */
int main( int argc, char *argv[] ) {
  // Check if parameters are valid
  if ( argc != 3 ) {
    fail( "usage: scrabbleServer <rows> <cols>" );
  }
  rows = convertStrToInt( argv[ 1 ] );
  columns = convertStrToInt( argv[ 2 ] );
  if ( rows == ' ' || columns == ' ' ) {
    fail( "usage: scrabbleServer <rows> <cols>" );
  }
  if ( rows <= 0 || columns <= 0 ) {
    fail( "usage: scrabbleServer <rows> <cols>" );
  }

  pthread_mutex_init( &mon, NULL );

  // Create board
  boardList = (char **) malloc( rows * sizeof( char * ) );
  for ( int i = 0; i < rows; i++ ) {
    boardList[ i ] = (char *) malloc( columns * sizeof( char ) );
    for ( int j = 0; j < columns; j++ ) {
      boardList[ i ][ j ] = ' ';
    }
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  pthread_t tid;

  while ( true  ) {
    // Accept a client connection.
    int *sock = (int *) malloc( sizeof( int ) );
    *sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_create( &tid, NULL, handleClient, sock );
    pthread_detach( tid );

    // handleClient( sock );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
