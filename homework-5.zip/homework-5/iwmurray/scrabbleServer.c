/**
 * scrabbleServer.c
 * Homework 5 - Problem 2 - CSC 246
 * @author Ian Murray (iwmurray)
 */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Line feed */
#define LF 10

/** Port number used by my server */
#define PORT_NUMBER "26290"

/** Maximum word length */
#define WORD_LIMIT 26

/** Command length limit */
#define CMD_LIMIT 42

/** Struct that holds the game state, including size */
typedef struct game_state {
    /** The game board itself, as 2D array of on and off */
    char *board;

    /** The size of the board */
    int rows;
    int cols;
} GameState;

/** Semaphore to protect command execuction. */
sem_t commandLock;

/** Game state (global) */
struct game_state *state;


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/**
 * handle a command to place text on the command board
 * @param fp File pointer to network socket
 * @param down Print down if true, otherwise across
 * @return if invalid command
 */
bool placementCommandHandler(FILE *fp, bool down) {
  // Finish parsing command
  char *rowStr = strtok(NULL, " ");
  if(rowStr == NULL)
    return true;

  char *colStr = strtok(NULL, " ");
  if(colStr == NULL)
    return true;

  char *word = strtok(NULL, " ");
  if(word == NULL)
    return true;

  // Validate word is lowercase
  char *ch = word;
  while( *ch != '\0')
    if( islower(*ch) )
      ch++;
    else
      return true;

  // Convert and validate starting position
  int row = atoi(rowStr);
  int col = atoi(colStr);

  if(row < 0 || col < 0 || row >= state->rows || col >= state->cols)
    return true;

  // Validate end of word is on board
  int len = strlen(word);
  if(down) {
    if(row + len - 1 >= state->rows) {
      return true;
    }
  } else {
    if(col + len - 1 >= state->cols) {
      return true;
    }
  }

  // Set deltas for either across/down for code readablity
  int row_del = 0;
  int col_del = 0;

  if(down)
    row_del = 1;
  else
    col_del = 1;

  // Dry run to check we won't override any letters
  for (size_t i = 0; i < len; i++)
  {
    int r = row + (i * row_del);
    int c = col + (i * col_del);

    char cur_char = state->board[r * state->cols + c];

    if(cur_char != ' ' && cur_char != word[i])
      return true;
  }

  // Place letters on board
  for (size_t i = 0; i < len; i++)
  {
    int r = row + (i * row_del);
    int c = col + (i * col_del);

    state->board[r * state->cols + c] = word[i];
  }

  return false;
}


/** handle a client connection, close it when we're done. */
void *handleClient( void* sockarg ) {
  int sock = *((int*)sockarg);

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );

  // Main REPL loop
  bool run_repl = true;
  while( run_repl ) {

    // Prompt the user for a command.
    fprintf( fp, "cmd> " );

    // Read and parse command
    char cmd[ CMD_LIMIT + 1 ];
    int chars_read = 0;
    bool invalid_command = false;
    
    // Validate input loop
    while( true ) {
      char char_read = fgetc(fp);

      if(char_read == EOF || char_read == LF)
        break;
      
      // Prevent buffer overflow
      if(chars_read >= CMD_LIMIT) {
        invalid_command = true;
        break;
      }

      // Else add it too the string
      cmd[chars_read] = char_read;
      chars_read++;
    }

    // Write \0 to end of command
    cmd[chars_read] = '\0';

    // Enter critical section
    sem_wait( &commandLock );

    // Get first token of command string
    char *token = strtok(cmd, " ");

    if(strncmp(token, "across", CMD_LIMIT) == 0) {
      // Across command
      invalid_command = placementCommandHandler(fp, false);
    } else if(strncmp(token, "down", CMD_LIMIT) == 0) {
      // Down command
      invalid_command = placementCommandHandler(fp, true);
    } else if(strncmp(token, "board", CMD_LIMIT) == 0) {
      /*** Board command ***/

      // Print header
      fprintf( fp, "+" );
      for (size_t j = 0; j < state->cols; j++) {
        fprintf( fp, "-" );
      }
      fprintf( fp, "+\n" );

      // Print board section
      for (size_t i = 0; i < state->rows; i++) {
        fprintf( fp, "|" );
        for (size_t j = 0; j < state->cols; j++) {
          fprintf( fp, "%c", state->board[i * state->cols + j]);
        }
        fprintf( fp, "|\n" );
      }

      // Print footer
      fprintf( fp, "+" );
      for (size_t j = 0; j < state->cols; j++) {
        fprintf( fp, "-" );
      }
      fprintf( fp, "+\n" );

    } else if(strncmp(token, "quit", CMD_LIMIT) == 0) {
      // Quit command
      run_repl = false;
    } else {
      invalid_command = true;
    }

    // Exit critcal section
    sem_post( &commandLock );

    // Print if invalid command
    if( invalid_command )
      fprintf( fp, "Invalid command\n" );

    // Print spacing
    fprintf( fp, "\n" );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Parse arguments
  if(argc != 3)
    fail( "usage: scrabbleServer <rows> <cols>" );

  int rows = atoi(argv[1]);
  int cols = atoi(argv[2]);

  if( rows <= 0 || cols <= 0)
    fail( "usage: scrabbleServer <rows> <cols>" );

  // Initalize sempahores
  sem_init( &commandLock, 0, 1 );

  // Create state and board
  state = (struct game_state *) malloc( sizeof( struct game_state ) );
  state->board = (char *)malloc( rows * cols * sizeof(char) );
  state->rows = rows;
  state->cols = cols;

  // Clear board
  for (size_t i = 0; i < rows; i++)
  {
    for (size_t j = 0; j < cols; j++)
    {
      state->board[i * cols + j] = ' ';
    }
  }
  
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    // Create thread
    pthread_t thread;
    if ( pthread_create( &thread, NULL, handleClient, &sock ) != 0 ) 
      fail( "Can't create a child thread\n" );

    // and detach it
    if ( pthread_detach( thread ) != 0 ) 
      fail( "Could not detach child thread\n" );
  }

  // Free board and state
  free(state->board);
  free(state);

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
