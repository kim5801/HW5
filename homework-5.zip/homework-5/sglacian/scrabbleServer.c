/**
 * Assignment 5, program 2
 * @file scrabbleServer.c
 * @author Sophia Laciano
 * port number: 26048
 */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26048"

/** Maximum word length */
#define WORD_LIMIT 26

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

char **board;
int rows;
int columns;
sem_t lock;

/** handle a client connection, close it when we're done. */
void *handleClient( void *arg ) {    // was: int sock
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int sock = *((int*)arg);
  FILE *fp = fdopen( sock, "a+" );  
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );
  
  char command[ 11 ];
  int r;
  int c;
  char word[ 30 ];
  char extra[ 10 ];

  // Temporary values for parsing commands.
  char cmd[ 100 ];
  while ( fgets( cmd, 100, fp ) != NULL &&
          strcmp( cmd, "quit" ) != 0 ) {
    
    // Get the first command 
    int total = sscanf( cmd, "%s %d %d %s %s", command, &r, &c, word, extra );
    int wordLength = strlen( word );
    bool invalid = false;
    
    if ( strlen( extra ) != 0 ) {
      // there is extra output, this is an invalid command
      fprintf( fp, "Invalid command\n" );
    }
    else if ( strcmp( command, "across" ) == 0 && total == 4 && wordLength <= 26 ) {
      // wait for lock to be ready.
      sem_wait( &lock );
      for ( int i = 0; i < wordLength; i++ ) {
        if ( !islower( word[ i ] ) ) {
          // invalid since it's not a lowercase letter in the word.
          invalid = true;
          break;
        }
      }
      if ( invalid ) {
        fprintf( fp, "Invalid command\n" );
      }
      else if ( r < 0 || r > rows ) {
        fprintf( fp, "Invalid command\n" );
      }
      else if ( c < 0 || c > columns ) {
        fprintf( fp, "Invalid command\n" );
      }
      else if ( c + wordLength - 1 > columns ) {
        // the end of the word will be beyond the edge of the board
        fprintf( fp, "Invalid command\n" );
      }
      else {
        int lineValid = true;
        for ( int i = c; i < c + wordLength; i++ ) {
          if ( isspace( board[ r ][ i ] ) != 0  || 
               board[ r ][ i ] == word[ i - c ] ) {
            // do nothing, this is valid
          }
          else {
            lineValid = false;
            break;
          }
        }
        
        if ( !lineValid ) {
          fprintf( fp, "Invalid command\n" );
        }
        else {
          for ( int i = c; i < c + wordLength; i++ ) {
            board[ r ][ i ] = word[ i - c ];
          }
        }
      }
      // release the lock.
      sem_post( &lock );
    }
    else if ( strcmp( command, "down" ) == 0 && total == 4 && wordLength <= 26 ) {
      // wait for the lock to be ready.
      sem_wait( &lock );
      for ( int i = 0; i < wordLength; i++ ) {
        if ( !islower( word[ i ] ) ) {
          // invalid since it's not a lowercase letter in the word.
          invalid = true;
          break;
        }
      }
      if ( invalid ) {
        fprintf( fp, "Invalid command\n" );
      }
      else if ( r < 0 || r > rows ) {
        fprintf( fp, "Invalid command\n" );
      }
      else if ( c < 0 || c > columns ) {
        fprintf( fp, "Invalid command\n" );
      }
      else if ( r + wordLength - 1 > rows ) {
        // the end of the word will be beyond the edge of the board
        fprintf( fp, "Invalid command\n" );
      }
      else {
        int lineValid = true;
        for ( int i = r; i < r + wordLength; i++ ) {
          if ( isspace( board[ i ][ c ] ) != 0  || 
               board[ i ][ c ] == word[ i - r ] ) {
            // do nothing, this is valid
          }
          else {
            lineValid = false;
            break;
          }
        }
        
        if ( !lineValid ) {
          fprintf( fp, "Invalid command\n" );
        }
        else {
          for ( int i = r; i < r + wordLength; i++ ) {
            board[ i ][ c ] = word[ i - r ];
          }
        }
      }
      // release the lock.
      sem_post( &lock );
    }
    else if ( strcmp( command, "board" ) == 0 && total == 1 ) {
      // wait for the lock to be ready.
      sem_wait( &lock );
      
      fprintf( fp, "+");
      for( int i = 0; i < columns; i++ ) {
        fprintf( fp, "-");
      }
      fprintf( fp, "+\n");
      for (int j = 0; j < rows; j++ ) {
        fprintf( fp, "|");
        for ( int i = 0; i < columns; i++ ) {
          fprintf( fp, "%c", board[ j ][ i ] );
        }
        fprintf( fp, "|\n");
      }
      fprintf( fp, "+");
      for( int i = 0; i < columns; i++ ) {
        fprintf( fp, "-");
      }
      fprintf( fp, "+\n");
      // release the lock.
      sem_post( &lock );
    }
    else if ( strcmp( command, "quit" ) == 0 && total == 1 ) {
      break;
    }
    else {
        // else it is an invalid command
        fprintf( fp, "Invalid command\n" );
    }
    
    
    /* // Just echo the command back to the client for now.
    fprintf( fp, "%s\n", cmd );*/

    //Prompt the user for the next command.
    fprintf( fp, "cmd> " );
    
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);
  
  if( isdigit( argv[ 1 ][ 0 ] ) == 0 || isdigit( argv[ 2 ][ 0 ] ) == 0 ) {
    printf("usage: scrabbleServer <rows> <cols>\n");
    exit( EXIT_FAILURE );
  }
  else if ( argv[ 1 ][ 0 ] - 48 < 0 || argv[ 2 ] - 48 < 0 ) {
    printf("usage: scrabbleServer <rows> <cols>\n");
    exit( EXIT_FAILURE );
  }
  rows =  atoi( argv[ 1 ] );
  columns =  atoi( argv[ 2 ] );
  board = (char **)malloc( rows * sizeof( char * ) );
  for ( int i = 0; i < rows; i++ ) {
    board[ i ] = (char *)malloc( columns * sizeof( char ) );
  }
  
  for (int i = 0; i < rows; i++ ) {
    for ( int j = 0; j < columns; j++ ) {
      board[ i ][ j ] = ' ';
    }
  }
  
  sem_init( &lock, 0, 1 );
  
  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_t multThreads;
    pthread_create( &multThreads, NULL, handleClient, &sock );
    pthread_detach( multThreads );
  }
    
  // free the board
  for ( int i = 0; i < rows; i++ ) {
    free( board[ i ] );
  }
  free(board);
  
  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
