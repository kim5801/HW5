/**
  @file scrabbleServer.c
  @author Mitthu Tiwari
  Allows for client programs and users to interface with a scrabble board using TCP network communication
  Code for dynamically allocating memory for scrabble board is taken from code for allocating 2D arrays provided 
  on slide 17 of lecture 13 from CSC 230, which was created and presented by Dr. Sturgill in Spring 2022
*/

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by server */
#define PORT_NUMBER "26192"

/** Maximum word length */
#define WORD_LIMIT 26

/** Number of rows in board */
int rows = 0;

/** Number of columns in board */
int cols = 0;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** 
  Message to print when invalid command line arguments are provided 
*/

static void usage() {
  printf("usage: scrabbleServer <rows> <cols>");
  exit(1);
}

/**
  Method used for comparing user-provided command with across command option
*/

bool cmdComp(int cmdLength, char *arr1, char *arr2) {
  bool match = false;
  int matchCount = 0;

  for (int i = 0; i < cmdLength; i++) {
    if (arr1[i] === arr2[i]) {
      matchCount++;
    }
  }

  if (matchCount == cmdLength) {
    match = true;
  }

  return match;
}

/** handle a client connection, close it when we're done. */
void *handleClient( int sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );

  char (*board)[cols] = (char (*)[cols]) malloc(rows * cols * sizeof(char));
  bool empty = true;
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 + WORD_LIMIT + 1 ];
  while ( fscanf( fp, "%37s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    int acrossLength = strlen("across");
    int downLength = strlen("down");
    char enteredCommand[acrossLength];

    for (int i = 0; i < acrossLength; i++) {
      enteredCommand[i] = cmd[i];
    }

    if (cmdComp(acrossLength, enteredCommand, "across")) {
      if ((cmd[7] < 0 || cmd[7] >= rows) || (cmd[9] < 0 || cmd[9] >= cols)) {
        fprintf("Invalid command\n");
      } else if (!(cmd[11] >= 'a' && cmd[11] <= 'z')) {
        fprintf("Invalid command\n");
      } else {
        int wordCharCount = 0;
        char word[WORD_LIMIT];

        for (int i = 11; i < 37; i++) {
          if (cmd[i] >= 'a' && cmd[i] <= 'z') {
            wordCharCount++;
            word[i - 11] = cmd[i];
          }
        }

        if (wordCharCount < cols) {
          for (int i = cmd[9]; i < wordCharCount; i++) {
            board[cmd[7]][i] = word[i];
          }

          empty = false;
        }
      }
    } else if (cmdComp(downLength, enteredCommand, "down")) {
      if ((cmd[7] < 0 || cmd[7] >= rows) || (cmd[9] < 0 || cmd[9] >= cols)) {
        fprintf("Invalid command\n");
      } else if (!(cmd[11] >= 'a' && cmd[11] <= 'z')) {
        fprintf("Invalid command\n");
      } else {
        int wordCharCount = 0;
        char word[WORD_LIMIT];

        for (int i = 11; i < 37; i++) {
          if (cmd[i] >= 'a' && cmd[i] <= 'z') {
            wordCharCount++;
            word[i - 11] = cmd[i];
          }
        }

        if (wordCharCount < rows) {
          for (int i = cmd[7]; i < wordCharCount; i++) {
            board[i][cmd[9]] = word[i];
          }

          empty = false;
        }
      }
    } else if (strcmp(cmd, "board") == 0) {
      fprintf('+');

      for (int i = 0; i < cols; i++) {
        fprintf('-');
      }

      fprintf('+\n');

      for (int i = 0; i < rows; i++) {
        fprintf('|');

        for (int j = 0; j < cols; j++) {
          fprintf(board[i][j]);
        }

        fprintf('|\n');
      }

      fprintf('+');

      for (int i = 0; i < cols; i++) {
        fprintf('-');
      }

      fprintf('+\n');
    } else {
      fprintf("Invalid command");
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  free(board);

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  if (argc == 0 || argc > 3) {
    usage();
  }

  if (*(argv[1]) <= 0 || *(argv[2]) <= 0) {
    usage();
  }

  rows = *(argv[1]);
  cols = *(argv[2]);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    handleClient( sock );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
