/**
 * @author Evan Jonson (ecjonson)
 * @author CSC 246
 * @file scrabbleServer.c
 * My scrabble board server! Attempts to start a server that holds the current state of
 * a scrabble board. Each time a client connects, a new thread is created to handle its work.
 * The client can issue commands to place words on the board and to view the current state.
 * If a dictionary at DICTIONARY_PAPTH exists, then each word created on the board must be
 * in the dictionary. Otherwise words must lowercase and at most WORD_LIMIT characters long. The port
 * number is list at PORT_NUMBER. A monitor is used to prevent race conditions when accessing the board.
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26380"

/** Maximum word length */
#define WORD_LIMIT 26

/** Ascii difference for converting between char and int */
#define ASCII_DIFF 48

/** The rank for decimal */
#define RANK 10

/** The smallest valid commad size */
#define MIN_CAP 5

/** The maximum length of a valid word */
#define MAX_LEN 26

/** The dictionary path */
#define DICTIONARY_PATH "words"

// create and initialize the monitor
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;

/** 
 * The Board struct! The state of the board can be accessed
 * as a 2d array of characters. It is stored as a pointer to a
 * char pointer, which is allocated as an array of dynamically
 * allocated strings, each of which represents a row in the board.
 */
typedef struct ScrabbleBoardStateStruct {
    int rows; // the number of rows
    int cols; // the number of collumns
    char **state; // board state, can be used as a 2d array of characters
} Board;

/** the board! */
static Board *board;

/** The Args struct! Used for passing arguments to thread functions. */
typedef struct ThreadArgsStruct {
    int sock; // the socket number
} Args;

/** The Type enum! Represents different client command types. */
typedef enum {QUIT, BOARD, ACROSS, DOWN, INVALID} Type;

/** The Command struct! Stores a client command. */
typedef struct CommandStruct {
    Type type; // the commands type {QUIT, BOARD, ACROSS, DOWN, INVALID}
    int row; // the commands row
    int col; // the commands collumn
    char *word; // the commands word
} Command;

/** The Words struct! Stores the dictionary. */
typedef struct DictionaryStruct {
    char **list; // the dictionary list, can be used as an array of strings
    int size; // the length of the dictionary list
} Words;

/** the dictionary of valid words */
static Words *dictionary;

/**
 * Print out an error message and exit.
 * @param message The message to print.
 */
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( EXIT_FAILURE );
}

/**
 * Gets the next word from the fiven file pointer. Returns a
 * dynamically allocated and minimized string of characters. Can
 * be used to eat the newline character or not.
 * @param fp The file pointer to read from.
 * @param eatLine Eat the new line character if found?
 * @return a dynamically allocated string of characters, or empty string, or NULL.
 */
static char *getWord( FILE *fp, const bool eatLine ) {

    char c;
    int cap = MIN_CAP, len = 0;
    char *word = (char *)malloc( cap * sizeof( char ) );

    // eat whitespace
    fscanf( fp, " " );

    // get the word
    while ( (c = fgetc( fp )) != EOF && !isspace( c ) ) {

        // check capacity
        if ( len + 1 == cap )
            word = (char *)realloc( word, (cap *= 2) * sizeof( char ) );

        word[ len++ ] = c;
    }

    // return NULL on EOF in eatLine mode
    if ( eatLine ) {
        if ( len == 0 ) {
            free( word );
            return NULL;
        }
    }

    // preserve the new line character
    else if ( c == '\n' )
        ungetc( c, fp );

    // end of file
    else if ( c == EOF )
        return NULL;

    // terminate the word
    word[ len ] = '\0';

    // minimize word memory consumption
    word = (char *)realloc( word, (len + 1) * sizeof( char ) );

    return word;
}

/**
 * Eat the remainder of the line in the given file pointer.
 * @param fp The file pointer to read from.
 * @return True if any characters were consumed.
 */
static bool eatLine( FILE *fp ) {

    char c;
    bool ate = false;

    // eat characters until EOF or newline
    while ( (c = fgetc( fp )) != EOF && c != '\n' ) {

        // did i eat characters?
        if ( isspace( c ) != 0 )
            ate = true;
    }

    return ate;
}

/**
 * Converts a string of digits to an integer. Updates the contents
 * of the given int with the result if successsful. The result must
 * be greater than the given lower bound.
 * @param s The string to convert.
 * @param lb The given lower bound. The result must be greater than this.
 * @param d The location to put the results.
 * @return False if successful. FALSE IF SUCCESSFUL.
 */
static bool strToInt( char const *s, const int lb, int *d ) {

    // oops NULL
    if ( s == NULL )
        return true;

    int total = 0;
    int rank = 1;
    int len = strlen( s ) - 1;

    // oops too short
    if ( len < 0 )
        return true;

    // convert the string
    for ( int i = len; i >= 0; --i ) {

        // oops not a digit
        if ( !isdigit( s[ i ] ) )
            return true;

        // convert
        total += (s[ i ] - ASCII_DIFF) * rank;

        // increase the rank
        rank *= RANK;
    }

    // oops too small
    if ( total < lb )
        return true;

    // put the results
    *d = total;

    return false;
}

/**
 * Gets a user command from the given file pointer. Creates
 * a Command struct with the results. Uses getWord() and eatLine()
 * to consume a line of input.
 * @param fp The file pointer to read from.
 * @return A command struct with a new command.
 */
static Command *getCommand( FILE *fp ) {

    // create a command struct
    Command *cmd = (Command *)malloc( sizeof( Command ) );

    // get the command type
    char *type = getWord( fp, false ); // temp
    char *row = NULL; // temp
    char *col = NULL; // temp
    char *word; // not temporary!

    // quit command or EOF
    if ( type == NULL || strcmp( "quit", type ) == 0 )
        cmd->type = QUIT;

    // board command
    else if ( strcmp( "board", type ) == 0 )
        cmd->type = BOARD;

    // across & down commands
    else if ( strcmp( "across", type ) == 0 || strcmp( "down", type ) == 0 ) {

        // set the type
        cmd->type = type[ 0 ] == 'a' ? ACROSS : DOWN;

        // get the row, validate and set
        if ( (row = getWord( fp, false )) == NULL || strToInt( row, 0, &cmd->row ) )
            cmd->type = INVALID;

        // get the collumn, validate and set
        else if ( (col = getWord( fp, false )) == NULL || strToInt( col, 0, &cmd->col ) )
            cmd->type = INVALID;

        // get the scrabble word
        else if ( (word = getWord( fp, false )) == NULL )
            cmd->type = INVALID;

        // final checks
        else {
            // check for lower case letters
            int i;
            for ( i = 0; word[ i ]; ++i ) {
                if ( !islower( word[ i ] ) ) {
                    cmd->type = INVALID;
                    break;
                }
            }

            // check word length
            if ( i > MAX_LEN )
                cmd->type = INVALID;
        }

        cmd->word = word;
    }

    // invalid command type
    else
        cmd->type = INVALID;

    // check for extra input
    if ( eatLine( fp ) )
        cmd->type = INVALID;

    // free the temp char pointers
    free( type );
    free( row );
    free( col );

    return cmd;
}

/**
 * Print the board with a border.
 * @param fp The file pointer to print to.
 */
static void printBoard( FILE *fp ) {

    // print the top of the box
    fprintf( fp, "+" );
    for ( int i = 0; i < board->cols; ++i )
        fprintf( fp, "-" );
    fprintf( fp, "+\n" );

    // print the board state
    for ( int r = 0; r < board->rows; ++r ) {

        // left side of the box
        fprintf( fp, "|" );

        // the board state
        for ( int c = 0; c < board->cols; ++c )
            fprintf( fp, "%c", board->state[r][c] );

        // right side of the box
        fprintf( fp, "|\n" );
    }

    // print the bottom of the box
    fprintf( fp, "+" );
    for ( int i = 0; i < board->cols; ++i )
        fprintf( fp, "-" );
    fprintf( fp, "+\n" );
}

/**
 * Binary Search! Adapted from an algorithm provided by Dr. King, CSC 316.
 * I changed a few things to work better in C. Searches the dictionary for the key.
 * @param key The key to search for.
 * @param low The current lower bound.
 * @param high The current upper bound.
 * @return The current result.
 */
static int binarySearch( char const *key, int low, int high ) {

    // current range
    int n = high - low;

    // base case, whole list searched
    if ( n >= 0 ) {

        // mid element
        int mid = (n / 2) + low;

        // compare against mid element
        int result = strcmp( dictionary->list[ mid ], key );

        // found!
        if ( result == 0 )
            return 1;

        // search lower
        else if ( result > 0 )
            return binarySearch( key, low, mid - 1 );

        // search higher
        else
            return binarySearch( key, mid + 1, high );
    }

    // not found
    return 0;
}

/**
 * Searches the dictionary for the prvoded string. Uses
 * a binary search helper function.
 * @param s The string to search for.
 * @return True if found.
 */
static bool search( char const *s ) {

    return binarySearch( s, 0, dictionary->size - 1 ) == 1;
}

/**
 * Checks the entire board for valid words according to the dictionary.
 * @return True if all words on the board are in the dictionary.
 */
static bool checkBoard() {

    char across[ board->cols ];
    char down[ board->rows ];
    int a = 0;
    int d = 0;

    // across, check each possible word horizontally
    for ( int r = 0; r < board->rows; ++r ) {
        for ( int c = 0; c < board->cols; ++c ) {
            
            // reached a new segment
            if ( board->state[ r ][ c ] == ' ' ) {

                // do we have a word to check?
                if ( a > 0 ) {
                    across[ a ] = '\0';

                    // check the word
                    if ( !search( across ) )
                        return false;
                }
                a = 0;
            }

            // add the letter to the word we're constructing
            else
                across[ a++ ] = board->state[ r ][ c ];
        }

        // finished the collumn, do we have a word to check?
        if ( a > 0 ) {
            across[ a ] = '\0';

            // check the word
            if ( !search( across ) )
                return false;
        }
        a = 0;
    }

    // down, check each possible word vertically
    for ( int c = 0; c < board->cols; ++c ) {
        for ( int r = 0; r < board->rows; ++r ) {

            // reached a new segment
            if ( board->state[ r ][ c ] == ' ' ) {

                // do we have a word to check?
                if ( d > 0 ) {
                    down[ d ] = '\0';

                    // check the word
                    if ( !search( down ) )
                        return false;
                }
                d = 0;
            }

            // add the letter to the word we're constructing
            else
                down[ d++ ] = board->state[ r ][ c ];
        }

        // finished the row, do we have a word to check?
        if ( d > 0 ) {
            down[ d ] = '\0';

            // check the word
            if ( !search( down ) )
                return false;
        }
        d = 0;
    }

    return true;
}

/**
 * Place the word in the given Command on the board. Validates the
 * location of the word, places it, then checks board for words in the
 * dictionary. If invalid words are found, the board is reset.
 * @param cmd The command, the type is either ACROSS or DOWN with a word to place.
 * @return False if successful. FALSE IF SUCCESSFUL.
 */
static bool placeWord( Command const *cmd ) {

    // accross
    if ( cmd->type == ACROSS ) {

        // the row is constant
        const int r = cmd->row;

        // save a copy of the row in case we need to reset
        char rowCopy[ board->cols ];
        for ( int c = 0; c < board->cols; ++c )
            rowCopy[ c ] = board->state[ r ][ c ];

        // validate location
        for ( int c = cmd->col, l = 0; cmd->word[ l ]; ++c, ++l ) {

            if ( c >= board->cols || (board->state[ r ][ c ] != ' ' && cmd->word[ l ] != board->state[ r ][ c ]) )
                return true;
        }

        // place the word!
        for ( int c = cmd->col, l = 0; cmd->word[ l ]; ++c, ++l )
            board->state[ r ][ c ] = cmd->word[ l ];

        // check the board
        if( dictionary != NULL && !checkBoard() ) {

            // reset the row if the check failed
            for ( int c = 0; c < board->cols; ++c )
                board->state[ r ][ c ] = rowCopy[ c ];
            return true;
        }
    }

    // down
    else {

        // the collumn is constant
        const int c = cmd->col;

        // save a copy of the collumn in case we need to reset
        char colCopy[ board->rows ];
        for ( int r = 0; r < board->rows; ++r )
            colCopy[ r ] = board->state[ r ][ c ];

        // validate location
        for ( int r = cmd->row, l = 0; cmd->word[ l ]; ++r, ++l ) {

            if ( r >= board->rows || (board->state[ r ][ c ] != ' ' && cmd->word[ l ] != board->state[ r ][ c ]) )
                return true;
        }

        // place the word!
        for ( int r = cmd->row, l = 0; cmd->word[ l ]; ++r, ++l )
            board->state[ r ][ c ] = cmd->word[ l ];

        // check the board
        if( dictionary != NULL && !checkBoard() ) {

            // reset the collumn if the check failed
            for ( int r = 0; r < board->rows; ++r )
                board->state[ r ][ c ] = colCopy[ r ];
            return true;
        }
    }

    return false;
}

/**
 * Thread start function. Handle a client connection and close
 * it when we're done. Each thread is passed an Arg struct,
 * which contains the socket number.
 * @param arg Thread arguments, an Arg struct.
 * @return NULL.
 */
void *handleClient( void *arg ) {

    // get the threads args
    Args *args = (Args *)arg;

    // Here's a nice trick, wrap a C standard IO FILE around the
    // socket, so we can communicate the same way we would read/write
    // a file.
    FILE *fp = fdopen( args->sock, "a+" );

    // holds the command
    Command *cmd;

    // loop through user input
    while ( true ) {

        // Prompt the user for the next command.
        fprintf( fp, "cmd> " );

        // get the next command
        cmd = getCommand( fp );

        // invalid command, continue
        if ( cmd->type == INVALID ) {
            fprintf( fp, "Invalid command\n" );
            free( cmd );
            continue;
        }

        // quit command, break
        if ( cmd->type == QUIT )
            break;

        // enter the monitor
        pthread_mutex_lock( &mon );

        // board command, print and continue
        if ( cmd->type == BOARD )
            printBoard( fp );

        // across or down commands, place the word
        else if ( cmd->type == ACROSS || cmd->type == DOWN ) {
            if ( placeWord( cmd ) )
                fprintf( fp, "Invalid command\n" );
            free( cmd->word );
        }

        // exit the monitor
        pthread_mutex_unlock( &mon );

        free( cmd );
    }

    // Close the connection with this client.
    fclose( fp );

    // free the command
    free( cmd );

    // free the args
    free( args );

    return NULL;
}

/**
 * Read from the dictionary located at DICTIONARY_PATH.
 * Get only the valid words and create a list. Words are
 * valid if they consist of only lowercase letters.
 */
static void readDictionary() {

    FILE *fp = fopen( DICTIONARY_PATH, "r" );

    // read the words list
    if ( fp != NULL ) {
        int size = 0, cap = MIN_CAP;

        // allocate the initial struct
        dictionary = (Words *)malloc( sizeof( Words ) );
        dictionary->list = (char **)malloc( cap * sizeof( char * ) );

        // invalid word flag
        bool valid;
        char *temp;

        // read dynamically allocated words from file
        while ( (temp = getWord( fp, true )) != NULL ) {

            // reset flag
            valid = true;

            // only get valid words
            for ( int c = 0; temp[ c ]; ++c ) {

                // invalid! 
                if ( !islower( temp[ c ] ) ) {
                    free( temp );
                    valid = false;
                    break;
                }
            }

            // check capacity
            if ( valid ) {
                dictionary->list[ size ] = temp;

                if ( ++size + 1 == cap )
                    dictionary->list = (char **)realloc( dictionary->list, (cap *= 2) * sizeof( char * ) );
            }
        }

        fclose( fp );

        // minimize dictionary memory consumption
        dictionary->list = (char **)realloc( dictionary->list, size * sizeof( char * ) );
        dictionary->size = size;

        // nothing in the dictionary
        if ( size == 0 ) {
            free( dictionary );
            dictionary = NULL;
        }
    }

    // no dictionary!
    else
        dictionary = NULL;
}

/**
 * Program starting point. Attempts to start a scrabble board server. Each
 * time a client connects, a new thread is created to handle its work. The
 * server loops forever until the user terminates it with ctrl + c.
 * @param argc The number of command line arguments.
 * @param argv The command line arguments.
 * @return The exit status.
 */
int main( int argc, char *argv[] ) {

    // board dimensions
    int rows, cols;

    // check usage
    if ( argc != 3 || strToInt( argv[ 1 ], 1, &rows ) || strToInt( argv[ 2 ], 1, &cols ) )
        fail( "usage: scrabbleServer <rows> <cols>" );

    // Prepare a description of server address criteria.
    struct addrinfo addrCriteria;
    memset( &addrCriteria, 0, sizeof( addrCriteria ) );
    addrCriteria.ai_family = AF_INET;
    addrCriteria.ai_flags = AI_PASSIVE;
    addrCriteria.ai_socktype = SOCK_STREAM;
    addrCriteria.ai_protocol = IPPROTO_TCP;

    // Lookup a list of matching addresses
    struct addrinfo *servAddr;
    if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr ) )
        fail( "Can't get address info" );

    // Try to just use the first one.
    if ( servAddr == NULL )
        fail( "Can't get address" );

    // Create a TCP socket
    int servSock = socket( servAddr->ai_family, servAddr->ai_socktype, servAddr->ai_protocol );
    if ( servSock < 0 )
        fail( "Can't create socket" );

    // Bind to the local address
    if ( bind( servSock, servAddr->ai_addr, servAddr->ai_addrlen ) != 0 )
        fail( "Can't bind socket" );
    
    // Tell the socket to listen for incoming connections.
    if ( listen( servSock, 5 ) != 0 )
        fail( "Can't listen on socket" );

    // Free address list allocated by getaddrinfo()
    freeaddrinfo(servAddr);

    // Fields for accepting a client connection.
    struct sockaddr_storage clntAddr; // Client address
    socklen_t clntAddrLen = sizeof( clntAddr );

    // construct the board
    board = (Board *)malloc( sizeof( Board ) );
    board->rows = rows;
    board->cols = cols;
    
    // allocate the row pointers
    board->state = (char **)malloc( rows * sizeof( char * ) );

    // allocate and initialize each row
    for ( int r = 0; r < rows; ++r ) {
        board->state[ r ] = (char *)malloc( cols * sizeof( char ) );
        
        for ( int c = 0; c < cols; ++c )
            board->state[ r ][ c ] = ' ';
    }

    // get the dictionary
    readDictionary();

    // loop until forced termination
    while ( true ) {

        // make a struct for argument passing, the worker thread becomes responsible for it
        Args *args = (Args *)malloc( sizeof( Args ) );

        // Accept a client connection.
        args->sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

        // create a worker thread to handle the client
        pthread_t worker;
        pthread_create( &worker, NULL, handleClient, args );

        // detach from the worker thread
        pthread_detach( worker );
    }

    // this section is never reacher :(

    // Stop accepting client connections
    close( servSock );

    // free the board rows
    for ( int i = 0; i < board->rows; ++i )
        free( board->state[ i ] );

    // free the board state
    free( board->state );

    // free the board itself
    free( board );

    // free the dictionary
    free( dictionary );

    // destroy the monitor
    pthread_mutex_destroy( &mon );
    
    return EXIT_SUCCESS;
}
