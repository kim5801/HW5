#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26244"

/** Maximum word length */
#define WORD_LIMIT 26

// Lock for access to the monitor.
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;

//number of rows in the grid
int rows = 0;

//number of columns in the grid
int cols = 0;

//dynamically allocated array representing the board without border
char* grid;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: scrabbleServer <rows> <cols>\n" );
  exit( 1 );
}

/** places the given word on the grid at spot (r,c) going across */
static void across(int r, int c, char word[], FILE *fp) {
  //can't have negative row or col values or outside of bounds
  if (r < 0 || c < 0 || r >= rows || c >= cols) {
    fprintf(fp, "Invalid command\n");
    return;
  }
  //word would go out of the column right border
  if (c + strlen(word) > cols) {
    fprintf(fp, "Invalid command\n");
    return;
  }

  //check word that its valid and will fit before placing it
  //technique for indexing array adapted from: https://linuxhint.com/two-dimensional-array-malloc-c-programming/
  for (int i = 0; i < strlen(word); i++) {
    //only lower case letters allowed
    if (word[i] < 'a' || word[i] > 'z' ) {
      fprintf(fp, "Invalid command\n");
      return;
    }
    //curr is the letter already in that place
    char curr = *(grid + r*cols + c + i);
    //if the spots isn't empty and isn't the same letter, it's bad
    if (curr != ' ' && curr != word[i]) {
      fprintf(fp, "Invalid command\n");
      return;
    }
  }

  //place word, character by character because we know it's valid
  //technique for indexing array adapted from: https://linuxhint.com/two-dimensional-array-malloc-c-programming/
  for (int i = 0; i < strlen(word); i++) {
    *(grid + r*cols + c + i) = word[i];
  }
}

/** places the given word on the grid at spot (r,c) going down */
static void down(int r, int c, char word[], FILE *fp) {
  //can't have negative row or col values or outside bounds
  if (r < 0 || c < 0 || r >= rows || c >= cols) {
    fprintf(fp, "Invalid command\n");
    return;
  }
  //word would go out of the row bottom border
  if (r + strlen(word) > rows) {
    fprintf(fp, "Invalid command\n");
    return;
  }
  
  //check word that its valid and will fit before placing it
  //technique for indexing array adapted from: https://linuxhint.com/two-dimensional-array-malloc-c-programming/
  for (int i = 0; i < strlen(word); i++) {
    //only lower case letters allowed
    if (word[i] < 'a' || word[i] > 'z' ) {
      fprintf(fp, "Invalid command\n");
      return;
    }

    //curr is the letter already in that place
    char curr = *(grid + r*cols + c + cols*i);
    //if the spots isn't empty and isn't the same letter, it's bad
    if (curr != ' ' && curr != word[i]) {
      fprintf(fp, "%c %c\n", curr, word[i]);
      fprintf(fp, "Invalid command\n");
      return;
    }
    //spot is valid, so place letter
    *(grid + r*cols + c + cols*i) = word[i];
  }

  //place word letter by letter bc we know it's valid
  //technique for indexing array adapted from: https://linuxhint.com/two-dimensional-array-malloc-c-programming/
  for (int i = 0; i < strlen(word); i++) {
    *(grid + r*cols + c + cols*i) = word[i];
  }
}

/** prints out the grid to fp with a border */
static void board(FILE *fp) {
  //top of box
  fprintf(fp, "+");
  for (int i = 0; i < cols; i++) {
    fprintf(fp, "-");
  }
  fprintf(fp, "+\n");

  //print out middle chars between two |'s
  //technique adapted from: https://linuxhint.com/two-dimensional-array-malloc-c-programming/
  for (int i = 0; i < rows; i++) {
    fprintf(fp, "|"); 
    for (int c = 0; c < cols; c++) {
      fprintf(fp, "%c", *(grid + i*cols + c));
    }
    fprintf(fp, "|\n"); 
  }

  //bottom of box
  fprintf(fp, "+");
  for (int i = 0; i < cols; i++) {
    fprintf(fp, "-");
  }
  fprintf(fp, "+\n");
}


/** handle a client connection, close it when we're done. */
void *handleClient( void *arg ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int sock = *(int *)arg;
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {

    //user wants across
    if (strcmp( cmd, "across" ) == 0 ) {
      int r, c;
      char word[WORD_LIMIT + 1];
      if (fscanf(fp, "%d %d %27s", &r, &c, word) == 3) {
        //exceeded word limit, ignore
        if (word[WORD_LIMIT] != '\0') {
          fprintf(fp, "Invalid command\n");
        }
        else {
          //enter monitor
          pthread_mutex_lock(&mon);
          across(r, c, word, fp);
          //exit monitor
          pthread_mutex_unlock(&mon);
        }
      } else {
        fprintf(fp, "Invalid command\n");
      }
    }

    //user wants down
    else if (strcmp( cmd, "down" ) == 0 ) {
      int r, c;
      char word[WORD_LIMIT + 1];
      if (fscanf(fp, "%d %d %27s", &r, &c, word) == 3) {
        //exceeded word limit, ignore
        if (word[WORD_LIMIT] != '\0') {
          fprintf(fp, "Invalid command\n");
        }
        else {
          //enter monitor
          pthread_mutex_lock(&mon);
          down(r, c, word, fp);
          //exit monitor
          pthread_mutex_unlock(&mon);
        }
      } else {
        fprintf(fp, "Invalid command\n");
      }
    }

    //user wants board
    else if (strcmp( cmd, "board" ) == 0 ) {
      //enter monitor
      pthread_mutex_lock(&mon);
      board(fp);
      //exit monitor
      pthread_mutex_unlock(&mon);
    }

    //not one of the options, so invalid
    else {
      fprintf(fp, "Invalid command\n");
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  //make sure there are only 2 command line parameters
  if (argc != 3) {
    usage();
  }
  //not integers larger than 0
  if (atoi(argv[1]) <= 0 || atoi(argv[2]) <= 0) {
    usage();
  //update rows and cols with valid parameters
  } else {
    rows = atoi(argv[1]);
    cols = atoi(argv[2]);
  }

  //allocate board to right size and fill with blanks
  //technique adapted from: https://linuxhint.com/two-dimensional-array-malloc-c-programming/
  grid = (char*)malloc(rows * cols * sizeof(char));
  for (int i = 0; i < rows; i++) {
    for (int c = 0; c < cols; c++) {
        *(grid + i*cols + c) = ' ';
    } 
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    
    //create a new thread for every new sock request
    pthread_t thread;
    if ( pthread_create( &thread, NULL, handleClient, &sock ) != 0 ) 
      fail( "Can't create a thread" );
    pthread_detach(thread);
  }

  // Stop accepting client connections (never reached).
  close( servSock );

  //deallocate mem
  free(grid);
  
  return 0;
}
