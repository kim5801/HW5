/**
 * @file scrabbleServer.c
 * @author Abhinav Pratap, aspratap
 *
 * Sets up a scrabble board for any client to play.
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <stdbool.h>

/** Port number used by my server */
#define PORT_NUMBER "26134"

/** Maximum word length */
#define WORD_LIMIT 26

/** max length of command line */
#define BUFFER_LEN 1000

// number of rows on the grid
int rows;
// number of columns on the grid
int cols;

// holds the current board state
char **board = NULL;

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(EXIT_FAILURE);
}

// returns true if all the characters in the word are lowercase
bool validWord(char word[], int wordLen)
{
  if (wordLen > WORD_LIMIT)
    return false;

  for (int i = 0; i < wordLen; i++)
  {
    if (word[i] < 'a' || word[i] > 'z')
      return false;
  }

  return true;
}

/** method for handling all across moves, returns true if successful, false if not*/
bool across(int r, int c, char word[])
{
  int wordLen = strlen(word);
  if (c + wordLen - 1 > cols - 1 || r < 0 || r >= rows || c < 0 || !validWord(word, wordLen))
  {
    return false;
  }

  pthread_mutex_lock(&lock);

  for (int i = 0; i < wordLen; i++)
  {
    if (word[i] != board[r][c + i] && board[r][c + i] != ' ')
    {
      pthread_mutex_unlock(&lock);
      return false;
    }
  }

  memcpy(board[r] + c, word, wordLen * sizeof(char));
  pthread_mutex_unlock(&lock);
  return true;
}

/** method for handling all down moves, returns true if successful, false if not*/
bool down(int r, int c, char word[])
{
  int wordLen = strlen(word);
  if (r + wordLen - 1 > rows - 1 || r < 0 || r >= rows || c < 0 || !validWord(word, wordLen))
  {
    return false;
  }

  pthread_mutex_lock(&lock);

  for (int i = 0; i < wordLen; i++)
  {
    if (word[i] != board[r + i][c] && board[r + i][c] != ' ')
    {
      pthread_mutex_unlock(&lock);
      return false;
    }
  }

  for (int i = 0; i < wordLen; i++)
  {
    board[r + i][c] = word[i];
  }
  pthread_mutex_unlock(&lock);
  return true;
}

/** method for printing out the board */
void printBoard(FILE *fp)
{
  pthread_mutex_lock(&lock);
  fprintf(fp, "+");
  for (int i = 0; i < cols; i++)
  {
    fprintf(fp, "-");
  }
  fprintf(fp, "+\n");
  for (int i = 0; i < rows; i++)
  {
    fprintf(fp, "|");
    for (int j = 0; j < cols; j++)
    {
      fprintf(fp, "%c", board[i][j]);
    }
    fprintf(fp, "|\n");
  }
  fprintf(fp, "+");
  for (int i = 0; i < cols; i++)
  {
    fprintf(fp, "-");
  }
  fprintf(fp, "+\n");
  pthread_mutex_unlock(&lock);
}

/** handle a client connection, close it when we're done. */
void *handleClient(void *arg)
{

  int sock = *((int *)arg);
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen(sock, "a+");

  // Prompt the user for a command.
  fprintf(fp, "cmd> ");

  char buffer[BUFFER_LEN];

  while (fgets(buffer, BUFFER_LEN, fp) != NULL)
  {

    // Temporary values for parsing commands.
    char cmd[WORD_LIMIT + 5];
    cmd[0] = '\0';

    int n = 0;
    char *bufPointer = buffer;

    int cmdMatch = sscanf(buffer, "%26s %n", cmd, &n);

    bufPointer += n;

    if (cmdMatch != 1)
    {
      fprintf(fp, "Invalid command\n");
      fprintf(fp, "cmd> ");
      continue;
    }

    if (strcmp("quit", cmd) == 0)
      break;

    if (strcmp("across", cmd) == 0 || strcmp("down", cmd) == 0)
    {
      int r = -1;
      int c = -1;
      char word[WORD_LIMIT + 5];
      char excessBuf[12];
      excessBuf[0] = '\0';

      int matches = sscanf(bufPointer, "%d %d %26s %10s", &r, &c, word, excessBuf);

      if (matches != 3)
      {
        fprintf(fp, "Invalid command\n");
        fprintf(fp, "cmd> ");
        continue;
      }

      bool successful = false;
      if (strcmp("across", cmd) == 0)
        successful = across(r, c, word);
      else if (strcmp("down", cmd) == 0)
        successful = down(r, c, word);

      if (!successful)
      {
        fprintf(fp, "Invalid command\n");
        fprintf(fp, "cmd> ");
        continue;
      }
    }
    else if (strcmp("board", cmd) == 0)
    {
      char excessBuf[12];
      excessBuf[0] = '\0';

      if (sscanf(bufPointer, " %10s ", excessBuf) != 0 && strlen(excessBuf) != 0)
      {
        fprintf(fp, "Invalid command\n");
        fprintf(fp, "cmd1> ");
        continue;
      }
      printBoard(fp);
    }
    else if (strlen(buffer) != 0)
    {
      fprintf(fp, "Invalid command\n");
      fprintf(fp, "cmd> ");
      continue;
    }

    // Prompt the user for the next command.
    fprintf(fp, "cmd> ");
  }

  // Close the connection with this client.
  fclose(fp);
  return NULL;
}

/** free the memory allocated for the board */
void freeBoard()
{
  for (int i = 0; i < rows; i++)
  {
    free(board[i]);
  }

  free(board);
  pthread_mutex_destroy(&lock);
  // printf("finished freeing memory for board.\n");
  exit(EXIT_SUCCESS);
}

int main(int argc, char *argv[])
{

  if (argc != 3)
  {
    printf("usage: scrabbleServer <rows> <cols>\n");
    exit(EXIT_FAILURE);
  }

  int nrows = -1;
  int rowMatch = sscanf(argv[1], "%d", &nrows);

  int ncols = -1;
  int colsMatch = sscanf(argv[2], "%d", &ncols);

  if (colsMatch != 1 || rowMatch != 1 || nrows <= 0 || ncols <= 0)
  {
    printf("usage: scrabbleServer <rows> <cols>\n");
    exit(EXIT_FAILURE);
  }

  // char board[nrows][ncols];

  // memset(board, ' ', sizeof(board));

  rows = nrows;
  cols = ncols;

  board = (char **)malloc(rows * sizeof(char *));

  for (int i = 0; i < rows; i++)
  {
    board[i] = (char *)malloc(cols * sizeof(char));
    memset(board[i], ' ', cols * sizeof(char));
  }

  struct sigaction act;
  act.sa_handler = freeBoard;
  sigemptyset(&(act.sa_mask));
  act.sa_flags = 0;
  sigaction(SIGINT, &act, 0);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if (getaddrinfo(NULL, PORT_NUMBER, &addrCriteria, &servAddr))
    fail("Can't get address info");

  // Try to just use the first one.
  if (servAddr == NULL)
    fail("Can't get address");

  // Create a TCP socket
  int servSock = socket(servAddr->ai_family, servAddr->ai_socktype,
                        servAddr->ai_protocol);
  if (servSock < 0)
    fail("Can't create socket");

  // Bind to the local address
  if (bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0)
    fail("Can't bind socket");

  // Tell the socket to listen for incoming connections.
  if (listen(servSock, 5) != 0)
    fail("Can't listen on socket");

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while (true)
  {
    // Accept a client connection.
    int sock = accept(servSock, (struct sockaddr *)&clntAddr, &clntAddrLen);

    pthread_t newThread;
    pthread_create(&newThread, NULL, &handleClient, &sock);
    pthread_detach(newThread);
    // handleClient(sock, board);
  }

  // Stop accepting client connections (never reached).
  close(servSock);

  return 0;
}
