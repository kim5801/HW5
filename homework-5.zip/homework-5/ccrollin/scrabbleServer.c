/**
    @file scrabbleServer.c
    @author Caleb Rollins (ccrollin)
    This is the server component of the scrabble board game for homework 5. The
    program below can be run to accept any connections over port 26056 from multiple
    client connections. Each client connection has a thread dedicated to it. Critical
    sections of code have synchronization solutions implemented with a POSIX semaphore.
    Results from playing the game are displayed to the generic client (we used nc).
*/

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26056"

/** Maximum word length */
#define WORD_LIMIT 26

// The number of rows for the board (as specified by the user)
int rows;

// The number of columns for the board (as specified by the user)
int columns;

// An array to represent the scrabble board with words or empty spaces
char **boardArray;

// An anonymous POSIX semaphore to provide for mutual exclusion between the multiple threads in
// for functions that are manipulating the same global board array
sem_t x;

// Print out an error message and exit.
static void fail( char const *message )
{
    fprintf( stderr, "%s\n", message );
    exit( EXIT_FAILURE );
}

// This is a helper method that takes care of the game move of placing a word on the board that
// is going across from left to right starting at the parameter indexes of row and col.
static void across( int row, int col, char *word, FILE *fp )
{
    // Check that the word is at least 1 and not larger than our 26-character limit
    if ( strlen( word ) < 1 || strlen( word ) > WORD_LIMIT ) {
        fprintf( fp, "Invalid command\n" );
        return;
    }

    // Check that the word contains all lowercase letters
    for ( int i = 0; i < strlen( word ); i++ ) {
        if ( *( word + i ) < 'a' || *( word + i ) > 'z' ) {
            fprintf( fp, "Invalid command\n" );
            return;
        }
    }

    // Check that the row and col parameters make logical sense
    // for the size of the game board we specified earlier
    if ( row < 0 || row > rows || col < 0 || col > columns ) {
        fprintf( fp, "Invalid command\n" );
        return;
    }

    // Check that the word does not run off the board horizontally (across)
    if ( col + strlen( word ) > columns ) {
        fprintf( fp, "Invalid command\n" );
        return;
    }

    // Aquire on our semaphore to ensure we are allowed to enter critical code
    sem_wait( &x );

    // Check character by character in the board to see if it is empty or a character that is allowed
    // to have another word with the same character overlayed
    for ( int i = 0; i < strlen( word ); i++ ) {
        if ( *( *( boardArray + row ) + col + i ) == ' ' ) {
            continue;
        }
        else if (( *( *( boardArray + row ) + col + i )) == *( word + i )) {
            continue;
        }
            // If we encounter a cell that has a character already placed that does
            // not match up with the character in this word then we prematurely quit
        else {
            fprintf( fp, "Invalid command\n" );
            sem_post( &x );
            return;
        }
    }

    // Now that we have ensured that the word can be placed, we add it to the
    // board array in its entirety
    for ( int i = 0; i < strlen( word ); i++ ) {
        ( *( *( boardArray + row ) + col + i )) = *( word + i );
    }

    // We no longer need this lock
    sem_post( &x );
}

// This is a helper method that takes care of the game move of placing a word on the board that
// is going down from top to bottom starting at the parameter indexes of row and col. This function
// has many of the same functionality of the across function.
static void down( int row, int col, char *word, FILE *fp )
{
    // Check that the word is at least 1 and not larger than our 26-character limit
    if ( strlen( word ) < 1 || strlen( word ) > WORD_LIMIT ) {
        fprintf( fp, "Invalid command\n" );
        return;
    }

    // Check that the word contains all lowercase letters
    for ( int i = 0; i < strlen( word ); i++ ) {
        if ( *( word + i ) < 'a' || *( word + i ) > 'z' ) {
            fprintf( fp, "Invalid command\n" );
            return;
        }
    }

    // Check that the row and col parameters make logical sense
    // for the size of the game board we specified earlier
    if ( row < 0 || row > rows || col < 0 || col > columns ) {
        fprintf( fp, "Invalid command\n" );
        return;
    }

    // Check that the word does not run off the board vertically (down)
    if ( row + strlen( word ) > rows ) {
        fprintf( fp, "Invalid command\n" );
        return;
    }

    // Aquire on our semaphore to ensure we are allowed to enter critical code
    sem_wait( &x );

    // Check character by character in the board to see if it is empty or a character that is allowed
    // to have another word with the same character overlayed
    for ( int i = 0; i < strlen( word ); i++ ) {
        if ( *( *( boardArray + row + i ) + col ) == ' ' ) {
            continue;
        }
        else if (( *( *( boardArray + row + i ) + col )) == *( word + i )) {
            continue;
        }
            // If we encounter a cell that has a character already placed that does
            // not match up with the character in this word then we prematurely quit
        else {
            fprintf( fp, "Invalid command\n" );
            sem_post( &x );
            return;
        }
    }

    // Now that we have ensured that the word can be placed, we add it to the
    // board array in its entirety
    for ( int i = 0; i < strlen( word ); i++ ) {
        ( *( *( boardArray + row + i ) + col )) = *( word + i );
    }

    // We no longer need this lock
    sem_post( &x );
}

// This is another helper function that prints out to the client the current configuration
// of the board array with empty spaces indicating there is no letter placed there yet. A
// decorative border is added to define the edges/boundaries of where we can place words.
static void board( FILE *fp )
{
    fprintf( fp, "+" );
    for ( int i = 0; i < columns; i++ ) {
        fprintf( fp, "-" );
    }
    fprintf( fp, "+\n" );

    for ( int r = 0; r < rows; r++ ) {
        fprintf( fp, "|" );
        sem_wait( &x );
        for ( int c = 0; c < columns; c++ ) {
            fprintf( fp, "%c", *( *( boardArray + r ) + c ));
        }
        sem_post( &x );
        fprintf( fp, "|\n" );
    }

    fprintf( fp, "+" );
    for ( int i = 0; i < columns; i++ ) {
        fprintf( fp, "-" );
    }
    fprintf( fp, "+\n" );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *arg )
{
    // Use the parameter passed to this function to get the socket
    int sock = *(( int * ) arg );

    // Here's a nice trick, wrap a C standard IO FILE around the
    // socket, so we can communicate the same way we would read/write
    // a file.
    FILE *fp = fdopen( sock, "a+" );

    // Prompt the user for a command.
    fprintf( fp, "cmd> " );

    // Temporary values for parsing commands.
    char cmd[11];
    while ( fscanf( fp, "%10s", cmd ) == 1 && strcmp( cmd, "quit" ) != 0 ) {

        // Temporary values for storing command parameters
        int row;
        int col;
        char word[51];

        // If the command is across, two numbers for row and col are specified, and a word are passed then we delegate to the across helper function
        if ( strcmp( cmd, "across" ) == 0 && fscanf( fp, "%d", &row ) == 1 && fscanf( fp, "%d", &col ) == 1 && fscanf( fp, "%50s", word ) == 1 ) {
            across( row, col, word, fp );
        }
            // If the command is down, two numbers for row and col are specified, and a word are passed then we delegate to the down helper function
        else if ( strcmp( cmd, "down" ) == 0 && fscanf( fp, "%d", &row ) == 1 && fscanf( fp, "%d", &col ) == 1 && fscanf( fp, "%50s", word ) == 1 ) {
            down( row, col, word, fp );
        }
            // If the command is board, then we delegate to the board helper function
        else if ( strcmp( cmd, "board" ) == 0 ) {
            board( fp );
        }
            // Otherwise, we know that the command is invalid so let the client know accordingly
        else {
            fprintf( fp, "Invalid command\n" );
        }

        // Prompt the user for the next command.
        fprintf( fp, "cmd> " );
    }

    // Close the connection with this client.
    fclose( fp );
    return NULL;
}

// This is the entry-point for scrabble server component. Here we manage the
// game board array, synchronization code, and network communication/socket code.
// Much of this code was provided in the starter file.
int main( int argc, char *argv[] )
{
    // Check that exactly 3 command line arguments are passed and that the row and column values are positive integers.
    if ( argc != 3 || sscanf( argv[1], "%d", &rows ) != 1 || sscanf( argv[2], "%d", &columns ) != 1 || atoi( argv[1] ) <= 0 || atoi( argv[2] ) <= 0 ) {
        printf( "usage: scrabbleServer <rows> <cols>\n" );
        return EXIT_FAILURE;
    }

    // Dynamically allocate a 2D board array that contains the representation of the scrabble game at a given time
    boardArray = ( char ** ) malloc( rows * sizeof( char * ));
    for ( int i = 0; i < rows; i++ ) {
        *( boardArray + i ) = ( char * ) malloc( columns );
    }

    // Initialize all cells to have a space indicating they are currently empty
    for ( int r = 0; r < rows; r++ ) {
        for ( int c = 0; c < columns; c++ ) {
            *( *( boardArray + r ) + c ) = ' ';
        }
    }

    // Initialize our POSIX anonymous semaphore to have one free pass
    int xInit = sem_init( &x, 0, 1 );
    if ( xInit == -1 ) {
        fail( "There was a problem initializing a semaphore." );
    }

    // Prepare a description of server address criteria.
    struct addrinfo addrCriteria;
    memset( &addrCriteria, 0, sizeof( addrCriteria ));
    addrCriteria.ai_family = AF_INET;
    addrCriteria.ai_flags = AI_PASSIVE;
    addrCriteria.ai_socktype = SOCK_STREAM;
    addrCriteria.ai_protocol = IPPROTO_TCP;

    // Lookup a list of matching addresses
    struct addrinfo *servAddr;
    if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr ))
        fail( "Can't get address info" );

    // Try to just use the first one.
    if ( servAddr == NULL )
        fail( "Can't get address" );

    // Create a TCP socket
    int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                           servAddr->ai_protocol );
    if ( servSock < 0 )
        fail( "Can't create socket" );

    // Bind to the local address
    if ( bind( servSock, servAddr->ai_addr, servAddr->ai_addrlen ) != 0 )
        fail( "Can't bind socket" );

    // Tell the socket to listen for incoming connections.
    if ( listen( servSock, 5 ) != 0 )
        fail( "Can't listen on socket" );

    // Free address list allocated by getaddrinfo()
    freeaddrinfo( servAddr );

    // Fields for accepting a client connection.
    struct sockaddr_storage clntAddr; // Client address
    socklen_t clntAddrLen = sizeof( clntAddr );

    // Continue accepting connections until the server is killed with CTRL + C
    while ( true ) {
        // Accept a client connection.
        int sock = accept( servSock, ( struct sockaddr * ) &clntAddr, &clntAddrLen );

        // Create a new pthread for each client connection and assign it the starter function handleClient
        pthread_t newThread;
        // Notice that we are passing the address of the sock as a void ptr to follow calling convention
        if ( pthread_create( &newThread, NULL, handleClient, ( void * ) &sock ) != 0 ) {
            fail( "There was a problem creating a new thread." );
        }
        pthread_detach( newThread );
    }

    // This will destroy our semaphore
    int xDest = sem_destroy( &x );
    if ( xDest == -1 ) {
        fail( "There was a problem destroying a semaphore." );
    }

    // Stop accepting client connections (never reached).
    close( servSock );

    // Free all the allocated memory for our boardArray
    for ( int i = 0; i < rows; i++ ) {
        free( *( boardArray + i ));
    }
    free( boardArray );

    return 0;
}
