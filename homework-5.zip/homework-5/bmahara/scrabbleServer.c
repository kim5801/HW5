#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26248"

/** Maximum word length */
#define WORD_LIMIT 26

//board represented as a global variable
char *b1;

//global vars for row and col number
int rows = 0; 
int digitsInRows = 0;
int cols = 0; 
int digitsInCols = 0;

//semaphore for restricting threads from accessing same state
sem_t lock;

//to know if a wordList was accessible
bool wordListExists;

//points to list of words
char *ptrToWordList;
//wordList
char **wordList;
//length of word list
int listSize = 0;

//method for reading words from a file
void readWords(char const *filename) {

  wordListExists = true;

  //opening file FP
  FILE *inp;
  if( (inp = fopen(filename, "r")) == NULL ) {
      wordListExists = false;
      return;
  }

  int numWords = 0;  
  int cap = 100;
  wordList = malloc(sizeof(char*) * cap);
  for(int t = 0; t < cap; t++) {
    wordList[t] = malloc((27) * sizeof(char));
  }

  char oneWord[28];

  while( fscanf(inp, "%[^\n] ", oneWord) != EOF ) {

    if(numWords == cap) { 
      cap *= 2;
      wordList = realloc(wordList, cap * (WORD_LIMIT + 1));
      for(int t = numWords; t < cap; t++) {
        wordList[t] = malloc((27) * sizeof(char));
      }
    }

    bool readThisWord = true;
    oneWord[strlen(oneWord)] = '\0';
    //greater than 26 letters in a word
    if(strlen(oneWord) > WORD_LIMIT) {
      readThisWord = false;
      continue;
    }

    oneWord[strlen(oneWord)] = '\0'; 
    //check for char other than lower
    for(int y = 0; oneWord[y]; y++) { 
      if(!islower(oneWord[y])) {
        readThisWord = false; 
        break;
      }
    } 

    if(readThisWord) {
      strcpy(wordList[numWords++], oneWord); 
      readThisWord = true;
    }
 

  }

  listSize = numWords;
  fclose(inp);

}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void * s ) {
  int *ptr = (int *) s;
  int sock = *ptr;
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );

  char (*boardRep) [cols] = (char (*)[cols]) b1;
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );
  
  char entireCmd[80];
  while ( fscanf( fp, "%50[^\n]", entireCmd ) == 1 &&
          strcmp( entireCmd, "quit" ) != 0 ) { //command is NOT "quit"
    
    // collecting 43 chars because we need to check if there is a character beyond max length possible
    if((strlen(entireCmd) > 42) ) { 
      //i have an extra char in input 
      fprintf(fp, "%s\n", "Invalid command");
      fprintf( fp, "cmd> " );
      continue;
      
    } //handling buffer overflow

    sem_wait(&lock); //locking access to server state
    
    if(strcmp(entireCmd, "board") == 0 ) {
      
      //printing +..-..+
      fprintf(fp, "%c", '+');
      for(int i = 0; i < cols; i++) {
        fprintf(fp, "%c", '-');
      }
      fprintf(fp, "%c\n", '+'); //newline in the end

      //print rows
      for(int h = 0; h < rows; h++){
        fprintf(fp, "%c", '|');
        for(int f = 0; f < cols; f++) {
          fprintf(fp, "%c", boardRep[h][f]);
        }
        fprintf(fp, "%c", '|');
        fprintf(fp, "\n");
      }

      //printing +..-..+
      fprintf(fp, "%c", '+');
      for(int i = 0; i < cols; i++) {
        fprintf(fp, "%c", '-');
      }
      fprintf(fp, "%c\n", '+'); //newline in the end


    } //end of board

    else {
      char cmd[10];
      int r = -1;
      int c = -1;
      char word[30];

      sscanf(entireCmd, "%6s %d %d %26s", cmd, &r, &c, word);

      //check for lowercase
      bool invalid = false;
      for(int i = 0; word[i]; i++) {
        if(!islower(word[i])) {
          invalid = true;
          break;
        }
      }
      //checking if word is greater than 26 letters or if there are lowercase letters
      if(strlen(word) > WORD_LIMIT || invalid) {
        fprintf(fp, "Invalid command\n");
        goto done;
      }

      //checking if rows/cols are valid
      if(r >= rows || c >= cols || r < 0 || c < 0) {
        fprintf(fp, "%s\n", "Invalid command");
        goto done;
      }

      if(strlen(cmd) < 4) {
        fprintf(fp, "%s\n", "Invalid command");
        goto done;
      }
      
      bool found = false;
      if(wordListExists) {
        for(int u = 0; u < listSize; u++) {
          if(strcmp(word, wordList[u]) == 0) {
            found = true;
            break;
          }
        }
        if(!found) {
          fprintf(fp, "%s\n", "Invalid command");
          goto done;
        }
      }

      if(strcmp(cmd, "down") == 0) {

        if((r + strlen(word)) > rows) { //word goes beyond rows
          fprintf(fp, "%s\n", "Invalid command");
          goto done;
        }

        //first: check if letters in the spot match.
        int z = 0;
        for(int currRow = r; currRow < (r + strlen(word)); currRow++) {
          if(boardRep[currRow][c] != ' ') { //if a letter exists in the spot
            if(boardRep[currRow][c] != word[z]) { //letters dont match in the spot
              fprintf(fp, "%s\n", "Invalid command");
              goto done;
            }
          }
          z++;
        }

        //only a valid word made it till here
        int idx = 0;
        for(int currRow = r; currRow < (r + strlen(word)); currRow++) {
          boardRep[currRow][c] = word[idx++];
        }

      } //end of down

      else if(strcmp(cmd, "across") == 0) {

        if((c + strlen(word)) > cols) { //word goes beyond col
          fprintf(fp, "%s\n", "Invalid command");
          goto done;
        }

        //checking if cols match for the same letter
        int z = 0;
        for(int currCol = c; currCol < (c + strlen(word)); currCol++) {
          if(boardRep[r][currCol] != ' ') { //if a letter exists in the spot
            if(boardRep[r][currCol] != word[z]) { //letters dont match in the spot
              fprintf(fp, "%s\n", "Invalid command");
              goto done;
            }
          }
          z++;
        }

        int idx = 0;
        for(int currCol = c; currCol < (c + strlen(word)); currCol++) {
          boardRep[r][currCol] = word[idx++];
        }

      } //end of across

      else {
        fprintf(fp, "Invalid command\n");
      }

    }
    done:
      fprintf( fp, "cmd> " );
      sem_post(&lock); //releasing the lock so someone else can access server state

  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  //checking for valid number of args
  //and values of row and col given by user
  if(argc != 3 || argv[1] <= 0 || argv[2] <= 0) {
    fail("usage: scrabbleServer <rows> <cols>");
  }

  digitsInRows = strlen(argv[1]); // 2 dgits in "12"
  char *rowWord = argv[1]; //getting "12"

  char rc[digitsInRows + 1];
  int i = 0;
  while(i < digitsInRows) {
    rc[i] = rowWord[i];
    i++;
  }
  rc[digitsInRows] = '\0';
  rows = atoi(rc); //"12" --> 12

  digitsInCols = strlen(argv[2]); // 2 dgits in "22"
  char *colWord = argv[2]; //getting "22"

  char cc[digitsInCols + 1];
  int j = 0;
  while(j < digitsInCols) {
    cc[j] = colWord[j];
    j++;
  }
  cc[digitsInCols] = '\0';
  cols = atoi(cc); //"22" --> 22

  //init board
  b1 = malloc( rows * cols * sizeof(char) );
  char (*boardRep) [cols] = (char (*)[cols]) b1;


  //init board values to a space
  for(int y = 0; y < rows; y++) {
    for(int g = 0; g < cols; g++) {
      boardRep[y][g] = ' ';
    }
  }


  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  //init sem with 1 so that the first thread can acquire the lock
  sem_init(&lock, 0, 1);
  
  wordListExists = true; 
  const char filename[] = "words";
  readWords(filename);

  int *d = (int *) malloc(sizeof(int));

  while ( true) {

    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    //create threads for each connection
    pthread_t thr;
    d = &sock;
    if ( pthread_create( &thr, NULL, handleClient, d ) != 0)
      fail( "Can't create one of the threads.\n" );

    //detaching a thread so that it frees memory after execution
    pthread_detach(thr);

  }

  // Stop accepting client connections (never reached).
  close( servSock );

  free(b1);
  free(wordList);
  
  return 0;
}
