#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26142"

/** Maximum word length */
#define WORD_LIMIT 26

/** Scrabble board struct definition. Has a board, number of rows,
  * and number of columns. */
typedef struct {
  char **board;
  int rows;
  int cols;
} ScrabbleBoard;

/** Scrabble board used by the entire program. Initialized in main. */
ScrabbleBoard *sb;

/** Lock semphor for changing and reading the scrabble board's board. */
sem_t lock;

/** Server socket. Global variable so it can be closed when ^C is pressed
  * using a signal handler. */
int servSock;

// When ^C is pressed in the server, this method runs
void signalHandler (int signal) {
  printf("\n");
  
  // Free the scrabble board struct
  for (int i = 0; i < sb->rows; i++) {
    free(sb->board[i]);
  }
  free(sb->board);
  free(sb);
  
  // Close the server socket
  close( servSock ); 
  
  // Exit the program
  exit (0);
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Prints out invalid command error message
// and prompts for a new command.
static void invalidCommand (FILE *fp) {
  fprintf( fp, "Invalid command\n" );
  fflush(fp);
  fprintf( fp, "cmd> " );
}

// handle a client connection, close it when we're done.
// This is used as the thread initialization method, so each client thread
// will run this method separately.
void *handleClient( void *sock ) {
  
  // Cast the void pointer to an int which represents the client socket
  int intSock = *(int *)sock;
  
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( intSock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  // Runs while there is input to read and the command is not quit
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    
    // Row, column, and word to parse, depending on the command
    int row = -1;
    int col = -1;
    char word[27];
    // across command
    if (strcmp(cmd, "across") == 0) {
      // Reads in the row and error checks
      int num = fscanf( fp, "%d", &row);
      if (num != 1 || row < 0 || row >= sb->rows ) {
        invalidCommand( fp );
        continue;
      }
      
      // Reads in the column and error checks
      num = fscanf( fp, "%d", &col);
      if (num != 1 || col < 0 || col >= sb->cols ) {
        invalidCommand( fp );
        continue;
      }
      
      // Reads in the word and error checks
      num = fscanf( fp, "%s", word);
      if (num != 1 || word[26] != '\0') {
        invalidCommand( fp );
        continue;
      }
      
      // Checking that the word does not go out of the
      // scrabble board boundaries
      int len = strlen(word);
      if (col + len > sb->cols) {
        invalidCommand( fp );
        continue;
      }
      
      // Waits for the lock to be given up on the board
      // so that this thread can access it
      sem_wait(&lock);
      bool valid = true;
      // Error checking the word
      for (int i = 0; i < len; i++) {
        // Checks that the word characters are valid
        if (word[i] < 'a' || word[i] > 'z') {
          invalidCommand( fp );
          valid = false;
          break;
        }
        
        // Checks that there are no conflicts with the word and the current
        // words on the board
        if (sb->board[row][col + i] != ' ' && sb->board[row][col + i] != word[i]) {
          invalidCommand( fp );
          valid = false;
          break;
        }
      }
      
      // If the word was not valid, releases the lock and moves on
      if (!valid) {
        sem_post(&lock);
        continue;
      }
      
      // Valid word. Puts word on the board and releases the lock
      for (int i = 0; i < len; i++) {
        sb->board[row][col + i] = word[i];
      }
      sem_post(&lock);
    }
    // down command, functions very similarly to the across command
    else if (strcmp(cmd, "down") == 0) {
      // Reads in and error checks the row
      int num = fscanf( fp, "%d", &row);
      if (num != 1 || row < 0 || row >= sb->rows ) {
        invalidCommand( fp );
        continue;
      }
      
      // Reads in and error checks the column
      num = fscanf( fp, "%d", &col);
      if (num != 1 || col < 0 || col >= sb->cols ) {
        invalidCommand( fp );
        continue;
      }
      
      // Reads in and error checks the word
      num = fscanf( fp, "%27s", word);
      if (num != 1 || word[26] != '\0') {
        invalidCommand( fp );
        continue;
      }
      
      // Checks that the word does not go out of the
      // scrabble board boundaries
      int len = strlen(word);
      if (row + len > sb->rows) {
        invalidCommand( fp );
        continue;
      }
      
      bool valid = true;
      // Waits for the lock to be given up on the scrabble board
      // so that this thread can access it
      sem_wait(&lock);
      // Loop to error check the word further
      for (int i = 0; i < len; i++) {
        // Checks that the word contains valid characters
        if (word[i] < 'a' || word[i] > 'z') {
          invalidCommand( fp );
          valid = false;
          break;
        }
        
        // Checks that the word characters do not conflict with the
        // current words on the scrabble board
        if (sb->board[row + i][col] != ' ' && sb->board[row + i][col] != word[i]) {
          invalidCommand( fp );
          valid = false;
          break;
        }
      }
      
      // If the word is invalid, give up the lock and move on
      if (!valid) {
        sem_post(&lock);
        continue;
      }
      
      // Valid word. Puts the word on the board and releases the lock
      for (int i = 0; i < len; i++) {
        sb->board[row + i][col] = word[i];
      }
      sem_post(&lock);
    }
    // print out board command
    else if (strcmp(cmd, "board") == 0) {
      // Creates a string array of the board rows
      char str[sb->rows + 2][sb->cols + 4];
      
      // Adds dashes ('-') to the top and bottom row
      for (int i = 1; i < sb->cols + 1; i++) {
        str[0][i] = '-';
        str[sb->rows + 1][i] = '-';
      }
      
      // Waits for the lock to be released on the board
      // so this thread can access it
      sem_wait(&lock);
      // Reads in the data of the board and assigns it
      // to the string as well as padding the outsides
      // wish '|' and newline and null terminators
      // so each row of str can be printed out as a string
      for (int i = 1; i < sb->rows + 1; i++) {
        for (int j = 0; j < sb->cols + 3; j++) {
          if (j == 0 || j == sb->cols + 1) {
            str[i][j] = '|';
          }
          else if (j == sb->cols + 2) {
            str[i][j] = '\n';
            str[i][j + 1] = '\0';
          }
          else {
            str[i][j] = sb->board[i - 1][j - 1];
          }
        }
      }
      // Releases the lock on the scrabble board
      sem_post(&lock);
      
      // Adds '+' and ends the top and bottom rows
      // with newline and null terminators
      str[0][0] = '+';
      str[0][sb->cols + 1] = '+';
      str[0][sb->cols + 2] = '\n';
      str[0][sb->cols + 3] = '\0';
      
      str[sb->rows + 1][0] = '+';
      str[sb->rows + 1][sb->cols + 1] = '+';
      str[sb->rows + 1][sb->cols + 2] = '\n';
      str[sb->rows + 1][sb->cols + 3] = '\0';
      
      // Prins out each row of the str array as a string
      for (int i = 0; i < sb->rows + 2; i++) {
        fprintf(fp, "%s", str[i]);
      }
      
    }
    // invalid command
    else {
      invalidCommand( fp );
    }
    // flushes the io
    fflush(fp);
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  // detaches the thread from the main thread
  pthread_detach(pthread_self());
  return NULL;
}

// Main method
int main( int argc, char *argv[] ) {
  
  // error checking number of command line args
  if (argc != 3) {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  
  // Mallocs space for a new scrabble board
  sb = (ScrabbleBoard *)malloc(sizeof(ScrabbleBoard));
  
  // Parses the row and column values from the command line args
  sb->rows = atoi(argv[1]);
  sb->cols = atoi(argv[2]);
  // Error checks the row and col values
  if (sb->rows < 1 || sb->cols < 1) {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  
  // Mallocs space for each row of the scrabble board
  sb->board = (char **)malloc(sizeof(char *) * sb->rows);
  for (int i = 0; i < sb->rows; i++) {
    sb->board[i] = (char *)malloc(sb->cols);
  }
  
  // Initializes each space of the scrabble board to blank
  for (int i = 0; i < sb->rows; i++) {
    for (int j = 0; j < sb->cols; j++) {
      sb->board[i][j] = ' ';
    }
  }
  
  // Initializes the lock semaphor
  sem_init(&lock, 0, 1);
  
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  // Tells the program to call the signalHandler method if ^C is pressed
  signal(SIGINT, signalHandler);

  while ( true ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_t clientThread;
    if ( pthread_create( &clientThread, NULL, handleClient, (void *)(&sock) ) != 0 ) 
      fail( "Can't create a client thread" );
  }
  
  return 0;
}
