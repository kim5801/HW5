#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

//declarations
void setup(int row, int col);
char *readLine(FILE *fp);
void printBoard();
void processCommand(FILE *ptr, char *cmd);
void drawAcross(FILE *fp, char *cmd);
void drawDown(FILE *fp, char *cmd);

/** Port number used by my server */
#define PORT_NUMBER "26274"

/** Maximum word length */
#define WORD_LIMIT 26

//semaphore for synchronization
sem_t spinlock;

//main board used by the game
char **board;
int totalRows;
int totalCols;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *args ) {
  //conversion from void pointer
  int *sockptr = (int *) args;
  int sock = *sockptr;
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char *cmd;
  // read in the client input
  cmd = readLine(fp);
  while (cmd != NULL && strcmp( cmd, "quit" ) != 0 ) {
    // Just echo the command back to the client for now.
    //fprintf( fp, "%s\n", cmd );
    //allow other thread to process command
    sem_wait(&spinlock);
    //perform the command the user requested
    processCommand(fp, cmd);
    //unlock the semaphore
    sem_post(&spinlock);
    // Prompt the user for the next command.
    free(cmd);
    fprintf( fp, "cmd> " );
    cmd = readLine(fp);
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  //check for proper user input
  if(argc != 3){
    fail("usage: scrabbleServer <rows> <cols>");
  }
  if(atoi(argv[1]) == 0 || atoi(argv[2]) == 0) fail("usage: scrabbleServer <rows> <cols>");
  //create the gamebox
  setup(atoi(argv[1]), atoi(argv[2]));

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  //initialize the semaphore
  sem_init(&spinlock, 0, 1);

  while ( true  ) {
    pthread_t clientThread;
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    pthread_create(&clientThread, NULL, handleClient, &sock);
    pthread_detach(clientThread);
    //handleClient( sock );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}

//create the board based on the user parameters
void setup(int row, int col)
{
  //include spacing for border
  row += 2;
  col += 2;
  totalRows = row;
  totalCols = col;
  //initiate the board
  board = (char **) malloc(sizeof(char *) * row);
  for(int i=0; i<row; i++){
    board[i] = (char *) malloc(sizeof(char) * col);
    //memset(&board[i], '\0', sizeof(board[i]));
  }
  //create the border
  for(int i=0; i<row; i++){
    for(int j=0; j<col; j++){
      if(i == 0 || i == row-1){
        if(j == 0 || j == col-1){
          board[i][j] = '+';
          continue;
        }
        board[i][j] = '-';
        continue;
      }
      if(j == 0 || j == col-1){
        board[i][j] = '|';
        continue;
      }
      board[i][j] = ' ';
    }
  }
  //debugging only
  //printBoard();
}

//prints out the board state
void printBoard(FILE *fp)
{
  for(int i=0; i<totalRows; i++){
    for(int j=0; j<totalCols; j++){
      fprintf(fp, "%c", *(board[i]+j));
    }
    fprintf(fp, "\n");
  }
}
//reads input from the netcat server side
//prevents buffer overflow
char *readLine(FILE *fp)
{
    char ch = fgetc(fp);
    if(ch == EOF || ch == '\n'){
        return NULL;
    }
    char *array = (char *) malloc(sizeof(char) * 10);
    int cap = 10;
    int index = 0;
    array[index] = ch;
    while(ch != '\n' && ch != EOF){
        ch = fgetc(fp);
        if(index >= cap){
            //over bounds
            array = (char *) realloc(array, 2 * cap);
            cap = cap * 2;
        }
        index++;
        array[index] = ch;
        
    }
    array[index++] = '\0';
    return array;
}

//parse the command given by the user and perform needed function
void processCommand(FILE *ptr, char *cmd)
{
  if(strcmp("board", cmd) == 0) printBoard(ptr);
  else if(strncmp("across ", cmd, 7) == 0) drawAcross(ptr, cmd);
  else if(strncmp("down ", cmd, 5) == 0) drawDown(ptr, cmd);
  else fprintf(ptr, "Invalid command\n");
}

//draws the word in the board across
void drawAcross(FILE *fp, char *cmd)
{
  int offset = 7;
  int row = 0;
  int col = 0;
  char *word = (char *) malloc(sizeof(cmd));
  //clear out the word array
  //memset(word, '\0', sizeof(&cmd));
  //find the row number
  for(int i=offset; cmd[i]; i++){
    if(cmd[i] >= '0' && cmd[i] <= '9'){
      //convert from char to int
      int temp = atoi(&cmd[i]);
      row *= 10;
      row += temp;
    }
    else if(cmd[i] == ' '){
      offset = i+1;
      break;
    } else{
      //break out of the function call
      fprintf(fp, "Invalid command\n");
      return;
    }
  }
  //find the column number
  for(int i=offset; cmd[i]; i++){
    if(cmd[i] >= '0' && cmd[i] <= '9'){
      //convert from char to int
      int temp = atoi(&cmd[i]);
      col *= 10;
      col += temp;
    }
    else if(cmd[i] == ' '){
      offset = i+1;
      break;
    } else{
      fprintf(fp, "Invalid command\n");
      return;
    }
  }
  //fix the row and col offsets
  if(row > 9) row /= 10;
  if(col > 9) col /= 10;
  //check for valid ranges
  if(row >= totalRows-2 || row < 0){
    fprintf(fp, "Invalid command\n");
    return;
  }
  if(col >= totalCols-2 || col < 0){
    fprintf(fp, "Invalid command\n");
    return;
  }
  //find the word itself
  int cursor = 0;
  for(int i=offset; cmd[i]; i++){
    if(cmd[i] == ' ' || cmd[i] == '\n')
    break;
    word[cursor] = cmd[i];
    cursor++;
  }
  word[cursor] = '\0';
  //check for uppercase letters
  for(int i=0; word[i]; i++){
    if(word[i] >= 'A' && word[i] <= 'Z'){
      fprintf(fp, "Invalid command\n");
      return;
    }
  }
  //debugging only
  //fprintf(fp, "row: %d col: %d word: %s|\n", row, col, word);
  //place it into the board
  int wordlen = strlen(word);
  //check if it goes off the board
  if(wordlen + col > totalCols - 2){
    fprintf(fp, "Invalid command\n");
    return;
  }
  //fix the offset for placement
  row++;
  col++;
  //board[row][col] = 'x';
  //make sure the word doesn't overlap
  int index = 0;
  for(int i=0; i<wordlen; i++){
    if(board[row][i+col] != word[index] && board[row][i+col] != ' '){
      fprintf(fp, "Invalid command\n");
      return;
    }
    index++;
  }
  //reset the index counter
  index = 0;
  //place in the word
  for(int i=0; i<wordlen; i++){
    board[row][i+col] = word[index];
    index++;
    //debugging only
    //board[row][i] = 'x';
  }
}

//draws the word in the board down
void drawDown(FILE *fp, char *cmd)
{
  int offset = 5;
  int row = 0;
  int col = 0;
  char *word = (char *) malloc(sizeof(cmd));
  //clear out the word array
  //memset(word, '\0', sizeof(&cmd));
  //find the row number
  for(int i=offset; cmd[i]; i++){
    if(cmd[i] >= '0' && cmd[i] <= '9'){
      //convert from char to int
      int temp = atoi(&cmd[i]);
      row *= 10;
      row += temp;
    }
    else if(cmd[i] == ' '){
      offset = i+1;
      break;
    } else{
      //break out of the function call
      fprintf(fp, "Invalid command\n");
      return;
    }
  }
  //find the column number
  for(int i=offset; cmd[i]; i++){
    if(cmd[i] >= '0' && cmd[i] <= '9'){
      //convert from char to int
      int temp = atoi(&cmd[i]);
      col *= 10;
      col += temp;
    }
    else if(cmd[i] == ' '){
      offset = i+1;
      break;
    } else{
      fprintf(fp, "Invalid command\n");
      return;
    }
  }
  //fix the row and col offsets
  if(row > 9) row /= 10;
  if(col > 9) col /= 10;
  //check for valid ranges
  if(row >= totalRows-2 || row < 0){
    fprintf(fp, "Invalid command\n");
    return;
  }
  if(col >= totalCols-2 || col < 0){
    fprintf(fp, "Invalid command\n");
    return;
  }
  //find the word itself
  int cursor = 0;
  for(int i=offset; cmd[i]; i++){
    if(cmd[i] == ' ' || cmd[i] == '\n')
    break;
    word[cursor] = cmd[i];
    cursor++;
  }
  word[cursor] = '\0';
  //check for uppercase letters
  for(int i=0; word[i]; i++){
    if(word[i] >= 'A' && word[i] <= 'Z'){
      fprintf(fp, "Invalid command\n");
      return;
    }
  }
  //debugging only
  //fprintf(fp, "row: %d col: %d word: %s|\n", row, col, word);
  //place it into the board
  int wordlen = strlen(word);
  //check if it goes off the board
  if(wordlen + row > totalRows - 2){
    fprintf(fp, "Invalid command\n");
    return;
  }
  //fix the offset for placement
  row++;
  col++;
  //board[row][col] = 'x';
  //make sure the word doesn't overlap
  int index = 0;
  for(int i=0; i<wordlen; i++){
    if(board[i+row][col] != word[index] && board[i+row][col] != ' '){
      fprintf(fp, "Invalid command\n");
      return;
    }
    index++;
  }
  //reset the index counter
  index = 0;
  //place in the word
  for(int i=0; i<wordlen; i++){
    board[i+row][col] = word[index];
    index++;
    //debugging only
    //board[i][col] = 'x';
  }
}