/**
 * @file scrabbleServer.c
 * @author Ethan Treece (eltreece)
 * 
 * The scrabbleServer.c program is the server portion of a  multi-threaded Unix client/server in C
 * using TCP/IP sockets for communication. The server lets users view and update 2D game board
 * containing lower case letters (blank spaces, like a scrabble board). A user will be able to add
 * words to the board, going vertically or horizontally, but letters of any new words must match 
 * existing letters for words that have already been placed on the board.
 * 
 */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>



/** Port number used by my server */
#define PORT_NUMBER "26258"

/** Maximum word length */
#define WORD_LIMIT 26

/**
 * Structure used for passing an argument to a thread
 * 
 */
typedef struct Argstruct {
  int x;
  char **y;
} ArgStruct;

// Board row count
int row = 0;

// Board column count
int col = 0;

/**Semaphore for printing the board **/
sem_t printing;

/**Semaphore for writing onto the board **/
sem_t writing;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf(stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Prints a usage statement and exits
static void usage() {
  fail("usage: scrabbleServer <rows> <cols>\n");
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *arg) {

  int sock;
  char **board;

  // Cast the arg ptr
  ArgStruct *astruct = (ArgStruct *)arg;
  sock = astruct->x;
  board = astruct->y;

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf(fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while (  fscanf( fp, "%10s", cmd) == 1 && 
          strcmp( cmd, "quit" ) != 0 ) {

    if (strcmp(cmd, "board") == 0) {
      sem_wait(&printing);
      for (int i = -1; i < row + 1; i++) {
        for (int j = -1; j < col + 1; j++) {
          if (i == -1 && j == -1) { // top left corner
            fprintf(fp, "+");
          } else if (i == -1 && j == col) { // top right corner
            fprintf(fp, "+");
          } else if (i == row && j == -1) { // botton left corner
            fprintf(fp, "+");
          } else if (i == row && j == col) { // botton right corner
            fprintf(fp, "+");
          } else if (i == -1) { // top border
            fprintf(fp, "-");
          } else if (i == row) { //bottom border
            fprintf(fp, "-");
          } else if (j == -1) { // left border
            fprintf(fp, "|");
          } else if (j == col) { // right border
            fprintf(fp, "|");
          }
          if (i > -1 && j > -1 && i < row && j < col) {
            fprintf(fp, "%c", board[i][j]);
          }
        }
        fprintf(fp, "\n");
      }
      sem_post(&printing);
    } else {

      // Get the rest of the values (r c word)
      int rowInput;
      int colInput;
      char word[WORD_LIMIT + 2];
      fscanf(fp, "%d%d%s", &rowInput, &colInput, word);

      for (int i = 0; i < WORD_LIMIT + 1; i++) {
        if (word[i] == '\0')
          break;
        if (word[i] < 97 || word[i] > 122) {
          goto invalid_command;
        }
      }
      int wordLength = strlen(word);
      // Word too long
      if (wordLength > WORD_LIMIT) {
        goto invalid_command;
      }
      // Word position starts off the board
      if (rowInput > row || colInput > col) {
        goto invalid_command;
      }
      
      sem_wait(&printing);

      if (strcmp(cmd, "across") == 0) {
        // Word too long for the board
        if (colInput + wordLength > col) {
          sem_post(&printing);
          goto invalid_command;
        }
        // Word contents invalid with the board contents
        for (int i = colInput; i < colInput + wordLength; i++) {
          if (board[rowInput][i] != ' ' && board[rowInput][i] != word[i - colInput]) {
            sem_post(&printing);
            goto invalid_command;
          }
        }
        // VALID - input characters
        for (int i = colInput; i < colInput + wordLength; i++) {
          board[rowInput][i] = word[i - colInput];
        }
      } else if (strcmp(cmd, "down") == 0) {
        // Word too long for the board
        if (rowInput + wordLength > row) {
          sem_post(&printing);
          goto invalid_command;
        }
        // Word contents invalid with the board contents
        for (int i = rowInput; i < rowInput + wordLength; i++) {
          if (board[i][colInput] != ' ' && board[i][colInput] != word[i - rowInput]) {
            sem_post(&printing);
            goto invalid_command;
          }
        }
        // VALID - input characters
        for (int i = rowInput; i < rowInput + wordLength; i++) {
          board[i][colInput] = word[i - rowInput];
        }
      }

      sem_post(&printing);

    } 

    goto valid_command;

    invalid_command:
    fprintf(fp, "Invalid command\n");
    valid_command:

    cmd[0] = '\0';

    // Prompt the user for the next command.
    fprintf(fp, "cmd> " );
  }

  free(astruct);
  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  // Ensure command-line args are valid 
  if (argc != 3) {
    usage();
  }
  row = atoi(argv[1]);
  col = atoi(argv[2]);
  if (row <= 0 || col <= 0) {
    usage();
  }

  // Initialize semaphores
  sem_init(&printing, 0, 1);
  sem_init(&writing, 0, 1);

  // Allocate space for the board
  char **board = (char **) calloc(row, sizeof(char *));
  for (int i = 0; i < row; i++) {
    board[i] = (char *) calloc(col, sizeof(char));
  }

  // Initialize the board
  for (int i = 0; i < row; i++) {
    for (int j = 0; j < col; j++) {
      board[i][j] = ' ';
    }
  }


  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  pthread_t thread_id;

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    ArgStruct *astruct = (ArgStruct *)malloc(sizeof(ArgStruct));
    astruct->x = sock;
    astruct->y = board;

    if (pthread_create(&thread_id, NULL, handleClient, astruct) < 0) {
      fail("Cannot not create thread");
    }

    // handleClient( sock, board );
  }

  // Free the board
  for (int i = 0; i < row; i++)
  {
      free(board[i]);
  }
  free(board);

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0; 
}