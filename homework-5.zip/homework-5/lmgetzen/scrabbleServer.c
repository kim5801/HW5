#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26146"

/** Maximum word length */
#define WORD_LIMIT 26

/**Semaphore for changing board **/
sem_t changing;



// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(EXIT_FAILURE);
}

//initialize beginning of board
void initBoard(int rowSize, int colSize, char board[rowSize][colSize]) {

    board[0][0] = '+';
    board[0][colSize - 1] = '+';
    board[rowSize - 1][0] = '+';
    board[rowSize - 1][colSize - 1] = '+';
    
    //initialize the entire board to empty spaces
    for (int i = 1; i < rowSize - 1; i++) {
        for (int j = 1; j < colSize - 1; j++) {
            board[i][j] = ' ';
        }
    }


    //initalize the sides of the board 
    for (int i = 1; i < rowSize - 1 ; i++) {
        for (int j = 1; j < colSize - 1; j++) {
            board[i][0] = '|';
            board[i][colSize - 1] = '|';
            board[0][j] = '-';
            board[rowSize - 1][j] = '-';
        }
    }

}

//method for making a move on the board whether it be down or across
void makeMove(int row, int col, char str[], bool across, int rowSize, int colSize, char board[rowSize][colSize], FILE *fp) {


    //check to see if string is lowercase
    for (int i = 0; i < strlen(str); i++) {
        if (!islower(str[i])) {
            fprintf(fp, "Invalid command\n");
            return;
        }
    }

    //make sure the string doesn't go off the board
    if (row + 1 < 1 || row + 1 > rowSize - 1 || col + 1 < 1 || col + 1 > colSize - 1) {
        fprintf(fp, "Invalid command\n");
        return;
    }
        
    //if command is for across
    if (across) {

        //check to see if the command falls off the board
        if ((col + strlen(str)) > colSize - 1){
            fprintf(fp, "Invalid command\n");
            return;
        }

        //make sure that string are either blank or connect
        for (int i = col + 1; i < col + 1 + strlen(str); i++) {
            if (board[row + 1][i] != ' ' && board[row + 1][i] != str[i - col - 1]) {
                fprintf(fp, "Invalid command\n");
                return;
            }
        }
        

        //set the board to the string as long as its an open space or its letters correspond
        for (int i = col + 1; i < col + 1 + strlen(str); i++) {
            board[row + 1][i] = str[i - col - 1];
        }

    }

    //if command is for down
    if (!across) {
        //make sure it doesn't fall off board
        if ((row + strlen(str)) > rowSize - 1){
            fprintf(fp, "Invalid command\n");
            return;
        }

        //make sure that strings are either in open space or connecting word
        for (int i = row + 1; i < row + 1 + strlen(str); i++) {
            if (board[i][col + 1] != ' ' && board[i][col + 1] != str[i - row - 1]) {
                fprintf(fp, "Invalid command\n");
                return;
            }
        }
         //set the board to the string as long as its an open space or its letters correspond
        for (int i = row + 1; i < row + 1 + strlen(str); i++) {
            board[i][col + 1] = str[i - row - 1];    
        }
    }
    
}

/** handle a client connection, close it when we're done. */
void *handleClient(int sock, int rowSize, int colSize, char board[rowSize][colSize])
{
    // Here's a nice trick, wrap a C standard IO FILE around the
    // socket, so we can communicate the same way we would read/write
    // a file.
    FILE *fp = fdopen(sock, "a+");

    initBoard(rowSize, colSize, board);

    // Prompt the user for a command.
    fprintf(fp, "cmd> ");

    // Temporary values for parsing commands.
    char cmd[11];
    while (fscanf(fp, "%10s", cmd) == 1 &&
           strcmp(cmd, "quit") != 0)
    {
        // Just echo the command back to the client for now.
        // fprintf(fp, "%s\n", cmd);


        //error check
        for (int i = 0; i < strlen(cmd); i++) {
            if (!islower(cmd[i])) {
                printf("Invalid command");
                break;
            }
        }

        //if command is across
        if (strcmp("across", cmd) == 0) {

            //wait for multiple clients
            sem_wait(&changing);

            //read in moves and string
            int rowMove;
            int colMove;
            char str[26];
            fscanf(fp, "%d%d%s", &rowMove, &colMove, str);
            //make the move on the board with error checks within the method
            makeMove(rowMove, colMove, str, true, rowSize, colSize, board, fp);
            //let other clients know they're good to work
            sem_post(&changing);

        }
        
        //if command is across
        if (strcmp("down", cmd) == 0) {
            //wait for multiple clients
            sem_wait(&changing);
            //read in moves and string
            int rowMove;
            int colMove;
            char str[26];
            fscanf(fp, "%d%d%s", &rowMove, &colMove, str);
            //make the move on the board with error checks within the method
            makeMove(rowMove, colMove, str, false, rowSize, colSize, board, fp);
            //let other clients know they're good to work
            sem_post(&changing);

        }

        //if command is board
        if (strcmp("board", cmd) == 0) {

            //go through array and print out the board
            for (int i = 0; i < rowSize; i++) {
                for (int j = 0; j < colSize; j++) {
                    fprintf(fp, "%c", board[i][j]);
                }
                //print new line for each row in grid
                fprintf(fp, "\n");
            }
        }

        // Prompt the user for the next command.
        fprintf(fp, "cmd> ");

    }

    // Close the connection with this client.
    fclose(fp);
    return NULL;
}

int main(int argc, char *argv[])
{

    sem_init(&changing, 0, 1);

    // Prepare a description of server address criteria.
    struct addrinfo addrCriteria;
    memset(&addrCriteria, 0, sizeof(addrCriteria));
    addrCriteria.ai_family = AF_INET;
    addrCriteria.ai_flags = AI_PASSIVE;
    addrCriteria.ai_socktype = SOCK_STREAM;
    addrCriteria.ai_protocol = IPPROTO_TCP;

    // Lookup a list of matching addresses
    struct addrinfo *servAddr;
    if (getaddrinfo(NULL, PORT_NUMBER, &addrCriteria, &servAddr))
        fail("Can't get address info");

    // Try to just use the first one.
    if (servAddr == NULL)
        fail("Can't get address");

    // Create a TCP socket
    int servSock = socket(servAddr->ai_family, servAddr->ai_socktype,
                          servAddr->ai_protocol);
    if (servSock < 0)
        fail("Can't create socket");

    // Bind to the local address
    if (bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0)
        fail("Can't bind socket");

    // Tell the socket to listen for incoming connections.
    if (listen(servSock, 5) != 0)
        fail("Can't listen on socket");

    // Free address list allocated by getaddrinfo()
    freeaddrinfo(servAddr);

    // Fields for accepting a client connection.
    struct sockaddr_storage clntAddr; // Client address
    socklen_t clntAddrLen = sizeof(clntAddr);

    //thread for multiple clients
    pthread_t threads;

    while (true)
    {

        // Accept a client connection.
        int sock = accept(servSock, (struct sockaddr *)&clntAddr, &clntAddrLen);
        
        int rowSize = atoi(argv[1]);
        int colSize = atoi(argv[2]);
        char board[rowSize + 2][colSize + 2];

        //create threads for multiple clients to work
        if( pthread_create( &threads , NULL ,  handleClient(sock, rowSize + 2, colSize + 2, board) , (void*) &sock) < 0) {
            perror("thread fail");
            return 1;
        }

    }

    // Stop accepting client connections (never reached).
    close(servSock);

    return 0;
}
