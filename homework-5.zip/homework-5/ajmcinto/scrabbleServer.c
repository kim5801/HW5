#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** the maximum size of an array of valid words */
#define MAX_WORDSARR_SIZE 100000

/** the number of chars used between lines in the board string, a bar, a newline, and another bar*/
#define GRID_OFFSET 3

/** Port number used by my server */
#define PORT_NUMBER "26168"

/** Maximum word length */
#define WORD_LIMIT 26

/**
 * Struct for representing a Scrabble board 
 */
typedef struct {

  //the number of rows and columns in the board
  int rows;
  int cols;

  /** an array for the gameBoard, stored as a single pointer */
  char* boardArr;

  /** tells whether or not the board is using a words file */
  bool hasWords;

  /** An array of valid words */
  char** wordsArr;

  /** the number of words in wordsArr */
  int wordsCount;

} Board;

//a lock for accessing the game board
pthread_mutex_t boardLock;

//the game board
Board* game;

/**
 * Determine whether or not a word is in the words file
 * 
 * @param word the word being checked
 * @param board the board with the words list
 * @return true 
 * @return false 
 */
bool inDictionary(char* word, Board* board) {
  //inDictionary is only called by functions that have acquired the board lock,
  //so it does not need to acquire the lock (in fact, we will deadlock if it does without
  //extra conditions)
  //linear search should be fine for now
  for (int i = 0; i < board->wordsCount; i++) {
    if (strcmp(board->wordsArr[i], word) == 0) {
      return true;
    }
  }
  return false;
}

/**
 * Determines whether or not the board contains words that are not real words
 * 
 * @param board the board whose words are to be checked
 * @return whether or not all words on the board are valid
 */
bool checkWords(Board* board) {
  //checkWords is only called by functions that have acquired the board lock,
  //so it does not need to acquire the lock (in fact, we will deadlock if it does without
  //extra conditions)
  if (board->hasWords == false) {
    return true;
  }
  else {
    //check all horizontal words
    //for each row
    for (int row = 0; row < board->rows; row++) {
      char* currWord = (char *)malloc(sizeof(char) * (board->cols + 1));
      int currWordLen = 0;
      int colIndex = 0;
      while (colIndex < board->cols) {
        char currChar = board->boardArr[row * board->cols + colIndex];
        if (currChar == ' ') {
          if (currWordLen > 1) {
            //we just finished seeing a word, let's see if it is in the dictionary
            currWord[currWordLen] = '\0';
            if (!inDictionary(currWord, board)) {
              free(currWord);
              return false;
            }
          }
          //reset currWord (don't actually need to change memory, just reset the length)
          currWordLen = 0;
        }
        else {
          currWord[currWordLen++] = currChar;
        }
        colIndex++;
      }
      //check if our word ended at the end of the board (no space afterward)
      if (colIndex == board->cols && currWordLen > 1) {
        currWord[currWordLen] = '\0';
        if (!inDictionary(currWord, board)) {
          free(currWord);
          return false;
        }
      }
      free(currWord);
    }

    //check all vertical words
    //for each column
    for (int col = 0; col < board->cols; col++) {
      char* currWord = (char *)malloc(sizeof(char) * (board->rows + 1));
      int currWordLen = 0;
      int rowIndex = 0;
      while (rowIndex < board->rows) {
        char currChar = board->boardArr[rowIndex * board->cols + col];
        if (currChar == ' ') {
          if (currWordLen > 1) {
            //we just finished seeing a word, let's see if it is in the dictionary
            currWord[currWordLen] = '\0';
            if (!inDictionary(currWord, board)) {
              free(currWord);
              return false;
            }
          }
          //reset currWord (don't actually need to change memory, just reset the length)
          currWordLen = 0;
        }
        else {
          currWord[currWordLen++] = currChar;
        }
        rowIndex++;
      }
      //check if our word ended at the end of the board (no space afterward)
      if (rowIndex == board->rows && currWordLen > 1) {
        currWord[currWordLen] = '\0';
        if (!inDictionary(currWord, board)) {
          free(currWord);
          return false;
        }
      }
      free(currWord);
    }
  }
  return true;
}

/**
 * Places a word going down from the starting location
 * 
 * @param fp a handle for the client making the move
 * @param board the board on which the move is to be made
 * @param r the row index of the move 
 * @param c the col index of the move
 */
void placeDown(FILE* fp, Board* board, int r, int c, char* word) {
  //lock the board
  pthread_mutex_lock(&boardLock);

  int len = strlen(word);

  //For the extra credit:
  //we will keep up with which tiles the command changes, so that it can revert these changes
  //if the board contains a word that is not real
  int changeCount = 0;
  int changes[len];
  for (int i = 0; i < len; i++) {
    if (board->boardArr[r * board->cols + c + (i * board->cols)] != word[i]) {
      changes[changeCount++] = i;
    }
    board->boardArr[r * board->cols + c + (i * board->cols)] = word[i];
  }
  //if the board has become invalid, revert changes
  if (!checkWords(board)) {
    fprintf(fp, "Invalid command\n");
    for (int i = 0; i < changeCount; i++) {
      board->boardArr[r * board->cols + c + (changes[i] * board->cols)] = ' ';
    }
  }
  //unlock the board
  pthread_mutex_unlock(&boardLock);
}

/**
 * Places a word going across from the starting location
 * 
 * @param fp a handle for the client making the move
 * @param board the board on which the move is to be made
 * @param r the row index of the move 
 * @param c the col index of the move
 */
void placeAcross(FILE* fp, Board* board, int r, int c, char* word) {
  //lock the board
  pthread_mutex_lock(&boardLock);

  int len = strlen(word);

  //For the extra credit:
  //we will keep up with which tiles the command changes, so that it can revert these changes
  //if the board contains a word that is not real
  int changeCount = 0;
  int changes[len];
  for (int i = 0; i < len; i++) {
    if (board->boardArr[r * board->cols + c + i] != word[i]) {
      changes[changeCount++] = i;
    }
    board->boardArr[r * board->cols + c + i] = word[i];
  }
  //if the board has become invalid, revert changes
  if (!checkWords(board)) {
    fprintf(fp, "Invalid command\n");
    for (int i = 0; i < changeCount; i++) {
      board->boardArr[r * board->cols + c + changes[i]] = ' ';
    }
  }
  //unlock the board
  pthread_mutex_unlock(&boardLock);
}


/**
 * Determine whether or not a downward word placement is valid
 * 
 * @param board the game board on which the word is to be placed
 * @param r the row index of the word
 * @param c the col index of the word
 * @param word the word to be placed
 * @return whether or not the word can be placed
 */
bool validateDown(Board* board, int r, int c, char* word) {
  //lock the board
  pthread_mutex_lock(&boardLock);
  //is the location off the board
  if (r < 0 || c < 0 || r > board->rows - 1 || c > board->cols - 1) {
    //unlock the board
    pthread_mutex_unlock(&boardLock);
    return false;
  }
  //does the word extend off of the board
  int len = strlen(word);
  if (r + len > board->rows) {
    //unlock the board
    pthread_mutex_unlock(&boardLock);
    return false;
  }
  //does the word have an invalid length
  if (len < 1 || len > WORD_LIMIT) {
    //unlock the board
    pthread_mutex_unlock(&boardLock);
    return false;
  }
  //does the word contain invalid characters or any characters that disagree with the board
  for (int i = 0; word[i]; i++) {
    if (word[i] > 'z' || word[i] < 'a') {
      //unlock the board
      pthread_mutex_unlock(&boardLock);
      return false;
    }
    if (word[i] != board->boardArr[r * board->cols + c + (i * board->cols)] && board->boardArr[r * board->cols + c + (i * board->cols)] != ' ') {
      //unlock the board
      pthread_mutex_unlock(&boardLock);
      return false;
    }
  }
  //unlock the board
  pthread_mutex_unlock(&boardLock);
  return true;
}

/**
 * Determine whether or not a horizontal word placement is valid
 * 
 * @param board the game board on which the word is to be placed
 * @param r the row index of the word
 * @param c the col index of the word
 * @param word the word to be placed
 * @return whether or not the word can be placed
 */
bool validateAcross(Board* board, int r, int c, char* word) {
  //lock the board
  pthread_mutex_lock(&boardLock);
  //is the location off the board
  if (r < 0 || c < 0 || r > board->rows - 1 || c > board->cols - 1) {
    //unlock the board
    pthread_mutex_unlock(&boardLock);
    return false;
  }
  //does the word extend off of the board
  int len = strlen(word);
  if (c + len > board->cols) {
    //unlock the board
    pthread_mutex_unlock(&boardLock);
    return false;
  }
  //does the word have an invalid length
  if (len < 1 || len > WORD_LIMIT) {
    //unlock the board
    pthread_mutex_unlock(&boardLock);
    return false;
  }
  //does the word contain invalid characters or any characters that disagree with the board
  for (int i = 0; word[i]; i++) {
    if (word[i] > 'z' || word[i] < 'a') {
      //unlock the board
      pthread_mutex_unlock(&boardLock);
      return false;
    }
    if (word[i] != board->boardArr[r * board->cols + c + i] && board->boardArr[r * board->cols + c + i] != ' ') {
      //unlock the board
      pthread_mutex_unlock(&boardLock);
      return false;
    }
  }
  //unlock the board
  pthread_mutex_unlock(&boardLock);
  return true;
}


/**
 * Retrieves a string representation of a board
 * 
 * @param board the board for which a string representation is desired
 * @return char* the string representation of the board
 */
char* getBoardString(Board* board) {
  //lock the board
  pthread_mutex_lock(&boardLock);

  //allocate room for the string, with an extra rows * 3 spaces for newlines and vertical bars and an extra character for null terminator
  //2 is added to board->rows because of the top and bottom rows
  char* str = (char*)malloc(sizeof(char) * (board->rows + 2) * (board->cols + GRID_OFFSET) + 1);

  //set the top and bottom border
  for (int i = 1; i < board->cols + 1; i++) {
    str[i] = '-';
    str[(board->rows + 1) * (board->cols + 3) + i] = '-';
  }
  str[board->cols + 2] = '\n';
  str[0] = '+';
  str[board->cols + 1] = '+';
  str[(board->rows + 1) * (board->cols + GRID_OFFSET)] = '+';
  str[(board->rows + 1) * (board->cols + GRID_OFFSET) + board->cols + 1] = '+';

  //the board is not stored as 2d, so some math is required to get individual rows
  //a new row begins at every multiple of cols + 3 (since the bars and newlines make 3 extra characters)
  for (int row = 0; row < board->rows; row++) {
    for (int col = 0; col < board->cols; col++) {
      //plus 1 for cols because newlines are on each line
      //plus one for row to account for the top border
      str[(row + 1) * (board->cols + GRID_OFFSET) + col + 1] = board->boardArr[row * board->cols + col];
    }
    //add bars
    str[(row + 1) * (board->cols + GRID_OFFSET)] = '|';
    str[(row + 1) * (board->cols + GRID_OFFSET) + board->cols + 1] = '|';
    //add newline
    str[(row + 1) * (board->cols + GRID_OFFSET) + board->cols + 2] = '\n';
  }
  //add final newline and null terminator
  str[(board->rows + 1) * (board->cols + GRID_OFFSET) + board->cols + 2] = '\n';
  str[(board->rows + 1) * (board->cols + GRID_OFFSET) + board->cols + GRID_OFFSET] = '\0';

  //unlock the board
  pthread_mutex_unlock(&boardLock);

  return str;
}

/**
 * Reads a line from a file and returns it as one word
 * 
 * @param fp the file from which words are read
 * @return the word that is read, or null if EOF is hit 
 */
char *readWord(FILE *fp) {

    //allocate 2 extra characters, one to see if a word is too long and another for the null terminator
    char *word = (char *)malloc(sizeof(char) * (WORD_LIMIT + 2));

    int len = 0;
    char nextChar = NULL;

    //read in characters
    int matches = fscanf(fp, "%c", &nextChar);
    if (matches == EOF) {
        free(word);
        return NULL;
    }
    while (matches == 1) {
        if (nextChar == '\n') {
            break;
        }
        else {
          //do we have room for another character?
          if (len <= WORD_LIMIT) {
            //place the next character
            word[len] = nextChar;
            len++;
          }
        }
        matches = fscanf(fp, "%c", &nextChar);
    }
    if (matches == EOF) {
        return NULL;
    }
    word[len] = '\0';
    //return a pointer to the word
    return word;
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void* arg ) {
  int* sockP = (int *) arg;
  int sock = *sockP;

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    // // Just echo the command back to the client for now.
    // fprintf( fp, "%s\n", cmd );

    if (strcmp(cmd, "board") == 0) {
      // fprintf(fp, "rows: %d, cols: %d\n", game->rows, game->cols);
      char* str = getBoardString(game);
      fprintf(fp, "%s", str);
    }
    else if (strcmp(cmd, "down") == 0) {
      //we should have a word followed by two integers and another word
      char word[game->rows + game->cols];
      int r;
      int c;
      //get the next three words from the input
      if (fscanf(fp, "%d", &r) == 0)
        fprintf(fp, "Invalid command\n");
      else if (fscanf(fp, "%d", &c) == 0) 
        fprintf(fp, "Invalid command\n");
      //read up to 27 characters. We know that if all 27 get read in, the input is invalid.
      else if (fscanf(fp, "%27s", word) == 0 || strlen(word) > WORD_LIMIT)
        fprintf(fp, "Invalid command\n");
      else {
        if (validateDown(game, r, c, word)) {
          placeDown(fp, game, r, c, word);  
        }
        else {
          fprintf(fp, "Invalid command\n");
        }
      }
    }
    else if (strcmp(cmd, "across") == 0) {
      //we should have a word followed by two integers and another word
      char word[game->rows + game->cols];
      int r;
      int c;
      //get the next three words from the input
      if (fscanf(fp, "%d", &r) == 0)
        fprintf(fp, "Invalid command\n");
      else if (fscanf(fp, "%d", &c) == 0) 
        fprintf(fp, "Invalid command\n");
      //read up to 27 characters. We know that if all 27 get read in, the input is invalid.
      else if (fscanf(fp, "%27s", word) == 0 || strlen(word) > WORD_LIMIT)
        fprintf(fp, "Invalid command\n");
      else {
        if (validateAcross(game, r, c, word)) {
          placeAcross(fp, game, r, c, word);  
        }
        else {
          fprintf(fp, "Invalid command\n");
        }
      }
    }
    else {
      fprintf(fp, "Invalid command\n");
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  pthread_exit(NULL);
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  //parse command-line arguments
  if (argc != 3) {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  int rows;
  int cols;
  int ret1 = sscanf(argv[1], "%d", &rows);
  int ret2 = sscanf(argv[2], "%d", &cols);
  if (ret1 == 0 || ret2 == 0) {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  if (rows <= 0 || cols <= 0) {
    fail("usage: scrabbleServer <rows> <columns>");
  }

  //read in the words file if it exists
  FILE* wordsFile = fopen("./words.c", "r");
  char* wordsArr[MAX_WORDSARR_SIZE];
  int wordCount = 0;
  bool runAgain = true;
  if (wordsFile != NULL) {
    while (runAgain) {
      //read in a word from the file
      char* word = readWord(wordsFile);
      bool valid = true;
      if (word == NULL) {
        valid = false;
        runAgain = false;
      }
      else if (strlen(word) > WORD_LIMIT) {
        valid = false;
      }
      else {
        //verify that the characters are valid
        for (int i = 0; word[i]; i++) {
          if (word[i] < 'a' || word[i] > 'z') {
            valid = false;
          }
        }
      }
      if (valid)
        wordsArr[wordCount++] = word;
    }
  }

  //make a board
  game = (Board*)malloc(sizeof(Board));
  game->rows = rows;
  game->cols = cols;
  game->boardArr = (char*)malloc(sizeof(char) * rows * cols);
  if (wordsFile == NULL) {
    game->hasWords = false;
  }
  else {
    game->hasWords = true;
    game->wordsArr = wordsArr;
    game->wordsCount = wordCount;
  }
  //fill in boardArr with spaces
  for (int i = 0; i < rows * cols; i++) {
    game->boardArr[i] = ' ';
  }

  while ( true  ) {
    // Accept a client connection. 
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    //create a thread to handle this client
    pthread_t serverThread;
    int* sockArg = (int *)malloc(sizeof(int));
    *sockArg = sock;
    pthread_create(&serverThread, NULL, handleClient, sockArg);
  }
  
  //free the words list
  for (int i = 0; i < wordCount; i++) {
    free(wordsArr[i]);
  }

  //free the board array
  free(game->boardArr);

  //free the whole board
  free(game);

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return EXIT_SUCCESS;
}
