/**
 * @file scrabbleServer.c
 * @author Christina Albores (ccalbore@ncsu.edu)
 * @brief This program uses a multi-threaded Unix client/server program in C using TCP/IP
 * sockets for communication. The server will let users view and and update two-dimensional game board
 * containing lower case letters (and blank spaces, like a scrabble board). A user will be able to add
 * words to the board, going vertically or horizontally, but letters of any new words must match existing
 * letters for words that have already been placed on the board.
 * @version 0.1
 * @date 2022-11-16
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <semaphore.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26202"

/** Maximum word length */
#define WORD_LIMIT 26

/** A semaphore representing access to the state of the server */
sem_t boardState;
/** The number of rows the client can access */
int r = 0;
/** The number of columns the client can access */
int c = 0;
/** The actual rows of the board */
int boardR = 0;
/** The actual cols of the board */
int boardC = 0;
/** The 2D array that holds the board */
char** game = NULL;

/**
 * @brief Print out an error message and exit.
 * 
 * @param message the message to print to stderr
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/**
 * @brief Uses user input to set the game board based on the dimensions
 * 
 * @param boardR the actual board row size
 * @param boardC the actual board col size
 * @return char** return the set game board
 */
static char** createGame(int boardR, int boardC)
{
  // Set the values of the board by
  char* vals = calloc(boardC * boardR, sizeof(char));
  char** game = malloc(boardR * sizeof(char*));
  for (int i = 0; i < boardR; ++i) {
    game[i] = vals + i * boardC;
  }
  // Set the corners of the board to '+'
  game[0][0] = '+';
  game[0][boardC - 1] = '+';
  game[boardR - 1][0] = '+';
  game[boardR - 1][boardC - 1] = '+';
  
  // Fill the top, bottom, and sides of the board by row and col.
  // Set the top row
  for (int i = 1; i < boardC - 1; i++) {
    game[0][i] = '-';
  }
  // Set the bottom row
  for (int i = 1; i < boardC - 1; i++) {
    game[boardR - 1][i] = '-';
  }
  // Set the first column
  for (int i = 1; i < boardR - 1; i++) {
    game[i][0] = '|';
  }
  // Set the left column
  for (int i = 1; i < boardR - 1; i++) {
    game[i][boardC - 1] = '|';
  }

  // Fill the game board by row and column with ' ' spaces
  for (int i = 1; i < boardR - 1; i++)
  {
      for (int j = 1; j < boardC - 1; j++)
      {
          game[i][j] = ' ';
      }
  } 
    return game;
}

/**
 * @brief Checks if the given col and row are valid, and if the word is all lowercase letters.
 * 
 * @param game the 2D array game board 
 * @param boardR the actual board row size
 * @param boardC the actual board col size
 * @param r the row given
 * @param c the col given
 * @param word the word given
 * @return int returns 1 if successful and 0 if not
 */
static int checkHelper(char **game, int boardR, int boardC, int r, int c, char *word) {
  // Check that the col and row are in a valid range
  if (c >= boardC - 1|| r >= boardR - 1|| c < 0 || r < 0) {
      return 0;
  }
  
  // The length of the word
  int length = strlen(word);

  // Check that the word only contains lowercase letters
  for (int i = 0; i < length; i++) {
      if (!islower(word[i]) || !isalpha(word[i])) {
        return 0;
      }
  }

  return 1;
}

/**
 * @brief This command places a new word on the board going horizontally. The left end of the word starts
 * at the given row, r, and column, c, on the board. Both row number and column number start
 * from zero (the top row and left column of the board). The given word must be a sequence of 1 to
 * 26 lower-case letters. It is placed on the board, one character per location going right from the
 * starting location.
 * The command is invalid if the given location is off the board, if the word would extend beyond
 * the bounds of the board, if the word contains something other than lower-case letters or if the
 * one of the characters in the word disagrees with a character already placed on the board.
 * 
 * @param game the 2D array game board 
 * @param boardR the actual board row size
 * @param boardC the actual board col size
 * @param r the row given
 * @param c the col given
 * @param word the word given
 * @return int returns 1 if successful and 0 if not
 */
static int across(char **game, int boardR, int boardC, int r, int c, char *word) {

  // Use helper method to check board inputs
  int rtn = checkHelper(game, boardR, boardC, r, c, word);
  if (rtn == 0) {
    return 0;
  }
  // The length of the word
  int length = strlen(word);
  // Check that the length of the word does not start on or go off the board
  if ((length + c) >= boardC - 1) {
      return 0;
  }

  // Check that the word is placed in the correct place
  int idx = 0;
  for (int i = c + 1; i < length + c + 1; i++) {
      if (game[r + 1][i] != ' ') {
          if (game[r + 1][i] != word[idx]) {
            return 0;
          }
      }
      idx++;
  }
  // If command passes all tests, place the word
  idx = 0;
  for (int i = c + 1; i < length + c + 1; i++) {
      game[r + 1][i] = word[idx];
      idx++;
  }
  // Return 1 on success and return 0 on failure.
  return 1;
}

/**
 * @brief This command is like the across command, but it places a word going down from the given
 * starting location. It has the same rules for valid words and word placement on the board.
 * 
 * @param game the 2D array game board 
 * @param boardR the actual board row size
 * @param boardC the actual board col size
 * @param r the row given
 * @param c the col given
 * @param word the word given
 * @return int returns 1 if successful and 0 if not
 */
static int down(char **game, int boardR, int boardC, int r, int c, char *word) {
  // Use helper method to check board inputs
  int rtn = checkHelper(game, boardR, boardC, r, c, word);
  if (rtn == 0) {
    return 0;
  }
  // The length of the word
  int length = strlen(word);
  // Check that the length of the word does not start on or go off the board
  if ((length + r) >= boardC - 1) {
      return 0;
  }

  // Check that the word is placed in the correct place
  int idx = 0;
  for (int i = r + 1; i < length + r + 1; i++) {
      if (game[i][c + 1] != ' ') {
          if (game[i][c + 1] != word[idx]) {
            return 0;
          }
      }
      idx++;
  }
  // If command passes all tests, place the word
  idx = 0;
  for (int i = r + 1; i < length + r + 1; i++) {
      game[i][c + 1] = word[idx];
      idx++;
  }
  // Return 1 on success and return 0 on failure.
  return 1;
}

/**
 * @brief This command instructs the server to print the current state of the board for the client. It prints
 * the board with a border around the edge consisting of vertical bars on the left and right, dashes
 * along the top and bottom and plus signs in the corners.
 * 
 * @param game the 2D array game board 
 * @param boardR the actual board row size
 * @param boardC the actual board col size
 * @param fp the client to output to
 */
static void board(char **game, int boardR, int boardC, FILE** fp) {
   // Print out the game board by row and column
  for (int i = 0; i < boardR; i++)
  {
      for (int j = 0; j < boardC; j++)
      {
          char c = game[i][j];
          fprintf(*fp, "%c", c);
          
      }
      fprintf(*fp, "\n");
  }
}

/**
 * @brief Handles a client connection, close it when done.
 * Reads in teh client's commands and executes them depending if they are valid.
 * 
 * @param sockArg the sock int number 
 * @return void* 
 */
void *handleClient( void *sockArg ) {

  // Cast the thread argument to an int
  int sock = *(int*)sockArg;
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Tells when the clients enters quit. Stops taking in commands.
  int quitFlag = 1;
  
  fprintf( fp, "cmd> " );

  // While the clients has not entered quit
  while (quitFlag) {
    // The length of the buffer
    int len = 11 + 26;
    // The buffer that holds the client input command
    char str[len + 1];
    // The length of the string. Used to detect if the clent is inputting a large command
    int strLen = 0;
    // Flag for if a large command was entered.
    int longInput = 0;
    // Get the input command one char at a time
    char c = fgetc(fp);
    // While the end of the command has not been reached
    while (c != '\n') {
      //Check if the length of the comand is greater than the length of the buffer
      if (strLen > len) {
        // If so set flag and break
        longInput = 1;
        fprintf(fp, "Invalid command\n");
        break;
      }
      // If not add the char to the command string and increment the length
      str[strLen++] = c;
      // Get the next char
      c = fgetc(fp);
    }
    // If a command was entered and no overflow detected
    if (strLen != 0 && longInput == 0) {
        // Complete the inputted string command
        str[strLen] = '\0';
        // The number of inputs entered
        int count = 0;
        // Parse the string for a command, row, col, and word if there is any
        char *token = strtok(str, " ");
        // The command
        char *cmd = token;
        count++;
        // The row
        char *row = NULL;
        // The col
        char *col = NULL;
        // The word
        char *word = NULL;
        
        // While there are still tokens to parse
        token = strtok(NULL, " ");
        while (token != NULL)
        {
            // Based on the count set the given argument
            if (count == 1) {
                row = token;
            } else if (count == 2) {
                col = token;
            } else if (count == 3) {
                word = token;
            }
            token = strtok(NULL, " ");
            count++;
        }
        // If the command was quit
        if (strcmp(cmd, "quit") == 0) {
            // If there was more than one argument, print invalid
            if (count != 1) {
              fprintf(fp, "Invalid command\n");
            } else {
              // Else quit taking input
              quitFlag = 0;
            }
        } else if (strcmp(cmd, "board") == 0){
          // If the command was board
            // If there was more than one argument, print invalid
            if (count != 1) {
                fprintf(fp, "Invalid command\n");
            } else {
              // Else print the board
              // Use semaphores to control access to the board state
                sem_wait( &boardState );
                board(game, boardR, boardC, &fp);
                sem_post( &boardState );
            }
        } else if (strcmp(cmd, "across") == 0 || strcmp(cmd, "down") == 0){
          // If the command was across or down
            // If there was more or less than 4 arguments, print invalid
            if (count != 4) {
                fprintf(fp, "Invalid command\n");
            } else {
              // Else attempt to add to the board
              // Use semaphores to control access to the board state
                // Get the given row. If returns zero it'll be invalid anyway
                int rGiven = atoi(row);
                // Get the given col. If returns zero it'll be invalid anyway
                int cGiven = atoi(col);
                
                // Do across or down based on the command
                if (strcmp(cmd, "across") == 0) {
                    sem_wait( &boardState );
                    int rtn = across(game, boardR, boardC, rGiven, cGiven, word);
                    sem_post( &boardState );
                    if (rtn == 0) {
                      fprintf(fp, "Invalid command\n");
                    }
                } else {
                    sem_wait( &boardState );
                    int rtn = down(game, boardR, boardC, rGiven, cGiven, word);
                    sem_post( &boardState );
                    if (rtn == 0) {
                      fprintf(fp, "Invalid command\n");
                    }
                }
            }
        } else {
             fprintf( fp, "Invalid Command\n");
        }
    }
      fprintf( fp, "cmd> " );
  }
  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

/**
 * @brief Gets the user inputs and sets the board with it.
 * Sets the semaphore and prepares setting up the client connections.
 * 
 * @param argc the number of arguments entered
 * @param argv the array of arguments
 * @return int returns 0 if successful (never reached)
 */
int main( int argc, char *argv[] ) {

  // Check if there are more or less than 3 arguments entered
  if (argc != 3) {
    printf("usage: scrabbleServer <rows> <cols>\n");
    exit(1);
  }

  // Check if the arguments entered are less than zero
  for (int i = 1; i < argc; i++){
    if (atoi(argv[i]) <= 0) {
      printf("usage: scrabbleServer <rows> <cols>\n");
      exit(1);
    }
  }

  // Initialize the semaphore to 1
  sem_init( &boardState, 0, 1 );
  // Get the dimensions of the board row
  r = atoi(argv[1]);
  // Get the dimensions of the board col
  c = atoi(argv[2]);
  // Set the dimensions of the actual board row
  boardR = r + 2;
  // Set the dimensions of the actual board col
  boardC = c + 2;

  // Set the game board with given inputs
  game = createGame(boardR, boardC);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  // Thread for each client
  pthread_t thread;

  while ( 1  ) {
    // Wait to accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    // Create a thread for the given client
    if ( pthread_create( &thread, NULL, handleClient, (void *)&sock ) != 0 )
      fail( "Can't create thread.\n" );
    
    // Detach the thread and not join
    pthread_detach(thread);
  }
  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
