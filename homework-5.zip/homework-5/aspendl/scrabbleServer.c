#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netdb.h>
#include <pthread.h>
#include <semaphore.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

/** Port number used by my server */
#define PORT_NUMBER "26302"

/** Maximum word length */
#define WORD_LIMIT 26

// Print out an error message and exit.
static void fail(char const* message) {
	fprintf(stderr, "%s\n", message);
	exit(EXIT_FAILURE);
}

/*
* BOARD Section
*/

// Board
static char* board;
static char* boarder; // epic pun
static int rows = 0, cols = 0;

// Synchronization
sem_t board_access;

// Try to place a word on the board
// This assumes the word itself was already verified
bool word_place(char* word, int r, int c, bool down) {
	int start = cols * r + c;
	int inc = down ? cols : 1;
	// Check if word is valid (only lowercase letters)
	for (char* search = word; *search; search++)
		if (*search < 'a' || 'z' < *search)
			return false;
	// Check if word can fit
	if ((down ? rows - r : cols - c) < strlen(word)) return false;
	// Check if word would overwrite an existing character
	sem_wait(&board_access); // Only need to aquire semaphore when board is being accessed
	char* search = word;
	for (int i = start; *search; i += inc)
		if (board[i] != *search++ && board[i] != ' ') {
			sem_post(&board_access);
			return false;
		}
	// Place word
	for (int i = start; *word; i += inc)
		board[i] = *word++;
	sem_post(&board_access);
	return true;
}

/** handle a client connection, close it when we're done. */
void* handleClient(int sock) {
	// Here's a nice trick, wrap a C standard IO FILE around the
	// socket, so we can communicate the same way we would read/write
	// a file.
	FILE* fp = fdopen(sock, "a+");

	// Temporary values for parsing commands.
	char cmd[11] = { 0 };

	// Command loop
	while (true) {
		// Prompt the user for the next command.
		fprintf(fp, "cmd> ");
		fscanf(fp, "%10s", cmd);

		// Quit command (doesn't need any synchronization)
		if (strcmp(cmd, "quit") == 0) break;

		// Print board command (requires synchronization)
		if (strcmp(cmd, "board") == 0) {
			fprintf(fp, "+%.*s+\n", cols, boarder);
			sem_wait(&board_access);
			for (int i = 0; i < rows; i++)
				fprintf(fp, "|%.*s|\n", cols, board + i * cols);
			sem_post(&board_access);
			fprintf(fp, "+%.*s+\n", cols, boarder);
			continue;
		}

		// Place commands (require synchronization, but only inside of 'word_place')
		if (strcmp(cmd, "across") == 0 || strcmp(cmd, "down") == 0) {
			int r = -1, c = -1;
			char word[28] = { 0 };
			// Read and validate arguments
			if (fscanf(fp, "%d", &r) == 1 && 0 <= r && r < rows // r
				&& fscanf(fp, "%d", &c) == 1 && 0 <= c && c < cols // c
				&& fscanf(fp, "%27s", word) == 1 && strlen(word) < 27 // word
				&& word_place(word, r, c, *cmd == 'd')) // word was placed
				continue;
		}

		// Invalid command (doesn't need any synchronization)
		fprintf(fp, "Invalid command\n");
	}

	// Close the connection with this client.
	fclose(fp);
	return NULL;
}

int main(int argc, char* argv[]) {
	// Validate arguments
	if (argc != 3
		|| sscanf(argv[1], "%d", &rows) != 1 || rows <= 0
		|| sscanf(argv[2], "%d", &cols) != 1 || cols <= 0) {
		printf("usage: scrabbleServer <rows> <cols>\n");
		return 0;
	}

	// setup board
	board = malloc(rows * cols * sizeof(char));
	memset(board, ' ', rows * cols);
	boarder = malloc(cols * sizeof(char));
	memset(boarder, '-', cols);
	sem_init(&board_access, 0, 1);

	// Prepare a description of server address criteria.
	struct addrinfo addrCriteria;
	memset(&addrCriteria, 0, sizeof(addrCriteria));
	addrCriteria.ai_family = AF_INET;
	addrCriteria.ai_flags = AI_PASSIVE;
	addrCriteria.ai_socktype = SOCK_STREAM;
	addrCriteria.ai_protocol = IPPROTO_TCP;

	// Lookup a list of matching addresses
	struct addrinfo* servAddr;
	if (getaddrinfo(NULL, PORT_NUMBER, &addrCriteria, &servAddr))
		fail("Can't get address info");

	// Try to just use the first one.
	if (servAddr == NULL)
		fail("Can't get address");

	// Create a TCP socket
	int servSock = socket(servAddr->ai_family, servAddr->ai_socktype, servAddr->ai_protocol);
	if (servSock < 0)
		fail("Can't create socket");

	// Bind to the local address
	if (bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0)
		fail("Can't bind socket");

	// Tell the socket to listen for incoming connections.
	if (listen(servSock, 5) != 0)
		fail("Can't listen on socket");

	// Free address list allocated by getaddrinfo()
	freeaddrinfo(servAddr);

	// Fields for accepting a client connection.
	struct sockaddr_storage clntAddr; // Client address
	socklen_t clntAddrLen = sizeof(clntAddr);

	while (true) {
		// Accept a client connection.
		int sock = accept(servSock, (struct sockaddr*)&clntAddr, &clntAddrLen);
		pthread_t t_client;
		pthread_create(&t_client, NULL, handleClient, sock);
		pthread_detach(t_client);
	}

	// Stop accepting client connections (never reached).
	close(servSock);

	return 0;
}
