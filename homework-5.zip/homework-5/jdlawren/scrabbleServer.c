#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26162"

/** Maximum word length */
#define WORD_LIMIT 26

/** Struct to hold all important values for to the game board */
typedef struct {
  int rows;
  int cols;
  char **board;
  char *border;
} gameBoard;

/** Struct used to pass arguments to threads */
typedef struct {
  int sock;
} args;

/** Global semaphore used to restrict board access */
sem_t boardAccess;

/** Global game board */
gameBoard *g;

/** Server socket */
int servSock;

/** Method used to deallocate memory on and close connection on exit */
static void exitHandler() {
  for (int i = 0; i < g->rows; i++) {
    free((g->board[i]));
  }
  free(g->board);
  free(g->border);
  free(g);
  close(servSock);
  signal(SIGINT, SIG_DFL);
  raise(SIGINT);
}

/** Method used to initialize a board */
static gameBoard *makeBoard(int rows, int cols) {
  gameBoard *g = (gameBoard *) malloc(sizeof(gameBoard));
  g->cols = cols;
  g->rows = rows;
  //Make a double array for the board
  g->board = (char **) calloc(g->rows, sizeof(char *));
  for (int i = 0; i < g->rows; i++) {
    g->board[i] = (char *) calloc(g->cols + 1, sizeof(char));
    memset(g->board[i], ' ', g->cols);
  }
  // The border field is what is  printed above and blow the board
  g->border = (char *) calloc(g->cols + 3, sizeof(char));
  g->border[0] = '+';
  memset(g->border + 1, '-', g->cols);
  g->border[g->cols + 1] = '+';
  return g;
}

// Print out an error message and exit.
static void fail(char const *message) {
  fprintf(stderr, "%s\n", message);
  exit(EXIT_FAILURE);
}

/** handle a client connection, close it when we're done. */
void *handleClient(void *arg) {
  //Parse the arguments
  args *a = (args *) arg;
  int sock = a->sock;

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen(sock, "a+");

  // Prompt the user for a command.
  fprintf(fp, "cmd> ");
  fflush(fp);

  //Field for commands
  char cmd[11];
  while (fscanf(fp, "%10s", cmd) == 1 &&
         strcmp(cmd, "quit") != 0) {
    if (strcmp(cmd, "board") == 0) {
      //Get semaphore, print board, release semaphore
      sem_wait(&boardAccess);
      fprintf(fp, "%s\n", g->border);
      for (int i = 0; i < g->rows; i++) {
        fprintf(fp, "|%s|\n", g->board[i]);
      }
      fprintf(fp, "%s\n", g->border);
      sem_post(&boardAccess);
    } else if (strcmp(cmd, "across") == 0) {
      //Get semaphore
      sem_wait(&boardAccess);
      //Is the input valid
      bool valid = true;
      //Input fields
      int r = -1;
      int c = -1;
      char string[27];
      //Scan for the values, max length of word is 26
      fscanf(fp, "%d %d %26s", &r, &c, string);
      //Length of string
      int length = strlen(string);
      //Ensure all values were inputted and valid
      if (r < 0 || c < 0 || length <= 0) {
        valid = false;
      } else if (r >= g->rows || c + length > g->cols) {
        valid = false;
      } else {
        for (int i = 0; i < length && valid; i++) {
          //Check the string for conflicts, moving across
          if (g->board[r][c + i] != ' ' && g->board[r][c + i] != string[i]) {
            valid = false;
          }
          //Make sure string only has lowercase letters
          if (string[i] < 'a' || string[i] > 'z') {
            valid = false;
          }
        }
      }
      if (valid) {
        //Place input on board, moving across
        for (int i = 0; i < length; i++) {
          g->board[r][c + i] = string[i];
        }
      } else {
        //Return invalid
        fprintf(fp, "Invalid command\n");
      }
      //Return semaphore
      sem_post(&boardAccess);

    } else if (strcmp(cmd, "down") == 0) {
      //The vast majority of the section is identical to the above code, differences noted
      sem_wait(&boardAccess);
      bool valid = true;
      int r = -1;
      int c = -1;
      char string[27];
      fscanf(fp, "%d %d %26s", &r, &c, string);
      int length = strlen(string);
      if (r < 0 || c < 0 || length <= 0) {
        valid = false;
      } else if (r + length > g->rows || c >= g->cols) {
        valid = false;
      } else {
        for (int i = 0; i < length; i++) {
          //Check the string for conflicts, moving down
          if (g->board[r + i][c] != ' ' && g->board[r + i][c] != string[i]) {
            valid = false;
          }
        }
      }
      if (valid) {
        for (int i = 0; i < length; i++) {
          //Place input on board moving down rather than across
          g->board[r + i][c] = string[i];
        }
      } else {
        fprintf(fp, "Invalid command\n");
      }
      sem_post(&boardAccess);

    } else {
      //Print when command is not valid
      fprintf(fp, "Invalid command\n");
    }

    // Prompt the user for the next command.
    fprintf(fp, "cmd> ");
  }

  // Close the connection with this client.
  fclose(fp);
  return NULL;
}

/** Main method, created networking capability, and threads for each connection */
int main(int argc, char *argv[]) {
  //Make sure the correct number of args are given
  if (argc != 3) {
    fail("usage: scrabbleServer <rows> <cols>");
  }

  //Make sure the args are valid
  int r = atoi(argv[1]);
  int c = atoi(argv[2]);
  if (r <= 0 || c <= 0) {
    fail("usage: scrabbleServer <rows> <cols>");
  }

  //Initialize board and board access semaphore
  g = makeBoard(r, c);
  sem_init(&boardAccess, 0, 1);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if (getaddrinfo(NULL, PORT_NUMBER, &addrCriteria, &servAddr))
    fail("Can't get address info");


  // Try to just use the first one.
  if (servAddr == NULL)
    fail("Can't get address");

  // Create a TCP socket
  servSock = socket(servAddr->ai_family, servAddr->ai_socktype, servAddr->ai_protocol);
  if (servSock < 0)
    fail("Can't create socket");

  // Bind to the local address
  if (bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0) {
    printf("%d\n", errno);
    fail("Can't bind socket");
  }

  // Tell the socket to listen for incoming connections.
  if (listen(servSock, 5) != 0)
    fail("Can't listen on socket");

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  //Deallocate memory and close server socket when SIGINT signal received
  signal(SIGINT, exitHandler);

  while (true) {
    // Accept a client connection.
    int sock = accept(servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_t worker;
    // Set up args struct
    args a;
    a.sock = sock;
    //Start thread, passing arg struct
    pthread_create(&worker, NULL, handleClient, (void *) &a);
    //Detach thread
    pthread_detach(worker);
  }

  // Stop accepting client connections (never reached).
  close(servSock);

  return 0;
}
