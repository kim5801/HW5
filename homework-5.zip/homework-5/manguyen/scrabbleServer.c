#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include<semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26374"

/** Maximum word length */
#define WORD_LIMIT 26

int boardRow;
int boardCol;

char *scrabbleBoard;

sem_t sem;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

static void invalid( FILE *fp) {
  fprintf( fp, "Invalid command\n");
}

static void printBoard(FILE *fp) {
  //printf top row
  fprintf( fp, "+" );
  for (int i = 0; i < boardCol; i++) {
    fprintf(fp, "-");
  }
  fprintf( fp, "+\n" );

  //print middle rows
  for (int i = 0; i < boardRow; i++) {
    fprintf(fp, "|");
    for (int j = 0; j < boardCol; j++) {
      fprintf(fp, "%c", scrabbleBoard[i * boardCol + j]);
    }
    fprintf( fp, "|\n");
  }

  //print bottom
  fprintf( fp, "+" );
  for (int i = 0; i < boardCol; i++) {
    fprintf(fp, "-");
  }
  fprintf( fp, "+\n" );
}

int hasCaps(char *word) {
  int len = strlen(word);
  int count = 0;
  for (int i = 0; i < len; i++) {
    if (word[i] < 'a' || word[i] > 'z') {
      count++;
    }
  }
  return count;
}

void across(int r, int c, char *word, FILE *fp) {
  //check to see if it goes past (board)-er (hahhahahahaha)
  int len = strlen(word);
  if (len + c > boardCol || hasCaps(word) > 0) {
    invalid(fp);
    return;
  }

  for (int i = 0; i < len; i++) {
    //first check it isn't null
    if (scrabbleBoard[r * boardCol + c + i] != ' ') {
      //should be the same letter, else invalid
      if (scrabbleBoard[r * boardCol + c + i] != word[i]) {
        invalid(fp);
        return;
      }
    }
  }

  for (int i = 0; i < len; i++) {
    scrabbleBoard[r * boardCol + c + i] = word[i];
  }
}

void down(int r, int c, char *word, FILE *fp) {
  //check to see if it goes past (board)-er (hahhahahahaha)
  int len = strlen(word);
  if (len + r > boardRow || hasCaps(word) > 0) {
    invalid(fp);
    return;
  }

  for (int i = 0; i < len; i++) {
    //first check it isn't null
    if (scrabbleBoard[(r + i) * boardCol + c] != ' ') {
      //should be the same letter, else invalid
      if (scrabbleBoard[(r + i) * boardCol + c] != word[i]) {
        invalid(fp);
        return;
      }
    }
  }

  for (int i = 0; i < len; i++) {
    scrabbleBoard[(r + i) * boardCol + c] = word[i];
  }
}

/** handle a client connection, close it when we're done. */
void *handleClient( void* pClient) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int sock = *((int*)pClient);
  FILE *fp = fdopen( sock, "a+" );

  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  //vars for r and c for the commands
  int row;
  int col;
  char word[WORD_LIMIT + 1];
  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    
    if (strcmp( cmd, "across" ) == 0) {
      //check to see if valid call to across
      sem_wait(&sem);
      if (fscanf(fp, "%d %d %27s", &row, &col, word) == 3) {
        if (row > 0 && col > 0) {
          //call it
          across(row, col, word, fp);
          
        } else {
          fail("Invalid command");
        }
      } else {
        fail("Invalid command");
      }
      sem_post(&sem);

    } else if (strcmp( cmd, "down" ) == 0) {
      sem_wait(&sem);
      //check to see if valid call to across
      if (fscanf(fp, "%d %d %27s", &row, &col, word) == 3 && row > 0 && col > 0) {
        //call it
        down(row, col, word, fp);
      } else {
        fail("Invalid command");
      }

    } else if (strcmp(cmd, "board") == 0) {
      sem_wait(&sem);
      printBoard(fp);
      sem_post(&sem);
    } else {
      fail("Invalid command");
    }
    sem_post(&sem);

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  sem_init(&sem, 0, 1);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    if (sscanf(argv[1], "%d", &boardRow) != 1 || sscanf(argv[2], "%d", &boardCol) != 1 ) {
      fail("usage: scrabbleServer <rows> <cols>");
    } else if (boardRow < 1 || boardCol < 1) {
      fail("usage: scrabbleServer <rows> <cols>");
    }

    scrabbleBoard = (char *)malloc(boardRow * boardCol);
    // make the game board and manaually calloc
    for (int i = 0; i < boardRow; i++) {
      for (int j = 0; j < boardCol; j++) {
        scrabbleBoard[i * boardCol + j] = ' ';
      }
    }



    pthread_t t;
    int* pClient = &sock;
    pthread_create(&t, NULL, handleClient, pClient);
    // free(scrabbleBoard);
    pthread_detach(t);
    // handleClient( sock);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
