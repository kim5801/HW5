#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26088"

/** Maximum word length */
#define WORD_LIMIT 26

// The index of the wordlist that marks the first lowercase word, "a"
#define START_LOWER 19204

// The total size of the wordlist
#define LIST_SIZE 102401

// The size of the list of lowercase words within the wordlist
#define LOWER_LIST_SIZE 83179

// Number of rows on the game board, to be specified by the user
int rows;

// Number of rows on the game board, to be specified by the user
int cols;

// 2d array of characters acting as the game board
char ** gameBoard = NULL;

// Monitor used for locking and unlocking critical sections
static pthread_mutex_t mon;

// // Condition variable used to control waiting threads
// static pthread_cond_t wait;

// Whether or not a "words" file is specified
bool hasDict = false;

// A list of valid words
char ** wordList = NULL;


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}


// Print out a usage message and exit.
static void usage() {
  fprintf( stderr, "usage: scrabbleServer <rows> <cols>\n" );
  exit( EXIT_FAILURE );
}


// A private method that allocates space for and reads in a list of words
static void readWords(FILE * fp) {

  // Allocate space for the wordlist
  wordList = calloc(LOWER_LIST_SIZE, sizeof(char *));
  for(int i = 0; i < LOWER_LIST_SIZE; i++) {
    wordList[i] = calloc(WORD_LIMIT, sizeof(char));
  }

  // Iterate through all of the words that start with a capital letter and scrap them
  for(int i = 0; i < START_LOWER; i++) {
    fscanf(fp, "%[^\n] ", wordList[0]);
  }

  // Iterate through all of the words that start with a lowercase letter and save them
  for(int i = START_LOWER; i < LIST_SIZE; i++) {
    fscanf(fp, "%[^\n] ", wordList[i - START_LOWER]);
  }

  // Close the file pointer to our wordlist
  fclose(fp);
}


// A private method to quickly search our wordlist. Since it should be alphabetically 
// sorted, binary search is a good choice here
static bool binarySearch(char * word) { 

    // The leftmost element in our list
    int l = 0;

    // The rightmost element in our list
    int r = LOWER_LIST_SIZE - 1;

    // Perform a binary search
    while (l <= r) { 
        int m = l + (r - l) / 2; 
        if (strcmp(wordList[m], word) == 0) 
            return true; 
        if (strcmp(wordList[m], word) < 0) 
            l = m + 1; 
        else
            r = m - 1; 
    }  

    return false; 
} 


// A private, recursive method to check the board after a new string of characters is placed,
// to ensure that that line and all lines intersecting it are valid words
static bool checkValid(char * cmd, int r, int c, char * word) {

    // If we're now out of bounds or have reached the end of our recently placed string, 
    // then we've checked all the characters and can conclude the board state is valid.
    // We also want to return true if no dictionary file has been set up.
    if (r >= rows || c >= cols || gameBoard[r][c] == ' ' || !hasDict) {
        return true;
    }

    // The line of characters that should be a valid word
    char check[WORD_LIMIT] = "";

    // A counter to increment the index of check
    int counter = 0;

    // Used to increment r in recursive calls
    int i = r;

    // Used to increment c in recursive calls
    int j = c;

    // Here's how this is going to work:
    // We're going to check the adjacent spaces of the string we just placed on the boad in this order:
    //     2
    //     ^
    // 1 < c  > 3
    //     v
    //     4
    //
    // If 1 or 2 contains a letter, we must follow it back to the start of the word. If 3 or 4 contains a letter,
    // then we're already at the start of the word. Once we reach the start, we can save the word and check it 
    // in the dictionary with our binary search function

    if (j - 1 >= 0 && gameBoard[i][j - 1] != ' ') {
        // Check 1: the left space
        // printf("%s\n", "LEFT");

        // If there's a letter there, go left until we reach the start of the word
        while (j - 1 >= 0 && gameBoard[i][j - 1] != ' ') {
            j--;
        }

        // We are now at the start of the word
        // printf("Starting at %c, going across\n", gameBoard[i][j]);
        goto followAcross;

    } else if (i - 1 >= 0 && gameBoard[i - 1][j] != ' ') {
        // Check 1: the above space
        // printf("%s\n", "UP");

        // If there's a letter there, go up until we reach the start of the word
        while (i - 1 >= 0 && gameBoard[i - 1][j] != ' ') {
            i--;
        }

        // We are now at the start of the word
        // printf("Starting at %c, going down\n", gameBoard[i][j]);
        goto followDown;

    } else if (j + 1 < cols && gameBoard[i][j + 1] != ' ') {
        // Check 3: the right space
        // printf("%s\n", "RIGHT");

        followAcross: ;

        // Save the word into our check variable
        while (j + 1 <= cols && gameBoard[i][j] != ' ') {
            check[counter] = gameBoard[i][j];
            counter++;
            j++;
        }

    } else if (i + 1 < rows && gameBoard[i + 1][j] != ' ') {
        // Check 4: the below space
        // printf("%s\n", "DOWN");

        followDown: ;

        // Save the word into our check variable
        while (i + 1 <= rows && gameBoard[i][j] != ' ') {
            check[counter] = gameBoard[i][j];
            counter++;
            i++;
        }

    } else {
        // If there's no surrounding letters, then it must be the case that we've just placed 
        // a one-letter word with no surrounding words. In that case, we can just check the word and return
        // printf("Word is %s\n", word);
        return binarySearch(word);
    }

    // printf("Check is: %s\n", check);


    if (!binarySearch(check)) {
        // If the word isn't in the dictionary, return false
        return false;
    } else if (strcmp(cmd, "across") == 0) {
        // If this is an across word, check the next letter to the right
        return checkValid(cmd, r, c + 1, word);
    } else {
        // If this is a down word, check the next letter below
        return checkValid(cmd, r + 1, c, word);
    }

}


// This command places a new word on the board going horizontally. The left end of the word starts
// at the given row, r, and column, c, on the board. Both row number and column number start
// from zero (the top row and left column of the board). The given word must be a sequence of 1 to
// 26 lower-case letters. It is placed on the board, one character per location going right from the
// starting location.
// The command is invalid if the given location is off the board, if the word would extend beyond
// the bounds of the board, if the word contains something other than lower-case letters or if the
// one of the characters in the word disagrees with a character already placed on the board.
void across( int r, int c, char * word) {

    // Establish that the start and end of the word are valid positions
    int length = strlen(word);

    // Marks where existing letters are when placing a new word. This will be used when we can place a string,
    // but it causes some line on the board to be invalid.
    bool index[length];

    // Initialize all indexes to false, meaning that the word is not building on pre-existing letters
    for (int i = 0; i < length; i++)
        index[i] = false;

    // printf("%d\n", length);

    // Do our initial bounds checking to ensure the placed word can fit on the board
    if ( r >= 0 && r < rows && length >= 1 && (c + length) <= cols ) {
        // Check each index of the board to ensure it matches ' ' or the matching char of the word
        for (int i = 0; i < length; i++) {
            if (islower(word[i]) && (gameBoard[r][i + c] == ' ' || gameBoard[r][i + c] == word[i])) {
                // valid, move on
                // printf("Letter %c is valid\n", word[i]);
            } else {
                goto exit;
            }
        }

        // Fill in the word
        for (int i = 0; i < length; i++) {
            if (gameBoard[r][i + c] == ' ')
                gameBoard[r][i + c] = word[i];
            else
                index[i] = true;
        }

        // Check the line and all intersecting lines to ensure they are valid words
        bool valid = checkValid("across", r, c, word);

        if (!valid) {
            // We've already placed a new word on the board, but it ended up causing some problems
            // Now we'll have to erase it, making sure we don't erase letters that were already there before
            for (int i = 0; i < length; i++) {
                if (!index[i])
                    gameBoard[r][i + c] = ' ';
            }

            goto exit;
        }

    } else {
        goto exit;
    }

    if (false) {
        // A small error handling block that can't normally be accessed. It had to go somewhere.

        exit: ;

        printf("Invalid command\n");
    }

}


// This command is like the across command, but it places a word going down from the given
// starting location. It has the same rules for valid words and word placement on the board.
void down( int r, int c, char * word) {

    // Establish that the start and end of the word are valid positions
    int length = strlen(word);

    // Marks where existing letters are when placing a new word. This will be used when we can place a string,
    // but it causes some line on the board to be invalid.
    bool index[length];

    // Initialize all indexes to false, meaning that the word is not building on pre-existing letters
    for (int i = 0; i < length; i++)
        index[i] = false;

    // Do our initial bounds checking to ensure the placed word can fit on the board
    if ( c >= 0 && c < cols && length >= 1 && (r + length) <= rows ) {
        // Check each index of the board to ensure it matches ' ' or the matching char of the word
        for (int i = 0; i < length; i++) {
            if (islower(word[i]) && (gameBoard[i + r][c] == ' ' || gameBoard[i + r][c] == word[i])) {
                // valid, move on
                // printf("Letter %c is valid\n", word[i]);
            } else {
                goto exit;
            }
        }

        // Fill in the word
        for (int i = 0; i < length; i++) {
            if (gameBoard[i + r][c] == ' ')
                gameBoard[i + r][c] = word[i];
            else
                index[i] = true;
        }

        // Check the line and all intersecting lines to ensure they are valid words
        bool valid = checkValid("down", r, c, word);

        if (!valid) {
            // We've already placed a new word on the board, but it ended up causing some problems
            // Now we'll have to erase it, making sure we don't erase letters that were already there before
            for (int i = 0; i < length; i++) {
                if (!index[i])
                    gameBoard[i + r][c] = ' ';
            }

            goto exit;
        }

    } else {
        goto exit;
    }

    if (false) {
        // A small error handling block that can't normally be accessed. It had to go somewhere.

        exit: ;

        printf("Invalid command\n");
    }
    
}


// This command instructs the server to print the current state of the board for the client.
void board() {

  // Print the top border of the board
  printf("+");
  for (int j = 0; j < cols; j++) {
    printf("%c", '-');
  }
  printf("+\n");

  // Print the side boarders of the board, as well as all its contents
  for(int i = 0; i < rows; i++) {
    printf("|");
    for (int j = 0; j < cols; j++) {
        printf("%c", gameBoard[i][j]);
    }
    printf("|\n");
  }

  // Print the bottom border of the board
  printf("+");
  for (int j = 0; j < cols; j++) {
    printf("%c", '-');
  }
  printf("+\n");

}


/** handle a client connection, close it when we're done. */
void *handleClient( void * pSock ) {

  // Save the contents of our void pointer as an int, and free the old pointer
  int sock = *((int*)pSock);
  free(pSock);

  // Detach the thread
  pthread_detach(pthread_self());

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 7 ];
  while ( fscanf( fp, "%6s", cmd ) == 1 && strcmp( cmd, "quit" ) != 0 ) {
    // fprintf( fp, "|%s|\n", cmd );

    if (strcmp(cmd, "across") == 0) {

        // Break the rest of the line up into components and check them all
        int r; // Our row
        int c; // Our column
        char word[WORD_LIMIT + 1]; // Our word to be placed

        // Read in all our extra arguments
        if (fscanf( fp, "%d %d %26s", &r, &c, word ) != 3) {
            goto error;
        }

        // Do some basic bounds checking on our row and column numbers.
        // The rest will be done inside the across() method
        if (r < 0 || c < 0) {
            goto error;
        }

        // Enter the critical section
        pthread_mutex_lock(&mon);

        across(r, c, word);

        // Exit the critical section
        pthread_mutex_unlock(&mon);

    } else if (strcmp(cmd, "down") == 0) {

        // Break the rest of the line up into components and check them all
        int r; // Our row
        int c; // Our column
        char word[WORD_LIMIT + 1]; // Our word to be placed

        // Read in all our extra arguments
        if (fscanf( fp, "%d %d %26s", &r, &c, word ) != 3) {
            goto error;
        }

        // Do some basic bounds checking on our row and column numbers.
        // The rest will be done inside the down() method
        if (r < 0 || c < 0) {
            goto error;
        }

        // Enter the critical section
        pthread_mutex_lock(&mon);

        down(r, c, word);

        // Exit the critical section
        pthread_mutex_unlock(&mon);
        
    } else if (strcmp( cmd, "board" ) == 0) {

        // Enter the critical section
        pthread_mutex_lock(&mon);

        board();

        // Exit the critical section
        pthread_mutex_unlock(&mon);

    } else {
        error: ;

        printf("Invalid command\n");
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}


int main( int argc, char *argv[] ) {

  // If we have the wrong number of args, fail
  if (argc != 3 || atoi(argv[1]) <= 0 || atoi(argv[2]) <= 0)
    usage();

  // Set number of rows and columns
  rows = atoi(argv[1]);
  cols = atoi(argv[2]);

  // Create our board
  gameBoard = calloc(rows, sizeof(char *)); // REMEMBER TO FREE ME
  for(int i = 0; i != rows; i++) {
    gameBoard[i] = calloc(cols, sizeof(char));
  }

  // Initialize the whole board to be empty
  for(int i = 0; i < rows; i++) {
    for (int j = 0; j < cols; j++) {
        gameBoard[i][j] = ' ';
    }
  }

  // Look for words file
  FILE * dictionary = fopen("words", "r");
  if (dictionary) {
    hasDict = true;
    readWords(dictionary);
  }

  // Initialize monitor and condition variable
  pthread_mutex_init(&mon, NULL);
//   pthread_cond_init(&wait, NULL);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    // handleClient( sock );
    pthread_t t;
    int *pclient = malloc(sizeof(int));
    *pclient = sock;
    pthread_create(&t, NULL, handleClient, pclient);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
