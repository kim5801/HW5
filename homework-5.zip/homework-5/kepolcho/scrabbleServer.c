#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <semaphore.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26066"

/** Maximum word length */
#define WORD_LIMIT 26

sem_t boardLock;

/** board variable to hold the board */
char **gameBoard = NULL;

int maxRow = 0;
int maxCol = 0;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// modify board for across command
bool across(int row, int col, char *word) {
  for (int i = 0; i < strlen(word); i++) {
    if (islower(word[i]) == 0) {
      printf("Invalid command\n");
      return false;
    }
  }

  // error handling for across
  if (col < 0 || col >= maxCol || row < 0 || row >= maxRow || col + strlen(word) - 1 > maxCol) {
    printf("Invalid command\n");
    return false;
  }

  // lock access to board
  sem_wait(&boardLock);

  // check if the board has crossing letters
  int idx = 0;
  for (int c = col; idx < strlen(word); c++, idx++) {
    // check if there's something already in spot
    
    if (gameBoard[row][c] != '\0' && word[idx] != gameBoard[row][c]) {
      // reverse the board
      printf("Invalid command\n");
      // done w/ board
      sem_post(&boardLock);
      return false;
    }
  }

  // board is valid, update!
  idx = 0;
  for (int c = col; idx < strlen(word); c++, idx++) {
  // change values in board
  gameBoard[row][c] = word[idx];
}

  // done w/ board
  sem_post(&boardLock);
  return true;
}

// Modify board for down command
bool down(int row, int col, char *word) {
  // check if the word is valid
  for (int i = 0; i < strlen(word); i++) {
    if (islower(word[i]) == 0) {
      printf("Invalid command\n");
      return false;
    }
  }

  if (col < 0 || col >= maxCol || row < 0 || row >= maxRow || row + strlen(word) - 1 > maxRow) {
    printf("Invalid command\n");
    return false;
  }

  // lock access to board
  sem_wait(&boardLock);

  // no issues, update the board
  int idx = 0;
  for (int r = row; idx < strlen(word); r++, idx++) {
    // check if there's something already in spot    
    if (gameBoard[r][col] != '\0' && word[idx] != gameBoard[r][col]) {
      printf("Invalid command\n");
      // done w/ board
      sem_post(&boardLock);
      return false;
    }
  }

  // board is valid, update!
  idx = 0;
  for (int r = row; idx < strlen(word); r++, idx++) {
    // change values in board
    gameBoard[r][col] = word[idx];
  }

  // done w/ board
  sem_post(&boardLock);
  return true;
}

// print board w/ border
void board() {

  // lock access to board
  sem_wait(&boardLock);

  // print top row
  printf("+");
  for (int i = 0; i < maxCol; i++) {
    printf("-");
  }
  printf("+\n");

  // print each row
  for (int r = 0; r < maxRow; r++) {
    printf("|");
    // print each column in row
    for (int c = 0; c < maxCol; c++) {
      // if it's a 0, print it as a space!
      if (gameBoard[r][c] == '\0') {
        printf(" ");
      }
      else {
        printf("%c", gameBoard[r][c]);
      }
    }
    printf("|\n");
  }

  // print bottom row
  printf("+");
  for (int i = 0; i < maxCol; i++) {
    printf("-");
  }
  printf("+\n");

  // done w/ board
  sem_post(&boardLock);
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *socket ) {

  int sock = *((int *)socket);
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {

    // Just echo the command back to the client for now.
    // fprintf( fp, "%s\n", cmd );

    // start parsing in commands
    if (strcmp(cmd, "across") == 0) {
      int row;
      int col;
      char word[100];
      int wordLen = 0;
      // check if inputs are valid
      if (fscanf(fp, "%d", &row) != 1 || fscanf(fp, "%d", &col) != 1 || fscanf(fp, "%s%n", word, &wordLen) != 1 || wordLen > 26) {
        printf("Invalid command\n");
      }
      else {
        across(row, col, word);
      }
    }
    else if(strcmp(cmd, "down") == 0) {
      int row;
      int col;
      char word[100];
      int wordLen = 0;
      // check if inputs are valid
      if (fscanf(fp, "%d", &row) != 1 || fscanf(fp, "%d", &col) != 1 || fscanf(fp, "%s%n", word, &wordLen) != 1 || wordLen > 26) {
        printf("Invalid command\n");
      }
      else {
        down(row, col, word);
      }
    }
    else if(strcmp(cmd, "board") == 0) {
      board();
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // initalize lock, set to 0
  sem_init(&boardLock, 0, 0);

  // check if valid arguments
  if (argc != 3) {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  if (argv[1] < 0) {
    fail("usage: scrabbleServer <rows> <cols>");
  }  
  if (argv[2] < 0) {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  maxRow = atoi(argv[1]);
  maxCol = atoi(argv[2]);  

  // create the board
  gameBoard = (char **)malloc(maxRow * sizeof(char *));

  // make space for the board
  for (int r = 0; r < maxRow; r++) {
    gameBoard[r] = (char *)calloc(maxCol, sizeof(char));
  }

  // create locks
  sem_init(&boardLock, 0, 1);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    pthread_t threads;
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    pthread_create(&threads, NULL, handleClient, &sock);
    pthread_detach(threads);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
