/**
 * Scrabble server using TCP/IP communication with sockets. Accepts connections and
 * commands from clients, manipulating game board
 * @file scrabbleServer.c
 * @author Zach Taylor (zstaylor)
 * @author CSC246 Teaching Staff
 */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>
#include <regex.h>

/** Port number used by my server */
#define PORT_NUMBER "26350"

/** Maximum word length */
#define WORD_LIMIT 26

/**
 * Board structure, row and col information, and game board
 */
struct board {
    int rows;
    int cols;
    char* boardarr;
} typedef Board;

/**
 * Client request parameters, includes socket information
 */
struct clientRequestParam {
    int sock;
}typedef ClientRequestParam;

/** shared Game board */
Board* gameBoard;
/** game board access semaphore */
sem_t boardAccess;

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( EXIT_FAILURE );
}

/**
 * Print usage message
 */
static void usage() {
    fprintf(stderr, "usage: scrabbleServer <rows> <cols>\n");
    exit(EXIT_FAILURE);
}

void* handleClient(int);


/**
 * Thread entry point, takes in parameter of client request
 * @param param Client request parameter object pointer
 * @return unused
 */
void* ThreadClientHandler(void* param) {

    ClientRequestParam* input = (ClientRequestParam*)param;

    handleClient(input->sock);

    free(param);
    return NULL;
}

/**
 * Places a word on the board going across, starting at row/col
 * @param row Start row
 * @param col Start col
 * @param word Word to add
 * @param len Word length
 */
void across(FILE* fp, int row, int col, char* word, int len) {

    //calculate starting idx
    int idx = (row * gameBoard->cols) + col;

    if(idx + len >= (gameBoard->rows * gameBoard->cols) || col + len - 1 >= gameBoard->cols || row >= gameBoard->rows) {
        fprintf(fp, "Invalid command\n");
        return;
    }

    sem_wait(&boardAccess);

    //scan the location to determine if the word conflicts with any existing words
    bool conflicting = false;
    for(int i = 0; i < len; i++) {

        //if empty cell, move to next idx
        if(strncmp(gameBoard->boardarr + idx, " ", sizeof(char)) == 0) {
            idx += 1;
        } //if not empty and does not match existing
        else if (strncmp(gameBoard->boardarr + idx, word + i, sizeof(char)) != 0) {
            conflicting = true;
            break;
        }
        else {
            idx += 1;
        }
    }

    //reset idx value
    idx = (row * gameBoard->cols) + col;

    //if the word is not conflicting with anything existing, add it in
    if(!conflicting) {

        for(int i = 0; i < len; i++) {

            //add character if cell empty
            memcpy(gameBoard->boardarr+idx, word + i, sizeof(char));
            idx += 1;
        }
    }
    else {
        fprintf(fp,"Invalid command\n");
    }

    sem_post(&boardAccess);
}

/**
 * Places a word on the board going down, starting at given row/col
 * @param row Start row
 * @param col Start col
 * @param word Word to add
 * @param len Word length
 */
void down(FILE* fp, int row, int col, char* word, int len) {

    //calculate starting idx
    int idx = (row * gameBoard->cols) + col;

    if(idx + ((len - 1)*gameBoard->cols) >= (gameBoard->rows * gameBoard->cols) || row + len - 1 >= gameBoard->rows || col >= gameBoard->cols) {
        fprintf(fp,"Invalid command\n");
        return;
    }

    sem_wait(&boardAccess);

    //scan the location to determine if the word conflicts with any existing words
    bool conflicting = false;
    for(int i = 0; i < len; i++) {

        //if empty cell, move to next idx
        if(strncmp(gameBoard->boardarr + idx, " ", sizeof(char)) == 0) {
            idx += gameBoard->cols;
        } //if not empty and does not match existing
        else if (strncmp(gameBoard->boardarr + idx, word + i, sizeof(char)) != 0) {
            conflicting = true;
            break;
        }
        else {
            idx += gameBoard->cols;
        }
    }

    idx = (row * gameBoard->cols) + col;

    //if the word is not conflicting with anything existing, add it in
    if(!conflicting) {

        for(int i = 0; i < len; i++) {
            //add character if cell empty
            memcpy(gameBoard->boardarr+idx, word + i, sizeof(char));
            idx += gameBoard->cols;
        }
    }
    else {
        fprintf(fp,"Invalid command\n");
    }

    sem_post(&boardAccess);
}

/**
 * Prints the board to the given file pointer
 * @param fp File pointer
 */
void printboard(FILE* fp) {

    //print first line
    fprintf(fp, "+");
    for(int i = 0; i < gameBoard->cols; i++) {
        fprintf(fp, "-");
    }
    fprintf(fp, "+\n|");

    //print body
    for(int i = 0, j = 0; i <= gameBoard->rows * gameBoard->cols; i++, j++) {

        //end point of row
        if(j == gameBoard->cols ) {

            //within board
            if(i != (gameBoard->rows * gameBoard->cols)) {
                fprintf(fp, "|\n|%c", gameBoard->boardarr[i]);
                j = 0;
            }
            else { //end of board, dont print second pipe
                fprintf(fp, "|\n");
            }
        }
        else { //within board, print char
            fprintf(fp, "%c", gameBoard->boardarr[i]);
        }
    }

    fprintf(fp, "+");
    for(int i = 0; i < gameBoard->cols; i++) {
        fprintf(fp, "-");
    }
    fprintf(fp, "+\n");
    fflush(fp);
}


/** handle a client connection, close it when we're done. */
void *handleClient( int sock ) {
      // Here's a nice trick, wrap a C standard IO FILE around the
      // socket, so we can communicate the same way we would read/write
      // a file.nn
    FILE *fp = fdopen( sock, "a+" );

      // Prompt the user for a command.
    fprintf( fp, "cmd> " );

    char cmdinput[7];
    while(fscanf(fp, "%8s", cmdinput) == 1) {

        if( strcmp(cmdinput, "quit") == 0) {

            free(gameBoard);

            sem_close(&boardAccess);
            close(sock);
            exit(EXIT_SUCCESS);
        }

        if( strcmp(cmdinput, "across") == 0 || strcmp(cmdinput, "down") == 0) {

            bool choseAcross = (strcmp(cmdinput, "across") == 0);

            int row, col, wordlen, wordlenp;
            char word[27];
            if(fscanf(fp, "%d %d %n%26s%n", &row, &col, &wordlenp, word, &wordlen) != 3)
                fail("Could not parse across/down cmd");

            wordlen -= wordlenp;
            word[wordlen] = '\0';

            //determine if any characters are not lowercase ascii
            bool validWord = true;
            for(int i = 0; i < wordlen; i++) {
                if(word[i] < 'a' || word[i] > 'z') {
                    fprintf(fp, "Invalid command\n");
                    validWord = false;
                    break;
                }
            }

            //execute on board if valid
            if(validWord) {
                if(choseAcross) {
                    across(fp, row, col, word, wordlen);
                }
                else {
                    down(fp, row, col, word, wordlen);
                }
            }
        }
        else if (strcmp(cmdinput, "board") == 0) {
            //print board to console
            printboard(fp);
        }
        else {
            fprintf(fp, "Invalid command\n");
        }

        fprintf(fp, "cmd> ");
    }

    // Close the connection with this client.
    fclose( fp );
    return NULL;
}

int main( int argc, char *argv[] ) {

    //usage message
    if(argc != 3)
        usage();

    //init gameboard
    gameBoard = (Board*)malloc(sizeof(Board));
    gameBoard->rows = atoi(argv[1]);
    gameBoard->cols = atoi(argv[2]);
    gameBoard->boardarr = (char*)malloc(sizeof(char) * gameBoard->rows * gameBoard->cols);

    for(int i = 0; i < gameBoard->rows*gameBoard->cols; i++) {
        gameBoard->boardarr[i] = ' ';
    }


    sem_init(&boardAccess, 0, 1);

    // Prepare a description of server address criteria.
    struct addrinfo addrCriteria;
    memset(&addrCriteria, 0, sizeof(addrCriteria));
    addrCriteria.ai_family = AF_INET;
    addrCriteria.ai_flags = AI_PASSIVE;
    addrCriteria.ai_socktype = SOCK_STREAM;
    addrCriteria.ai_protocol = IPPROTO_TCP;

      // Lookup a list of matching addresses
    struct addrinfo *servAddr;
    if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
        fail( "Can't get address info" );

      // Try to just use the first one.
    if ( servAddr == NULL )
        fail( "Can't get address" );

      // Create a TCP socket
    int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                             servAddr->ai_protocol);
    if ( servSock < 0 )
        fail( "Can't create socket" );

      // Bind to the local address
    if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
        fail( "Can't bind socket" );



      // Tell the socket to listen for incoming connections.
    if ( listen( servSock, 5 ) != 0 )
        fail( "Can't listen on socket" );

    // Free address list allocated by getaddrinfo()
    freeaddrinfo(servAddr);

      // Fields for accepting a client connection.
    struct sockaddr_storage clntAddr; // Client address
    socklen_t clntAddrLen = sizeof(clntAddr);

    while ( true  ) {

        // Accept a client connection.
        int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

        ClientRequestParam* param = (ClientRequestParam*)malloc(sizeof(ClientRequestParam));
        param->sock = sock;

        pthread_t thread;
        pthread_create(&thread, NULL, ThreadClientHandler, param);
        pthread_detach(thread);
    }

      // Stop accepting client connections (never reached).
    close( servSock );
    return 0;
}
