#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26042"

/** Maximum word length */
#define WORD_LIMIT 26

/** Expected argument count */
#define ARG_COUNT 3

/** Number of rows on the board */
int boardRows = 0;
/** Number of columns on the board */
int boardCols = 0;
/** 2D array of chars representing the board */
char **board;
/** Semaphore for board synchronization */
sem_t boardLock;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** Print the board */
void printBoard( FILE *fp ) {
  // Print the first line
  fputc( '+', fp );
  for ( int i = 0; i < boardCols; i++ ) {
    fputc( '-', fp );
  }
  fprintf( fp, "+\n" );
  // Print the main lines of the board
  for ( int i = 0; i < boardRows; i++ ) {
    for ( int j = 0; j < boardCols + 2; j++ ) {
      if ( j == 0 || j == boardCols + 1 ) {
        fputc( '|', fp );
      } else {
        fputc( board[ i ][ j - 1 ], fp );
      }
    }
    fputc( '\n', fp );
  }
  // Print the last line
  fputc( '+', fp );
  for ( int i = 0; i < boardCols; i++ ) {
    fputc( '-', fp );
  }
  fprintf( fp, "+\n" );
}

/** Place a word across from the given position */
void wordAcross( FILE *fp, int row, int col, char *word ) {
  bool validWord = true;
  for ( int i = 0; i < strlen( word ); i++ ) {
    if ( board[ row ][ col + i ] != ' ' && board[ row ][ col + i ] != word[ i ] ) {
      validWord = false;
      break;
    }
  }
  if ( validWord ) {
    for ( int i = 0; i < strlen( word ); i++ ) {
      board[ row ][ col + i ] = word[ i ];
    }
  } else {
    fprintf( fp, "Invalid command\n" );
  }
}

/** Place a word down from the given position */
void wordDown( FILE *fp, int row, int col, char *word ) {
  bool validWord = true;
  for ( int i = 0; i < strlen( word ); i++ ) {
    if ( board[ row + i ][ col ] != ' ' && board[ row + i ][ col ] != word[ i ] ) {
      validWord = false;
      break;
    }
  }
  if ( validWord ) {
    for ( int i = 0; i < strlen( word ); i++ ) {
      board[ row + i ][ col ] = word[ i ];
    }
  } else {
    fprintf( fp, "Invalid command\n" );
  }
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *sockVoid ) {
  int *sockPtr = ( int * ) sockVoid;
  int sock = *sockPtr;
  
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  char word[ WORD_LIMIT + 2 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    int row = -1;
    int col = -1;
    if ( strcmp( cmd, "board" ) == 0 ) {
      // Command to print the board, check for extra input
      sem_wait( &boardLock );
      printBoard( fp );
      sem_post( &boardLock );
    } else if( strcmp( cmd, "across" ) == 0 ) {
      // Command to place a word across, check for valid row, column, and word input, and check for extra input
      if ( fscanf( fp, "%d%d%27s", &row, &col, word ) != 3 || row == -1 || col == -1 || row >= boardRows || 
           col >= boardCols || col + strlen( word ) > boardCols || strlen( word ) > WORD_LIMIT ) {
        fprintf( fp, "Invalid command\n" );
      } else {
        bool validWord = true;
        for ( int i = 0; i < strlen( word ); i++ ) {
          if ( !islower( word[ i ] ) ) {
            validWord = false;
            break;
          }
        }
        if ( validWord ) {
          sem_wait( &boardLock );
          wordAcross( fp, row, col, word );
          sem_post( &boardLock );
        } else {
          fprintf( fp, "Invalid command\n" );
        }
      }
    } else if( strcmp( cmd, "down" ) == 0 ) {
      // Command to place a word down, check for valid row, column, and word input, and check for extra input
      if ( fscanf( fp, "%d%d%27s", &row, &col, word ) != 3 || row == -1 || col == -1 || row >= boardRows || 
           col >= boardCols || row + strlen( word ) > boardRows || strlen( word ) > WORD_LIMIT ) {
        fprintf( fp, "Invalid command\n" );
      } else {
        bool validWord = true;
        for ( int i = 0; i < strlen( word ); i++ ) {
          if ( !islower( word[ i ] ) ) {
            validWord = false;
            break;
          }
        }
        if ( validWord ) {
          sem_wait( &boardLock );
          wordDown( fp, row, col, word );
          sem_post( &boardLock );
        } else {
          fprintf( fp, "Invalid command\n" );
        }
      }
    } else {
      fprintf( fp, "Invalid command\n" );
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Check for correct command line arguments
  if ( argc != ARG_COUNT ) {
    fail( "usage: scrabbleServer <rows> <cols>" );
  }
  for ( int i = 0; i < strlen( argv[ 1 ] ); i++ ) {
    if ( !isdigit( argv[ 1 ][ i ] ) ) {
      fail( "usage: scrabbleServer <rows> <cols>" );
    }
  }
  for ( int i = 0; i < strlen( argv[ 2 ] ); i++ ) {
    if ( !isdigit( argv[ 2 ][ i ] ) ) {
      fail( "usage: scrabbleServer <rows> <cols>" );
    }
  }
  boardRows = atoi( argv[ 1 ] );
  boardCols = atoi( argv[ 2 ] );
  if ( boardRows <= 0 || boardCols <= 0 ) {
    fail( "usage: scrabbleServer <rows> <cols>" );
  }

  // Create the board
  board = ( char ** ) malloc( sizeof( char * ) * boardRows );
  for ( int i = 0; i < boardRows; i++ ) {
    board[ i ] = ( char * ) malloc( sizeof( char ) * boardCols );
  }
  for ( int i = 0; i < boardRows; i++ ) {
    for ( int j = 0; j < boardCols; j++ ) {
      board[ i ][ j ] = ' ';
    }
  }
  
  sem_init( &boardLock, 0, 1 );

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_t thread;
    pthread_create( &thread, NULL, handleClient, &sock );
    pthread_detach( thread );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
