#include <stdio.h>
#include <semaphore.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26190"

/** Maximum word length */
#define WORD_LIMIT 26

typedef struct {
  int num;
} myStruct;


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

static void invalidCMD(FILE *fp) {
  fprintf(fp, "Invalid command");
  fprintf(fp, "\n");
  fprintf(fp, "cmd> ");
}


static bool space(FILE *fp) {
  char c = fgetc(fp);
  if (c != ' ') {
    invalidCMD(fp);
    return false;
  }
  return true;
}

/*
static bool number(FILE *fp) {
  char c = fgetc(fp);
  if (c > '9' || c < '0') {
    invalidCMD(fp);
    return false;
  }
  ungetc(c, fp);
  return true;
}
*/
sem_t board;

char *scrabbleBoard;

int c;
int r;

/** handle a client connection, close it when we're done. */
void *handleClient( int sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    // Just echo the command back to the client for now.
    //fprintf( fp, "%s\n", cmd );

    //If the command is "board"
    if (strcmp( cmd, "board" ) == 0) {

      //Print the first line of the board with + and -
      fprintf(fp, "+");
      for (int i = 0; i < c; i++) fprintf(fp, "-");
      fprintf(fp, "+");
      fprintf(fp, "\n");

      //Print the middle of the board, with each end having a "|", and the rest of the board filled
      //With the characters of the scrabbleBoard array
      for (int i = 0; i < r; i++) {
        fprintf(fp, "|");

        //Print each of the columns
        for (int j = 0; j < c; j++) {
          int printIndex = i * c + j;
          fprintf(fp, "%c", scrabbleBoard[printIndex]);
        }

        //Print the ending of each line, and go to the next one
        fprintf(fp, "|");
        fprintf(fp, "\n");
      }

      //Print the final line of the board
      fprintf(fp, "+");
      for (int i = 0; i < c; i++) fprintf(fp, "-");
      fprintf(fp, "+");
      fprintf(fp, "\n");

    }

    //If the user wants the across command
    else if (strcmp(cmd, "across") == 0) { 
      //create storage to store the word the user wants
      char acrossWord[27];

      int colNum;
      int rowNum;
      
      //Store the length of the word
      int len = 0;

      if (!space(fp)) continue;
      //if (!number(fp)) continue;
      if (fscanf(fp, "%d", &rowNum) != 1) {
        invalidCMD(fp);
        //printf("THIS GOT HERE");
        continue;
      }

      //All error checking
      if (rowNum < '0' || rowNum > '9' || rowNum > r) {
        invalidCMD(fp);
        continue;
      }

      if(!space(fp)) continue;

      //Get the column number
      if (fscanf(fp, "%d", &colNum) != 1) {
        invalidCMD(fp);
        continue;
      }

      if (colNum < '0' || colNum > '9' || colNum > c) {
        invalidCMD(fp);
        continue;
      }

      //More error checking
      if (!space(fp)) continue;

      
      //Iterate through the board and make sure everything is valid
      for (int i = 0; i < 26; i++) {
        c = fgetc(fp);
        if (c == '\n') {
          acrossWord[i] = '\0';
          break;
        }
        if (c > 'z' || c < 'a') {
          invalidCMD(fp);
          continue;
        }
        acrossWord[i] = c;
        len++;
      }

      if (len + c > colNum) {
        invalidCMD(fp);
        continue;
      }



      sem_wait(&board);
      //int rowsCols = r * c + colNum;
      //int startingPos = rowsCols + len;
      //For across, make sure that the board is valid
      for (int i = (r * c + colNum); i < (r * c + colNum) + len; i++) {
        if (scrabbleBoard[i] != acrossWord[i - (r * c + colNum)]) {
          invalidCMD(fp);
          goto OUTOFLOOP;
        }
      }
      //int l = (r * c + colNum);

      //Add letters into the board
      for (int j = (r * c + colNum); j < (r * c + colNum) + len; j++) {
        scrabbleBoard[j] = acrossWord[j - (r * c + colNum)];
      }

      if (1 == 2) {
        OUTOFLOOP: continue;
      }

      sem_post(&board);


    }

    //If the user wants down, Do the same as across except for the end
    else if (strcmp(cmd, "down") == 0) { 

    //Create our vars
      char downWord[27];

      int colNum;
      int rowNum;
      
      //Store the length of the word
      int len = 0;

      if (!space(fp)) continue;
      //if (!number(fp)) continue;
      if (fscanf(fp, "%d", &rowNum) != 1) {
        invalidCMD(fp);
        continue;
      }

      //Error handling
      if (rowNum < '0' || rowNum > '9' || rowNum > r) {
        invalidCMD(fp);
        continue;
      }

      if(!space(fp)) continue;

      if (fscanf(fp, "%d", &colNum) != 1) {
        invalidCMD(fp);
        continue;
      }

      if (colNum < '0' || colNum > '9' || colNum > c) {
        invalidCMD(fp);
        continue;
      }

      if (!space(fp)) continue;

      
      //Iterate therough the letters, just like in across
      for (int i = 0; i < 26; i++) {
        c = fgetc(fp);
        if (c == '\n') {
          downWord[i] = '\0';
          break;
        }
        if (c > 'z' || c < 'a') {
          invalidCMD(fp);
          continue;
        }
        downWord[i] = c;
        len++;
      }


      if (r - rowNum < len) { 
        invalidCMD(fp);
        continue;
      }

      sem_wait(&board);

      //do {
        //if (board[i] != ' ' && board[i] != downWord[j])
        //int j = 0;
      
      //Make sure that the word selected for down is correct.
      int i = (r * c + colNum);
      for (int j = 0; downWord[j] != '\0'; i += c) {
        if (scrabbleBoard[i] == ' ') {
          //Do Nothing
        }
        //Jumpt to the goto to get out of this loop
        else if (scrabbleBoard[i] != downWord[j]) {
          invalidCMD(fp);
          goto OUTOFLOOP;
        }
        j++;
      }

      //Finally, add in our down word
      int k = (r * c + colNum);
      for (int j = 0; downWord[j] != '\0'; k += c) {
        scrabbleBoard[k] = downWord[j];
        j++;
      }
      //}
      //while (word[j]);


      sem_post(&board);

    }
    else {
      invalidCMD(fp);
    }


    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}


//The thread function used for each pthread
void *threadFunction(void *argument) {

  //Create the struct, then call the client
  myStruct *str = (myStruct *)argument;
  handleClient(str->num);

  //Free,exit,
  free(str);
  pthread_exit(0);
  return NULL;
}

//Static helper method to tell the user how to use the program
static void usage() {
  printf("usage: scrabbleServer <rows> <cols>\n");
  exit(1);
}

//Starting point for the program
int main( int argc, char *argv[] ) {

  //If there are < 2 command line args then exit the program
  if (argc != 3) {
    usage();
  }

  //Set the rows and columns to the input
  c = atoi(argv[2]);
  r = atoi(argv[1]);

  //If the rows/columns are invalid exit
  if (c <= 0 || r <= 0) usage();

  //Malloc our necessary board
  //MAKE SURE TO FREE THIS
  int rc = c * r;
  scrabbleBoard = (char *)malloc(sizeof(char) * rc);

  for (int i = 0; i < r*c; i++) scrabbleBoard[i] = ' ';

  sem_init(&board, 0, 1);
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    //handleClient( sock );
    myStruct *str = (myStruct *)malloc(sizeof(myStruct));
    str->num = sock;


    //Create the pthread and run it, then detatch
    pthread_t t;
    pthread_create(&t, NULL, threadFunction, str);
    pthread_detach(t);


  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
