#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server, specific to cafligg */
#define PORT_NUMBER "26368" 

/** Maximum word length */
#define WORD_LIMIT 26

/* global constants to define our board */
int rows;
int cols;
char **board;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( int sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 40 ];
  while ( fscanf( fp, "%39[^\n]", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {

    //handle a board command
    if(strcmp( cmd, "board") == 0) {
      //create a header for the board of plus signs
      for(int i = 0; i<cols+2; i++) {
        fprintf( fp, "+");
      }
      fprintf( fp, "\n");

      //iterate through the board and print it
      for(int i = 0; i < rows; i++) {
        fprintf( fp, "|");
        for(int j = 0; j < cols; j++) {
          fprintf( fp, "%c", board[i][j]);
        }
        fprintf( fp, "|\n");
      }

      //create the footer for the board of plus signs
      for(int i = 0; i<cols+2; i++) {
        fprintf( fp, "+");
      }
      fprintf( fp, "\n" );
    }

    //across command
    else if(strncmp(cmd, "across", 6) == 0) {
      char cmd2[40];
      int row; //values to parse from across command
      int col;
      char word[40]; //not possible for overflow
      if(sscanf(cmd, "%s %d %d %[a-z]s", cmd2, &row, &col, word) != 4) {
        fprintf(fp, "Invalid command\n");
      } else {
        if(strlen(word) + col > cols || row > rows) { //make sure everything fits
          fprintf(fp, "Invalid command\n");
        } else {
          //check to make sure its possible to actually place the word on the board
          bool validword = true; 
          for(int i = 0; word[i] != '\0'; i++) {
            if(board[row][col + i] != ' ') {
              if(board[row][col + i] != word[i]) {
                fprintf(fp, "Invalid command\n");
                validword = false;
              }
            }
          }

          //if we can place it, place it
          if(validword){
            for(int i = 0; word[i] != '\0'; i++) {
              board[row][col + i] = word[i];
            }
          }
        }
      }
    }


    //handle down command
    else if(strncmp(cmd, "down", 4) == 0) {
      char cmd2[40];
      int row;
      int col;
      char word[40]; //not possible for overflow
      if(sscanf(cmd, "%s %d %d %s", cmd2, &row, &col, word) != 4) {
        fprintf(fp, "Invalid command\n");
      } else {
        if(strlen(word) + row > rows || col > cols) { //make sure everything fits
          fprintf(fp, "Invalid command\n");
        } else {
          //check to make sure its possible to actually place the word on the board
          bool validword = true;
          for(int i = 0; word[i] != '\0'; i++) {
            if(board[row + i][col] != ' ') {
              if(board[row + i][col] != word[i]) {
                fprintf(fp, "Invalid command\n");
                validword = false;
              }
            }
          }
          //if we can place it, place it
          if(validword){
            for(int i = 0; word[i] != '\0'; i++) {
              board[row + i][col] = word[i];
            }
          }
        }
      }
      //no valid commands left
    } else {
      fprintf(fp, "Invalid command\n");
    }
   

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  //get rows and columns of server
  if(argc != 3) {
    printf("usage: scrabbleServer <rows> <cols>\n");
    exit(1);    
  }

  //ensure that the values passed to the scrabble server are actually numbers
  bool valid = true;

  for(int i = 0; argv[1][i] != '\0'; i++) {
    if(!isdigit(argv[1][i])) {
      valid = false;
    }
  }

  for(int i = 0; argv[2][i] != '\0'; i++) {
    if(!isdigit(argv[2][i])) {
      valid = false;
    }
  }

  //if not numbers then exit
  if(!valid) {
    printf("usage: scrabbleServer <rows> <cols>\n");
    exit(1);
  }

  //assign rows and columns
  rows = atoi(argv[1]);
  cols = atoi(argv[2]); 

  //if invalid numbers than exit
  if(rows <= 0 || cols <= 0) {
    printf("usage: scrabbleServer <rows> <cols>\n");
    exit(1);
  }

  //otherwise -> create the board
  board = (char**)calloc(rows, sizeof(char*));

  for(int i = 0; i < rows; i++) {
    board[i] = (char*)calloc(cols, sizeof(char));
    for(int j = 0; j < cols; j++) {
      board[i][j] = ' ';
    }
  }



  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    handleClient( sock );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
