#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26358"

/** Maximum word length */
#define WORD_LIMIT 26

/** Row and column lengths, given dummy values */
int rowLength = -1;
int colLength = -1;

/** Semaphore for working in the board function */
sem_t sema;

typedef struct {
    int row;
    int col;
    char **board;
}GameBoard;

GameBoard *b;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *arg ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int *sock = (int *)arg;
  FILE *fp = fdopen( *sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  int row = -1;
  int col = -1;
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    sem_wait(&sema);
    if (strcmp(cmd, "across") == 0) {
        fscanf(fp, "%d %d", &row, &col);
        if (row == -1 || col == -1) {
            fprintf(fp, "Invalid command\n");
            sem_post(&sema);
            break;
        }
        char word[WORD_LIMIT]; //the word to be added
        bool valid = true;
        int val = fscanf(fp, "%s", word);
        if (val != 1 || col + strlen(word) > b->col) { 
        //check another word is there and it doesn't go over the board
            valid = false;
            sem_post(&sema);
        } 
        for (int i = 0; i < strlen(word); i++) { //check that it only contains lowercase letters
            if(word[i] < 'a' || word[i] > 'z') {
                fprintf(fp, "Invalid command\n");
                valid = false;
                sem_post(&sema);
                break;
            }
        }
        for (int i = 0; i < strlen(word); i++) {
            if (b->board[row][col + i] != word[i] && b->board[row][col + i] != ' ') {
                fprintf(fp, "Invalid command\n");
                valid = false;
                sem_post(&sema);
                break;
            }
        }
        if (valid) {
            for (int i = 0; i < strlen(word); i++) {
                if (b->board[row][col + i] == ' ') {
                    b->board[row][col + i] = word[i];
                } 
            } 
        }
        sem_post(&sema);
    }
    else if (strcmp(cmd, "down") == 0) {
        fscanf(fp, "%d %d", &row, &col);
        if (row == -1 || col == -1) {
            fprintf(fp, "Invalid command\n");
            sem_post(&sema);
            continue;
        }
        char word[WORD_LIMIT]; //the word to be added
        int val = fscanf(fp, "%s", word);
        if (val != 1 || row + strlen(word) > b->row) {
            fprintf(fp, "Invalid command\n");
        }
        else {
            bool valid = true;
            for (int i = 0; i < strlen(word); i++) {
                if(word[i] < 'a' || word[i] > 'z') {
                    fprintf(fp, "Invalid command\n");
                    valid = false;
                    break;
                }
            }
            for (int i = 0; i < strlen(word); i++) {
                if (b->board[row + i][col] != word[i] && b->board[row + i][col] != ' ') {
                    fprintf(fp, "Invalid command\n");
                    valid = false;
                    break;
                }
            }
            if (valid) {
                for (int i = 0; i < strlen(word); i++) {
                    if (b->board[row + i][col] == ' ') {
                        b->board[row + i][col] = word[i];
                    }
                }
            }
        }
        sem_post(&sema);
    }
    else if (strcmp(cmd, "board") == 0) {
        //print the top row
        fprintf(fp, "+");
        for (int i = 0; i < colLength; i++) {
            fprintf(fp, "-");
        }
        fprintf(fp, "+\n");
        for (int i = 0; i < rowLength; i++) {
          fprintf(fp, "|");
          for (int j = 0; j < colLength; j++) {
            fprintf(fp, "%c", b->board[i][j]);
          }
          fprintf(fp, "|\n");
        }
        //print the bottom row
        fprintf(fp, "+");
        for (int i = 0; i < colLength; i++) {
            fprintf(fp, "-");
        }
        fprintf(fp, "+\n");
        sem_post(&sema);
    }
    else {
        fprintf(fp, "Invalid command\n");
        sem_post(&sema);
    }
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  if (argc != 3 || *argv[1] < '0' || *argv[2] < '0') {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  sscanf(argv[1], "%d", &rowLength);
  sscanf(argv[2], "%d", &colLength);
  if (rowLength < 0 || colLength < 0) {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);
  
  b = malloc(sizeof(GameBoard));
  b->row = rowLength;
  b->col = colLength;
  b->board = malloc(rowLength * colLength);
  for (int i = 0; i < rowLength; i++) {
    b->board[i] = malloc(colLength);
  }
  
  for (int i = 0; i < rowLength; i++) {
    for (int j = 0; j < colLength; j++) {
        b->board[i][j] = ' ';
    }
  }
  //Setting up semaphore
  sem_init(&sema, 0, 1);
  //Set up the thread
  pthread_t thread; 
  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_create( &thread, NULL, handleClient, &sock);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
