#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26304"

/** Maximum word length */
#define WORD_LIMIT 26

/** base for numbers */
#define BASE 10

//semaphore for board access
sem_t boardAccess;

//board values and representation
static int rows = 0;
static int cols = 0;
static char **board;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/**
 * prints current board state with a border of '+','-', & '|'
 * ex: r = 3, c = 4
 * +----+
 * | a  |
 * | t  |
 * |    |
 * +----+
 */
void printBoard( FILE *fp ) {
  //top border
  fputc( '+', fp );
  for( int i = 0; i < cols; i++ ) fputc( '-', fp );
  fputc( '+', fp );
  fputc( '\n', fp );
  //middle rows
  for( int r = 0; r < rows; r++ ) {
    fputc( '|', fp );
    for( int c = 0; c < cols; c++ ) {
      fputc( board[r][c], fp );
    }
    fputc( '|', fp );
    fputc( '\n', fp );
  }
  //bottom border
  fputc( '+', fp );
  for( int i = 0; i < cols; i++ ) fputc( '-', fp );
  fputc( '+', fp );
  fputc( '\n', fp );
}

/**
 * Places word(w) on board in given direction(d) starting from row and col
 */
void placeWord( char *w, int row, int col, char d ) {
  if ( d == 'r' ) {
    for( int i = 0; i < strlen(w); i++ )
      board[row][col + i] = w[i]; 
  } else if ( d == 'd' ) {
    for( int i = 0; i < strlen(w); i++ )
      board[row + i][col] = w[i];
  } else {
    fail("invalid direction for placement");
  }
}

/**
 * loop over word placement location to make sure nothing is overwritten
 */
bool validPlace(char *w, int row, int col, char d ) {
  if ( d == 'r' ) {
    for( int i = 0; i < strlen(w); i++ ) {
      if (board[row][col + i] != ' ' && board[row][col + i] != w[i]) {
        return false;
      }
    }
  } else if ( d == 'd' ) {
    for( int i = 0; i < strlen(w); i++ ) {
      if (board[row + i][col] != ' ' && board[row + i][col] != w[i]) {
        return false;
      }
    }
  } else {
    fail("invalid direction for placement check");
  }
  return true;
}

/**
 * skip past any whitespace characters in input except '\n' and EOF
 * puts first non-skipped char back on stream
 */
void skipSpace( FILE *fp ) {
  int ch = fgetc( fp );
  while( ch == ' ' || ch == '\t' || ch == '\r' || ch == '\v' || ch == '\f' ) {
    ch = fgetc( fp );
  }
  ungetc( ch, fp );
}

/**
 * parses input in fp to return first digit value delineated by space
 * returns -99 if input finds alphabetical char
 * puts first whitespace char encountered back in stream
 */
int processInt10( FILE *fp ) {
 skipSpace( fp );
 int ch = fgetc( fp );
 //if ch detected is newline or EOF we have reached end of input
 if ( ch == '\n' || ch == EOF)
   return -99;
 int i = 0;
 while ( !isspace( ch ) && ch != EOF ) {
   if ( !isdigit(ch) )
     return -99;
   i *= BASE;
   //convert ch to actual number '0' = 49 '9' = 57 therefore '1' - '0' = 50 - 49 = 1
   i += (ch - '0');
   ch = fgetc( fp );
 }
 ungetc( ch, fp );
 return i;
}

/**
 * parses input for valid word composed of [a-z] until whitespace or WORD_LIMIT
 * returns 0 if word is successfully processed, -99 if word contains an error or no word is found
 * puts first whitespace char encountered back in stream
 */
int processWord( FILE *fp, char *w ) {
  int end = 0;
  skipSpace( fp );
  int ch = fgetc( fp );
  if ( ch == '\n' || ch == EOF)
   return -99;
  while ( !isspace( ch ) && ch != EOF ) {
    if ( ch < 'a' || ch > 'z' || end == WORD_LIMIT ) 
      return -99;
    w[ end ] = (char) ch;
    end++;
    ch = fgetc( fp );
  }
  w[ end ] = '\0';
  ungetc( ch, fp );
  return 0;
}

/**
 * verifies that there are no more arguments in fp
 */
bool endOfCommand( FILE *fp ) {
  skipSpace( fp );
  return fgetc( fp ) == '\n' || fgetc( fp ) == EOF;
}

/** handle a client connection, close it when we're done. */
void *handleClient( void * vSock ) {
  int sock = *((int *) vSock); 
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 8 ];
  while ( fscanf( fp, "%7s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    // Just echo the command back to the client for now.
    //process the command
    sem_wait( &boardAccess );
    if ( strcmp( cmd, "board" ) == 0 && endOfCommand( fp ) ) {
      printBoard( fp );
    } else if ( strcmp( cmd, "across" ) == 0 || strcmp( cmd, "down" ) == 0 ) {
      int r = processInt10( fp ), c = processInt10( fp );
      char word[ WORD_LIMIT + 1 ];
      //check if we have input not in the form of <across/down> <0-(rows-1)> <0-(cols-1)> <w*, 0 < l <= 26 [a-z]>
      if (r < 0 || c < 0 || r >= rows || c >= cols || processWord( fp, word ) != 0) {
        fprintf( fp, "Invalid command\n" );
      } else {
        //verify that the placement will not cross boundaries or overwrite an existing char
        if ( strcmp( cmd, "across" ) == 0 && (c + (int)strlen(word)) <= cols && validPlace(word, r, c, 'r') && endOfCommand( fp ) ) {
          placeWord(word, r, c, 'r');
        } else if ( strcmp( cmd, "down" ) == 0 && (r + (int)strlen(word)) <= rows && validPlace(word, r, c, 'd') && endOfCommand( fp ) ) {
          placeWord(word, r, c, 'd');
        } else {
          fprintf( fp, "Invalid command\n" );
        }
      }
    } else {
      fprintf( fp, "Invalid command\n" );
    }
    sem_post( &boardAccess );
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  //validate that there are two command line args
  if ( argc != 3 ) {
    fail( "usage: scrabbleServer <rows> <cols>" );
  }

  //validate the two command line args as integers > 0
  rows = atoi(argv[1]);
  cols = atoi(argv[2]);
  if( rows < 1 || cols < 1 ) {
    fail( "usage: scrabbleServer <rows> <cols>" );
  }

  //Initialize semaphore
  if ( sem_init( &boardAccess, 0, 1 ) == -1 ) {
    fail( "Can't create boardAccess Sem" );
  }
 
  //allocate space for board and fill it with empty spaces
  board = (char **)malloc( rows * sizeof( char * ));
  for (int r = 0; r < rows; r++ ) {
    board[r] = (char *)malloc( cols * sizeof( char ));
    memset( board[r], ' ', cols );
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    
    pthread_t t;
    if ( pthread_create( &t, NULL, handleClient, &sock ) != 0 )
      fail("Failed to make client thread");
    if ( pthread_detach( t ) != 0)
      fail("Couldn't detach thread");
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  for(int r = 0; r < rows; r++)
    free( board[r] );
  free( board );

  return 0;
}
