#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26014"

/** Maximum word length */
#define WORD_LIMIT 26

// Array for the board
char** board;

int maxRows;
int maxCol;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Monitor to make sure commands can only be accessed one at a time
pthread_mutex_t commandMon = PTHREAD_MUTEX_INITIALIZER;

/** function for the across command*/
void *across(FILE *fp, char* word, int row, int col) {
  int currCol = col;
  // check to make sure the word is valid
  for (int i = 0; i < strlen(word); i++ ) {
    // printf("%d", strlen(word));

    if (word[i] < 'a' || word[i] > 'z') {
      fprintf(fp, "Invalid command\n");
      return NULL;
    }
    if (board[row][currCol] != '\0' && board[row][currCol] != word[i]) {
      fprintf(fp, "Invalid command\n");
      return NULL;
    }
    currCol++;
  }
  // add the word to the word
  for (int i = 0; i < strlen(word); i++) {
    board[row][col] = word[i];
    col++;
  }
  return NULL;
}

/** function for the down command*/
void *down (FILE *fp, char* word, int row, int col) {
  // printf("%d", strlen(word));
  int currRow = row;
  // check to make sure the word is valid
  for (int i = 0; i < strlen(word); i++ ) {
    if (word[i] < 'a' || word[i] > 'z') {
      fprintf(fp, "Invalid command\n");
      return NULL;
    }
    if (board[currRow][col] != '\0' && board[currRow][col] != word[i]) {
      fprintf(fp, "Invalid command\n");
      return NULL;
    }
    currRow++;
  }
  // add the word to the word
  for (int i = 0; i < strlen(word); i++) {
    board[row][col] = word[i];
    row++;
  }
  return NULL;
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *voidSock ) {

  // cast sock to a int variable
  int sock = *((int *) voidSock);

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char inputString[ 40 ];
  while ( fgets( inputString, 40, fp ) != NULL) {

    if (strcmp( inputString, "quit\n" ) == 0 ) {
      break;
    }

    // enter a lock to modify shared values
    pthread_mutex_lock( &commandMon);

    // client command to the server and word to enter
    char cmd[40];
    char *word = (char *)calloc(WORD_LIMIT + 1, sizeof(char));
    // row and column of the command
    int row;
    int col;
    
    sscanf( inputString, "%s %d %d %s", cmd, &row, &col, word);

    if (strcmp( cmd, "across") == 0 ) {
      if ( row < 0 || row >= maxRows || col < 0 || col >= maxCol) {
        fprintf(fp, "Invalid command\n");
      }
      else if ( strlen(word) == 0 || col + strlen(word) > maxCol) {
        fprintf(fp, "Invalid command\n");
      }

      else {
        across(fp, word, row, col);
      }
    }
    else if (strcmp( cmd, "down") == 0) {
      if ( row < 0 || row >= maxRows || col < 0 || col >= maxCol) {
        fprintf(fp, "Invalid command\n");
      }
      else if ( strlen(word) == 0 || row + strlen(word) > maxRows) {
        fprintf(fp, "Invalid command\n");
      }
      
      else {
        down(fp, word, row, col);
      }
    }
    
    else if (strcmp( cmd, "board") == 0) {
      fprintf(fp, "+");
      for (int i = 0; i < maxCol; i++) {
        fprintf(fp, "-");
      }
      fprintf(fp, "+");
      fprintf(fp, "\n");
      for (int i = 0; i < maxRows; i++) {
        fprintf(fp, "|");
        for (int j = 0; j < maxCol; j++) {
          if (board[i][j] == '\0') {
            fprintf(fp, " ");
          } else {
            fprintf(fp, "%c", board[i][j]);
          }
        }
        fprintf(fp, "|\n");
      }
      fprintf(fp, "+");
      for( int i = 0; i < maxCol; i++) {
        fprintf(fp, "-");
      }
      fprintf(fp, "+");
      fprintf(fp, "\n");
    }
    else {
      fprintf(fp, "Invalid command\n");
    }
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
    // unlock
    pthread_mutex_unlock( &commandMon );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  maxRows = atoi(argv[1]);
  maxCol = atoi(argv[2]);

  // initialize the board
  board = (char**)calloc(maxRows, maxRows * sizeof(char));
  for (int i = 0; i < maxRows; i++ ) {
    board[i] = ( char* ) calloc(maxCol, atoi(argv[2]) * sizeof(char));
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    pthread_t clientThread;

    // create the thread
    if (pthread_create(&clientThread, NULL, handleClient, (void *) &sock) != 0 ) {
      fail( "Failed to create thread" );
    }

    // wait for the thread to complete
    pthread_join(clientThread, NULL);
  }

  // Stop accepting client connections (never reached).
  close( servSock );

  for( int i = 0; i < maxRows; i++) {
    free(board[i]);
  }
  free(board);
  
  return 0;
}
