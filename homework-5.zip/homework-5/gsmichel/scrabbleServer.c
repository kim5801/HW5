#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26422"

/** Maximum word length */
#define WORD_LIMIT 26

char **board;

int maxRow;

int maxColumn;

//sem for locking the board
sem_t boardSem;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

int checkValidAcross(int row, int start, char word[maxColumn + 1]){
  if( strlen(word) + start > maxColumn || row > maxRow || start > maxColumn ){
    return -1;
  }
  sem_wait( &boardSem );
  for ( int i = start; i < strlen( word ) + start; i++ ){
    if (word[i - start] > 'z' || word[i - start] < 'a'){
      
      sem_post( &boardSem );
      return -1;
    }
    if (board[row][i] != 0 && board[row][i] != word[i - start]){
      
      sem_post( &boardSem );
      return -1;
    }
  }
  sem_post( &boardSem );
  return 0;
}

int checkValidDown(int start, int column, char word[maxRow + 1]){
  //error checking, if word is too big or if column or start are too big
  if( strlen(word) + start > maxRow || start > maxRow || column > maxColumn ){
    return -1;
  }
  
  sem_wait( &boardSem );
  for ( int i = start; i < strlen( word ) + start; i++ ){
    if (word[i - start] > 'z' || word[i - start] < 'a'){
      sem_post( &boardSem );
      return -1;
    }
    if (board[i][column] != 0 && board[i][column] != word[i - start]){
      sem_post( &boardSem );
      return -1;
    }
  }
  sem_post( &boardSem );
  return 0;
}

/** Helper function that modifies the board for command across */
int across(int row, int start, char word[maxColumn + 1]){
  
  sem_wait( &boardSem );
  for ( int i = start; i < strlen( word ) + start; i++ ){
    board[row][i] = word[i - start];
  }
  sem_post( &boardSem );
  return 0;
  
}
 
/** Helper function that modifies the board for command across */
int down(int start, int column, char word[maxRow + 1]){
  //error checking, if word is too big or if column or start are too big
  if( strlen(word) + start > maxRow || start > maxRow || column > maxColumn ){
    return -1;
  }
  
  sem_wait( &boardSem );
  for ( int i = start; i < strlen( word ) + start; i++ ){
    board[i][column] = word[i - start];
  }
  sem_post( &boardSem );
  return 0;
  
}


/** handle a client connection, close it when we're done. */
void *handleClient( void *arg ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int sock = *(int *)arg;
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) != 0 && strcmp( cmd, "quit" ) != 0 ) {
    if ( strcmp( cmd, "across") == 0){
      //if across
      int row;
      int column;
      char word[ WORD_LIMIT + 1] = {};
      //error checking to make sure that it has all arguments
      if(fscanf( fp, "%d %d", &row, &column) != 2){
        fprintf( fp, "Invalid command1\n");
      } else if (fscanf( fp, " %26s", word ) != 1){
        fprintf( fp, "Invalid command3\n");
      } else {
        if( strlen(word) > maxColumn){
          fprintf( fp, "Invalid command4\n");
        } else {
        //plays the word
          if(row > maxRow || column > maxColumn || row < 0 || column < 0 ){
            fprintf( fp, "Invalid command5\n");
          }
          if( checkValidAcross(row, column, word) != 0 ){
            fprintf( fp, "Invalid command5\n");
          } else if( across(row, column, word) != 0 ){
            fprintf( fp, "Invalid command5\n");
          }
        }
      }
      
    } else if (strcmp( cmd, "down") == 0){
      //if down
      int column;
      int start;
      char word[ WORD_LIMIT + 1] = {};
      if(fscanf( fp, "%d ", &start ) != 1 ){
        fprintf( fp, "Invalid command6\n");
      } else if (fscanf( fp, "%d ", &column ) != 1 ){
        fprintf( fp, "Invalid command7\n");
      } else if (fscanf( fp, "%26s", word ) != 1){
        fprintf( fp, "Invalid command8\n");
      } else {
        if( strlen(word) > maxRow ){
          fprintf( fp, "Invalid command9\n");
        } else {
          if(start > maxRow || column > maxColumn || start < 0 || column < 0 ){
            fprintf( fp, "Invalid command5\n");
          }
          if( checkValidDown(start, column, word) != 0 ){
            fprintf( fp, "Invalid command5\n");
          } else if( down(start, column, word) != 0 ){
            fprintf( fp, "Invalid command10\n");
          }
        }
      }
    } else if (strcmp( cmd, "board") == 0){
      //print it out to client
      sem_wait( &boardSem );
      fprintf(fp, "+");
      for ( int j = 0; j < maxColumn; j++ ){
          fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
      for ( int i = 0; i < maxRow; i++ ){
        fprintf(fp, "|");
        for ( int j = 0; j < maxColumn; j++ ){
          if (!board[i][j]){
            fprintf(fp, " ");
          } else {
            fprintf(fp, "%c",board[i][j]);
          }
        }
        fprintf(fp, "|");
        fprintf(fp, "\n");
      }
      fprintf(fp, "+");
      for ( int j = 0; j < maxColumn; j++ ){
          fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
      sem_post( &boardSem );
    } else {
      fprintf(fp, "Invalid command\n");
    }
  
    // Just echo the command back to the client for now.
    //fprintf( fp, "%s\n", cmd );

    // Prompt the user for the next command.
    fprintf( fp, "\ncmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  
  
  if(argc != 3){
    printf("usage: scrabbleServer <rows> <cols>");
    exit( EXIT_FAILURE );
  }
  if( argv[1] <= 0 || argv[2] <= 0 ){
    printf("usage: scrabbleServer <rows> <cols>");
    exit( EXIT_FAILURE );
  }
  sscanf(argv[1],"%d", &maxRow);
  sscanf(argv[2],"%d", &maxColumn);

  //Malloc memory for board
  board = (char **)calloc(maxRow, sizeof(char *));
  for ( int i = 0; i < maxRow; i++){
    board[i] = (char *)calloc( maxColumn, sizeof(char));
  }
  
  
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);
  
  //initalize semaphore
  sem_init( &boardSem, 0, 1 );
  
  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    
    pthread_t thread;
    if ( pthread_create( &thread, NULL, handleClient ,  (void *)&sock ) != 0 ) 
      fail( "Can't create thread\n" );
    pthread_detach(thread);
  }
  for ( int i = 0; i < maxRow; i++){
    free(board[i]);
  }
  free(board);
  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
