#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26268"

/** Maximum word length */
#define WORD_LIMIT 26

/** Max command length */
#define COM_LIMIT 60

/** Dictionary number of words */
#define DIC_LEN 102401

//pointer to pointer to keep board
char **board;
//size of board
int n, m;

//mutex lock
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

//dictionary
char words[DIC_LEN][WORD_LIMIT + 1];

//flag for words
int wordsFound = 0;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

//Method to build the board initially
void buildBoard() {
  board = (char **) malloc(n * sizeof(char *));
  for (int i = 0; i < n; i++) {
    board[i] = (char *) malloc(m * sizeof(char));
    for (int j = 0; j < m; j++) {
      board[i][j] = ' ';
    }
  }
}

//Method to free the board
void freeBoard() {
  for (int i = 0; i < n; i++) {
    free(board[i]);
  }
  free(board);
}

//Method to print the board
// @param fp file pointer to print to
void printBoard(FILE *fp) {

  //lock
  pthread_mutex_lock(&lock);

  fprintf(fp, "+");
  for (int i = 0; i < m; i++) {
    fprintf(fp, "-");
  }
  fprintf(fp, "+\n");
  for (int i = 0; i < n; i++) {
    fprintf(fp, "|");
    for (int j = 0; j < m; j++) {
      fprintf(fp, "%c", board[i][j]);
    }
    fprintf(fp, "|\n");
  }
  fprintf(fp, "+");
  for (int i = 0; i < m; i++) {
    fprintf(fp, "-");
  }
  fprintf(fp, "+\n");

  //unlock
  pthread_mutex_unlock(&lock);
}

/**
 * Method to check word againts dictionary
 * @param word the word to check
 * @return -1 if not found
 */
int checkWord(char word[WORD_LIMIT + 1]) {
  
  if (!wordsFound) {
    return 0;
  }
  for (int i = 0; i < DIC_LEN; i++) {
    if (strcmp(words[i], word) == 0) {
      return 0;
    }
  } 
  return -1;
}

/**
 * Method to check board words
 * @return 0 if valid -1 if invalid
 */
int checkBoard() {
  
  //check horizontal
  char word[WORD_LIMIT + 1];
  for (int i = 0; i < n; i++) {
    int nr = 0;
    for (int j = 0; j < m; j++) {
      if (board[i][j] != ' ') {
        word[nr++] = board[i][j];
        if (nr > WORD_LIMIT) {
          return -1;
        }
      }
      if (board[i][j] == ' ' || j == m - 1) {
        word[nr] = '\0';
        if (nr > 1 && checkWord(word) == -1) {
          return -1;
        }
        nr = 0;
      }
    }
  }
  //check vertical
  for (int j = 0; j < m; j++) {
    int nr = 0;
    for (int i = 0; i < n; i++) {
      if (board[i][j] != ' ') {
        word[nr++] = board[i][j];
        if (nr > WORD_LIMIT) {
          return -1;
        }
      }
      if (board[i][j] == ' ' || i == n - 1) {
        word[nr] = '\0';
        if (nr > 1 && checkWord(word) == -1) {
          return -1;
        }
        nr = 0;
      }
    }
  }
  return 0;
}

/**
 * Method to apply cross operation on board
 * @param x the x coordinate of the operation
 * @param y the y coordinate of the operation
 * @param word the word to put on board
 */
int applyAcross(int x, int y, char word[WORD_LIMIT + 2]) {
  
  //lock
  pthread_mutex_lock(&lock);

  if (y + strlen(word) > m) {
    //unlock
    pthread_mutex_unlock(&lock);
    return -1;
  }
  for (int j = 0; j < strlen(word); j++) {
    if (board[x][y + j] != ' ' && board[x][y + j] != word[j]) {
      //unlock
      pthread_mutex_unlock(&lock);
      return -1;
    }
  }
  
  char old[WORD_LIMIT + 2];
  for (int j = 0; j < strlen(word); j++) {
    old[j] = board[x][y + j];
    board[x][y + j] = word[j];
  }
  
  if (checkBoard() == -1) {
    for (int j = 0; j < strlen(word); j++) {
      board[x][y + j] = old[j];
    }
    //unlock
    pthread_mutex_unlock(&lock);
    return -1;
  }
  //unlock
  pthread_mutex_unlock(&lock);
  return 0;
}

/**
 * Method to apply downoperation on board
 * @param x the x coordinate of the operation
 * @param y the y coordinate of the operation
 * @param word the word to put on board
 */
int applyDown(int x, int y, char word[WORD_LIMIT + 2]) {

  //lock
  pthread_mutex_lock(&lock);
 
  if (x + strlen(word) > n) {
    //unlock
    pthread_mutex_unlock(&lock);
    return -1;
  }
  for (int i = 0; i < strlen(word); i++) {
    if (board[x + i][y] != ' ' && board[x + i][y] != word[i]) {
      //unlock
      pthread_mutex_unlock(&lock);
      return -1;
    }
  }
  
  char old[WORD_LIMIT + 2];
  for (int i = 0; i < strlen(word); i++) {
    old[i] = board[x + i][y];
    board[x + i][y] = word[i];
  }

  if (checkBoard() == -1) {
    for (int i = 0; i < strlen(word); i++) {
      board[x + i][y] = old[i];
    }
    //unlock
    pthread_mutex_unlock(&lock);
    return -1;
  }
  //unlock
  pthread_mutex_unlock(&lock);
  return 0;
}

/**
 * Method to process command
 * @param cmd command string
 * @return code about status
 */
int processCommand(char cmd[COM_LIMIT + 1], FILE *fp) {
  
  //command checks
  char word[WORD_LIMIT + 2];
  int x = -1, y = -1;
  
  if (strcmp(cmd, "board") == 0) {
    printBoard(fp);
    return 0;
  }
  if (strcmp(cmd, "across") != 0 && strcmp(cmd, "down") != 0) {
    return -1;
  }

  int nr = fscanf(fp, "%d %d %27s", &x, &y, word);
  if (nr != 3 || strlen(word) > WORD_LIMIT) {
    return -1;
  }
  if (x < 0 || y < 0 || x >= n || y >= m) {
    return -1;
  }
  for (int i = 0; i < strlen(word); i++) {
    if (word[i] < 'a' || word[i] > 'z') {
      return -1;
    }
  }
  
  if (strcmp(cmd, "across") == 0) {
    return applyAcross(x, y, word);
  }
  return applyDown(x, y, word);
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *pSock ) {
  
  //sock value
  int sock = *(int *)pSock;

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ COM_LIMIT + 1];
  while ( fscanf( fp, "%60s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    //process command
    int status = processCommand(cmd, fp);

    if (status == -1) {
      fprintf(fp, "Invalid command\n");
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  //read word file
  FILE *fwp = NULL;
  fwp = fopen("words", "r");

  if (fwp != NULL) {
    wordsFound = 1;
    int nr = 0;
    while (fgets(words[nr], WORD_LIMIT, fwp) != NULL) {
      words[nr][strlen(words[nr]) - 1] = '\0';
      nr++;
    }
  }

  //make the board
  if (sscanf(argv[1], "%d", &n) != 1)
    fail("Can't read rows");

  if (sscanf(argv[2], "%d", &m) != 1)
    fail("Can't read columns");

  buildBoard();

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    
    pthread_t thread;
    pthread_create(&thread, NULL, handleClient, (void *)&sock);

    pthread_detach(thread);
  }

  // Stop accepting client connections (never reached).
  close( servSock );

  freeBoard();
  
  return 0;
}
