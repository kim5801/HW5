#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "28123"

/** Maximum word length */
#define WORD_LIMIT 26

/** Semaphore to prevent multiple threads from accessing the board at once.*/
sem_t boardStop;

bool running;

/** Struct to hold the arguments for the pthread_create, so as to avoid void problems */
typedef struct threadArgs {
  int socket;
} threadArgs;

/** Representation of the state of the board. */
typedef struct BoardState {
  char **sBoard;
  int r;
  int c;
} BoardState;

/** The struct that represents the board.*/
BoardState *gameBoard;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** Places a new word on the board going horizontally. 
The left end of the word starts at the given row, r, and column, c, on the board. */
void across( int r, int c, char *word, FILE *fp) {

  // Check that the starting point of the word is within the bounds of the board
  if (r < 0 || c < 0 || r > gameBoard->r || c > gameBoard->c) {
    fprintf( fp, "Invalid command\n");
    return;
  }
  // Check that the ending point of the word is within the bounds of the board
  if (strlen(word) + c > gameBoard->c) {
    fprintf( fp, "Invalid command\n");
    return;
  }
  int wordLength = strlen(word);
  // Check that the word contains no uppercase or non-alphabetical characters
  for (int i = 0; i < wordLength; i++) {
    if (isalpha(word[i]) == 0 || isupper(word[i]) != 0) {
      fprintf( fp, "Invalid command\n");
      return;
    }
  }
  // Check that the word is less than 27 characters and greater than 0 characters
  if (wordLength > 26 || wordLength < 1) {
    fprintf( fp, "Invalid command\n");
    return;
  }
  // Check that the word doesn't conflict with any existing words on the board.
  int k = 0;
  for (int i = c; i < wordLength + c; i++) {
    if (gameBoard->sBoard[r][i] != ' ' && gameBoard->sBoard[r][i] != word[k]) {
      fprintf( fp, "Invalid command\n");
      return;
    }
    k++;
  }

  // If the word makes it past the above checks, then add it to the board
  int j = 0;
  for (int i = c; i < c + wordLength; i++) {
    gameBoard->sBoard[r][i] = word[j++];
  }
}

/** Places a new word on the board going vertically. 
The top end of the word starts at the given row, r, and column, c, on the board. */
void down( int r, int c, char *word, FILE *fp) {
  // Check that the starting point of the word is within the bounds of the board
  if (r < 0 || c < 0 || r > gameBoard->r || c > gameBoard->c) {
    fprintf( fp, "Invalid command\n");
    return;
  }
  // Check that the ending point of the word is within the bounds of the board
  if (strlen(word) + r > gameBoard->r) {
    fprintf( fp, "Invalid command\n");
    return;
  }
  int wordLength = strlen(word);
  // Check that the word contains no uppercase or non-alphabetical characters
  for (int i = 0; i < wordLength; i++) {
    if (isalpha(word[i]) == 0 && isupper(word[i]) != 0) {
      fprintf( fp, "Invalid command\n");
      return;
    }
  }
  // Check that the word is less than 27 characters and greater than 0 characters
  if (wordLength > 26 || wordLength < 1) {
    fprintf( fp, "Invalid command\n");
    return;
  }
  // Check that the word doesn't conflict with any existing words on the board.
  int k = 0;
  for (int i = r; i < wordLength + r; i++) {
    if (gameBoard->sBoard[i][c] != ' ' && gameBoard->sBoard[i][c] != word[k]) {
      fprintf( fp, "Invalid command\n");
      return;
    }
    k++;
  }

  // If the word makes it past the above checks, then add it to the board
  int j = 0;
  for (int i = r; i < wordLength + r; i++) {
    gameBoard->sBoard[i][c] = word[j++];
  }
}

/** Instructs the server to print the current state of the board for the client. 
It should be printed with a border around the edge consisting of vertical bars on 
the left and right, dashes along the top and bottom and plus signs in the corners.*/
void board(FILE *fp) {
  // print the top boarder line
  fprintf( fp, "+------------+\n");

  // Cycle through the entire board and print the contents;
  for (int i = 0; i < gameBoard->r; i++) {
    fprintf( fp, "|");
    for (int j = 0; j < gameBoard->c; j++) {
      fprintf( fp, "%c", gameBoard->sBoard[i][j]);
    }
    fprintf( fp, "|\n");
  }

  // print the bottom boarder line
  fprintf( fp, "+------------+\n");
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *sock ) {
  // get the socket out of the struct passed in as an argument:
  threadArgs *tSocket = sock;

  // Detach thread here:
  pthread_detach(pthread_self());

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( tSocket->socket, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 && strcmp( cmd, "quit" ) != 0 ) {
    // If the user inputs an invalid command (not across, down, or board), then the server should
    // print "Invalid command" and ignore the user's command, re-prompting them for a new command.
    if (strcmp( cmd, "across") != 0 && strcmp(cmd, "down") != 0 && strcmp(cmd, "board") != 0) {
      fprintf( fp, "Invalid command\n");
    }

    // Variable to hold the word that may be input
    char word[28];
    // Row to start the word in
    int row;
    // Col to start the word in
    int col;

    // Check that if the user requested a move (across or down) that they also put in a 
    // valid start location (row and col), and a word.
    if (strcmp( cmd, "across") == 0 || strcmp(cmd, "down") == 0 ) {
      
      fseek(fp,0,SEEK_SET);
      //char trashCmd[11];
      // If the user inputs a valid set of numbers for the row and col, as well as a valid word, it can be 
      // sent to the requested command. If not, we print "Invalid command" and prompt for a new command.
      
      if (fscanf( fp, "%3d %3d %27s", &row, &col, word ) != 3 ) {
        fprintf( fp, "Invalid command\n");
      }
      else {
        if (strcmp( cmd, "across") == 0) {
          sem_wait(&boardStop);
          across(row, col, word, fp);
          sem_post(&boardStop);
        }
        
        if (strcmp( cmd, "down") == 0) {
          sem_wait(&boardStop);
          down(row, col, word, fp);
          sem_post(&boardStop);
        }
      }
    }

    // if user inputs command "board", print the current state of the board to the terminal.
    if (strcmp( cmd, "board") == 0) {
      sem_wait(&boardStop);
      board(fp);
      sem_post(&boardStop);
    }


    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }
  
  running = false;
  
  // Close the connection with this client.
  fclose( fp );
  pthread_exit(NULL);
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  //initialize the semaphore that prevents multiple threads from accessing the board at once.
  sem_init(&boardStop, 0, 1);

  // Check the user input on startup, to be sure they have the correct usage.
  // There should be a 2 additional arguments, one for number of rows, and one for number of columns.
  if (argc < 3) {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  // Throw usage error if the user puts in invalid values for rows and columns
  if (atoi(argv[1]) < 1 || atoi(argv [2]) < 1) {
    fail("usage: scrabbleServer <rows> <cols>");
  }

  // Initialize the board with the given row and column numbers.
  gameBoard = malloc(sizeof(BoardState));
  gameBoard->r = atoi(argv[1]) + 0;
  gameBoard->c = atoi(argv[2]) + 0;
  gameBoard->sBoard = malloc( sizeof(*gameBoard->sBoard) * gameBoard->r );
  if ( gameBoard->sBoard )
  {
    for ( size_t i = 0; i < gameBoard->r; i++ ) {
      gameBoard->sBoard[i] = malloc( sizeof(*gameBoard->sBoard[i]) * gameBoard->c );
    }
  }
  // Set every slot on the board to " " to indicate that those slots are empty.
  for (int i = 0; i < gameBoard->r; i++) {
    for (int j = 0; j < gameBoard->c; j++) {
      gameBoard->sBoard[i][j] = ' ';
    }
  }

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  threadArgs *tArgs;
  pthread_t tid;

  running = true;

  while ( running  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    tArgs = malloc(sizeof(threadArgs));
    tArgs->socket = sock;
    pthread_create(&tid, NULL, handleClient, tArgs);
    //handleClient( sock );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
