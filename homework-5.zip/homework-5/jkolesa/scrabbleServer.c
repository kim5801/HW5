/**
 * @file scrabble.c
 * @author Jonathan Kolesar (jkolesa)
 * This compenent acts as the server which handles all connections to clients. Each client gives
 * the server commands (game actions) to play the game called Scrabble. This program demonstates the 
 * use of TCP to connect a server with a client.
 */


#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>


/** Port number used by my server */
#define PORT_NUMBER "26312"

/** Maximum command length */
#define COMMAND_LIMIT 6

/** Maximum word length */
#define WORD_LIMIT 26

/** Semaphore for when a thread wants to use the gameboard */
sem_t useBoard;

/** Number of rows for the board given at start up */
int numRows;

/** Number of cols for the board given at start up */
int numCols;

/** Number of digits the given number of rows is */
int rowCount;

/** Number of digits the given number of cols is */
int colCount;

/** The character array representing the game board */
char **gameBoard;


/**
 * General function to report a failure and exit.
 * 
 * @param message failure message to report
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}


/**
 * Handles a client connection to make moves on the scrabble board.
 * Closes when we're done.
 * 
 * @param givenSock the socket the client is using
 */
void *handleClient( void *givenSock ) {

  // Casts the given socket to a local variable.
  int sock = *((int *) givenSock);
  free( givenSock );

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );


  /////////////
  // COMMAND //
  /////////////

  cmdPrompt:;

  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Allocates the buffer for reading in the given command from the client.
  char *commandInputArray = (char *) malloc( ( COMMAND_LIMIT + 1 ) * sizeof( char ) );
  // Initializes the array to null terminator characters.
  for ( int i = 0; i <= COMMAND_LIMIT; i++ ) {
    commandInputArray[ i ] = '\0';
  }

  // Number of characters read-in
  int numCharsRead = 0;

  // Read in the given word from the client.
  char currentChar = ' ';
  while ( ( currentChar = fgetc( fp ) ) != ' ' ) {

    if ( currentChar == '\n' ) {
      break;
    }

    // Invalid if the current character is not a lowercase.
    if ( currentChar < 'a' || currentChar > 'z' ) {
      free( commandInputArray );
      fprintf( fp, "Invalid command\n" );
      break;
    }
    
    // Invalid if the number of characters is greater than the 26.
    if ( numCharsRead > COMMAND_LIMIT ) {
      free( commandInputArray );
      fprintf( fp, "Invalid command\n" );
      break;
    }

    // Store the latest char in the next array slot.
    commandInputArray[ numCharsRead ] = currentChar;
    numCharsRead++;
  }

  if ( ( currentChar != '\n' && currentChar != ' ' ) && ( ( currentChar < 'a' || currentChar > 'z' ) || ( numCharsRead > COMMAND_LIMIT ) ) ) {
    goto cmdPrompt;
  }

  char cmd[ COMMAND_LIMIT + 1 ] = { '\0' };
  strcpy( cmd, commandInputArray );

  free( commandInputArray );

  // Checks if given command's are in the correct format.
  if ( strcmp( cmd, "across" ) == 0 && currentChar != ' ' ) {
    fprintf( fp, "Invalid command\n" );
    goto cmdPrompt;
  } else if ( strcmp( cmd, "down" ) == 0 && currentChar != ' ' ) {
    fprintf( fp, "Invalid command\n" );
    goto cmdPrompt;
  } else if ( strcmp( cmd, "board" ) == 0 && currentChar != '\n' ) {
    fprintf( fp, "Invalid command\n" );
    goto cmdPrompt;
  } else if ( strcmp( cmd, "quit" ) == 0 && currentChar != '\n' ) {
    fprintf( fp, "Invalid command\n" );
    goto cmdPrompt;
  }


  /////////////////
  // END COMMAND //
  /////////////////


  // Checks if the the given command is "across".
  if ( strcmp( cmd, "across" ) == 0 ) {
    
    /////////
    // ROW //
    /////////

    // Allocates the buffer for reading in the given row from the client.
    char *rowInputArray = (char *) malloc( ( rowCount + 1 ) * sizeof( char ) );
    // Initializes the array to null terminator characters.
    for ( int i = 0; i <= rowCount; i++ ) {
      rowInputArray[ i ] = '\0';
    }

    // Number of characters read-in
    int numCharsRead = 0;

    // Read in the given row from the client.
    char currentChar = ' ';
    while ( ( currentChar = fgetc( fp ) ) != ' ' ) {

      // Invalid if the current character is not a digit.
      if ( currentChar < '0' || currentChar > '9' ) {
        free( rowInputArray );
        fprintf( fp, "Invalid command\n" );
        break;
      }
      
      // Invalid if the number of digits is greater than the number 
      // of digits of the row dimension of the gameboard.
      if ( numCharsRead > rowCount ) {
        free( rowInputArray );
        fprintf( fp, "Invalid command\n" );
        break;
      }

      // Store the current char in the next array slot.
      rowInputArray[ numCharsRead ] = currentChar;
      numCharsRead++;
    }

    if ( currentChar != ' ' && ( ( currentChar < '0' || currentChar > '9' ) || ( numCharsRead > rowCount ) ) ) {
      goto cmdPrompt;
    }

    // Invalid if the given row number starts with a '0' and is multiple digits long.
    if ( rowInputArray[ 0 ] == '0' && numCharsRead > 1 ) {
      free( rowInputArray );
      fprintf( fp, "Invalid command\n" );
      goto cmdPrompt;
    }

    // Attemps to convert the client row to an integer.
    int givenRowNum = atoi( rowInputArray );

    // Invalid if the given row number is greater than the number of rows in the game board.
    if ( givenRowNum >= numRows ) {
      free( rowInputArray );
      fprintf( fp, "Invalid command\n" );
      goto cmdPrompt;
    }

    free( rowInputArray );


    /////////////
    // END ROW //
    /////////////


    /////////
    // COL //
    /////////


    // Allocates the buffer for reading in the given col from the client.
    char *colInputArray = (char *) malloc( ( colCount + 1 ) * sizeof( char ) );
    // Initializes the array to null terminator characters.
    for ( int i = 0; i <= colCount; i++ ) {
      colInputArray[ i ] = '\0';
    }

    // Number of characters read-in
    numCharsRead = 0;

    // Read in the given col from the client.
    currentChar = ' ';
    while ( ( currentChar = fgetc( fp ) ) != ' ' ) {

      // Invalid if the current character is not a digit.
      if ( currentChar < '0' || currentChar > '9' ) {
        free( colInputArray );
        fprintf( fp, "Invalid command\n" );
        break;
      }
      
      // Invalid if the number of digits is greater than the number 
      // of digits of the col dimension of the gameboard.
      if ( numCharsRead > colCount ) {
        free( colInputArray );
        fprintf( fp, "Invalid command\n" );
        break;
      }

      // Store the latest char in the next array slot.
      colInputArray[ numCharsRead ] = currentChar;
      numCharsRead++;
    }

    if ( currentChar != ' ' && ( ( currentChar < '0' || currentChar > '9' ) || ( numCharsRead > colCount ) ) ) {
      goto cmdPrompt;
    }

    // Invalid if the given col number starts with a '0' and is multiple digits long.
    if ( colInputArray[ 0 ] == '0' && numCharsRead > 1 ) {
      free( colInputArray );
      fprintf( fp, "Invalid command\n" );
      goto cmdPrompt;
    }

    // Attemps to convert the client col to an integer.
    int givenColNum = atoi( colInputArray );

    // Invalid if the given col number is greater than the number of cols in the game board.
    if ( givenColNum >= numCols ) {
      free( colInputArray );
      fprintf( fp, "Invalid command\n" );
      goto cmdPrompt;
    }

    free( colInputArray );


    /////////////
    // END COL //
    /////////////

    
    //////////
    // WORD //
    //////////


    // Allocates the buffer for reading in the given word from the client.
    char *wordInputArray = (char *) malloc( ( WORD_LIMIT + 1 ) * sizeof( char ) );
    // Initializes the array to null terminator characters.
    for ( int i = 0; i <= WORD_LIMIT; i++ ) {
      wordInputArray[ i ] = '\0';
    }

    // Number of characters read-in
    numCharsRead = 0;

    // Read in the given word from the client.
    currentChar = ' ';
    while ( ( currentChar = fgetc( fp ) ) != '\n' ) {

      // Invalid if the current character is not a lowercase.
      if ( currentChar < 'a' || currentChar > 'z' ) {
        free( wordInputArray );
        fprintf( fp, "Invalid command\n" );
        break;
      }
      
      // Invalid if the number of characters is greater than the 26.
      if ( numCharsRead > WORD_LIMIT ) {
        free( wordInputArray );
        fprintf( fp, "Invalid command\n" );
        break;
      }

      // Store the latest char in the next array slot.
      wordInputArray[ numCharsRead ] = currentChar;
      numCharsRead++;
    }

    if ( currentChar != '\n' && ( ( currentChar < 'a' || currentChar > 'z' ) || ( numCharsRead > WORD_LIMIT ) ) ) {
      goto cmdPrompt;
    }

    char word[ WORD_LIMIT + 1 ] = { '\0' };
    strcpy( word, wordInputArray );

    free( wordInputArray );

    
    //////////////
    // END WORD //
    //////////////


    //////////////////////////
    // ADDING TO GAME BOARD //
    //////////////////////////


    int wordLen = strlen( word );

    if ( wordLen == 0 ) {
      fprintf( fp, "Invalid command\n" );
      goto cmdPrompt;
    }

    if ( givenColNum + wordLen > numCols ) {
      fprintf( fp, "Invalid command\n" );
      goto cmdPrompt;
    }

    // Waits to update the game board.
    sem_wait( &useBoard );

    int gameBoardColIdx = givenColNum;
    int i;
    bool invalidCmd = false;
    // Checks that there are no conflicts with exitsing characters at the game board insertion location.
    for ( i = 0; i < wordLen; i++ ) {
      if ( word[ i ] != gameBoard[ givenRowNum ][ gameBoardColIdx ] && gameBoard[ givenRowNum ][ gameBoardColIdx ] != ' ' ) {
        fprintf( fp, "Invalid command\n" );
        invalidCmd = true;
        break;
      }
      gameBoardColIdx++;
    }

    if ( invalidCmd && word[ i ] != gameBoard[ givenRowNum ][ gameBoardColIdx ] && gameBoard[ givenRowNum ][ gameBoardColIdx ] != ' ' ) {
        // Releases the game board.
        sem_post( &useBoard );
        goto cmdPrompt;
    }

    gameBoardColIdx = givenColNum;
    // Fills in the game board with the at the insertion location with the word.
    for ( int j = 0; j < wordLen; j++ ) {
      gameBoard[ givenRowNum ][ gameBoardColIdx ] = word[ j ];
      gameBoardColIdx++;
    }

    // Releases the game board.
    sem_post( &useBoard );


    /////////////////////////////////
    // END OF ADDING TO GAME BOARD //
    /////////////////////////////////


    goto cmdPrompt;



  // Checks if the the given command is "down".
  } else if ( strcmp( cmd, "down" ) == 0 ) {


    /////////
    // ROW //
    /////////


    // Allocates the buffer for reading in the given row from the client.
    char *rowInputArray = (char *) malloc( ( rowCount + 1 ) * sizeof( char ) );
    // Initializes the array to null terminator characters.
    for ( int i = 0; i <= rowCount; i++ ) {
      rowInputArray[ i ] = '\0';
    }

    // Number of characters read-in
    int numCharsRead = 0;

    // Read in the given row from the client.
    char currentChar = ' ';
    while ( ( currentChar = fgetc( fp ) ) != ' ' ) {

      // Invalid if the current character is not a digit.
      if ( currentChar < '0' || currentChar > '9' ) {
        free( rowInputArray );
        fprintf( fp, "Invalid command\n" );
        break;
      }
      
      // Invalid if the number of digits is greater than the number 
      // of digits of the row dimension of the gameboard.
      if ( numCharsRead > rowCount ) {
        free( rowInputArray );
        fprintf( fp, "Invalid command\n" );
        break;
      }

      // Store the current char in the next array slot.
      rowInputArray[ numCharsRead ] = currentChar;
      numCharsRead++;
    }

    if ( currentChar != ' ' && ( ( currentChar < '0' || currentChar > '9' ) || ( numCharsRead > rowCount ) ) ) {
      goto cmdPrompt;
    }

    // Invalid if the given row number starts with a '0' and is multiple digits long.
    if ( rowInputArray[ 0 ] == '0' && numCharsRead > 1 ) {
      free( rowInputArray );
      fprintf( fp, "Invalid command\n" );
      goto cmdPrompt;
    }

    // Attemps to convert the client row to an integer.
    int givenRowNum = atoi( rowInputArray );

    // Invalid if the given row number is greater than the number of rows in the game board.
    if ( givenRowNum >= numRows ) {
      free( rowInputArray );
      fprintf( fp, "Invalid command\n" );
      goto cmdPrompt;
    }

    free( rowInputArray );


    /////////////
    // END ROW //
    /////////////


    /////////
    // COL //
    /////////


    // Allocates the buffer for reading in the given col from the client.
    char *colInputArray = (char *) malloc( ( colCount + 1 ) * sizeof( char ) );
    // Initializes the array to null terminator characters.
    for ( int i = 0; i <= colCount; i++ ) {
      colInputArray[ i ] = '\0';
    }

    // Number of characters read-in
    numCharsRead = 0;

    // Read in the given col from the client.
    currentChar = ' ';
    while ( ( currentChar = fgetc( fp ) ) != ' ' ) {

      // Invalid if the current character is not a digit.
      if ( currentChar < '0' || currentChar > '9' ) {
        free( colInputArray );
        fprintf( fp, "Invalid command\n" );
        break;
      }
      
      // Invalid if the number of digits is greater than the number 
      // of digits of the col dimension of the gameboard.
      if ( numCharsRead > colCount ) {
        free( colInputArray );
        fprintf( fp, "Invalid command\n" );
        break;
      }

      // Store the latest char in the next array slot.
      colInputArray[ numCharsRead ] = currentChar;
      numCharsRead++;
    }

    if ( currentChar != ' ' && ( ( currentChar < '0' || currentChar > '9' ) || ( numCharsRead > colCount ) ) ) {
      goto cmdPrompt;
    }

    // Invalid if the given col number starts with a '0' and is multiple digits long.
    if ( colInputArray[ 0 ] == '0' && numCharsRead > 1 ) {
      free( colInputArray );
      fprintf( fp, "Invalid command\n" );
      goto cmdPrompt;
    }

    // Attemps to convert the client col to an integer.
    int givenColNum = atoi( colInputArray );

    // Invalid if the given col number is greater than the number of cols in the game board.
    if ( givenColNum >= numCols ) {
      free( colInputArray );
      fprintf( fp, "Invalid command\n" );
      goto cmdPrompt;
    }

    free( colInputArray );


    /////////////
    // END COL //
    /////////////

    
    //////////
    // WORD //
    //////////


    // Allocates the buffer for reading in the given word from the client.
    char *wordInputArray = (char *) malloc( ( WORD_LIMIT + 1 ) * sizeof( char ) );
    // Initializes the array to null terminator characters.
    for ( int i = 0; i <= WORD_LIMIT; i++ ) {
      wordInputArray[ i ] = '\0';
    }

    // Number of characters read-in
    numCharsRead = 0;

    // Read in the given word from the client.
    currentChar = ' ';
    while ( ( currentChar = fgetc( fp ) ) != '\n' ) {

      // Invalid if the current character is not a lowercase.
      if ( currentChar < 'a' || currentChar > 'z' ) {
        free( wordInputArray );
        fprintf( fp, "Invalid command\n" );
        break;
      }
      
      // Invalid if the number of characters is greater than the 26.
      if ( numCharsRead > WORD_LIMIT ) {
        free( wordInputArray );
        fprintf( fp, "Invalid command\n" );
        break;
      }

      // Store the latest char in the next array slot.
      wordInputArray[ numCharsRead ] = currentChar;
      numCharsRead++;
    }

    if ( currentChar != '\n' && ( ( currentChar < 'a' || currentChar > 'z' ) || ( numCharsRead > WORD_LIMIT ) ) ) {
      goto cmdPrompt;
    }

    char word[ WORD_LIMIT + 1 ] = { '\0' };
    strcpy( word, wordInputArray );

    free( wordInputArray );
    

    //////////////
    // END WORD //
    //////////////


    //////////////////////////
    // ADDING TO GAME BOARD //
    //////////////////////////


    int wordLen = strlen( word );

    if ( wordLen == 0 ) {
      fprintf( fp, "Invalid command\n" );
      goto cmdPrompt;
    }

    if ( givenRowNum + wordLen > numRows ) {
      fprintf( fp, "Invalid command\n" );
      goto cmdPrompt;
    }

    // Waits to update the game board.
    sem_wait( &useBoard );

    int gameBoardRowIdx = givenRowNum;
    int i;
    bool invalidCmd = false;
    // Checks that there are no conflicts with exitsing characters at the game board insertion location.
    for ( i = 0; i < wordLen; i++ ) {
      if ( word[ i ] != gameBoard[ gameBoardRowIdx ][ givenColNum ] && gameBoard[ gameBoardRowIdx ][ givenColNum ] != ' ' ) {
        fprintf( fp, "Invalid command\n" );
        invalidCmd = true;
        break;
      }
      gameBoardRowIdx++;
    }

    if ( invalidCmd && word[ i ] != gameBoard[ gameBoardRowIdx ][ givenColNum ] && gameBoard[ gameBoardRowIdx ][ givenColNum ] != ' ' ) {
      goto cmdPrompt;
    }

    gameBoardRowIdx = givenRowNum;
    // Fills in the game board with the at the insertion location with the word.
    for ( int j = 0; j < wordLen; j++ ) {
      gameBoard[ gameBoardRowIdx ][ givenColNum ] = word[ j ];
      gameBoardRowIdx++;
    }

    // Releases the game board.
    sem_post( &useBoard );


    /////////////////////////////////
    // END OF ADDING TO GAME BOARD //
    /////////////////////////////////


    goto cmdPrompt;
  


  // Checks if the the given command is "board".
  } else if ( strcmp( cmd, "board" ) == 0 ) {

    /////////////////////////
    // PRINTING GAME BOARD //
    /////////////////////////
    

    // Prints the top of the border.
    fprintf( fp, "+" );
    for ( int i = 0; i < numCols; i++ ) {
      fprintf( fp, "-" );
    }
    fprintf( fp, "+\n" );

    // Waits to print 
    sem_wait( &useBoard );

    // Prints all the contents of the game board with the sides of the border.
    for ( int i = 0; i < numRows; i++ ) {
      fprintf( fp, "|" );
      for ( int j = 0; j < numCols; j++ ) {
        fprintf( fp, "%c", gameBoard[ i ][ j ] );
      }
      fprintf( fp, "|\n" );
    }

    // Releases the game board.
    sem_post( &useBoard );

    // Prints the bottom of the border.
    fprintf( fp, "+" );
    for ( int i = 0; i < numCols; i++ ) {
      fprintf( fp, "-" );
    }
    fprintf( fp, "+\n" );


    /////////////////////////
    // PRINTING GAME BOARD //
    /////////////////////////


    goto cmdPrompt;



  // Otherwise, the command given by the client is invalid.
  } else if ( strcmp( cmd, "quit" ) == 0 ) {

    // Close the connection with this client.
    fclose( fp );
    return NULL;
  
  } else {
    fprintf( fp, "Invalid command\n" );
  }
  

  goto cmdPrompt;
}

int main( int argc, char *argv[] ) {

  // Checks that the correct number of command line arguments are given by the user.
  if ( argc != 3 )
    fail( "usage: scrabbleServer <rows> <cols>" );

  // Attempts to convert the given command line arguments to ints and store them.
  numRows = atoi( argv[ 1 ] );
  numCols = atoi( argv[ 2 ] );

  // Checks that the given number of rows and columns is greater than 0.
  if ( numRows <= 0 || numCols <= 0 )
    fail( "usage: scrabbleServer <rows> <cols>" );

  // Allocate the gameBoard with the given number of rows and cols.
  gameBoard = malloc( numRows * sizeof( char * ) );
  for ( int i = 0; i < numRows; i++ ) {
    gameBoard[ i ] = malloc( numCols * sizeof( char ) );
  }

  // Initialize the gameBoard with null terminator characters.
  for ( int i = 0; i < numRows; i++ ) {
    for ( int j = 0; j < numCols; j++ ) {
      gameBoard[ i ][ j ] = ' ';
    }
  }

  // Calculates how many digits the given row number is.
  int number = numRows;
  rowCount = 0;
  do {
    number /= 10;
    ++rowCount;
  } while ( number != 0 );

  // Calculates how many digits the given col number is.
  number = numCols;
  colCount = 0;
  do {
    number /= 10;
    ++colCount;
  } while ( number != 0 );

  // Initializes the semaphore that is used when a thread wants to use the game board.
  sem_init( &useBoard, 0, 1 );


  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);


  pthread_t clientThread;

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    int *sockAllocated = malloc( sizeof( *sockAllocated ) );
    *sockAllocated = sock;

    if ( pthread_create( &clientThread, NULL, handleClient, (void *) sockAllocated ) != 0 )
        fail( "Can't create a child thread\n" );
    pthread_detach( clientThread );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
