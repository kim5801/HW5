#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26332"

/** Maximum word length */
#define WORD_LIMIT 26

char **board;
int rows;
int cols;

sem_t lock;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}


/** handle a client connection, close it when we're done. */
void *handleClient( void *vSock) {

  int *sock = (int *)vSock; //cast socket

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( *sock, "a+" );


  // Prompt the user for a command.
  fprintf( fp, "cmd> ");

  // Temporary values for parsing commands.
  char buffer[100];
  char cmd[ 11 ];
  int r = 0;
  int c = 0;
  char word[50];
  while (fgets(buffer, sizeof(buffer), fp) != NULL && strcmp( cmd, "quit" ) != 0 ) {

    //Scan for all arguments of the cmd
	  int args = sscanf(buffer, "%s %d %d %s", cmd,  &r, &c, word);

    if(strcmp( cmd, "board" ) == 0 ) { //Prints board
      fputc('+', fp);
      for(int i = 0; i < cols; i++) {
        fputc('-', fp);
      }
      fputc('+', fp);
      fputc('\n', fp);

      fputc('|', fp);
      for(int i = 0; i < rows; i++) {
        if(i > 0) {
          fputc('|', fp);
        }
        sem_wait(&lock);
        for(int ii = 0; ii < cols; ii++) {
          fputc(*(*(board + i) + ii), fp);
        }
        sem_post(&lock);
        fputc('|', fp);
        fputc('\n', fp);
      }

      fputc('+', fp);
      for(int i = 0; i < cols; i++) {
        fputc('-', fp);
      }
      fputc('+', fp);
      fputc('\n', fp);
    }
    else if(args == 4 && strlen(word) > 0 && strlen(word) <= WORD_LIMIT && r < rows && c < cols && c >= 0 && r >= 0) {

      //Check if word is lowercase
      bool lower = 1;
      for(int i = 0; i < strlen(word); i++) {
        if(word[i] < 'a' || word[i] > 'z') {
          lower = 0;
        }
      }

      if(lower) {

        if(strcmp( cmd, "across" ) == 0 ) { //handle across cmd
          if(c + strlen(word) <= cols) {

            //Check if word overwrites the board
            bool check = 1;
            for(int i = 0; i < strlen(word); i++) {
              if(board[r][c + i] != ' ' && board[r][c + i] != word[i]) {
                check = 0;
              }
            }

            if(check) {
              sem_wait(&lock);

              //Update boad while semaphore is locked
              for(int i = 0; i < strlen(word); i++) {
                board[r][c + i] = word[i];
              }
              sem_post(&lock);
            }
            else {
              fprintf(fp, "Invalid command\n" );
            }

          }
          else {
            fprintf(fp, "Invalid command\n" );
          }
        }
        else if(strcmp( cmd, "down") == 0 ) { //handle down command
          if(r + strlen(word) <= rows) { //check if word goes over limit

            //Check if word overwrites the board
            bool check = 1;
            for(int i = 0; i < strlen(word); i++) {
              if(board[r + i][c] != ' ' && board[r + i][c] != word[i]) {
                check = 0;
              }
            }

            if(check) {
              sem_wait(&lock);

              //Update board inside semaphore
              for(int i = 0; i < strlen(word); i++) {
                board[r + i][c] = word[i];
              }
              sem_post(&lock);
            }
            else {
              fprintf(fp, "Invalid command\n" );
            }

          }
          else {
            fprintf(fp, "Invalid command\n" );
          }
        }

      }
      else {
        fprintf(fp, "Invalid command\n" );
      }
    }
    else if(strcmp( cmd, "quit" ) == 0 ) {
      break;
    }
    else {
      fprintf(fp, "Invalid command\n" );
    }

    memset(cmd, ' ', 1); //clear command

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );//Create thread and run client
  return NULL;
}

int main( int argc, char *argv[] ) {

  //check for arguments
  if(argc != 3) {
    fail("usage: scrabbleServer <rows> <cols>");
  }

  int r = atoi(argv[1]);
  int c = atoi(argv[2]);

  //check for valid row and cols
  if(r == 0 || c == 0) {
    fail("usage: scrabbleServer <rows> <cols>");
  }

  //set global num of rows and cols
  rows = r;
  cols = c;

  //malloc 2d array for board
  board = malloc(r * sizeof(char *));
  for(int i = 0; i < r; i++) {
    board[i] = malloc(c * sizeof(char));
  }

  //fill board with blank space
  for(int i = 0; i < r; i++) {
    for(int ii = 0; ii < c; ii++) {
      board[i][ii] = ' ';
    }
  }

  sem_init (&lock, 0, 1); //Initialize semaphore


  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );

  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    pthread_t thread; //Declare thread

    //Create thread and run client
    pthread_create( &thread, NULL, handleClient, (void *) &sock );

    //detach thread
    pthread_detach(thread);
  }

  //free board
  for(int i = 0; i < r; i++) {
    free(board[i]);
  }
  free(board);

  // Stop accepting client connections (never reached).
  close( servSock );

  return 0;
}
