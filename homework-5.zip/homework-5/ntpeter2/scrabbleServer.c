/**
 * scrabble board server
 * accepts 2 parameters specifiying the width and length of the board
 * listens for incoming client connections and allows them to place words
 * onto the board, as well as to view it
 * @author Nolan Peters
 * @file scrabbleServer.c
 */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26352"

/** Maximum word length */
#define WORD_LIMIT 26

int rows = -1; // number of rows to be on board
int columns = -1; // number of columns to be on board

char **board; //2D Array to maintain board


pthread_mutex_t lock; // lock to ensure mutual exclusion


/** 
 * prints word across the board
 * @param row row of first letter
 * @param column column of first letter
 * @param word word to be printed
 * @param fp socket to be written to
 */
void printAcross(int row, int column, char *word, FILE *fp) {
    for (int i = column; i < column + strlen(word); i++) {
        if (board[row][i] != ' ' && board[row][i] != word[i - column]){
            fprintf(fp, "Invalid command\n");
            return;
        } 
    }
    
    for (int i = column; i < column + strlen(word); i++) {
        board[row][i] = word[i - column];
    }
}

/** 
 * prints word down the board
 * @param row row of first letter
 * @param column column of first letter
 * @param word word to be printed
 * @param fp socket to be written to
 */
void printDown(int row, int column, char *word, FILE *fp) {

for (int i = row; i < row + strlen(word); i++) {
        if (board[i][column] != ' ' && board[i][column] != word[i - row]){
            fprintf(fp, "Invalid command\n");
            return;
        } 
    }
    
    for (int i = row; i < row + strlen(word); i++) {
        board[i][column] = word[i - row];
    }
    
}

/**
 * prints board
 * @param fp socket to have board printed to
 */
void printBoard(FILE *fp) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            fprintf(fp, "%c", board[i][j]);
        }
        fprintf(fp, "\n");
    }
}

//intializes game board
void createBoard() {
    
    board[0][0] = '+';
    for (int i = 1; i < columns - 1; i++) {
        board[0][i] = '-';
    }
    
    board[0][columns - 1] = '+';
    
    
    for (int i = 1; i < rows - 1; i++) {
    
        for (int j = 0; j < columns; j++) {
            if (j == 0) {
               board[i][j] = '|';
               continue;
            }
            if (j == (columns - 1)) {
               board[i][j] = '|';
               continue;
            }
            board[i][j] = ' ';
        }
    }
    
    
    
     board[rows - 1][0] = '+';
    for (int i = 1; i < columns - 1; i++) {
        board[rows - 1][i] = '-';
    }
    board[rows - 1][columns - 1] = '+';
}



// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int realSock = *(int*)sock;

  FILE *fp = fdopen( realSock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    // Just echo the command back to the client for now.
    //fprintf( fp, "%s\n", cmd );

    if (strcmp(cmd, "board") == 0) {
        pthread_mutex_lock( &lock );
        printBoard(fp);
        pthread_mutex_unlock( &lock );
        
   }
   
   else if (strcmp(cmd, "across") == 0) {
      int row;
      int column;
      char word[100];
      int errFlag = 0;
      for (int i = 0; i < 100; i++) {
          word[i] = '\0';
      }
      if (fscanf( fp, "%d %d %99s", &row, &column, word) != 3 || strlen(word) > 26) {
          fprintf(fp, "Invalid command\n");
          errFlag = 1;
      }
      row++;
      column++;
      if  (row < 1 || column < 1) {
          fprintf(fp, "Invalid command\n");
          errFlag = 1;
      }
   
      int i = 0;
      
      while (word[i] != '\0') {
          if (word[i] >= 'a' && word[i] <= 'z') {
              i++;
              continue;
          }
          fprintf(fp, "Invalid command\n");
          errFlag = 1;
          break;
      }
          int length = strlen(word);
          if ((column + length) > columns - 1) {
              fprintf(fp, "Invalid command\n");
              errFlag = 1;
          }
          
          if (errFlag == 0) {
              pthread_mutex_lock( &lock );
              printAcross(row, column, word, fp);
              pthread_mutex_unlock( &lock );
          }
   }
   
   else if (strcmp(cmd, "down") == 0) {
   
   
      int row;
      int column;
      char word[27];
      int errFlag = 0;
      for (int i = 0; i < 27; i++) {
          word[i] = '\0';
      }
      if (fscanf( fp, "%d %d %26s", &row, &column, word) != 3) {
          fprintf(fp, "Invalid command\n");
          errFlag = 1;
      }
      row++;
      column++;
      if  (row < 1 || column < 1) {
          fprintf(fp, "Invalid command\n");
          errFlag = 1;
      }
   
      int i = 0;
      
      while (word[i] != '\0') {
          if (word[i] >= 'a' && word[i] <= 'z') {
              i++;
              continue;
          }
          fprintf(fp, "Invalid command\n");
          errFlag = 1;
          break;
      }
          int length = strlen(word);
          if ((row + length) > rows - 1) {
              fprintf(fp, "Invalid command\n");
              errFlag = 1;
          }
          
          if (errFlag == 0) {
              pthread_mutex_lock( &lock );
              printDown(row, column, word, fp);
              pthread_mutex_unlock( &lock );
          }
   
   } else {
       fprintf(fp, "Invalid command\n");
   }
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
    if (argc != 3) {
      fail("usage: scrabbleServer <rows> <cols>");
    }
  
rows = atoi(argv[1]);
  columns = atoi(argv[2]);
  
  if (rows <= 0 || columns <= 0) {
      fail("usage: scrabbleServer <rows> <cols>");
  }
  
  pthread_mutex_init( &lock, NULL );
  
  
  rows += 2;
  columns += 2;
  board = (char**)malloc(rows * sizeof(char*));
  
  for (int i = 0; i < rows; i++) {
        board[i] = (char*)malloc(columns * sizeof(char));
  
  }
 
  createBoard();

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    pthread_t clientThread = NULL;
    
    pthread_create(&clientThread, NULL, handleClient, &sock);
    pthread_detach(clientThread);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
