/**
* @file scrabbleServer.c
* @author dsmathur
* This program known as scrabbleServer.c
* it implements a multi threaded C program
* using TCP/IP sockets for communication.
* The server will allow users to update 
* a two dimensional board based on commands
* provided by the user. However, several 
* invalid checks need to be performed including
* checks for buffer overflow.
*/

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26328"

/** Maximum word length */
#define WORD_LIMIT 26

//Used for representing the two dimensional board array
char ** board;

//Mainting the number of rows in the board created by server 
int mainrows;

//Maintaining the number of columns in the board created by the server 
int maincols;

//Maintaining a semaphore for the board access 
sem_t boardAccess;

//sem_t boardReport;
// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( EXIT_FAILURE );
}

/**
* This is the thread starter routine.
* it takes an int sock as an argument
* however it is void at first , hence it 
* requires casting. Takes care of race conditions
* by the using semaphores.
* @param arg a void argument 
*/
void *handleClient( void * arg ) {
    // Here's a nice trick, wrap a C standard IO FILE around the
    // socket, so we can communicate the same way we would read/write
    // a file.
    
    int * sock = (int * )arg;
    FILE *fp = fdopen( *sock, "a+" );
    
    // Prompt the user for a command.
    fprintf( fp, "cmd> " );
    
    // Temporary values for parsing commands.
    char cmd[ 1024 ];
    while ( fgets( cmd, 1024, fp ) != NULL &&
            strcmp( cmd, "quit" ) != 0 ) {
        //Malloc space to hold the name of the command
        char * commandname=  malloc(1024 * sizeof(char));
        
        //Malloc space to hold the word
        char * word = malloc(1024 * sizeof(char));
        
        //To keep track if there is extra input for buffer overflow
        char *extraword = malloc(1024*sizeof(char));
        
        //To keep track of extra input for buffer overflow 
        int extraint;
        
        //A variable to hold the number of rows
        int rows;
        
        //A variable to hold the number of columns
        int cols;
        
        //Break the command string into different variables based on the 
        // allowed parameters
        
        //Check if there is an extra parameter to take the buffer overflow
        // case into consideration
        if(sscanf(cmd, "%s %d %d %s %s",commandname,&rows,&cols,word,extraword) == 5){
            fprintf(fp,"Invalid command\n");
        }
        else if(sscanf(cmd,"%s %d %d %s %d",commandname,&rows,&cols,word,&extraint) ==5){
            fprintf(fp,"Invalid command\n");
        }
        else{
            if(sscanf(cmd,"%s %d %d %s",commandname,&rows,&cols,word) == 4){
                //Check for buffer overflow possibility
                if(strlen(commandname) > WORD_LIMIT || strlen(word) > WORD_LIMIT){
                    fprintf(fp,"Invalid command\n");
                }
                else{
                    //Check if the operation is for writing a word across a board
                    if( strcmp(commandname,"across") == 0){
                        bool invalid = 0;
                        //Checks if all the characters used are lowercase.
                        for(int i = 0 ; i < strlen(word);i++){
                            //If any character is lower case mark it as invalid
                            if(word[i] < 97 || word[i] >122){
                                invalid = 1;
                            }
                        }
                     
                        //Check if the rows are valid 
                        if(rows < 0 || rows > mainrows - 1){
                            invalid = 1;
                        }
                    
                        //check if the columns are valid 
                        if(cols < 0 || cols > maincols - 1){
                            invalid = 1;
                        }
                        //check if the word can fit within the bounds 
                        if(strlen(word) > maincols - cols){
                            invalid =1;
                        }
                        //To keep track of the character index in the word for iteration
                        int count  = 0;
                        
                        //If it is not an invalid operation till now,
                        // we can move on to using the acquire functionality
                        if(!invalid){
                            //Start the acquire process 
                            //Make sure that only one thread gets to access
                            //the board at a time to prevent race condition
                            sem_wait(&boardAccess);
                            
                            //Go through all the columns required for adding this word
                            for(int j = cols ;j < cols + strlen(word);j++ ){
                                //If a cell is not blank the means that input is already present
                                // hence a check needs to be performed on whether the character
                                // present matches up with the word's current character
                                if(board[rows][j] != ' '){
                                    if(word[count] != board[rows][j]){
                                        invalid  = 1;
                                        break;
                                    }
                                }
                                
                                count++;
                            }   
                            //Release the semaphore
                            sem_post(&boardAccess);
                            
                        }
                        if(invalid){
                            fprintf(fp,"Invalid command\n");
                        }
                        else{
                            //To keep track of the character index in the word for iteration
                            count  = 0;
                            //Make sure that only one thread gets to access
                            //the board at a time to prevent race condition
                            sem_wait(&boardAccess);
                             
                            //Go through all the columns and add the character if the 
                            // cell is blank and leave those cells that already consist
                            // of the required character
                            for(int j = cols ;j < cols + strlen(word);j++ ){
                                if(board[rows][j] == ' '){
                                    board[rows][j] = word[count];
                                }
                                count++;
                            }  
                            //Release the semaphore
                            sem_post(&boardAccess);
                        }
                        
                    }
                    //Check if the operation to be performed is "down"
                    else if(strcmp(commandname,"down") == 0){
                        //Keep track of whether the given operation is valid or not 
                        bool invalid = 0;
                         
                        //Checks if all the characters used are lowercase.  
                        for(int i = 0 ; i < strlen(word);i++){
                            if(word[i] < 97 || word[i] >122){
                                invalid = 1;
                            }
                        }
                        
                        //Check if the rows are valid 
                        if(rows < 0 || rows > mainrows - 1){
                            invalid = 1;
                        }
                        
                        //check if the columns are valid 
                        if(cols < 0 || cols > maincols - 1){
                            invalid = 1;
                        }
                        //check if the word can fit within the bounds 
                        if(strlen(word) > mainrows - rows){
                            invalid =1;
                        }
                        int count  = 0;
                        
                        //If the given down operation is not invalid till now, 
                        // try checking if it will cause any of the word characters
                        // to clash with the ones already present on the board 
                        if(!invalid){ 
                            //Only one thread can gain access to the board at a time
                            sem_wait(&boardAccess);
                            
                            //Go through all the rows till the word length and perform the 
                            // above check
                            for(int j = rows ;j < rows + strlen(word);j++ ){
                                if(board[j][cols] != ' '){
                                    if(word[count] != board[j][cols]){
                                        invalid  = 1;
                                        break;
                                    }
                                }
                                count++;
                            }
                            //Release the semaphore 
                            sem_post(&boardAccess);
                        }
                        if(invalid){
                            fprintf(fp,"Invalid command\n");
                        }
                        else{
                            //After passing all the invalid checks the 
                            // down operation can be performed where
                            // the required characters are added to the board
                            count  = 0;
                            sem_wait(&boardAccess);
                            //Go till the requires length of the row 
                            // in terms of the table and only write those
                            // characters that are not present 
                            for(int j = rows ;j < rows + strlen(word);j++ ){
                                if(board[j][cols] == ' '){
                                    board[j][cols] = word[count];
                                }
                                count++;
                            }    
                        
                            //Release the semaphore 
                            sem_post(&boardAccess);
            
                        }
                    }
                    else{
                        fprintf(fp,"Invalid command\n");
                    }
                }
            }
        
            //If the command line is only one line it could be either "quit" or "board "
            else if(sscanf(cmd,"%s", commandname) == 1){
                
                //Make sure to check for buffer overflow 
                if(strlen(commandname) > WORD_LIMIT){
                    fprintf(fp,"Invalid command\n");
                }
                else{
                    //If the given command is board , need to print the board as provided 
                    // in the example runs with the grid bordering outside 
                    if(strcmp(commandname,"board") == 0){   
                        //For printing the first row edge
                        fprintf(fp,"+");
                        for(int i = 0 ; i <maincols ; i++ ){
                            fprintf(fp,"-");
                        }
                        fprintf(fp,"+\n");
                        //Use a semaphore to ensure one thread accesses the board at a
                        // time 
                        sem_wait(&boardAccess);
                        //Print each cell of the board 
                        for(int i = 0 ; i < mainrows;i++){
                            fprintf(fp,"|");
                            for(int j = 0 ; j < maincols;j++){
                                fprintf(fp,"%c",board[i][j]);
                            }   
                            fprintf(fp,"|\n");
                        }
                        //Release the semaphore 
                        sem_post(&boardAccess);
                        
                        //Print the bottom border of the board 
                        fprintf(fp,"+");
                        for(int i = 0 ; i <maincols ; i++ ){
                            fprintf(fp,"-");
                        }
                        fprintf(fp,"+\n");
                         
                    }
                    //If the command was "quit" break out of the loop
                    else if(strcmp(commandname,"quit") == 0){
                        break;
                    }
                    //Print invald command for anything else 
                    else{
                        fprintf(fp,"Invalid command\n");
                    }
                }
            }
            else if(strcmp(commandname,"quit") != 0){
                fprintf(fp,"Invalid command\n");
            }
        }
       
        // Prompt the user for the next command.
        fprintf( fp, "cmd> " );
        free(extraword);
        free(commandname);
        free(word);
    }

    // Close the connection with this client.
    fclose( fp );
    return NULL;
}

/**
* Takes care of the socket connections 
* Create a threads for different clients 
* and bind to the sockets to enable client 
* server connection.
* @param argc the number of arguments
* @param argv the arguments as an array of pointers
* @return an int of whether the program was successful or not 
*/
int main( int argc, char *argv[] ) {
    mainrows  = atoi(argv[1]);
    maincols = atoi(argv[2]);
    if(argc != 3 || mainrows<= 0 ||maincols <= 0){
        printf("usage: scrabbleServer <rows> <cols>");
        exit(1);
    }
    board = (char **) malloc(mainrows * sizeof(char *));
    for(int i = 0 ; i < mainrows;i++){
        board[i] = (char *)malloc(maincols * sizeof(char));
    }
    for(int i = 0 ; i < mainrows;i++){
        for(int j = 0 ; j < maincols;j++){
            board[i][j] = ' ';
        }    
    }
    // Prepare a description of server address criteria.
    struct addrinfo addrCriteria;
    memset(&addrCriteria, 0, sizeof(addrCriteria));
    addrCriteria.ai_family = AF_INET;
    addrCriteria.ai_flags = AI_PASSIVE;
    addrCriteria.ai_socktype = SOCK_STREAM;
    addrCriteria.ai_protocol = IPPROTO_TCP;

    // Lookup a list of matching addresses
    struct addrinfo *servAddr;
    if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
        fail( "Can't get address info" );
    
    // Try to just use the first one.
    if ( servAddr == NULL )
        fail( "Can't get address" );    
  
    // Create a TCP socket
    int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
    if ( servSock < 0 )
        fail( "Can't create socket" );
        
    // Bind to the local address
    if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
        fail( "Can't bind socket" );
    
    // Tell the socket to listen for incoming connections.
    if ( listen( servSock, 5 ) != 0 )
        fail( "Can't listen on socket" );
    
    // Free address list allocated by getaddrinfo()
    freeaddrinfo(servAddr);
    
    // Fields for accepting a client connection.
    struct sockaddr_storage clntAddr; // Client address
    socklen_t clntAddrLen = sizeof(clntAddr);
    
    //Initializing the semaphore 
    sem_init(&boardAccess,0,1);
    
    while ( true  ) {
        // Accept a client connection.
        int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
        pthread_t thread;
        pthread_create(&thread,NULL, handleClient,&sock);
        pthread_detach(thread);
    }
    
    //Freeing the two dimensional board
    for(int i = 0 ; i < mainrows;i++){
        free(board[i]);
    }
    free(board);
    // Stop accepting client connections (never reached).
    close( servSock );
    
    return 0;
}
