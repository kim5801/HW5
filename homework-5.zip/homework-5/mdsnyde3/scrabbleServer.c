#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26314"

/** Maximum word length */
#define WORD_LIMIT 26

/** 2d char array representing the scrabble board */
static char **scrabbleBoard = NULL;
/** number of rows */
static int rows = 0;
/** number of columns */
static int cols = 0;
/** semaphore lock object */
sem_t lock;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** across command */
void acrossCmd( int r, int c, char *word, FILE *fp ) {
  // enter critical section via semaphore
  sem_wait( &lock );
  // get the ending index of where the word would go based on the start index
  int endIdx = c + (strlen( word ) - 1 );
  // if it would extend past the board, it is invalid
  if( endIdx >= cols ) {
    fprintf( fp, "Invalid command\n" );
    // let someone else acquire the semaphore
    sem_post( &lock );
    return;
  }
  // make sure every character of the word is valid (lowercase letter)
  for( int w = 0; w < strlen( word ); w++ ) {
    if( word[ w ] < 97 || word[ w ] > 122 ) {
      fprintf( fp, "Invalid command\n" );
      // let someone else acquire the semaphore
      sem_post( &lock );
      return;
    }
  }
  // go through board and make sure the character can be placed there
  for( int i = c; i <= endIdx; i++ ) {
    char ch = scrabbleBoard[ r ][ i ];
    // if the character isn't a space and doesn't match the character already there, it is an invalid command
    if( ch != ' ' && ch != word[ i - c ] ) {
      fprintf( fp, "Invalid command\n" );
      // let someone else acquire the semaphore
      sem_post( &lock );
      return;
    }
  }
  // set the characters to show the word in the board
  for( int j = c; j <= endIdx; j++ ) {
    scrabbleBoard[ r ][ j ] = word[ j - c ];
  }
  // let someone else acquire the semaphore
  sem_post( &lock );
}

/** down command */
void downCmd( int r, int c, char *word, FILE *fp ) {
  // enter critical section via semaphore
  sem_wait( &lock );
  // get the ending index of where the word would go based on the start index
  int endIdx = r + (strlen( word ) - 1 );
  // if it would extend past the board, it is invalid
  if( endIdx >= rows ) {
    fprintf( fp, "Invalid command\n" );
    // let someone else acquire the semaphore
    sem_post( &lock );
    return;
  }
  // make sure every character of the word is valid (lowercase letter)
  for( int w = 0; w < strlen( word ); w++ ) {
    if( word[ w ] < 97 || word[ w ] > 122 ) {
      fprintf( fp, "Invalid command\n" );
      // let someone else acquire the semaphore
      sem_post( &lock );
      return;
    }
  }
  // go through board and make sure the character can be placed there
  for( int i = r; i <= endIdx; i++ ) {
    char ch = scrabbleBoard[ i ][ c ];
    // if the character isn't a space and doesn't match the character already there, it is an invalid command
    if( ch != ' ' && ch != word[ i - r ] ) {
      fprintf( fp, "Invalid command\n" );
      // let someone else acquire the semaphore
      sem_post( &lock );
      return;
    }
  }
  // set the characters to show the word in the board
  for( int j = r; j <= endIdx; j++ ) {
    scrabbleBoard[ j ][ c ] = word[ j - r ];
  }
  // let someone else acquire the semaphore
  sem_post( &lock );
}

/** board command */
void boardCmd( FILE *fp ) {
  // enter the critical section with the semaphore
  sem_wait( &lock );
  // print the top left corner
  fprintf( fp, "+" );
  // print the top row of dashes
  for( int i = 0; i < cols; i++ ) {
    fprintf( fp, "-" );
  }
  // print the top right corner and a newline
  fprintf( fp, "+\n" );
  // print each row of the board
  for( int j = 0; j < rows; j++ ) {
    // print lefthand border
    fprintf( fp, "|" );
    // print characters in board
    for( int k = 0; k < cols; k++ ) {
      fprintf( fp, "%c", scrabbleBoard[ j ][ k ] );
    }
    // print righthand border
    fprintf( fp, "|\n" );
  }
  // print bottom left corner
  fprintf( fp, "+" );
  // print the bottom row of dashes
  for( int i = 0; i < cols; i++ ) {
    fprintf( fp, "-" );
  }
  // print the bottom right corner
  fprintf( fp, "+\n" );
  // let someone else acquire the semaphore
  sem_post( &lock );  
}
/** function for getting a word off of the input stream, puts it into the given parameter */
bool findWord( FILE *fp, char *string ) {
  // enter critical section with semaphore
  sem_wait(&lock);
  // create a temporary character and an index
  char ch = ' ';
  int idx = 0;
  // keep grabbing values from the "file pointer", making sure they aren't EOF, \n, or a space
  while( ( ch = fgetc( fp ) ) != -1 && ch != '\n' && ch != ' ' ) {
    // set next character in the word
    string[ idx ] = ch;
    // increment index
    idx++;
    // if word is too long, return false
    if( idx > WORD_LIMIT ) {
      // let someone else acquire the semaphore
      sem_post(&lock);
      return false;
    }   
  }
  // add a null terminator to the end of the string
  string[ idx ] = '\0';
  // let someone else acquire the semaphore
  sem_post(&lock);
  return true;
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int* socket = (int*) sock;
  FILE *fp = fdopen( *socket, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    // starting row for the word
    int startRow;
    // starting column for the word
    int startCol;
    // word parameter for across/down
    char word[ WORD_LIMIT + 1 ];
    // case for "across" command
    if( strcmp( cmd, "across" ) == 0 ) {
      // if we don't have a row and a column, this is an invalid command
      if( fscanf( fp, "%d %d ", &startRow, &startCol ) != 2 ) {
        fprintf( fp, "Invalid command\n" );
      }
      // if our word is not valid, this is an invalid command
      else if( !findWord( fp, word ) ) {
        fprintf( fp, "Invalid command\n" );
      }
      // if our row and column are not valid, we have an invalid command
      else if( startRow < 0 || startCol < 0 || startRow > rows || startCol > cols ) {
        fprintf( fp, "Invalid command\n" );
      }
      // we're good, run the command
      else {
        acrossCmd( startRow, startCol, word, fp );
      }
    }
    // case for "down" command
    else if( strcmp( cmd, "down" ) == 0 ) {
      // if we don't have a row and a column, this is an invalid command
      if( fscanf( fp, "%d %d ", &startRow, &startCol ) != 2 ) {
        fprintf( fp, "Invalid command\n" );
      }
      // if our word is not valid, this is an invalid command
      else if( !findWord( fp, word ) ) {
        fprintf( fp, "Invalid command\n" );
      }
      // if our row and column are not valid, we have an invalid command
      else if( startRow < 1 || startCol < 1 || startRow > rows || startCol > cols ) {
        fprintf( fp, "Invalid command\n" );
      }
      // we're good, run the command
      else {
        downCmd( startRow, startCol, word, fp );
      }
    }
    // case for "board" command
    else if( strcmp( cmd, "board" ) == 0 ) {
      // run board command
      boardCmd( fp );
    }
    // case for invalid command
    else {
      fprintf( fp, "Invalid command\n" );
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // if we have less than 3 arguments, print usage
  if( argc != 3 ) {
    printf( "usage: scrabbleServer <rows> <cols>\n" );
    exit( 1 );
  }
  // set rows and columns
  rows = atoi( argv[ 1 ] );
  cols = atoi( argv[ 2 ] );
  // if rows/cols are less than 1, print usage
  if( rows < 1 || cols < 1 ) {
    printf( "usage: scrabbleServer <rows> <cols>\n" );
    exit( 1 );
  }
  // allocate space for the board
  scrabbleBoard = malloc( rows * cols  );
  // allocate space for each row
  for( int i = 0; i < rows; i++ ) {
    scrabbleBoard[ i ] = malloc(sizeof(char) * cols);
  }
  // set all characters to spaces
  for( int j = 0; j < rows; j++ ) {
    for( int k = 0; k < cols; k++ ) {
      scrabbleBoard[ j ][ k ] = ' ';
    }
  }
  // initialize the semaphore
  sem_init( &lock, 0, 1 );

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    // create a thread to run handleClient with the socket as a parameter
    pthread_t thread;
    pthread_create( &thread, NULL, &handleClient, &sock );
    // detach the thread
    pthread_detach( thread );
  }
  // destroy the semaphore
  sem_destroy( &lock );
  // free the scrabble board
  for( int a = 0; a < rows; a++ ) {
    free( scrabbleBoard[ a ] );
  }
  free( scrabbleBoard );
  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}

