#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26376"

/** Maximum word length */
#define WORD_LIMIT 26

/** Number of args in command line */
#define NUM_ARGS 3

/** Index of row number in argv */
#define ROW_NUM 1

/** Index of column number in argv */
#define COL_NUM 2

/** Initial max # of chars in a command line */
#define INITIAL_BUFFER 50

/** Initial max # of args in a command line */
#define MAX_ARGS 4

/** Monitor for protecting critical sections */
pthread_mutex_t mon;

/** Condition variable for making threads wait */
pthread_cond_t cond;

/** Whether another thread is executing a command */
bool busy = false;

/**
* Struct holding current state of the board, the
* number of rows in the board, and the number of 
* columns in the board
*/
typedef struct GameState
{
  char **board;
  int rows;
  int cols;
} GameState;

GameState *game; // Declare the game

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *arg ) {

  int *sock = (int *) arg; // Convert the parameter

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( *sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );
  fflush( fp );

  while ( true ) {
    
    // Get command line string from file stream

    // Variables to iterate through the file stream
    int cap = INITIAL_BUFFER;
    int size = 0;
    char *buf = malloc( cap * sizeof( char ) );
    char ch = fgetc( fp );

    // Iterate until end of command
    while ( ch != EOF && ch != '\n' ) { 
      buf[ size++ ] = ch;

      // Increase buffer size
      if ( size >= cap ) { 
        cap += cap;
        buf = realloc( buf, cap + 1 );
      }

      ch = fgetc( fp ); // Next char
    }
    
    // Variables to parse values from buffer
    char *cmd_buf = (char *) malloc( ( sizeof( char ) * size ) + 1 );
    int row = -1;
    int col = -1;
    char *word_buf = (char *) malloc( ( sizeof( char ) * size ) + 1 );

    // Parse string(s and numbers) from buffer
    int num_args = sscanf( buf, "%s %d %d %s", cmd_buf, &row, &col, word_buf );
    free( buf );

    if ( num_args != 1 && num_args != MAX_ARGS ) {
      // Invalid number of args
      fprintf( fp, "Invalid command\n" );

      // Free allocated space
      free( cmd_buf );
      free( word_buf );

      // Prompt user
      fprintf( fp, "cmd> " );
      fflush( fp );

      // Run the loop again
      continue;
    }

    // Are we inserting a word into the board?
    bool insert = false;
    if ( num_args == MAX_ARGS ) {
      insert = true;
    }
    
    // Move strings over to smaller strings 
    char cmd[ strlen( cmd_buf ) + 1 ];
    char word[ strlen( word_buf ) + 1 ];
    strncpy( cmd, cmd_buf, strlen( cmd_buf ) + 1 );
    strncpy( word, word_buf, strlen( word_buf ) + 1 );

    // Free allocated space
    free( cmd_buf );
    free( word_buf );

    bool valid = true; // Check for valid/invalid commands

    if ( insert && ( row < 0 || row >= game->rows ) ) {
      // Invalid row index
      fprintf( fp, "Invalid command.\n" );

      // Prompt the user for a command.
      fprintf( fp, "cmd> " );
      fflush( fp );
      continue;
    }

    if ( insert && ( col < 0 || col >= game->cols ) ) {
      // Invalid column index
      fprintf( fp, "Invalid command\n" );

      // Prompt the user for a command.
      fprintf( fp, "cmd> " );
      fflush( fp );
      continue;
    }

    if ( insert && strlen( word ) > WORD_LIMIT ) {
      // Invalid number of characters
      fprintf( fp, "Invalid command\n" );

      // Prompt the user for a command.
      fprintf( fp, "cmd> " );
      fflush( fp );
      continue;
    }

    // Across command
    if ( strcmp( cmd, "across" ) == 0 ) { 

      pthread_mutex_lock( &mon ); // Enter the monitor
      while ( busy ) {  // Block until other thread is done
        pthread_cond_wait( &cond, &mon );
      }
      busy = true;
              
      // Check if there's a proper number of args
      // and if there's room on this row
      if ( !insert || ( strlen( word ) > game->cols - col ) ) {
        // Invalid
        fprintf( fp, "Invalid command\n" );

        // Prompt the user for a command.
        fprintf( fp, "cmd> " );
        fflush( fp );

        busy = false;
        pthread_cond_broadcast( &cond ); // Wake up another thread
        pthread_mutex_unlock( &mon ); // Leave the monitor
        continue;
      }

      int count = 0;
      for ( int i = 0; i < strlen( word ); i++ ) {

        ch = word[ i ];

        if ( ch < 'a' || ch > 'z' ) {

          // Invalid character

          // Mark this command as not valid
          valid = false;
          break;
        }

        if ( !isspace( game->board[ row ][ col + count ] ) && 
              game->board[ row ][ col + count ] != ch ) {

          // Characters disagree!

          // Mark as not valid
          valid = false;
          break;
        }

        count++; // Increment count (letter index in word)

      }

      if ( !valid || count < 1 ) {
        // Invalid number of characters
        fprintf( fp, "Invalid command\n" );

        // Prompt the user for a command.
        fprintf( fp, "cmd> " );
        fflush( fp );

        // Mark as valid
        valid = true;

        busy = false;
        pthread_cond_broadcast( &cond ); // Wake up another thread
        pthread_mutex_unlock( &mon ); // Leave the monitor
        continue;
      }

      for ( int i = 0; i < strlen( word ); i++ ) {
        // Update the board
        game->board[ row ][ col + i ] = word[ i ];
      }

      busy = false;
      pthread_cond_broadcast( &cond ); // Wake up another thread
      pthread_mutex_unlock( &mon ); // Leave the monitor

    }

    // Down command
    else if ( strcmp( cmd, "down" ) == 0 ) { 

      pthread_mutex_lock( &mon ); // Enter the monitor
      while ( busy ) {  // Block until other thread is done
        pthread_cond_wait( &cond, &mon );
      }
      busy = true;
              
      // Check if there's a proper number of args
      // and if there's room on this row
      if ( !insert || ( strlen( word ) > game->rows - row ) ) {
        // Invalid
        fprintf( fp, "Invalid command\n" );

        // Prompt the user for a command.
        fprintf( fp, "cmd> " );
        fflush( fp );

        busy = false;
        pthread_cond_broadcast( &cond ); // Wake up another thread
        pthread_mutex_unlock( &mon ); // Leave the monitor
        continue;
      }

      int count = 0;
      for ( int i = 0; i < strlen( word ); i++ ) {

        ch = word[ i ];

        if ( ch < 'a' || ch > 'z' ) {

          // Invalid character

          // Mark this command as not valid
          valid = false;
          break;
        }

        if ( !isspace( game->board[ row + count ][ col ] ) && 
              game->board[ row + count ][ col ] != ch ) {

          // Characters disagree!

          // Mark as not valid
          valid = false;
          break;
        }

        count++; // Increment count (letter index in word)

      }

      if ( !valid || count < 1 ) {
        // Invalid number of characters
        fprintf( fp, "Invalid command\n" );

        // Prompt the user for a command.
        fprintf( fp, "cmd> " );
        fflush( fp );

        // Mark as valid
        valid = true;

        busy = false;
        pthread_cond_broadcast( &cond ); // Wake up another thread
        pthread_mutex_unlock( &mon ); // Leave the monitor
        continue;
      }

      for ( int i = 0; i < strlen( word ); i++ ) {
        // Update the board
        game->board[ row + i ][ col ] = word[ i ];
      }

      busy = false;
      pthread_cond_broadcast( &cond ); // Wake up another thread
      pthread_mutex_unlock( &mon ); // Leave the monitor

    }

    // Board command
    else if ( !insert && strcmp( cmd, "board" ) == 0 ) {

      pthread_mutex_lock( &mon ); // Enter the monitor
      while ( busy ) {  // Block until other thread is done
        pthread_cond_wait( &cond, &mon );
      }
      busy = true;

      // Print the top border
      fprintf( fp, "%c", '+' ); // Left top corner
      fflush( fp );
      for ( int i = 0; i < game->cols; i++ ) {
        fprintf( fp, "%c", '-' ); // Top border
        fflush( fp );
      }
      fprintf( fp, "%c\n", '+' ); // Right top corner

      // Print out the board row by row
      for ( int i = 0; i < game->rows; i++ ) {

        fprintf( fp, "%c", '|' ); // Left border
        fflush( fp );

        // Print out a row of the board
        for ( int j = 0; j < game->cols; j++ ) {
          fprintf( fp, "%c", game->board[ i ][ j ] );
          fflush( fp );
        }

        fprintf( fp, "%c\n", '|' ); // Right border
      }

      // Print the bottom border
      fprintf( fp, "%c", '+' ); // Left bottom corner
      fflush( fp );
      for ( int i = 0; i < game->cols; i++ ) {
        fprintf( fp, "%c", '-' ); // Bottom border
        fflush( fp );
      }
      fprintf( fp, "%c\n", '+' ); // Right bottom corner

      busy = false;
      pthread_cond_broadcast( &cond ); // Wake up another thread
      pthread_mutex_unlock( &mon ); // Leave the monitor
    }

    // Quit command
    else if ( !insert && strcmp( cmd, "quit" ) == 0 ) {

      break; // Leave the loop

    }

    // Invalid command
    else { 
      fprintf( fp, "Invalid command\n" );
    }
    
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
    fflush( fp );

    // busy = false;
    // pthread_cond_broadcast( &cond ); // Wake up another thread
    // pthread_mutex_unlock( &mon ); // Leave the monitor
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  if ( argc != NUM_ARGS ) 
    fail( "usage: scrabbleServer <rows> <cols>" );
  
  int row = 0;
  int col = 0;
  sscanf( argv[ ROW_NUM ], "%d", &row );
  sscanf( argv[ COL_NUM ], "%d", &col );

  if ( row < 1 || col < 1 ) 
    fail( "usage: scrabbleServer <rows> <cols>" );

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  // Allocate space for struct
  game = (GameState *) malloc( sizeof( GameState ) );

  // Initialize row and column number fields
  game->rows = row;
  game->cols = col;

  // Initialize the board in the struct
  game->board = (char **) malloc( row * sizeof(char *) );
  for ( int i = 0; i < row; i++ ) {
    game->board[ i ] = (char *) malloc( col * sizeof( char ) );
    for ( int j = 0; j < col; j++ ) {
      game->board[ i ][ j ] = ' ';
    }
  }

  pthread_mutex_init( &mon, NULL ); // Initialize the monitor
  pthread_cond_init( &cond, NULL); // Initialize the condition 

  while ( true ) {

    // Accept a client connection. (Have to kill each with Ctrl^C)
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
   
    // Make a worker thread
    pthread_t thread;
    int *arg = &sock;
    pthread_create( &thread, NULL, handleClient, arg );

    // Let the thread be freed when it's done
    pthread_detach( thread ); 
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
