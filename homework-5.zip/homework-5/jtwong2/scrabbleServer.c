#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26058"

/** Maximum word length */
#define WORD_LIMIT 26

/** Number of words contained in the words file */
#define NUM_LEGAL_WORDS 102401

/** Length of the longest English word */
#define LONGEST_WORD_LEN 45

/** 2D array of chars to represent spaces on the Scrabble board */
char **board;
/** Number of rows on the board */
int rows;
/** Number of columns on the board */
int cols;

/** Semaphore used to ensure that only one process can read or write from the board at once */
sem_t boardSem;
/** Array to hold all of the legal Scrabble words */
char *legalWords[NUM_LEGAL_WORDS];
/** Number of words in the legal words array */
int numLegalWords = 0;
/** Set to true if there is a words file being used */
bool usingWordList = false;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Handles the shutdown process. It is invoked when the server is killed with Ctrl + C
static void freeMemory( int sig ) {
  // Free the legal words array
  for (int i = 0; i < numLegalWords; i++) {
    // printf("%s\n", legalWords[i]);
    free(legalWords[i]);
  }
  
  // Free the board's rows, one at a time
  for (int i = 0; i < rows; i++) {
    free(board[i]);
  }

  // Free the board itself
  free(board);

  // Exit the program with status 0
  exit(0);
}

// Fills in the legal words array from a file named "words"
static bool importWordList() {
  // Open the words file in read-only mode
  FILE *fp = fopen("words", "r");
  if (!fp) { // If there was no words file, return false to say that it will not be checking if words are legal
    usingWordList = false;
    return false;
  }

  // Create a space in memory to store the word that is read from the file. This way, we don't have to guess
  // what the length of the next word is
  char *word = (char*)malloc(sizeof(char) * LONGEST_WORD_LEN + sizeof(char));
  while (fscanf(fp, "%s", word) == 1) { // While there is another word to read
    // Players are only allowed to enter words of up to 26 characters in length, so a word this length would be illegal
    if (strlen(word) < WORD_LIMIT) {
      for (int i = 0; i < strlen(word); i++) { // Check to make sure the word only contains legal characters
        if (word[i] < 'a' || word[i] > 'z') {
          goto END; // If a word contains characters, skip to the next iteration of the reading loop
        }
      }
      // Else, the word was legal, so create an exact-fit space in memory to store the word
      char *wordInList = (char*)malloc(strlen(word) * sizeof(char) + sizeof(char));
      strcpy(wordInList, word); // Copy the word to the space in memory
      legalWords[numLegalWords++] = wordInList; // Store the word in the list
      //printf("%s\n", word);
    }
    END:; // This label allows skipping to the next iteration of the while loop
  }
  free(word); // After the whole file has been read, we don't need the dummy word anymore
  //printf("%d\n", numLegalWords);

  fclose(fp); // Close the words file
  usingWordList = true;
  return true; // Return success to say that we have successfully read the words file
}

// Checks if a word is a legal Scrabble word, according to the words list (if there is one)
static bool isValidWord(char *word) {
  if (!usingWordList) { // If there was no words list read in at the beginning, then all words are allowed
    return true;
  }

  // Linearly search the words list to see if the given word is allowed
  for (int i = 0; i < numLegalWords; i++) {
    //printf("%s\n", legalWords[i]);
    if (strcmp(word, legalWords[i]) == 0) { // If the word is in the list, it is allowed
      return true;
    }
  }
  return false; // Else, the word must not be in the list, so the word is not legal
}

// Checks the current board state to make sure all of the words on it are legal. Words, in this case, are >2 characters long
static bool checkAllValidWords() {
  // Check horizontal words
  for (int i = 0; i < rows; i++) { // Go through one row at a time, recording clusters of characters
    int wordlen = 0;
    char currentWord[WORD_LIMIT + 1]; // Use WORD_LIMIT + 1, since another method has already made sure that the length constraint is satisfied
    for (int j = 0; j < cols; j++) { // For each cell in the row being examined
      if (board[i][j] >= 'a' && board[i][j] <= 'z') { // If the character is not a space
        currentWord[wordlen++] = board[i][j]; // Record the character
      } else { // If it is a space, check to see if the current word is long enough to actually be a word
        if (wordlen >= 2) {
          currentWord[wordlen] = '\0'; // Null terminate the word for ease of comparison
          if (!isValidWord(currentWord)) { // Check to see if the found word is legal
            return false;
          }

        }
        wordlen = 0; // Since the word ended, start over
      }
    }
    // In case there's still a word in the currentWord buffer, check to see if it constitutes a word
    if (wordlen >= 2) {
      currentWord[wordlen] = '\0';
      if (!isValidWord(currentWord)) { // Check to see if the word is valid
        return false;
      }
    }
  }

  // Check vertical words (the logic is the same as the horizontal words, but we go column by column instead)
  for (int j = 0; j < cols; j++) { // Go through one column at a time, recording clusters of characters
    int wordlen = 0;
    char currentWord[WORD_LIMIT + 1]; // Use WORD_LIMIT + 1, since another method has already made sure that the length constraint is satisfied
    for (int i = 0; i < rows; i++) { // For each cell in the row being examined
      if (board[i][j] >= 'a' && board[i][j] <= 'z') { // If the character is not a space
        currentWord[wordlen++] = board[i][j]; // Record the character
      } else { // If it is a space, check to see if the current word is long enough to actually be a word
        if (wordlen >= 2) {
          currentWord[wordlen] = '\0'; // Null terminate the word for ease of comparison
          if (!isValidWord(currentWord)) { // Check to see if the found word is legal
            return false;
          }

        }
        wordlen = 0; // Since the word ended, start over
      }
    }
    // In case there's still a word in the currentWord buffer, check to see if it constitutes a word
    if (wordlen >= 2) {
      currentWord[wordlen] = '\0';
      if (!isValidWord(currentWord)) { // Check to see if the word is valid
        return false;
      }
    }
  }

  return true; // If the word was not already deemed invalid, then it must be valid
}

// Prints the board with the border surrounding it
static void printBoard(FILE *fp) {
  sem_wait(&boardSem); // Since we're reading the board, we want to make sure someone else isn't writing to it at the same time
  // Print header
  fprintf(fp, "+");
  for (int i = 0; i < cols; i++) {
    fprintf(fp, "-"); // Print a bunch of '-' characters for the header
  }
  fprintf(fp, "+\n");

  // Print the body of the board
  for (int i = 0; i < rows; i++) {
    fprintf(fp, "|");
    for (int j = 0; j < cols; j++) {
      fprintf(fp, "%c", board[i][j]); // Between the sides of the board, print the row of characters
    }

    fprintf(fp, "|\n");
  }

  // Print footer
  fprintf(fp, "+");
  for (int i = 0; i < cols; i++) {
    fprintf(fp, "-"); // Same pattern as the header
  }
  fprintf(fp, "+\n");
  sem_post(&boardSem); // Release the semaphore so other clients can read or write to the board
}

// Checks if a word has room to be placed on the board (not if it is a legal word or not)
static bool checkValid(int r, int c, char *word, bool isAcross) {
  if (r < 0 || c < 0 || r >= rows || c >= cols) { // If the index is out of bounds, then it is not allowed
    return false;
  }

  // Check to make sure the word only contains legal characters (a-z)
  int wordlen = strlen(word);
  for (int i = 0; i < wordlen; i++) {
    if (word[i] < 'a' || word[i] > 'z') {
      return false;
    }
  }

  // Make sure there is room for the word on the column/row it is placed on, and that it does not illegally overlap
  if (isAcross) {
    if (c + wordlen > cols) { // If the word does not fit on the board, then return false
      return false;
    }

    // Check to make sure there are no overlaps. If there is one, then the overlapping letters must match
    for (int i = 0; i < wordlen; i++) {
      if (board[r][c + i] != ' ') {
        if (word[i] != board[r][c + i]) { // Check to make sure the overlapping letters are the same
          return false;
        }
      }
    }
  } else { // Check for vertically placed words (same logic)
    if (r + wordlen > rows) { // If the word does not fit on the board, then return false
      return false;
    }

    // Check to make sure there are no overlaps. If there is one, then the overlapping letters must match
    for (int i = 0; i < wordlen; i++) {
      if (board[r + i][c] != ' ') {
        if (word[i] != board[r + i][c]) { // Check to make sure the overlapping letters are the same
          return false;
        }
      }
    }
  }

  return true; // If the word was not deemed illegally placed, then it must be legally placed
}

// Place the given word at the starting row and column, horizontally
static bool placeAcross(int r, int c, char *word) {
  sem_wait(&boardSem); // Since we're writing to the board, we want to make sure no one else is trying to use it
  if (checkValid(r, c, word, true)) { // If the word is allowed to be placed there
    // Save a record of what it looked like before the word was placed
    char *contentsBefore = (char*)malloc(strlen(word) * sizeof(char) + 1);
    for (int i = 0; i < strlen(word); i++) { // Place the word on the board, one letter at a time
      contentsBefore[i] = board[r][c + i]; // Record what each cell looked like before the word was placed
      board[r][c + i] = word[i]; // Place the letter
    }

    if (!checkAllValidWords()) { // Undo the word if it turned out to be illegal (or create illegal words somewhere else)
      for (int i = 0; i < strlen(word); i++) { // Using the record of what the board looked like before, restore it
        board[r][c + i] = contentsBefore[i];
      }

      free(contentsBefore); // We are done using the "history"
      sem_post(&boardSem); // Allow others to read and write to the board
      return false; // Indicate that the placement was unsuccessful
    }

    free(contentsBefore); // Even if we did not use the history, free it anyways
    sem_post(&boardSem); // Allow others to use the board
    return true; // Successful write
  } else {
    sem_post(&boardSem);
    return false;
  }
}

// Place the given word at the starting row and column, vertically (same logic is placeAcross())
static bool placeDown(int r, int c, char *word) {
  sem_wait(&boardSem); // Since we're writing to the board, we want to make sure no one else is trying to use it
  if (checkValid(r, c, word, false)) { // If the word is allowed to be placed there
    // Save a record of what it looked like before the word was placed
    char *contentsBefore = (char*)malloc(strlen(word) * sizeof(char) + 1);
    for (int i = 0; i < strlen(word); i++) { // Place the word on the board, one letter at a time
      contentsBefore[i] = board[r + i][c]; // Record what each cell looked like before the word was placed
      board[r + i][c] = word[i]; // Place the letter
    }

    if (!checkAllValidWords()) { // Undo the word if it turned out to be illegal (or create illegal words somewhere else)
      for (int i = 0; i < strlen(word); i++) { // Using the record of what the board looked like before, restore it
        board[r + i][c] = contentsBefore[i];
      }

      free(contentsBefore); // We are done using the "history"
      sem_post(&boardSem); // Allow others to read and write to the board
      return false; // Indicate that the placement was unsuccessful
    }

    free(contentsBefore); // Even if we did not use the history, free it anyways
    sem_post(&boardSem); // Allow others to read and write to the board
    return true; // Successful write
  } else {
    sem_post(&boardSem); // Allow others to read and write to the board
    return false; // Indicate that the placement was unsuccessful
  }
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *sockPtr ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int sock = *(int*)sockPtr;
  FILE *fp = fdopen( sock, "a+" );
  if (!fp) {
    return NULL;
  }
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) { // The first <= 10 characters (not including the null terminator) are the command
    
    if (strcmp(cmd, "board") == 0) { // If the command is to print the board
      printBoard(fp);
    } else if (strcmp(cmd, "across") == 0) { // If the command is to place a word across the board
      int row;
      int col;
      char *word = (char*)malloc(sizeof(char) * WORD_LIMIT + 2); // 2 extra chars, one for null terminator and one to check length of the word

      // The command should be followed by two integers for the placement, and then a <= 26 character word.
      // We will read in up to 27 characters for the word, to check if the word is actually too long
      if (fscanf(fp, "%d", &row) == 1 && fscanf(fp, "%d", &col) == 1 && fscanf(fp, "%27s", word) == 1) {
        if (strlen(word) > WORD_LIMIT) { // Check if the word was longer than 26 characters
          fprintf(fp, "Invalid command\n");
          goto END;
        }
        if (!placeAcross(row, col, word)) { // Attempt to place the word. If it fails, then print the error message
          fprintf(fp, "Invalid command\n");
        } else {
          checkAllValidWords(); // Check to make sure that the words on the board are all valid
        }
      } else {
        fprintf(fp, "Invalid command\n"); // If the command was not in the correct format, print out error message
      }
      END:;

      free(word); // Free the space used to read the word in
    } else if (strcmp(cmd, "down") == 0) { // Placing a word vertically (same logic as for horizontally)
      int row;
      int col;
      char *word = (char*)malloc(sizeof(char) * WORD_LIMIT + 2); // 2 extra chars, one for null terminator and one to check the length of the word

      // The command should be followed by two integers for the placement, and then a <= 26 character word.
      // We will read in up to 27 characters for the word, to check if the word is actually too long
      if (fscanf(fp, "%d", &row) == 1 && fscanf(fp, "%d", &col) == 1 && fscanf(fp, "%27s", word) == 1) {
        if (strlen(word) > WORD_LIMIT) { // Check if the word was longer than 26 characters
          fprintf(fp, "Invalid command\n");
          goto END_LOOP;
        }
        if (!placeDown(row, col, word)) { // Attempt to place the word. If it fails, then print the error message
          fprintf(fp, "Invalid command\n");
        }
      } else { // If the command did not follow the expected format, print the error message
        fprintf(fp, "Invalid command\n");
      }
      END_LOOP:;
      free(word); // Free the space used for reading the word in
    } else {
      fprintf(fp, "Invalid command\n"); // Else, the command is not a valid command
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  // Create the signal handler struct
  struct sigaction act;

  // Fill in a structure to redirect the Ctrl + c signal.
  act.sa_handler = freeMemory;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, 0 );

  // Create the board based on the requested dimensions
  if (argc != 3) {
    fail("usage: scrabbleServer <rows> <cols>");
  }

  // Check if the first argument is a valid integer
  for (int i = 0; i < strlen(argv[1]); i++) {
    if (argv[1][i] < '0' || argv[1][i] > '9') {
      fail("usage: scrabbleServer <rows> <cols>");
    }
  }

  // Check if the second argument is a valid integer
  for (int i = 0; i < strlen(argv[2]); i++) {
    if (argv[2][i] < '0' || argv[2][i] > '9') {
      fail("usage: scrabbleServer <rows> <cols>");
    }
  }
    
  rows = atoi(argv[1]);
  cols = atoi(argv[2]);
  if (rows <= 0 || cols <= 0) { // Check to make sure the board's dimensions are legal
    fail("usage: scrabbleServer <rows> <cols>");
  }

  // Import list of legal words
  importWordList();

  // Init the semaphore used for board access synchronization
  sem_init(&boardSem, false, 1);

  // Malloc space for the board. Since we are using a 2D array, initialize each row separately
  board = (char**)malloc(rows * sizeof(char*)); // Create space for the row pointers
  for (int i = 0; i < rows; i++) {
    board[i] = (char*)malloc(cols * sizeof(char)); // Create space for the row pointers to point to (aka the rows of chars)

    for (int j = 0; j < cols; j++) {
      board[i][j] = ' '; // Fill the newly created row with spaces
    }
  }

  // Handle client connections until killed with Ctrl + c
  while ( true ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    // Create a new thread to handle the new client
    pthread_t t;
    pthread_create(&t, NULL, handleClient, &sock); // Create the thread
    pthread_detach(t); // Detach it, as we don't plan to join with it
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
