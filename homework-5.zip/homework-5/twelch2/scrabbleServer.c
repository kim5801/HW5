#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26098"

/** Maximum word length */
#define WORD_LIMIT 26

//Number of rows on board
int row;
//Number of columns on board
int col;
//Representation of board
char **board;
//Representation of top and bottom borders of board
char *border;
//Mutex lock for updating board state
pthread_mutex_t lock;

//Initialize the board with given dimensions
void *initializeBoard(int row, int col) {
  //Allocate space for rows
  board = (char **)malloc(row * sizeof(char *));
  //Allocate space for columns
  for (int i = 0; i < row; ++i) {
    board[i] = (char *)malloc(col * sizeof(char));
  }
  //Allocate space for border representation
  border = (char *)malloc((2 + col) * sizeof(char));

  //Iterate through rows to initialize board as empty spaces
  for (int j = 0; j < row; ++j) {
    //Iterate through columns to initialize board as empty spaces
    for (int k = 0; k < col; ++k) {
      board[j][k] = ' ';
    }
  }

  //Initialize border characters
  border[0] = '+';
  border[col + 1] = '+';
  for (int l = 1; l < col + 1; ++l) {
    border[l] = '-';
  }

  return NULL;
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( *(int *)sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {

    if (strcmp( cmd, "across") == 0) {
      int aRow;
      int aCol;
      char word[30];
      int wordLen;

      //Get move position and word
      if (fscanf(fp, "%d %d %29s", &aRow, &aCol, word) != 3) {
        fprintf( fp, "Invalid command\n" );
        // Prompt the user for the next command.
        fprintf( fp, "cmd> " );
        continue;
      }

      //Get length of string
      wordLen = strlen(word);

      //Check that string didn't exceed maximum word size
      if (wordLen > WORD_LIMIT ) {
        fprintf( fp, "Invalid command\n" );
        // Prompt the user for the next command.
        fprintf( fp, "cmd> " );
        continue;
      }

      //Check move boundaries
      if (aRow < 0 || aRow >= row || aCol < 0 || (aCol + wordLen) > col) {
        fprintf( fp, "Invalid command\n" );
        // Prompt the user for the next command.
        fprintf( fp, "cmd> " );
        continue;
      }

      //Flag for a word that incorrectly updates a grid space
      bool badInput = false;

      //Verify that word consists only of valid lowercase letter
      for (int i = 0; i < wordLen; ++i) {
        if (islower(word[i]) == 0) {
          //Flag the input as invalid
          badInput = true;
          break;
        }
      }

      //One or more of the characters were invalid
      if (badInput) {
        fprintf( fp, "Invalid command\n" );
        // Prompt the user for the next command.
        fprintf( fp, "cmd> " );
        continue;
      }

      //Enter the monitor
      pthread_mutex_lock( &lock );
    
      //Check that the new word doesn't violate existing board before updating
      for (int m = 0; m < wordLen; ++m) {
        char prevChar = board[aRow][m + aCol];
        char newChar = word[m];
        //Check that the new character matches previous or is going in an empty space
        if (prevChar == ' ' || prevChar == newChar) {
          //Do nothing; character is valid
        } else {
          //Leave loop and set flag
          badInput = true;
          break;
        }
      }

      //Leave the monitor
      pthread_mutex_unlock( &lock );

      //One or more of the characters were invalid
      if (badInput) {
        fprintf( fp, "Invalid command\n" );
        // Prompt the user for the next command.
        fprintf( fp, "cmd> " );
        continue;
      }

      //Enter the monitor
      pthread_mutex_lock( &lock );

      //Update the board with the new word
      for (int n = 0; n < wordLen; ++n) {
        board[aRow][n + aCol] = word[n];
      }

      //Leave the monitor
      pthread_mutex_unlock( &lock );

    } else if (strcmp( cmd, "down") == 0) {
      int dRow;
      int dCol;
      char word[30];
      int wordLen;

      //Get move position and word
      if (fscanf(fp, "%d %d %29s", &dRow, &dCol, word) != 3) {
        fprintf( fp, "Invalid command\n" );
        // Prompt the user for the next command.
        fprintf( fp, "cmd> " );
        continue;
      }

      //Get length of string
      wordLen = strlen(word);

      //Check that string didn't exceed maximum word size
      if (wordLen > WORD_LIMIT ) {
        fprintf( fp, "Invalid command\n" );
        // Prompt the user for the next command.
        fprintf( fp, "cmd> " );
        continue;
      }

      //Check move boundaries
      if (dRow < 0 || (dRow + wordLen) > row || dCol < 0 || dCol >= col) {
        fprintf( fp, "Invalid command\n" );
        // Prompt the user for the next command.
        fprintf( fp, "cmd> " );
        continue;
      }

      //Flag for a word that incorrectly updates a grid space
      bool badInput = false;

      //Verify that word consists only of valid lowercase letter
      for (int i = 0; i < wordLen; ++i) {
        if (islower(word[i]) == 0) {
          //Flag the input as bad
          badInput = true;
          break;
        }
      }

      //One or more of the characters were invalid
      if (badInput) {
        fprintf( fp, "Invalid command\n" );
        // Prompt the user for the next command.
        fprintf( fp, "cmd> " );
        continue;
      }

      //Enter the monitor
      pthread_mutex_lock( &lock );

      //Check that the new word doesn't violate existing board before updating
      for (int m = 0; m < wordLen; ++m) {
        char prevChar = board[m + dRow][dCol];
        char newChar = word[m];
        //Check that the new character matches previous or is going in an empty space
        if (prevChar == ' ' || prevChar == newChar) {
          //Do nothing; character is valid
        } else {
          //Leave loop and set flag
          badInput = true;
          break;
        }
      }

      //Leave the monitor
      pthread_mutex_unlock( &lock );

      //One or more of the characters were invalid
      if (badInput) {
        fprintf( fp, "Invalid command\n" );
        // Prompt the user for the next command.
        fprintf( fp, "cmd> " );
        continue;
      }

      //Enter the monitor
      pthread_mutex_lock( &lock );

      //Update the board with the new word
      for (int n = 0; n < wordLen; ++n) {
        board[n + dRow][dCol] = word[n];
      }

      //Leave the monitor
      pthread_mutex_unlock( &lock );

    } else if (strcmp( cmd, "board") == 0) {
      //Print top border
      for (int m = 0; m < col + 2; ++m) {
        fputc(border[m], fp);
      }
      //Move to next line to begin printing board
      fprintf(fp, "\n");

      //Enter the monitor
      pthread_mutex_lock( &lock );

      //Print board state
      for (int i = 0; i < row; ++i) {
        //Put left border
        fputc( '|', fp );
        //Iterate through columns to print contents of row
        for (int j = 0; j < col; ++j) {
          fputc( board[i][j], fp );
        }
        //Put right border
        fputc( '|', fp );
        //Row complete; move to next line
        fprintf(fp, "\n");
      }
      //Print bottom border
      for (int n = 0; n < col + 2; ++n) {
        fputc(border[n], fp);
      }
      //Move to next line when done printing board and borders
      fprintf(fp, "\n");

      //Leaver the monitor
      pthread_mutex_unlock( &lock );

    } else {
      //Command doesn't exist
      fprintf( fp, "Invalid command\n" );
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  //Check for correct number of arguments
  if (argc != 3) {
    fail( "usage: ScrabbleServer <rows> <cols>\n" );
    exit(1);
  }

  //Get row and column numbers
  row = atoi(argv[1]);
  col = atoi(argv[2]);

  //Check for valid row and column numbers
  if (row < 1 || col < 1) {
    fail( "usage: ScrabbleServer <rows> <cols>\n" );
    exit(1);
  }

  //Initialize the board with the given parameters
  initializeBoard(row, col);
  //Initialize the mutex lock
  pthread_mutex_init( &lock, NULL );

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    //Create new thread to handle client
    pthread_t newThread;
    pthread_create( &newThread, NULL, handleClient, (void *) &sock );

    //Detach thread
    pthread_detach(newThread);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
