#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>


/** Port number used by my server */
#define PORT_NUMBER "26060"

/** Maximum word length */
#define WORD_LIMIT 26

/** The number of rows in server */
static int rows;

/** The number of cols in server */
static int cols;


// Lock for access to the 
static pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *vArg ) {
  
  // cast a void pointer
  int *num = (int*)vArg;
  int sock = *num;
  
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  //hold the contents of the board;
  static char board[100][100];
  
  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    //acofprintf( fp, "reponce is %s\n", cmd );
    
    // across?
    if ( strcmp( cmd, "across") == 0 ) {
      pthread_mutex_lock( &mon );   // Enter the monitor
      //get the r and c from client - invalid if not numbers for next two input
      int rowStart;
      if (fscanf( fp, "%d", &rowStart ) != 1 ) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      int colStart;
      if (fscanf( fp, "%d", &colStart ) != 1) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      //fprintf( fp, "row %d curRow %d\n", rows, rowStart );
      //read string
      char str[ 101 ];
      if ( fscanf(fp, "%100s", str) != 1) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      //check- r and c must be in board
      if (rowStart >= rows || colStart >= cols) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      
      if ( strlen(str) > 26 ) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      
      //get the string
      //max length of string
      int maxStringLength;
      if ( rows > cols ) {
        maxStringLength = rows;
      } else {
        maxStringLength = cols;
      }
      
      //can't be too long -worst case
      if ( strlen(str) > maxStringLength ) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      
      
      //word must be lower case letters
      bool isValid = true;
      for (int i = 0; i < strlen(str); i++ ) {
        if ( !islower(str[i]) ) {
          isValid = false;
          break;
        }
      }
      if (!isValid) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      
      //will the word extend?
      int maximumColReached = colStart + strlen(str);
      if ( maximumColReached > cols ) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      
      //will the word match
      int strIdx = 0;
      bool isOverlapValid = true;
      for ( int i = colStart; i < maximumColReached; i++ ) {
        //check if a char is in the way
        if ( islower( board[rowStart][i] ) ) {
          if ( board[rowStart][i] != str[strIdx]) {
            isOverlapValid = false;
          }
        }
        strIdx++;
      }
      if ( !isOverlapValid ) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      //the word will overlap properly so we place it
      int pos = 0;
      for ( int i = colStart; i < maximumColReached; i++ ) {
        board[rowStart][i] = str[pos];
        pos++;
      }

      pthread_mutex_unlock( &mon );  // Leave the monitor
    } // across?
    
    
    
    // down?
    if ( strcmp( cmd, "down") == 0 ) {
      pthread_mutex_lock( &mon );   // Enter the monitor
      //get the r and c from client - invalid if not numbers for next two input
      int rowStart;
      if (fscanf( fp, "%d", &rowStart ) != 1 ) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      int colStart;
      if (fscanf( fp, "%d", &colStart ) != 1) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      //read string
      char str[ 101 ];
      if ( fscanf(fp, "%100s", str) != 1) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      //check- r and c must be in board
      if (rowStart >= rows || colStart >= cols) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      if ( strlen(str) > 26 ) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      
      //get the string
      //max length of string
      int maxStringLength;
      if ( rows > cols ) {
        maxStringLength = rows;
      } else {
        maxStringLength = cols;
      }
     
      //can't be too long -worst case
      if ( strlen(str) > maxStringLength ) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      
      //word must be lower case letters
      bool isValid = true;
      for (int i = 0; i < strlen(str); i++ ) {
        if ( !islower(str[i]) ) {
          isValid = false;
          break;
        }
      }
      if (!isValid) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      
      //will the word extend?
      int maximumRowReached = rowStart + strlen(str);
      if ( maximumRowReached > rows ) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      
      //will the word match
      int strIdx = 0;
      bool isOverlapValid = true;
      for ( int i = rowStart; i < maximumRowReached; i++ ) {
        //check if a char is in the way
        if ( islower( board[i][colStart] ) ) {
          if ( board[i][colStart] != str[strIdx]) {
            isOverlapValid = false;
          }
        }
        strIdx++;
      }
      if ( !isOverlapValid ) {
        fprintf( fp, "Invalid command\n" );
        fprintf( fp, "cmd> " );
        fflush(stdin);
        continue;
      }
      //the word will overlap properly so we place it
      int pos = 0;
      for ( int i = rowStart; i < maximumRowReached; i++ ) {
        board[i][colStart] = str[pos];
        pos++;
      }
    
      pthread_mutex_unlock( &mon );  // Leave the monitor
    
    } //down?
    
    
    //board?
    if ( strcmp( cmd, "board") == 0 ) {
      pthread_mutex_lock( &mon );   // Enter the monitor
       //top
       fprintf( fp, "+");
       for (int i = 0; i < cols; i++) {
         fprintf( fp, "—");
       }
       fprintf( fp, "+\n");
       //middle
       for (int r = 0; r < rows; r++) {
         fprintf( fp, "|");
         for (int c = 0; c < cols; c++) {
           if (islower(board[r][c])) {
             fprintf( fp, "%c", board[r][c]);
           } else {
             fprintf( fp, " ");
           }
           
         }
         fprintf( fp, "|\n");
       }
       //end
       fprintf( fp, "+");
       for (int i = 0; i < cols; i++) {
         fprintf( fp, "—");
       }
       fprintf( fp, "+\n");
      pthread_mutex_unlock( &mon );  // Leave the monitor
    }
    
    
    
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  //check run from command line
  //must be two numbers
  if ( argc != 3 ) {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  rows = atoi(argv[1]);
  
  cols = atoi(argv[2]);
  //cant be negative numbers
  if ( rows < 0 || cols < 0 ) {
    fail("usage: scrabbleServer <rows> <cols>");
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  int iThread = 0;
  pthread_t tid[5];
  while ( true ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_create(&tid[iThread], NULL, handleClient, &sock);
    pthread_detach(tid[iThread]); //we dont need to care about return value
    iThread++;
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
