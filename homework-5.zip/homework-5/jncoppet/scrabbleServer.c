#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26074"

/** Maximum word length */
#define WORD_LIMIT 26

int rows = 0;
int cols = 0;
char **board;
pthread_mutex_t lock;
pthread_t thread;

typedef struct {
    int x; // Parameter for thread
} ArgStruct;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

bool validAcross( int r, int c, int length, char word[] ) {
   
    if(c + length > cols) {
				    return false;
				}
    for(int i = c; i < c + length; i++) {
		    if( (board[r][i] != ' ' && word[i - c] != board[r][i]) || word[i - c] < 94 || word[i - c] > 122 ) {
				    return false;
				}
		}
	  return true;
}

bool validDown( int r, int c, int length, char word[] ) {

    if(r + length > rows) {
				    return false;
    }
    for(int i = r; i < r + length; i++) {
		    if( (board[i][c] != ' ' && word[i - r] != board[i][c]) || word[i - r] < 94 || word[i - r] > 122) {
				    return false;
				}
		}
	  return true;
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  ArgStruct *astruct = (ArgStruct *)sock;
  FILE *fp = fdopen( astruct->x, "a+" );
  
  pthread_mutex_init( &lock, NULL );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );
  
  // Temporary values for parsing commands.
  char cmd[ 11 ];
  int r = -1;
  int c = -1;
  char word[ WORD_LIMIT + 2];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    if( strcmp(cmd, "across") == 0 ) {
				if( fscanf( fp, "%d", &r) == 1 ) {
				    if( fscanf( fp, "%d", &c) == 1 ) {
						    if( fscanf( fp, "%27s", word) == 1 ) {
								    if( strlen(word) <= 26 ) {
										    if( (r >= 0 && c >= 0) && (r < rows && c < cols)) {
	 	 			 		              if( validAcross( r, c, strlen( word ), word ) ) {
	  			 			               pthread_mutex_lock( &lock );
															 for(int i = c; i < c + strlen(word); i++) {
									                  board[r][i] = word[i - c];
										           }
	 							               pthread_mutex_unlock( &lock );
													  } else {
						                    fprintf(fp, "%s\n", "Invalid across command: Indices do not work with current board, or invalid letters.");
														}  
												} else {
												    fprintf(fp, "%s\n", "Invalid command: Indices are out of range.");
												}
										} else {
										    fprintf(fp, "%s\n", "Invalid command: Word is too long.");
										}
								}  else {
		                fprintf(fp, "%s\n", "Invalid command: Could not find word.");
                }
						}  else {
		            fprintf(fp, "%s\n", "Invalid command: Could not find column.");
	        	}
				} else {
		        fprintf(fp, "%s\n", "Invalid command: Could not find row.");
		    }
		} else if( strcmp(cmd, "down") == 0 ) {
		    if( fscanf( fp, "%d", &r) == 1 ) {
				    if( fscanf( fp, "%d", &c) == 1 ) {
						    if( fscanf( fp, "%27s", word) == 1 ) {
								    if( strlen(word) <= 26 ) {
										    if( (r >= 0 && c >= 0) && (r < rows && c < cols)) {
	 	 			 		              if( validDown( r, c, strlen( word ), word ) ) {
	  			 			               pthread_mutex_lock( &lock );
															 for(int i = r; i < r + strlen(word); i++) {
									                  board[i][c] = word[i - r];
										           }
	 							               pthread_mutex_unlock( &lock );
													  } else {
						                    fprintf(fp, "%s\n", "Invalid down command: Indices do not work with current board.");
														}  
												} else {
												    fprintf(fp, "%s\n", "Invalid command: Indices are out of range.");
												}
										} else {
										    fprintf(fp, "%s\n", "Invalid command: Word is too long.");
										}
								}  else {
		                fprintf(fp, "%s\n", "Invalid command: Could not find word.");
                }
						}  else {
		            fprintf(fp, "%s\n", "Invalid command: Could not find column.");
	        	}
				} else {
		        fprintf(fp, "%s\n", "Invalid command: Could not find row.");
		    }
		} else if( strcmp(cmd, "board") == 0 ) {
		    for(int i = -1; i < rows + 1; i++) {
            for(int k = -1; k < cols + 1; k++) {
						    if( (i == -1 && k == -1) || (i == rows && k == cols) || (i == -1 && k == cols) || (i == rows && k == -1)) {
								    fprintf(fp, "%c", '+');
		 				        if(k == cols) {
										    fprintf(fp, "%c", '\n'); 
									  }
								} else if( i == -1 || k == -1 || i == rows || k == cols) {
								    fprintf(fp, "%c", '-');
			 	 		        if(k == cols) {
										    fprintf(fp, "%c", '\n'); 
									  }
								} else {
								    fprintf(fp, "%c", board[i][k]);
								}
						} 
				}
		} else {
			  fprintf(fp, "%s\n", cmd);
		    fprintf(fp, "%s\n", "Invalid command 4");
		}
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  if(argc != 3) {
	    fail("usage: scrabbleServe <rows> <cols>");
	} else if(atoi(argv[1]) < 1 || atoi(argv[2]) < 1) {
	    fail("usage: scrabbleServe <rows> <cols>");
	} 
	rows = atoi(argv[1]);
	cols = atoi(argv[2]);
	board = (char **)malloc( rows * sizeof(char *) );
	for(int i = 0; i < rows; i++) {
	    board[i] = (char *)malloc(cols * sizeof(char) );
	}
  for(int i = 0; i < rows; i++) {
	    for(int k = 0; k < cols; k++) {
			    board[i][k] = ' ';
			}
	}
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.

    ArgStruct *astruct = (ArgStruct *)malloc( sizeof( ArgStruct ) );
    astruct->x = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    if( pthread_create( &thread, NULL, handleClient, astruct) != 0 ) {
		    fail("Can't create a child thread\n");
		}
    pthread_detach( thread );
    //handleClient( sock );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  for(int i = 0; i < rows; i++) {
	    free(board[i]);
	}
	free(board);
  return 0;
}
