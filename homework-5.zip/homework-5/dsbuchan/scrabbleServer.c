/**
 * @file scrabbleServer.c
 * @author Daniel Buchanan (dsbuchan)
 * Plays a game of scrabble using a TCP/IP for connection and allows multiple clients to connect and access the server
 */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26284"

/** Maximum word length */
#define WORD_LIMIT 26

/** Numerical argument size*/
#define NUMARG_SIZE 5

/** Size of the first agrument*/
#define FIRST_ARG 11

typedef struct Board{
  int rows;
  int cols;
  char * grid;
} Board;

/** This record helps to keep up with each thread. */
typedef struct {
  // the socket
  int sock;
} ThreadRec;

// store reference to the board
Board * board;

/** ensure that only one thread at a time is looking or modifying the board*/
sem_t sem;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** Converts a string to an integer representation. Returns -1 in case of failure*/
int convertToInt(char * str){
  int len = strlen(str);
  int num = 0;
  for(int i = 0; i < len; i++){
    if(str[i] < '0' || str[i] > '9'){
      return -1;
    }
    num *= 10;
    num += str[i] - '0';
  }
  return num;
}


/**
 * Will run the across command, entering a word into the board at the given position
 * 
 * @param r row for word to start
 * @param c column for word to start
 * @param word the word to be entered
 * @param board the scrabble board
 * @return true if the command is valid, and false otherwise
 */
bool across(int r, int c, char * word, Board * board){
  int len = strlen(word);
  if(r >= board->rows || c + len > board->cols || c < 1 || r < 1){
    return false;
  }
  // check if valid entry before entering
  // - is the word all lowercase
  // - do the letters match the existing board
  for(int i = 0; i < len; i++){
    if(word[i] < 'a' || word[i] > 'z'){
      return false;
    }
    // check that there is not a word there, and if there is check if the letters match
    char ch = board->grid[(r * board->cols) + c + i];
    if(ch != ' ' && ch != word[i]){
      return false;
    }
  }
  // at this point, the word is valid so enter it into the board
  for(int i = 0; i < len; i++){
    board->grid[(r * board->cols) + c + i] = word[i];
  }
  // EC - is the word in the dictionary
  return true;
}

/**
 * Will run the down command for scrabble. Will enter the word at the coordinates going down
 * 
 * @param r row for word to be entered 
 * @param c column for word to be entered
 * @param word word to be entered
 * @param board board representation for scrabble
 * @return true if the command is valid, and false if the command was invalid
 */
bool down(int r, int c, char * word, Board * board){
  int len = strlen(word);
  if(r + len  > board->rows || c >= board->cols || c < 1 || r < 1){
    return false;
  }
  // check if valid entry before entering
  // - is the word all lowercase
  // - do the letters match the existing board
  for(int i = 0; i < len; i++){
    if(word[i] < 'a' || word[i] > 'z'){
      // print invalid command out to thread, but do not exit the server
      return false;
    }
    // check that there is not a word there, and if there is check if the letters match
    char ch = board->grid[((r + i) * board->cols) + c];
    if(ch != ' ' && ch != word[i]){
      return false;
    }
  }
  // at this point, the word is valid so enter it into the board
  for(int i = 0; i < len; i++){
    board->grid[((r + i) * board->cols) + c] = word[i];
  }
  // EC - is the word in the dictionary
  return true;
}

/** Prints the board*/
void boardCmd(Board * board, FILE * fp){
  // write the board to the client
  fprintf(fp, "+");
  for(int i = 0; i < board->cols; i++){
    fprintf(fp, "-");
  }
  fprintf(fp, "+\n");
  for(int i = 0; i < board->rows; i++){
    fprintf(fp, "|");
    for(int k = 0; k < board->cols; k++){
      fprintf(fp, "%c", board->grid[(board->cols * i) + k]);
    }
    fprintf(fp, "|\n");
  }
  fprintf(fp,"+");
  for(int i = 0; i < board->cols; i++){
    fprintf(fp, "-");
  }
  fprintf(fp,"+\n");
  
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *arg) {
  // need to get the socket to write to file
  ThreadRec *tr = arg;
  int sock = tr->sock;

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ FIRST_ARG + WORD_LIMIT + 1 ];
  // prevent buffer overflow by using fgets
  // if too many characters in input, throw an error
  while ( fgets(cmd, FIRST_ARG + WORD_LIMIT, fp) != NULL &&
          strcmp( cmd, "quit" ) != 0 ) {
            // if user has input that is too long, reprompt
    if(strlen(cmd) > FIRST_ARG + WORD_LIMIT - 1){
      fprintf(fp, "Invalid Command\ncmd> ");
      continue;
    }
    // get the type of command using substring
    char firstArg[FIRST_ARG];
    int idx = 0;
    while(idx < strlen(cmd)){
      if(cmd[idx] == '\0' || cmd[idx] == ' ' || cmd[idx] == '\n'){
        firstArg[idx] = '\0';
        idx++;
        break;
      }
      firstArg[idx] = cmd[idx];
      idx++;
    }
    // if valid command
    bool validCommand = true;
    // across command
    if(0 == strcmp("across", firstArg)){
      char secondArg[NUMARG_SIZE];
      
      for(int k = 0; k < strlen(cmd) - idx; k++){
        if(cmd[k + idx] == '\0' || cmd[k + idx] == ' ' || k >= NUMARG_SIZE){
          secondArg[k] = '\0';
          idx = k + idx + 1;
          break;
        }
        secondArg[k] = cmd[k + idx];
      }
      char thirdArg[NUMARG_SIZE];
      for(int k = 0; k < strlen(cmd) - idx; k++){
        if(cmd[k + idx] == '\0' || cmd[k + idx] == ' ' || k >= NUMARG_SIZE){
          thirdArg[k] = '\0';
          idx = k + idx + 1;
          break;
        }
        thirdArg[k] = cmd[k + idx];
      }
      int row = convertToInt(secondArg);
      int col = convertToInt(thirdArg);
      // allowing 2 extra characters, one for null, and another to see if the word is going to exceed the word limit
      char word[WORD_LIMIT + 2];
      // read in the word
      for(int k = 0; k < strlen(cmd) - idx; k++){
        if(cmd[k + idx] == '\0' || cmd[k + idx] == ' ' || cmd[k + idx] == '\n' || k >= WORD_LIMIT + 2){
          word[k] = '\0';
          idx = k + idx + 1;
          break;
        }
        word[k] = cmd[k + idx];
      }
      // if word is too long, or there is extra input after word, invalid
      if(strlen(word) > WORD_LIMIT || idx < strlen(cmd) - 1){
        fprintf(fp, "Invalid Command\ncmd> ");
        continue;
      }
      // make sure only one thread at a time is modifying the board
      sem_wait(&sem);
      validCommand = across(row , col, word, board);
      sem_post(&sem);

    // down command
    } else if(0 == strcmp("down", firstArg)){
      char secondArg[NUMARG_SIZE];
      // read the first number
      for(int k = 0; k < strlen(cmd) - idx; k++){
        if(cmd[k + idx] == '\0' || cmd[k + idx] == ' ' || k >= NUMARG_SIZE){
          secondArg[k] = '\0';
          idx = k + idx + 1;
          break;
        }
        secondArg[k] = cmd[k + idx];
      }
      // read the second number
      char thirdArg[NUMARG_SIZE];
      for(int k = 0; k < strlen(cmd) - idx; k++){
        if(cmd[k + idx] == '\0' || cmd[k + idx] == ' ' || k >= NUMARG_SIZE){
          thirdArg[k] = '\0';
          idx = k + idx + 1;
          break;
        }
        thirdArg[k] = cmd[k + idx];
      }
      // convert the numerical argument to integers
      int row = convertToInt(secondArg);
      int col = convertToInt(thirdArg);
      // read in the word
      char word[WORD_LIMIT + 2];
      for(int k = 0; k < strlen(cmd) - idx; k++){
        if(cmd[k + idx] == '\0' || cmd[k + idx] == ' ' || cmd[k + idx] == '\n' || k >= WORD_LIMIT + 2){
          word[k] = '\0';
          idx = k + idx + 1;
          break;
        }
        word[k] = cmd[k + idx];
      }
      if(strlen(word) > WORD_LIMIT || idx < strlen(cmd) - 1){
        fprintf(fp, "Invalid Command\ncmd> ");
        continue;
      }
      sem_wait(&sem);
      validCommand = down(row , col, word, board);
      sem_post(&sem);
    // print the board
    } else if(0 == strcmp("board", firstArg)){
      sem_wait(&sem);
      boardCmd(board, fp);
      sem_post(&sem);
    }else if(0 == strcmp("quit", firstArg)){
      break;
    } else {
      fprintf(fp, "Invalid Command\n");
    }
    if(!validCommand){
      fprintf(fp, "Invalid Command\n");
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}



int main( int argc, char *argv[] ) {
  // check that arguments are valid
  _Bool invalidArgs = false;
  sem_init(&sem, 0, 1);
  // setting up number of rows and columns
  int row = 0;
  int col = 0;
  if(argc < 4){
    row = convertToInt(argv[1]);
    col = convertToInt(argv[2]);
    if(row < 1 || col < 1){
      invalidArgs = true;
    }
  } else {
    invalidArgs = true;
  }

  if(invalidArgs){
    fail("usage: scrabbleServer <rows> <cols>\n");
  }
  
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  // create the board
  board = (Board *)malloc(sizeof(Board));
  board->grid = (char *)malloc(sizeof(char) * row * col);
  // initialize board to contain all whitespace
  for(int i = 0; i < row * col; i++){
    board->grid[i] = ' ';
  }
  board->cols = col;
  board->rows = row;
  // limited to 10 threads
  pthread_t threads[10];
  ThreadRec threadRec[10];
  int numThreads = 0;

  while ( true  ) {
    // will need to add multithreading here
    // Accept a client connection.
    
    // WILL have to make board a global variable
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    threadRec[numThreads].sock = sock;
    pthread_create(&(threads[numThreads]), NULL, handleClient, threadRec + numThreads);
    int threadNum = numThreads;
    numThreads++;
    
    pthread_detach(threads[threadNum]);
  }
  sem_destroy(&sem);
  free(board->grid);
  free(board);

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
