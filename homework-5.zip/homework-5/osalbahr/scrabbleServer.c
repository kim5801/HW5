// This program is a server that lets you play scrabble
// use "nc localhost 26118" in another window in the same host
// Compile with -DNOSTARVE to prevent reasers/writers starvation
// Compile with -DHANDLE_CTRL_C to free memory when killing server


#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

#define REPORTS( S ) //printf( "%s = %s\n", #S, S )

/** Port number used by my server */
#define PORT_NUMBER "26118"

/** Maximum word length */
#define WORD_LIMIT 26

/** Length of a row */
#define ROW_LEN (cols + 2 + 1)

// My DIY 2D board
static char *board;
static int rows;
static int cols;

// My DIY 2D words
static int size = 0;
static int capacity = 2;
typedef char Word[ WORD_LIMIT + 1 ];
static Word *words = NULL;

// static void printList()
// {
//   printf( "here %d\n", size );
//   for ( int i = 0; i < size; i++ )
//     printf( "%s\n", words[ i ] );
// }

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message and exit.
static void usage()
{
  fail( "scrabbleServer: <rows> <cols>" );
}

// See if the given null-terminated string
// consistents of only lowercase characters
static bool lowerWord( char const *word )
{
  for(; *word; word++)
    if ( !islower( *word ) )
      return false;
  return true;
}

static void readList( FILE *fp )
{
  words = malloc( capacity * sizeof( *words ) );
  Word word;
  while ( fscanf( fp, "%s", word ) == 1 ) {
    // bool fun = false;
    if ( size == capacity ) {
      Word *temp = NULL;
      int adder = capacity;
      capacity += adder;
      while ( temp == NULL ) {
        // fprintf( stderr, "adder capacity = %d\n", capacity );
        temp = realloc( words, capacity * sizeof( *words ) );
        if ( adder == 0 ) {
          // fprintf( stderr, "Cannot allocate for %d words.\n", capacity );
          free( words );
          free( board );
          fail( "Evil words file" );
        }
        if ( temp == NULL ) {
          // if( !fun) fprintf( stderr, ":fun begins:\n" ), fun = true;
          capacity -= adder;
          adder /= 2;
          capacity += adder;
          fprintf( stderr, "adder = %d\n", adder );
        }
      }
      // fprintf( stderr, "%p:%p:%d\n", words, temp, words == temp );
      words = temp;
      // fprintf( stderr, "capacity = %d\n", capacity );
    }

    if ( lowerWord( word ) ) {
      strcpy( words[ size ], word );
      size++;
    }
  }
}


// If applicable, let two threads read concurrently
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
int nr = 0;
bool  writing = 0;
pthread_cond_t readCond = PTHREAD_COND_INITIALIZER;
pthread_cond_t writeCond = PTHREAD_COND_INITIALIZER;

#ifdef NOSTARVE
// increment when reading (up to BOUND)
// decrement when writing (down to -BOUND)
int turn = 0;
#define BOUND 3
int waitingr = 0;
int waitingw = 0;
#endif

#if LONG_READ || LONG_WRITE
#define WAIT_TIME 10
#endif

static void fillBoard()
{
  // I know this looks bad, but trust me
  char *charPtr = board;

  // First row
  *charPtr++ = '+';
  for ( int i = 0; i < cols; i++ )
    *charPtr++ = '-';

  *charPtr++ = '+';
  *charPtr++ = '\0';

  // "Main" rows
  for ( int i = 0; i < rows; i++ ) {
    *charPtr++ = '|';
    for ( int i = 0; i < cols; i++ )
      *charPtr++ = ' ';

    *charPtr++ = '|';
    *charPtr++ = '\0';
  }

  // Last row
  *charPtr++ = '+';
  for ( int i = 0; i < cols; i++ )
    *charPtr++ = '-';

  *charPtr++ = '+';
  *charPtr = '\0';
}

// Print the board
static void printBoard( FILE *fp )
{
  // Again, trust me
  char *charPtr = board;
  for ( int i = 0; i < rows + 2; charPtr += ROW_LEN, i++ )
    fprintf( fp, "%s\n", charPtr );
}

// across r c word
static bool across( int r, int c, char const word[] )
{
  // Check initial location
  if ( r < 0 || r >= rows
      || c < 0 || c >= cols )
    return false;
  
  // Check final location
  int len = strlen( word );
  if ( c + len - 1 >= cols )
    return false;
  
  char *charPtr = board;
  
  // Go to the start
  // skip first row
  // row width is cols + 2 + 1
  charPtr += ( r + 1 ) * ROW_LEN + c + 1;

  // check first
  for ( int i = 0; i < len; i++ )
    if ( charPtr[ i ] != ' ' && charPtr[ i ] != word[ i ] )
      return false;

  strncpy( charPtr, word, strlen( word ) ); // yes, I do not want to copy '\0'
  return true;
}

// down r c word
static bool down( int r, int c, char const word[] )
{
  // Check initial location
  if ( r < 0 || r >= rows
      || c < 0 || c >= cols )
    return false;
  
  // Check final location
  int len = strlen( word );
  if ( r + len - 1 >= rows )
    return false;
  
  // Will point to the start of the insertion
  char *charPtr = board;
  
  // Go to the start
  // skip first row
  // row width is cols + 2 + 1
  charPtr += ( r + 1 ) * ROW_LEN + c + 1;

  // check first
  for ( int i = 0, j = 0; i < len; i++, j += ROW_LEN )
    if ( charPtr[ j ] != ' ' && charPtr[ j ] != word[ i ] )
      return false;

  for ( int i = 0, j = 0; i < len; i++, j += ROW_LEN )
    charPtr[ j ] = word[ i ];

  return true;
}

// revert back to the backup and free it
static void revert( char *backup )
{
  int bytes = ( rows + 2 ) * ROW_LEN * sizeof( char );
  memcpy( board, backup, bytes );
  free( backup );
}

// temporarily store the board
static char *getBackup()
{
  int bytes = ( rows + 2 ) * ROW_LEN * sizeof( char );
  char *backup = malloc( bytes );
  memcpy( backup, board, bytes );
  return backup;
}

// Compare the given word to the word list
// true if found
static bool validWord( char const *word, int len )
{
  // List is void
  if ( words == NULL )
    return true;

  // Try to find a match
  for ( int i = 0; i < size; i++ ) {
    char *current = words[ i ];
    REPORTS( word );
    REPORTS( current );
    if ( strlen( current ) == len && strncmp( current, word, len ) == 0 )
      return true;
  }

  return false;
}

// checks if the current "row" is valid
// also used to check columns, transposed
static bool validLine( char *line )
{
  for ( int i = 0; line[ i ] && line[ i ] != '|'; i++ ) {
    // skip spaces
    if ( line[ i ] == ' ' )
      continue;

    // start of a word
    int len = 0;
    for ( len = 0; islower( line[ i + len ] ); len++ )
      ;
    // Ignore 1-letter words (already checked)
    // now see if it is valid
    if ( len > 1 && !validWord( line + i, len ) )
      return false;
    // move forward
    i += len;
    i--; // undo the for loop's i++
  }

  return true;
}

static bool validBoard()
{
  if ( words == NULL )
    return true;

  char *row = board + ROW_LEN + 1;
  for ( int i = 0; i < rows; i++, row += ROW_LEN ) {
    if ( !validLine( row ) )
      return false;
  }
  
  char *col = board + ROW_LEN + 1;
  char transpose[ rows + 1 ];
  transpose[ rows ] = '\0';
  for ( int i = 0; i < cols; i++, col += 1 ) {
    for ( int j = 0; j < rows; j++ )
      transpose[ j ] = col[ j * ROW_LEN ];
    if ( !validLine( transpose ) )
      return false;
  }

  return true;
}

// Skip any lingering whitespace
static void skipSpace( FILE *fp )
{
  int ch;
  while ( ( ch = fgetc( fp ) ) == ' ' )
    ;
  if ( ch != EOF )
    ungetc( ch, fp );
}

static bool executeCmd( FILE *fp, char const cmd[] )
{
  // Is it board?
  if ( strcmp( cmd, "board" ) == 0 ) {
    pthread_mutex_lock( &lock );
    while ( writing
#ifdef NOSTARVE
        || turn >= BOUND ) {
      waitingr++;
      pthread_cond_wait( &readCond, &lock );
      waitingr--;
#else
           ) {
      pthread_cond_wait( &readCond, &lock );
#endif
    }
    nr++;
#ifdef NOSTARVE 
    // It is readers' turn
    if ( turn < 0 )
      turn = 0;
    
    // Be polite
    if ( waitingw > 0 )
      turn++;

    // fprintf( fp, "turn = %d\n", turn ); 
#endif
    pthread_mutex_unlock( &lock );
    
    printBoard( fp );
#ifdef LONG_READ
    fflush( fp ), sleep( WAIT_TIME ); // simulate reading taking too long
#endif
    pthread_mutex_lock( &lock );
    nr--;
    if ( nr == 0 )
      pthread_cond_broadcast( &writeCond );

    pthread_mutex_unlock( &lock );
    return true;
  }

  // It must be either across or down
  if ( strcmp( cmd, "across" ) != 0 && strcmp( cmd, "down" ) != 0 )
    return false;

  // Get " r c word"
  // leave extra room for error
  int bufferLen = 10 + 1 + 10 + WORD_LIMIT + 2;
  char line[ bufferLen ];
  int ch, i;
  for ( i = 0; ( ch = fgetc( fp ) ) != EOF && ch != '\n'; i++ ) {
    if ( i == bufferLen ) {
      return false;
    }
    if ( ch == ' ' )
      skipSpace( fp );
    line[ i ] = ch;
  }
  line[ i ] = '\0';

  int r, c;
  char word[ WORD_LIMIT + 1 ];
  char check;
  int count = sscanf( line, "%d%d%26s %c", &r, &c, word, &check );
  if ( count != 3 )
    return false;
  
  // Must be all lowercase and a valid word
  if ( !lowerWord( word ) || !validWord( word, strlen( word ) ) )
      return false;
  
  pthread_mutex_lock( &lock );
  while ( writing || nr > 0
#ifdef NOSTARVE
       || turn <= -BOUND ) {
    waitingw++;
    pthread_cond_wait( &writeCond, &lock );
    waitingw--;
#else
         ) {
    pthread_cond_wait( &writeCond, &lock );
#endif
  }
  writing = true;
#ifdef NOSTARVE
  // It is writers' turn
  if ( turn > 0 )
    turn = 0;
  
  // Be polite
  if ( waitingr > 0 )
    turn--;

  // fprintf( fp, "turn = %d\n", turn );
#endif
  // Create a backup
  char *backup = getBackup();

  bool result;
  // Can do without checking cmd twice, but less readable
  if ( strcmp( cmd, "across" ) == 0 )
    result = across( r, c, word );
  else 
    result = down( r, c, word );
  
  // Revert back if needed
  if ( result && !validBoard() ) {
    revert( backup );
    result = false;
  } else {
    free( backup );
  }

  writing = false;
#ifdef LONG_WRITE
    fprintf( fp, "I am technically done writing\n" ); // acknowledgment 
    fflush( fp ), sleep( WAIT_TIME ); // simulate writing taking too long
#endif
  pthread_cond_broadcast( &readCond );
  pthread_cond_broadcast( &writeCond );
  pthread_mutex_unlock( &lock );

  return result;
}

/** handle a client connection, close it when we're done. */
void *handleClient( int sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    
    // Try to execute the command
    if ( !executeCmd( fp, cmd ) )
      fprintf( fp, "Invalid command\n" );

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );

  return NULL;
}

// Pass on information to the thread
typedef struct threadTag {
  pthread_t threadt;
  int sock;
} threadInfo;


void *threadRoutine( void *arg )
{
  threadInfo *info = (threadInfo *)arg;
  handleClient( info->sock );
  pthread_detach( pthread_self() );
  free( info );
  return NULL;
}

// Flag for telling the server to stop running because of a sigint.
// This is safer than trying to print in the signal handler.
static int running = 1;

#ifdef HANDLE_CTRL_C
// Handles ctrl-c by changing the loop condition
void handler( int notUsed )
{
  running = 0;
}
#endif

int main( int argc, char *argv[] ) {
  // See if args are valid
  if ( argc != 3 )
    usage();
  rows = atoi( argv[ 1 ] );
  cols = atoi( argv[ 2 ] );
  if ( rows <= 0 || cols <= 0 )
    usage();
  
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    freeaddrinfo(servAddr), close( servSock ), fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

#ifdef HANDLE_CTRL_C
  // Handle ctrl-c
  // signal(SIGINT, handler);
  struct sigaction act;
  act.sa_handler = handler;
  sigemptyset( &( act.sa_mask ) );
  act.sa_flags = 0;
  sigaction( SIGINT, &act, NULL );
#endif

  // Prepare the board, with boarders
  board = malloc( ( rows + 2 ) * ROW_LEN * sizeof( char ) );
  if ( board == NULL )
    fail( "Cannot allocate memory for the board" );
 
  fillBoard();

  // Prepare the words array
  FILE *wfp = fopen( "words", "r" );
  if ( wfp ) {
    readList( wfp );
    fclose( wfp );
  }

  while ( running ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    if ( !running )
      break;
    threadInfo *info = malloc( sizeof( threadInfo ) );
    info->sock = sock;
    pthread_create( &info->threadt, NULL, threadRoutine, info );
  }

  // Stop accepting client connections
  close( servSock );

  // Free resources
  free( board );
  free( words );
  
  return 0;
}
