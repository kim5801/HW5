/**
 * @author Arnav Sharma
 * @file scrabbleServer.c
 *
 * Scrabble game using server and client
 *
 */

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netdb.h>
#include <pthread.h>
#include <semaphore.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

/** Port number used by my server */
#define PORT_NUMBER "26172"

/** Maximum word length */
#define WORD_LIMIT 26

int hor;

int ver;

int **board = NULL;

// sem wait sem post

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(EXIT_FAILURE);
}

/** handle a client connection, close it when we're done. */
void *handleClient(int sock)
{
    // Here's a nice trick, wrap a C standard IO FILE around the
    // socket, so we can communicate the same way we would read/write
    // a file.
    FILE *fp = fdopen(sock, "a+");

    // Prompt the user for a command.
    fprintf(fp, "cmd> ");

    // Temporary values for parsing commands.
    char cmd[11];
    // int board[hor][ver];
    char str[WORD_LIMIT];
    int mult = hor * ver;
    int x = 0;
    int y = 0;
    int maxNum = 11 + hor + ver + WORD_LIMIT;
    char format[10];
    char fullCommand[maxNum];
    snprintf(format, 10, "%%%ds", maxNum);
    // int tempLength = 0;
    // int tempNumber = 0;
    while (fscanf(fp, format, fullCommand)) {
        int tokens = sscanf(fullCommand, "%s %d %d %s", cmd, &x, &y, str);
        if (strcmp(cmd, "quit") == 0) {
            break;
        }
        // Just echo the command back to the client for now.
        if (strcmp(cmd, "across") == 0) {
            // printf("%d\n", ver);
            // fprintf(fp, "test ");
            if (tokens < 4) {
                printf("Invalid command");
            } else if (strlen(str) + x > hor) {
                printf("Invalid command");
            } else {
                for (int i = x; i < strlen(str) + x; i++) {
                    board[i][y] = str[i - x];
                }
            }
        }

        else if (strcmp(cmd, "down") == 0) {
            if (tokens < 4) {
                printf("Invalid command");
            } else if (strlen(str) + y > ver) {
                printf("Invalid command");
            } else {
                for (int i = y; i < strlen(str) + y; i++) {
                    board[x][i] = str[i - y];
                }
            }
        }

        else if (strcmp(cmd, "board") == 0) {
            fprintf(fp, "\n+");
            for (int i = 0; i < hor; i++) {
                fprintf(fp, "-");
            }
            fprintf(fp, "+\n");
            for (int i = 0; i < ver; i++) {
                fprintf(fp, "|");
                for (int j = 0; j < hor; j++) {
                    fprintf(fp, "%c", board[j][i]);
                }
                fprintf(fp, "|\n");
            }
            fprintf(fp, "+");
            for (int i = 0; i < hor; i++) {
                fprintf(fp, "-");
            }
            fprintf(fp, "+\n");
            fflush(fp);
        }

        // Prompt the user for the next command.
        fprintf(fp, "cmd> ");
    }

    // Close the connection with this client.
    fclose(fp);
    return NULL;
}

int main(int argc, char *argv[])
{
    // Prepare a description of server address criteria.
    struct addrinfo addrCriteria;
    memset(&addrCriteria, 0, sizeof(addrCriteria));
    addrCriteria.ai_family = AF_INET;
    addrCriteria.ai_flags = AI_PASSIVE;
    addrCriteria.ai_socktype = SOCK_STREAM;
    addrCriteria.ai_protocol = IPPROTO_TCP;

    // Lookup a list of matching addresses
    struct addrinfo *servAddr;
    if (getaddrinfo(NULL, PORT_NUMBER, &addrCriteria, &servAddr))
        fail("Can't get address info");

    // Try to just use the first one.
    if (servAddr == NULL)
        fail("Can't get address");

    // Create a TCP socket
    int servSock = socket(servAddr->ai_family, servAddr->ai_socktype,
                          servAddr->ai_protocol);
    if (servSock < 0)
        fail("Can't create socket");

    // Bind to the local address
    if (bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0)
        fail("Can't bind socket");

    // Tell the socket to listen for incoming connections.
    if (listen(servSock, 5) != 0)
        fail("Can't listen on socket");

    // Free address list allocated by getaddrinfo()
    freeaddrinfo(servAddr);

    // Fields for accepting a client connection.
    struct sockaddr_storage clntAddr; // Client address
    socklen_t clntAddrLen = sizeof(clntAddr);

    if (argv[1] <= 0 || argv[2] <= 0) {
        fail("usage: scrabbleServer<rows><cols>");
        exit(1);
    }

    hor = atoi(argv[1]);

    ver = atoi(argv[2]);

    board = malloc(sizeof(int) * hor * ver);

    memset(board, 0, sizeof(*board));

    for (int i = 0; i < hor; i++) {
        board[i] = malloc(sizeof(int) * ver);
        memset(board[i], ' ', sizeof(int) * ver);
    }

    while (true) {
        // Accept a client connection.
        int sock = accept(servSock, (struct sockaddr *)&clntAddr, &clntAddrLen);

        handleClient(sock);
    }

    // Stop accepting client connections (never reached).
    close(servSock);
    return 0;
}
