#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26170"

/** Maximum word length */
#define WORD_LIMIT 26

// Semaphore lock to avoid race conditions
sem_t lock;

// Struct to represent the state of the scrabble board
typedef struct board {
  // The 2d char array representing the board
  char **b;
  // number of rows in the board
  int rows;
  // number of cols in the board
  int cols;
} board;

// global pointer to the board
static board *b;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Prints out an invalid command message to the given file pointer.
static void invalid(FILE *fp) {
  fprintf(fp, "Invalid Command\n");
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *arg) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int sock = *((int *) arg);
  FILE *fp = fdopen( sock, "a+" );
  
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // check if it is a potentially valid cmd or quit.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    // If it is across
    if (strncmp(cmd, "across", 6) == 0) {
      // acquire semaphore
      sem_wait(&lock);
      int r;
      int c;
      // Get the row and col values from the command
      if (fscanf(fp, "%d %d ", &r, &c) == 2) {
        bool flag = false;
        char *str = (char *) malloc((b->cols + 1) * sizeof(char));
        char curr;
        int ptr = 0;
        // Continue parsing the word to be adding character by character
        while ((curr = fgetc(fp))) {
          // If reaching the end of the command
          if (curr == '\n') {
            break;
          }
          // if the row or col in the command is invalid
          if (r < 0 || r >= b->rows || c < 0 || c >= b->cols) {
            flag = true;
            break;
          }
          // If the character is invalid or the message is too long
          if (curr >= 'a' && curr <= 'z' && ptr < (b->cols - c) ) {
            str[ptr++] = curr;
          } else {
            flag = true;
            break;
          }
          
        }
        if (flag) {
          // Print invalid message
          invalid(fp);
        } else {
          // Update the board
          str[ptr] = '\0';
          int cc = c;
          bool valid = true;
          // Check that all the characters on the board agree with the word
          for (int i = 0; i < strlen(str); i++) {
            char bchar = b->b[r][cc++];
            if (bchar != '\0') {
              if(bchar != str[i]) {
                valid = false;
                break;
              }
            }
          }

          // If characters do agree
          if (valid) {
            // update board
            cc = c;
            for (int i = 0; i < strlen(str); i++) {
              b->b[r][cc++] = str[i];
            }
          } else {
            // invalid message if they do not agree
            invalid(fp);
          }
        }
        // free the word string
        free(str);
        // release the lock
        sem_post(&lock);
      } else {
        invalid(fp);
      }
    } else if (strncmp(cmd, "down", 4) == 0) {
      // acquire semaphore lock
      sem_wait(&lock);
      int r;
      int c;
      // Scan the row and column from command
      if (fscanf(fp, "%d %d ", &r, &c) == 2) {
        bool flag = false;
        char *str = (char *) malloc((b->cols + 1) * sizeof(char));
        char curr;
        int ptr = 0;
        // Read word given char by char
        while ((curr = fgetc(fp))) {
          // When reaching end of command
          if (curr == '\n') {
            break;
          }
          // If row or col is out of bounds
          if (r < 0 || r >= b->rows || c < 0 || c >= b->cols) {
            flag = true;
            break;
          }
          // If character is invalid or too long of a message
          if (curr >= 'a' && curr <= 'z' && ptr < (b->rows - r) ) {
            str[ptr++] = curr;
          } else {
            flag = true;
            break;
          }
          
        }
        if (flag) {
          // Print invalid message
          invalid(fp);
        } else {
          str[ptr] = '\0';
          int cr = r;
          bool valid = true;
          // Check that all chars on board agree with new word
          for (int i = 0; i < strlen(str); i++) {
            char bchar = b->b[cr++][c];
            if (bchar != '\0') {
              if(bchar != str[i]) {
                valid = false;
                break;
              }
            }
          }
          // If they do agree, update board
          if (valid) {
            cr = r;
            // update board
            for (int i = 0; i < strlen(str); i++) {
              b->b[cr++][c] = str[i];
            }
          } else {
            // Else, invalid message
            invalid(fp);
          }
        }
        // Free word string
        free(str);
        // Release semaphore lock
        sem_post(&lock);
      } else {
        invalid(fp);
      }
    } else if (strcmp(cmd, "board") == 0) {
      // Acquire semaphore lock
      sem_wait(&lock);
      // Start printing the board state
      fprintf(fp, "+");
      for (int col = 0; col < b->cols; col++) {
          fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
      // Print the actual board
      for (int row = 0; row < b->rows; row++) {
        fprintf(fp, "|");
        for (int col = 0; col < b->cols; col++) {
          // If empty
          if (b->b[row][col] == '\0') {
            fprintf(fp, " ");
          } else {
            // Print the character
            fprintf(fp, "%c", b->b[row][col]);
          }
        }
        fprintf(fp, "|\n");
      }
      fprintf(fp, "+");
      for (int col = 0; col < b->cols; col++) {
          fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
      // Release lock
      sem_post(&lock);
    } else {
      invalid(fp);
    }
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  // Ensure number of args is right
  if (argc != 3) {
    fail("usage: scrabbleServer <rows> <cols>\n");
  }
  // Try parsing row and col numbers to ints
  int rows = atoi(argv[1]);
  int cols = atoi(argv[2]);
  // If invalid values are given, usage message printed
  if (rows <= 0 || cols <= 0) {
    fail("usage: scrabbleServer <rows> <cols>\n");
  }
  // Allocate memory to the board
  b = (board *) malloc(sizeof(board));
  b->b = (char **) malloc(rows * sizeof(char *));
  for (int row = 0; row < rows; row++) {
    b->b[row] = (char *) malloc(cols * sizeof(bool));
  }
  // Initialize values
  b->rows = rows;
  b->cols = cols;
  // Nullify the entire board
  for (int row = 0; row < b->rows; row++) {
    for (int col = 0; col < b->cols; col++) {
      b->b[row][col] = '\0';
    }
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);
  sem_init(&lock, 0, 1);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    // Create new thread with arguments and routine
    pthread_t thread;
    pthread_create(&thread, NULL, handleClient, (void *) &sock);
    // Detach the thread
    pthread_detach(thread);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
