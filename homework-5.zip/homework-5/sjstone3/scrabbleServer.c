#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <semaphore.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26082"

/** Maximum word length */
#define WORD_LIMIT 26

//size of scrabble board
int boardRow;
int boardCol;
char **board;

//semaphore lock to prevent race conditions
sem_t lock;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

//allocates space for the scrabble board given the input coordinates
void createBoard() {
  int r = boardRow;
  int c = boardCol;

  board = malloc( r * c * sizeof( char ) );
  for( int i = 0; i < r; i++ ) {
    board[ i ] = malloc( c * sizeof( char ) );
  }

  //initialize board to all spaces
  for( int i = 0; i < r; i++ ) {
    for( int j = 0; j < c; j++ ) {
      board[ i ][ j ] = ' ';
    }
  }
}

//places a new word on the board going horizontally
bool across( FILE  *fp, char *word, int r, int c ) {
  sem_wait( &lock );
  int wordLen = 0;
  //word can only have lowercase letters
  while( word[ wordLen ] != '\0' ) {
    if( word[ wordLen ] < 'a' || word[ wordLen ] > 'z' ) {
      fprintf( fp, "Invalid command\n" );
      sem_post( &lock );
      return false;
    }
    wordLen++;
  }

  //length must be between 1 to 26 letters and can't go off the board
  if( wordLen == 0 || ( wordLen + c - 1 ) >= boardCol) {
    fprintf( fp, "Invalid command\n" );
    sem_post( &lock );
    return false;
  }
  //word can only overlap with one letter that it matches with
  for( int i = 0; i < wordLen; i++ ) {
    //letters don't match up
    if( board[ r ][ c + i ] != ' ' && board[ r ][ c + i ] != word[ i ] ) {
      fprintf( fp, "Invalid command\n" );
      sem_post( &lock );
      return false;
    }
  }


  //add the word into the board
  for( int i = 0; i < wordLen; i++ ) {
    board[ r ][ c + i ] = word[ i ];
  }
  sem_post( &lock );
  return true;
}

//places a new word on the board going horizontally
bool down( FILE  *fp, char *word, int r, int c ) {
  sem_wait( &lock );

  int wordLen = 0;
  //word can only have lowercase letters
  while( word[ wordLen ] != '\0' ) {
    if( word[ wordLen ] < 'a' || word[ wordLen ] > 'z' ) {
      fprintf( fp, "Invalid command\n" );
      sem_post( &lock );
      return false;
    }
    wordLen++;
  }

  //length must be between 1 to 26 letters and can't go off the board
  if( wordLen == 0 || ( wordLen + r - 1 ) >= boardRow) {
    fprintf( fp, "Invalid command\n" );
    sem_post( &lock );
    return false;
  }

//check to see if word only overlaps with the same letter of other words
  for( int i = 0; i < wordLen; i++ ) {
    if( board[ r + i ][ c ] != ' ' && board[ r + i ][ c ] != word[ i ] ) {
      fprintf(fp, "Invalid command\n");
      sem_post( &lock );
      return false;
    }
  }

  //add the word into the board
  for( int i = 0; i < wordLen; i++ ) {
    board[ r + i ][ c ] = word[ i ];
  }
  sem_post( &lock );
  return true;
}

//instructs the server to print the current state of the board
void printBoard( FILE *fp ) {
  sem_wait( &lock );
  for( int i = 0; i < boardRow + 1; i++ ) {
    //print top and bottom border
    if( i == 0 || i == boardRow ) {
      fprintf( fp, "+" );
      for( int i = 0; i < boardCol; i++ ) {
        fprintf( fp, "-" );
      }
      fprintf( fp, "+\n" );
    }
    if( i == boardRow ) { //last i used to print border, not to access board (will cause segfault)
      break;
    }

    //print board
    for( int j = 0; j < boardCol + 1; j++ ) {
      //print left right border
      if( j == 0 || j == boardCol ) {
        fprintf( fp, "|" );
      }
      if( j == boardCol ) { //last j used to print border, not to access board (will cause segfault)
        break;
      }

      fprintf( fp, "%c", board[ i ][ j ] );
    }
    fprintf( fp, "\n" );
  }
  sem_post( &lock );
}

//gets the word one character at a time to make sure there is no buffer overflow
bool getWord( FILE *fp, char *word ) {
  sem_wait( &lock );
  char ch = ' ';
  int count = 0;
  while( ( ch = fgetc( fp ) ) != -1 && ch != '\n' && ch != ' ') {
    word[ count ] = ch;
    count++;
    if( count > WORD_LIMIT ) {
      sem_post( &lock );
      return false;
    }

  }
  sem_post( &lock );
  return true;
}

//sets word array to all null characters so it's empty for next input store
void clearWord( char *word ) {
  for( int i = 0; i < WORD_LIMIT; i++ ) {
    word[ i ] = '\0';
  }
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *arg ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int sock = *( (int *)arg );
  FILE *fp = fdopen( sock, "a+" );

  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    // Just echo the command back to the client for now.
    //fprintf( fp, "%s\n", cmd );
    int r = 0;
    int c = 0;
    char word[ WORD_LIMIT ];

    if( strcmp( cmd, "across" ) == 0 ) {
      //scan in row and column positions and the given word
      if( fscanf( fp, "%d %d ", &r, &c) != 2 || !getWord( fp, word ) ) {
        fprintf( fp, "Invalid command\n" );
      } else {
        across( fp, word, r, c );
      }

    } else if( strcmp( cmd, "down" ) == 0 ) {
      //scan in row and column positions and the given word
      if( fscanf( fp, "%d %d ", &r, &c ) != 2 || !getWord( fp, word ) ) {
        fprintf( fp, "Invalid command\n" );
      } else {
        down( fp, word, r, c );
      }

    } else if( strcmp( cmd, "board" ) == 0 ) {
      printBoard( fp );

    } else {
      fprintf( fp, "Invalid command\n" );
    }
    clearWord( word );
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  //create the scrabble board
  boardRow = atol( argv[ 1 ] );
  boardCol = atol( argv[ 2 ] );
  createBoard();
  sem_init( &lock , 0, 1 );

  if( boardRow <= 0 || boardCol <= 0 ) {
    fprintf( stderr, "usage: scrabbleServer <rows> <cols>\n" );
    exit( 1 );
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );

  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  pthread_t threadId;

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    //create thread
    pthread_create( &threadId, NULL, handleClient, &sock );
    pthread_detach( threadId );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  free( board );
  return 0;
}
