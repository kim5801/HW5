#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <semaphore.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26224"

/** Maximum word length */
#define WORD_LIMIT 26

typedef struct {
  int sock;    // Parameter for the thread.
} ArgStruct;

//struct to hold information about the board
typedef struct{
  //game board as a 2d array
  char **board;
  //number of rows
  int rows;
  //number of columns
  int cols;
} BoardStruct;

//instance of game board
BoardStruct *boardSt;

//monitor for synchronization
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

//prints out the board with a border around it
void printBoard(FILE *fp){
  pthread_mutex_lock(&mon);
  //create top and bottom rows
  char border[boardSt->cols + 2];
  border[0] = '+';
  for(int i = 1; i < boardSt->cols + 1; i++){
    border[i] = '-';
  }
  border[boardSt->cols + 1] = '+';
  border[boardSt->cols + 2] = '\0';
  //print top row
  fprintf(fp, "%s\n", border);
  //print table contents with | characters at front and end of rows
  for(int i = 0; i < boardSt->rows; i++){
    fprintf(fp, "|");
    for(int j = 0; j < boardSt->cols; j++){
      fprintf(fp, "%c", boardSt->board[i][j]);
    }
    fprintf(fp, "%s", "|\n");
  }
  //print bottom border
  fprintf(fp, "%s\n", border);
  pthread_mutex_unlock(&mon);
}

//verify's the string passed in is made up of all digints and converts it to an int
//returns -1 on error
int convertToInt(char*pos){
  if(strlen(pos) == 0){
    return -1;
  }
  for(int i = 0; pos[i]; i++){
    if(pos[i] < 48 || pos[i] > 57){
      return -1;
    }
  }
  return atoi(pos);
}

//verifys a word is made up of all lowercase characters
bool verifyWord(char*word){
  //words of length 0 are invalid
  if(strlen(word) == 0){
    return false;
  }
  for(int i = 0; word[i]; i++){
    if(word[i] < 97 || word[i] > 122){
      return false;
    }
  }
  return true;
}

//writes the given word across the game board starting at the given row and column
//returns true on success, false on error
bool writeAcross(int row, int col, char*word){
  pthread_mutex_lock(&mon);
  for(int i = 0; word[i]; i++){
    //if the word runs off the board OR the space is not empty and does not contain the same character that will go here, error
    if(i + col >= boardSt->cols || (boardSt->board[row][i + col] != ' ' && boardSt->board[row][i + col] != word[i])){
      pthread_mutex_unlock(&mon);
      return false;
    }
  }
  //place word in spots now that we know its valid
  for(int i = 0; word[i]; i++){
    boardSt->board[row][i+col] = word[i];
  }
  pthread_mutex_unlock(&mon);
  return true;
}

//writes the given word down the game board starting at the given row and column
//returns true on success, false on error
bool writeDown(int row, int col, char*word){
  pthread_mutex_lock(&mon);
  for(int i = 0; word[i]; i++){
    //if the word runs off the board OR the space is not empty and does not contain the same character that will go here, error
    if(i + row >= boardSt->rows || (boardSt->board[i + row][col] != ' ' && boardSt->board[i + row][col] != word[i])){
      pthread_mutex_unlock(&mon);
      return false;
    }
  }
  //place word in spots now that we know its valid
  for(int i = 0; word[i]; i++){
    boardSt->board[i+row][col] = word[i];
  }
  pthread_mutex_unlock(&mon);
  return true;
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *sockStr ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( ((ArgStruct*)sockStr)->sock, "a+" );

  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  bool quitting = false;
  while ( !quitting ) {

    //variables to hold user input commands, reset them on each given comand
    int size = 0;
    char cmd1[ 7 ] = {'\0','\0','\0','\0','\0','\0','\0'};
    char cmd2[10] = {'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0'};
    char cmd3[10] = {'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0'};
    char cmd4[WORD_LIMIT + 1] = {'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0',
                                 '\0','\0','\0','\0','\0','\0','\0','\0','\0','\0',
                                 '\0','\0','\0','\0','\0','\0','\0'};
    //the command number we are parsing (1 is the 4 keywords, 2 is the row, 3 is the col, and 4 is the word)
    int cmdNum = 1;
    //flag for when an invalid command is given
    bool invalid = false;
    //get the first character
    char ch = fgetc(fp);
    //while we have not read in everything the user entered, keep getting characters
    while(ch != '\n'){
      //a space means the first word entered is over, and we need to prepare for the next word
      if(ch == ' '){
        cmdNum++;
        size = 0;
        ch = fgetc(fp);
        //ignore whitespace
        while(ch == ' '){
          ch = fgetc(fp);
        }
        continue;
      }
      //if we are reading the first word
      if(cmdNum == 1){
        //commands dont have a length longer than 6
        if(size > 6){
          fprintf(fp,"%s\n", "Invalid command");
          invalid = true;
          break;
        }
        cmd1[size] = ch;
        size++;
      }
      //reading what should be the row number
      else if(cmdNum == 2){
        //numbers can't be more than 9 digits
        if(size > 9){
          fprintf(fp,"%s\n", "Invalid command");
          invalid = true;
          break;
        }
        cmd2[size] = ch;
        size++;
      }
      //reading what should be the column number
      else if(cmdNum == 3){
        //numbers can't be more than 9 digits
        if(size > 9){
          fprintf(fp,"%s\n", "Invalid command");
          invalid = true;
          break;
        }
        cmd3[size] = ch;
        size++;
      }
      //reading the word to place
      else if (cmdNum == 4){
        //size cant be greater than the definied word limit
        if(size > WORD_LIMIT){
          fprintf(fp,"%s\n", "Invalid command");
          invalid = true;
          break;
        }
        cmd4[size] = ch;
        size++;
      }
      //if a 5th word is read in, that command is invalid
      else{
        fprintf(fp,"%s\n", "Invalid command");
        invalid = true;
        break;
      }
      //get the next character
      ch = fgetc(fp);
    } //end of loop to read in the user command

    if(!invalid){
      //across command
      if(strcmp(cmd1, "across") == 0){
        //attempt to convert the users entered row and col numbers to ints
        int row = convertToInt(cmd2);
        int col = convertToInt(cmd3);
        //if the row and col are not valid ints or are not the board or the word is all lowercase, error
        if(row == -1 || row >= boardSt->rows || col == -1 || col >= boardSt->cols || !verifyWord(cmd4)){
          fprintf(fp,"%s\n", "Invalid command");
        }
        else{
          //attempt to write the word across
          if(!writeAcross(row, col, cmd4)){
            fprintf(fp,"%s\n", "Invalid command");
          }
        }
      }
      //down command
      else if(strcmp(cmd1, "down") == 0){
        //attempt to convert the users entered row and col numbers to ints
        int row = convertToInt(cmd2);
        int col = convertToInt(cmd3);
        //if the row and col are not valid ints or are not the board or the word is all lowercase, error
        if(row == -1 || row >= boardSt->rows || col == -1 || col >= boardSt->cols || !verifyWord(cmd4)){
          fprintf(fp,"%s\n", "Invalid command");
        }
        else{
          //attempt to write the word down
          if(!writeDown(row, col, cmd4)){
            fprintf(fp,"%s\n", "Invalid command");
          }
        }
      }
      //print the board on the board command
      else if(strcmp(cmd1, "board") == 0){
        //make sure nothing else was given on the command line
        if(cmd2[0] == '\0'){
          printBoard(fp);
        }
        else{
          fprintf(fp,"%s\n", "Invalid command");
        }
      }
      //end the program on quit
      else if(strcmp(cmd1, "quit") == 0){
        //make sure nothing else was given on the command line
        if(cmd2[0] == '\0'){
          quitting = true;
          break;
        }
        else{
          fprintf(fp,"%s\n", "Invalid command");
        }
      }
      //the users first given word was not one of the 4 commands
      else{
        fprintf(fp,"%s\n", "Invalid command");
      }
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  free(sockStr);
  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  //make sure the program was started correctly with 3 arguments
  if(argc != 3){
    fail("Usage: scrabbleServer <rows> <cols>");
    exit(1);
  }

  //convert board size to ints and make sure its valid
  int rows = atoi(argv[1]);
  int cols = atoi(argv[2]);

  if(rows <= 0 || cols <= 0){
    fail("Usage: scrabbleServer <rows> <cols>");
  }

  //create board
  boardSt = (BoardStruct*)malloc(sizeof(BoardStruct));
  boardSt->board = (char**)malloc(sizeof(char*)*rows);
  for(int i = 0; i < rows; i++){
    boardSt->board[i] = (char*)malloc(sizeof(char) * cols);
  }
  boardSt->rows = rows;
  boardSt->cols = cols;
  for(int i = 0; i < rows; i++){
    for(int j = 0; j < cols; j++){
      //set each board spot to a space
      boardSt->board[i][j] = ' ';
    }
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);
  while ( true  ) {
    // Accept a client connection.
    ArgStruct *sockStr = (ArgStruct*)malloc(sizeof(ArgStruct)); 
    sockStr->sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    //create a thread for this 
    pthread_t thread;
    pthread_create(&thread, NULL, handleClient, sockStr);
    pthread_detach(thread);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
