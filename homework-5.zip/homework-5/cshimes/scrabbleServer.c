/**
 * @file scrabbleServer.c
 * @author Cameron Himes
 * @brief Manages a server that allows multiple clients to connect and play scrabble.
 */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26156"

/** Maximum word length */
#define WORD_LIMIT 26

/** Maximum total input length */
#define MAX_INPUT_LENGTH 500

/** Maximum command length - the longest possible is 'across' at 6 characters*/
#define MAX_CMD_LENGTH 6

// The global version of the rows variable 
int globalRows;

// The global version of the columns variable 
int globalColumns;

// The game board 
char ** board = NULL;

// The monitor lock
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out an invalid input message and prompt the user for new input
static void invalidCmd(FILE *fp) {
    fprintf( fp, "Invalid command\n" );
    fprintf( fp, "cmd> " );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void * sockPointer ) {
  // Convert the parameter to an integer
  int sock = * ((int *) sockPointer);

  // Keep track of whether you have the monitor lock
  bool inMonitor = false;

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Store the entire user input up to the first instance of a newline
  // We let the command have an extra character for the null terminator
  char input[ MAX_INPUT_LENGTH + 1 ];
  while ( fscanf( fp, "%[^\n]s", input ) == 1 &&
          strcmp( input, "quit" ) != 0 ) {

    // If you have the monitor locked, give it up
  if (inMonitor) {
    pthread_mutex_unlock(&mon);
    inMonitor = false;
  }

    // If the command was greater than 26 characters, it's invalid
    if (strlen(input) > MAX_INPUT_LENGTH) {
        invalidCmd(fp);
        continue;
    }
 
    // Parse the user's input into the separate potential components. It must have a command and potentially has a row, column, and word
    char cmd[MAX_CMD_LENGTH + 1]; 
    int row, column, inputComponents; // inputComponents will keep track of how many format specifiers were matched when parsing
    char word[WORD_LIMIT + 2]; // 2 extra characters - 1 for a potential extra character (a problem) and a second for a null terminator
    inputComponents = sscanf(input, "%s %d %d %s", cmd, &row, &column, word);
    // fprintf(fp, "CMD: %s, row: %d, col: %d, word: %s, inputComponents: %d\n", cmd, row, column, word, inputComponents);

    // If no commands were given, that's invalid
    if (inputComponents == 0) {
      invalidCmd(fp);
      continue;
    }

    // Check what command was given
    if (strcmp( cmd, "across") == 0 || strcmp( cmd, "down" ) == 0) {
      // Check that a row, column, and word were given
      if (inputComponents != 4) {
        invalidCmd(fp);
        continue;
      }

      // The given word must be of length 26 or less
      if (strlen(word) > WORD_LIMIT) {
        invalidCmd(fp);
        continue;
      }

      // The given word must consist entirely of lowercase characters
      bool containsOnlyLowercase = true;
      for (int i = 0; i < strlen(word); i++) {
        if (!islower(word[i])) {
            containsOnlyLowercase = false;
            invalidCmd(fp);
            break;
        }
      }
      if (!containsOnlyLowercase) {
        continue;
      }      

      // Check if the provided row and column are within the bounds of the board
      if (row > globalRows - 1 || column > globalColumns - 1) {
        invalidCmd(fp);
        continue;
      }

      // Check if the word is excessively long - specific handling per case (across, down)
      if (strcmp( cmd, "across") == 0) {
        if (column + strlen(word) > globalColumns) {
          invalidCmd(fp);
          continue;
        }

        // We're now starting to access board state. acquire the monitor lock
        pthread_mutex_lock(&mon);
        inMonitor = true;

        // The given word's characters must not disagree with an existing character on the board
        bool validAcross = true;
        for (int i = column; i < column + strlen(word); i++) {
          if (board[row] && board[row][i] && board[row][i] != word[i - column]) {
            invalidCmd(fp);
            validAcross = false;
            break;
          }
        }
        if (!validAcross) {
          continue;
        }

        // Put the word in horizontally (constant row value)
        for (int i = column; i < column + strlen(word); i++) {
          board[row][i] = word[i - column];
        }
        fprintf( fp, "cmd> " );
      } else {
        // Down
        if (row + strlen(word) > globalRows) {
            invalidCmd(fp);
            continue;
        }

        // The given word's characters must not disagree with an existing character on the board
        bool validDown = true;
        for (int i = row; i < row + strlen(word); i++) {
          if (board[i] && board[i][column] && board[i][column] != word[i - row]) {
            invalidCmd(fp);
            validDown = false;
            break;
          }
        }
        if (!validDown) {
          continue;
        }

        // Put the word in vertically (constant column value)
        for (int i = row; i < row + strlen(word); i++) {
          board[i][column] = word[i - row];
        }
        fprintf( fp, "cmd> " );
      }

    } else if (strcmp( cmd, "board" ) == 0) {
      // Print the top border of the board
      fprintf(fp, "+");
      for (int i = 0; i < globalColumns; i++) {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");

      // Print out the board state
      for (int i = 0; i < globalRows; i++) {
        fprintf(fp, "|");
        for (int j = 0; j < globalColumns; j++) {
          if (board[i] && board[i][j] && islower(board[i][j])) {
            fprintf(fp, "%c", board[i][j]);
          } else {
            fprintf(fp, " ");
          }
        }
        fprintf(fp, "|\n");
      }
      // Print the bottom border of the board
      fprintf(fp, "+");
      for (int i = 0; i < globalColumns; i++) {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");

      fprintf( fp, "cmd> " );
    } else {
      // Invalid command
      invalidCmd(fp);
    }
  }

  // Close the connection with this client and exit
  fclose( fp );
  return NULL;
}

// Print out a usage message then exit with status 1
static void usage() {
  printf("usage: scrabbleServer <rows> <cols>\n");
  exit(1);
}

int main( int argc, char *argv[] ) {
  // Check the provided commandline arguments for validity
  int numArguments = argc - 1;
  if (numArguments != 2) {
    usage();
  }

  // Attempt to parse the commandline arguments into row and column numbers
  int rows;
  int columns;
  if ( sscanf( argv[ 1 ], "%d", &rows ) != 1 || rows <= 0 )
    usage();
  
  if ( sscanf( argv[ 2 ], "%d", &columns ) != 1 || columns <= 0 )
    usage();

  // Record the number of rows and columns globally so they can be accessed elsewhere
  globalRows = rows;
  globalColumns = columns;
    

  // Initialize the game board's size
  board = (char **) malloc(rows * sizeof(char *));
  for (int i = 0; i < rows; i++) {
    board[i] = (char *) malloc(columns * sizeof(char));
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
 
    // Create a new thread for handling the client
    pthread_t thread;
    pthread_create(&thread, NULL, handleClient, &sock);
    pthread_detach(thread);
    // handleClient( (void *) &sock );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
