/**
 * The ScrabbleServer program runs a Scrabble game using TCP/IP connections
 * this file stores all of the state of the game and parses all of the
 * commands given from client connections. This program was coded to use
 * the "words" file, if present, to make sure the player can only guess
 * valid words.
 * and threads 
 * @file scrabbleServer.c
 * @author Isaac Dunn (ijdunn)
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26326"

/** Maximum word length */
#define WORD_LIMIT 26

/** Maximum buffer size */
#define BUFF_SIZE 64

/** The number of valid scrabble words in the words file */
#define NUM_WORDS 110000

/** The name of the dictionary file */
#define DICT_FILE "words"

/** The scrabble board */
static char **board;

/** The number of rows in the board */
static int numRows;

/** The number of columns in the board */
static int numCols;

/** The dictionary of the words */
static char dictionary[ NUM_WORDS ][ WORD_LIMIT + 1 ];

/** Flag used when dictionary is on, off by default */
static bool dictOn;

/** Mutex used to prevent race conditions */
pthread_mutex_t boardLock = PTHREAD_MUTEX_INITIALIZER;

/**
 * Prints the specified message to standard error and exits the program with
 * a failure error code.
 * @param message  The message to print to standard error
 */
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/**
 * Reads the dictionary file and places the words into an array.
 * @param file  The file pointer to the dictionary file
 * @return True if file was read successfully, false if the file cannot be read
 */
bool readDict( FILE *file ) {
  for ( int i = 0; i < NUM_WORDS; i++ ) {
    for ( int j = 0; j < WORD_LIMIT + 1; j++ ) {
      // Place the character into the dictionary
      dictionary[ i ][ j ] = fgetc( file );
      // If we placed a newline character, replace it with a null and break
      if ( dictionary[ i ][ j ] == '\n' ) {
        dictionary[ i ][ j ] = '\0';
        break;
      }
    }
  }
  return true;
}

/**
 * Checks the dictionary for the specified word.
 * @param word  The word to check and see if its in the dictionary
 * @return True if the word is in the dictionary, false if it is not in the ditionary
 */
bool checkDict( const char *word ) {
  int wordLen = strlen( word );
  // Loop through the entire dictionary and find our word
  for ( int i = 0; i < NUM_WORDS; i++ ) {
    // If we find our word, return true
    for ( int j = 0; j < WORD_LIMIT; j++ ) {
      // If the characters don't match, move on to the next word
      if ( dictionary[ i ][ j ] != word[ j ] ) {
        break;
      }
      // If the words match exactly, return true
      if ( j == wordLen && dictionary[ i ][ j ] == '\0' ) {
        return true;
      }
    }
  }
  // Did not find the word, return false
  return false;
}

/**
 * This function checks all of the words in a temporary Scrabble board to make
 * sure every word is a valid word based on the dictionary. It is called before
 * the board is updated with the most recent word.
 * @param board  Copy of the Scrabble board
 * @return True if all of the words are valid, false if there is an invalid word
 */
bool checkBoardWords( char tmpBoard[ numRows][ numCols ] ) {
  // A word must be two or more characters, let's check all of the rows
  char tmpRow[ numCols + 1 ];
  for ( int i = 0; i < numRows; i++ ) {
    for ( int j = 0; j < numCols; j++ ) {
      tmpRow[ j ] = tmpBoard[ i ][ j ];
    }
    tmpRow[ numCols ] = '\0';
    // Now, let's parse the words
    char tmpWord[ numCols + 1 ];
    int placeIdx = 0;
    int numChars = 0;
    while ( sscanf( tmpRow + placeIdx, " %s%n", tmpWord, &numChars ) == 1 ) {
      // Make sure the word we scanned is at least two characters long
      if ( strlen( tmpWord) >= 2 ) {
        // If the word we scanned is not in the dictionary, we need to return false
        if ( !checkDict( tmpWord ) ) {
          return false;
        }
      }
      placeIdx += numChars;
    }
  }

  // Now we need to check all of the columns
  char tmpCol[ numRows + 1 ];
  for ( int i = 0; i < numCols; i++ ) {
    for ( int j = 0; j < numRows; j++ ) {
      tmpCol[ j ] = tmpBoard[ j ][ i ];
    }
    tmpCol[ numRows ] = '\0';
    // Now, let's parse the words
    char tmpWord[ numCols + 1 ];
    int placeIdx = 0;
    int numChars = 0;
    while ( sscanf( tmpCol + placeIdx, " %s%n", tmpWord, &numChars ) == 1 ) {
      // Make sure the word we scanned is at least two characters long
      if ( strlen( tmpWord ) >= 2 ) {
        // If the word we scanned is not in the dictionary, we need to return false
        if ( !checkDict( tmpWord ) ) {
          return false;
        }
      }
      placeIdx += numChars;
    }
  }
  // If we got to here, all the words are valid, return true
  return true;
}

/**
 * Prints the current contents of the board with the border 
 * @param fp  The file pointer to the client
 */
void boardCmd( FILE *fp ) {
  // Loop through, but need two extra rows for the border
  for ( int i = -1; i < numRows + 1; i++ ) {
    // Print the upper or lower border
    if ( i == -1 || i == numRows ) {
      fprintf( fp, "+" );
      for ( int j = 0; j < numCols; j++ ) {
        fprintf( fp, "-" );
      }
      fprintf( fp, "+" );
    }
    // For any other row, print the side borders and what is inside the scrabble board
    else {
      for ( int j = -1; j < numCols + 1; j++ ) {
        if ( j == -1 || j == numCols ) {
          fprintf( fp, "|" );
        } else {
          fprintf( fp, "%c", board[ i ][ j ] );
        }
      }
    }
    // Print newline for next row
    fprintf( fp, "\n" );
  }
}

/**
 * This function checks the parameters to place horizontal words on the Scrabble
 * board and returns a boolean to indicate if the word was placed on the board.
 * @param row  The row number the word starts at
 * @param col  The column number the word starts at
 * @param word  The word to place into the board
 * @return True if word was placed successfully, false if parameters were invalid
 */
bool acrossCmd( int row, int col, const char *word ) {
  // If the row and column numbers are not in the puzzle, return false
  if ( row < 0 || row >= numRows || col < 0 || col >= numCols )
    return false;

  // Return false if the word is too long or too short
  int wordLen = strlen( word );
  if ( wordLen <= 1 || numCols < wordLen + col - 1 )
    return false;

  // Return false if the word contains an invalid character 
  for ( int i = 0; word[ i ]; i++ ) {
    if ( word[ i ] < 'a' || word[ i ] > 'z' )
      return false;
  }
  
  // Make sure we won't overwrite anything already on the board
  // First, let's copy the current row of the board into a temporary array
  // Make it a string to easily parse
  char tempRow[ numCols + 1 ];
  tempRow[ numCols ] = '\0';
  for ( int i = 0; i < numCols; i++ ) {
    tempRow[ i ] = board[ row ][ i ];
  }
  // Now let's try to place the word into the temporary row
  for ( int i = 0; word[ i ]; i++ ) {
    // If it is a space, we're fine
    if ( tempRow[ col + i ] == ' ' ) {
      tempRow[ col + i ] = word[ i ];
    }
    // If the letters are the same, we're fine
    else if ( tempRow[ col + i ] == word[ i ] ) {
      tempRow[ col + i ] = word[ i ];
    }
    // If none of these conditions are true, then we can't accept this word
    else {
      return false;
    }
  }

  // If the dictionary is on, we need to check if all the words on the board are in the dictionary
  if ( dictOn ) {
    // First, let's make a copy of the board to pass into a function
    char cpyBoard[ numRows ][ numCols ];
    for ( int i = 0; i < numRows; i++ ) {
      for ( int j = 0; j < numCols; j++ ) {
        cpyBoard[ i ][ j ] = board[ i ][ j ];
      }
    }
    // Now, we need to place the word into the copied board
    for ( int i = 0; word[ i ]; i++ ) {
      cpyBoard[ row ][ i + col ] = word[ i ];
    }
    // Let's check if all of the words are valid, if not the function will return false
    if ( !checkBoardWords( cpyBoard ) )
      return false;
  }

  // We can now place the word in the board and return true
  for ( int i = 0; word[ i ]; i++ ) {
    board[ row ][ i + col ] = word[ i ];
  }
  return true;
}

/**
 * This function checks the parameters to place vertical words on the Scrabble
 * board and returns a boolean to indicate if the word was placed on the board.
 * @param row  The row number the word starts at
 * @param col  The column number the word starts at
 * @param word  The word to place into the board
 * @return True if word was placed successfully, false if parameters were invalid
 */
bool downCmd( int row, int col, const char *word ) {
  // If the row and column numbers are not in the puzzle, return false
  if ( row < 0 || row >= numRows || col < 0 || col >= numCols )
    return false;

  // Return false if the word is too long or too short
  int wordLen = strlen( word );
  if ( wordLen <= 1 || numRows < wordLen + row - 1 )
    return false;

  // Return false if the word contains an invalid character 
  for ( int i = 0; word[ i ]; i++ ) {
    if ( word[ i ] < 'a' || word[ i ] > 'z' )
      return false;
  }
  
  // Make sure we won't overwrite anything already on the board
  // First, let's copy the current column of the board into a temporary array
  // Make it a string to easily parse
  char tempCol[ numRows + 1 ];
  tempCol[ numRows ] = '\0';
  for ( int i = 0; i < numRows; i++ ) {
    tempCol[ i ] = board[ i ][ col ];
  }
  // Now let's try to place the word into the temporary column
  for ( int i = 0; word[ i ]; i++ ) {
    // If it is a space, we're fine
    if ( tempCol[ row + i ] == ' ' ) {
      tempCol[ row + i ] = word[ i ];
    }
    // If the letters are the same, we're fine
    else if ( tempCol[ row + i ] == word[ i ] ) {
      tempCol[ row + i ] = word[ i ];
    }
    // If none of these conditions are true, then we can't accept this word
    else {
      return false;
    }
  }

  // If the dictionary is on, we need to check if all the words on the board are in the dictionary
  if ( dictOn ) {
    // First, let's make a copy of the board to pass into a function
    char cpyBoard[ numRows ][ numCols ];
    for ( int i = 0; i < numRows; i++ ) {
      for ( int j = 0; j < numCols; j++ ) {
        cpyBoard[ i ][ j ] = board[ i ][ j ];
      }
    }
    // Now, we need to place the word into the copied board
    for ( int i = 0; word[ i ]; i++ ) {
      cpyBoard[ row + i ][ col ] = word[ i ];
    }
    // Let's check if all of the words are valid, if not the function will return false
    if ( !checkBoardWords( cpyBoard ) )
      return false;
  }

  // We can now place the word in the board and return true
  for ( int i = 0; word[ i ]; i++ ) {
    board[ i + row ][ col ] = word[ i ];
  }
  return true;
}

/** 
 * This function handles the client threads that connect to the Scrabble server.
 * It prompts the user to enter commands through the client connection and parses
 * the commands to change the state of the Scrabble board.
 * @param arg  Void pointer to thread arguments, used to pass the socket number
 */
void *handleClient( void *arg ) {
  // Cast the thread argument to an integer
  int sock = *( ( int * ) arg );

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Create a buffer to store the command
  char buffer[ BUFF_SIZE ];
  // Continue reading commands until we get a quit
  while ( !fgets( buffer, BUFF_SIZE, fp ) || strcmp( buffer, "quit\n" ) != 0 ) {
    // When we get a command, lock the monitor
    pthread_mutex_lock( &boardLock );
    // Lets save some info
    char placeWord[ WORD_LIMIT + 1 ];
    placeWord[ WORD_LIMIT ] = '\0';
    int rowNum, colNum;
    // We got a board command
    if ( strncmp( buffer, "board", 5 ) == 0 ) {
      // Call the function to print the board to the client
      boardCmd( fp );
    } 
    // Check if the command is for across
    else if ( strncmp( buffer, "across", 6 ) == 0) {
      // Now parse the across command and get the word
      int wordIdx;
      if ( sscanf( buffer, "across %d %d %n", &rowNum, &colNum, &wordIdx ) == 2 ) {
        // Parse the word from the buffer
        for (int i = 0; i < BUFF_SIZE - wordIdx; i++ ) {
          // Grab the next character
          char ch = buffer[ wordIdx + i ];
          // Make sure it is lowercase letter
          if ( ch >= 'a' && ch <= 'z' ) {
            placeWord[ i ] = ch;
          }
          // If it is a newline, we make it a null terminator and go place the word
          else if ( ch == '\n' ) {
            placeWord[ i ] = '\0';
            // Call the function to place the word across
            // If the function returns false, then parameters were invalid
            if ( !acrossCmd( rowNum, colNum, placeWord ) ) {
              fprintf( fp, "Invalid command\n" );
            }
            break;
          }
          // If it is not lowercase letter or newline, its a bad command
          else {
            fprintf( fp, "Invalid command\n" );
            break;
          }
        }
      }
      // If we can't parse this, it must be invalid
      else {
        fprintf( fp, "Invalid command\n" );
      }
    }
    // We got a down command
    else if ( strncmp( buffer, "down", 4 ) == 0 ) {
      // Now parse the down command and get the word
      int wordIdx;
      if ( sscanf( buffer, "down %d %d %n", &rowNum, &colNum, &wordIdx ) == 2 ) {
        // Parse the word from the buffer
        for (int i = 0; i < BUFF_SIZE - wordIdx; i++ ) {
          // Grab the next character
          char ch = buffer[ wordIdx + i ];
          // Make sure it is lowercase letter
          if ( ch >= 'a' && ch <= 'z' ) {
            placeWord[ i ] = ch;
          }
          // If it is a newline, we make it a null terminator and go place the word
          else if ( ch == '\n' ) {
            placeWord[ i ] = '\0';
            // Call the function to place the word downward
            // If the function returns false, then parameters were invalid
            if ( !downCmd( rowNum, colNum, placeWord ) ) {
              fprintf( fp, "Invalid command\n" );
            }
            break;
          }
          // If it is not lowercase letter or newline, its a bad command
          else {
            fprintf( fp, "Invalid command\n" );
          }
        }
      }
      // If we can't parse this, it must be invalid
      else {
        fprintf( fp, "Invalid command\n" );
      }
    }
    // Does not match anything else, print invalid command
    else {
      fprintf( fp, "Invalid command\n" );
    }
    // Set all of the bytes of the buffer to null
    for ( int i = 0; i < BUFF_SIZE; i++ ) {
      buffer[ i ] = '\0';
    }
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
    // Unlock the monitor for another thread to access
    pthread_mutex_unlock( &boardLock );
  }
  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

/**
 * The main method starts the Scrabble server and parses command-line arguments
 * to initialize the game board. It then attempts to read the "words" file if
 * to establish a dictionary. Afterwards, it initializes the gameboard and establishes
 * a TCP connection using threads.
 * @param argc  The number of command-line arguments
 * @param argv  The command-line arguments
 * @return  Exit code, 0 for success, non-zero for failure
 */
int main( int argc, char *argv[] ) {
  // Parse command line arguments
  // Must have exactly three command-line arguments
  if ( argc != 3 )
    fail( "usage: scrabbleServer <rows> <cols>" );

  // Parse the number of rows and columns
  if ( sscanf( argv[1], "%d", &numRows ) != 1 || sscanf( argv[2], "%d", &numCols ) != 1 ) {
    // Must be greater than zero
    if ( numRows <= 0 || numCols <= 0 ) {
      fail( "usage: scrabbleServer <rows> <cols>" );
    }
  }

  // Create the board in heap memory
  board = ( char ** )malloc( numCols * sizeof( char * ) );
  for ( int i = 0; i < numCols; i++ ) {
    board[ i ] = ( char * )malloc( numRows * sizeof( char ) );
  }
  // Make the board all empty spaces
  for ( int i = 0; i < numRows; i++ ) {
    for ( int j = 0; j < numCols; j++ ) {
      board[ i ][ j ] = ' ';
    }
  }
  
  // Check if the words file is in the current directory
  FILE *dictFile = fopen( DICT_FILE, "r" );
  // If there's no file, set the flag to false
  if ( !dictFile ) {
    dictOn = false;
  }
  // If there is a words file, try to read it
  else {
    // Set the flag to the return value of readDict()
    dictOn = readDict( dictFile );
    // Close the dictionary file
    fclose( dictFile );
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    // Create the client thread
    pthread_t client;
    if ( pthread_create( &client, NULL, handleClient, &sock ) != 0 )
      fail( "Could not create client thread" );
    
    // Detach the client thread so we can make more threads
    pthread_detach( client );
  }
  // Free the board from heap memory
  for ( int i = 0; i < numCols; i++ ) {
    free( board[ i ] );
  }
  free( board );
  
  // Stop accepting client connections (never reached).
  close( servSock );
  // Return success exit code
  return 0;
}
