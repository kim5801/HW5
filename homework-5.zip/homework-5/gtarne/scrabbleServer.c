#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26300"

/** Maximum word length */
#define WORD_LIMIT 26

/** Lock on the board */
pthread_mutex_t boardLock;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** Struct to represent the board */
typedef struct {
  int rows;
  int cols;
  char **array;

} Board;

/** Strcut for passing args to threads*/
typedef struct {
  int sock;
  Board *board;
} ArgStruct;

/* Checks whether the word placement is valid and adds it at the location going down if vlaid */
bool across(int r, int c, char *word, Board *board) {
  int len = strlen(word);
  if ( r > board->rows || r < 0 || c > board->cols || c < 0 || c + len - 1 > board->cols ) {
    return false;
  }
  // Check for valid word placement
  for (int i = 0; i < len; i++) {
    if ( word[i] > 'z' || word[i] < 'a' || ( word[i] != board->array[r][c+i] && board->array[r][c+i] != ' ' ) ) {
      return false;
    }
  }

  // Place word on board
  for (int i = 0; i < len; i++) {
    board->array[r][c+i] = word[i];
  }
  return true;
}

/* Checks whether word placement is valid and adds it at the location going down if valid*/
bool down(int r, int c, char *word, Board *board) {
  int len = strlen(word);
  if ( r > board->rows || r < 0 || c > board->cols || c < 0 || r + len - 1 > board->rows) {
    return false;
  }
  // Check for valid word placement
  for (int i = 0; i < len; i++) {
    if ( word[i] > 'z' || word[i] < 'a' || ( word[i] != board->array[r+i][c] && board->array[r+i][c] != ' ' ) ) {
      return false;
    }
  }

  // Place word on board
  for (int i = 0; i < len; i++) {
    board->array[r+i][c] = word[i];
  }
  return true;
}

/* Prints the current status of the given board to the given file */
void printBoard( FILE *fp, Board *board ) {
  // Print the board
  for (int r = 0; r < board->rows + 2; r++, fputc('\n',fp) ) {
    for (int c = 0; c < board->cols + 2; c++) {
      if (r == 0 || r == board->rows + 1) {
        if (c == 0 || c == board->cols + 1) {
          fputc( '+', fp );
        } else {
          fputc( '-', fp );
        }
      } else {
        if (c == 0 || c == board->cols + 1) {
          fputc( '|', fp );
        } else {
          fputc( board->array[r-1][c-1], fp);
        }
      }
    }
  }
}

/** handle a client connection, close it when we're done. */
void *handleClient( int sock, Board *board ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    int row = 0;
    int col = 0;
    char word[ 28 ];
    bool valid = false;
    
    if ( strcmp(cmd, "across") == 0 ) {
      if ( fscanf( fp, "%d %d %27s", &row, &col, word ) == 3 && strlen(word) <= WORD_LIMIT ) {\
        pthread_mutex_lock( &boardLock );
        valid = across( row, col, word, board );
        pthread_mutex_unlock( &boardLock );
      }
    } else if ( strcmp(cmd, "down") == 0 ) {
      if ( fscanf( fp, "%d %d %27s", &row, &col, word ) == 3 && strlen(word) <= WORD_LIMIT ) {
        pthread_mutex_lock( &boardLock );
        valid = down( row, col, word, board );
        pthread_mutex_unlock( &boardLock );
      }
    } else if ( strcmp(cmd, "board") == 0 ) {
      pthread_mutex_lock( &boardLock );
      printBoard( fp, board );
      pthread_mutex_unlock( &boardLock );
      valid = true;
    } else {
      valid = false;
    }

    if ( !valid ) {
      fprintf( fp, "Invalid command\n" );
    }

    // Just echo the command back to the client for now.
    //fprintf( fp, "%s\n", cmd );

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

void *threadfunc(void *argStruct) {
  pthread_detach(pthread_self());
  ArgStruct *astruct = (ArgStruct *)argStruct;
  handleClient(astruct->sock, astruct->board);
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Read and check arugments
  if (argc != 3)
    fail("Invalid number of arguments\n");


  // Read rows input
  int rows = atoi( argv[1] );

  // Read columns input
  int cols = atoi( argv[2] );

  // Check row and column values
  if (rows == 0 || cols == 0)
    fail("Invalid arguments\n");

  // Create board
  Board *board = (Board *)malloc( sizeof(int) * 2 + sizeof(char *));
  board->rows = rows;
  board->cols = cols;
  board->array = (char**)malloc( sizeof(char*) * rows );
  // Initialize initial board values
  for (int r = 0; r < rows; r++) {
    board->array[r] = (char *)malloc( sizeof(char*) * cols );
    for (int c = 0; c < cols; c++) {
      board->array[r][c] = ' ';
    }
  }

  // Make board lock
  pthread_mutex_init( &boardLock, NULL );

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    // Create argument struct
    ArgStruct *argStruct = (ArgStruct *)malloc( sizeof( ArgStruct ) );
    argStruct->board = board;
    argStruct->sock = sock;

    pthread_t thread;
    pthread_create( &thread, NULL, threadfunc, argStruct );
    //pthread_detach( threadNum );
  }

  // Stop accepting client connections (never reached).
  free(board->array);
  free(board);
  close( servSock );
  
  return 0;
}
