#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <string.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26030"

/** Maximum word length */
#define WORD_LIMIT 26

//represents number of rows in board
int row = 0;

//represents number of columns in board
int col = 0;

//represents a 2D pointer char array for board
char **board;

//lock for threads */
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( int sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  //49 max command with +1 for error checking and null terminator
  char cmd[ 7 ];
  int rowNum = -1;
  int colNum = -1;
  char wordCmd[ 27 ];
  while ( fscanf( fp, "%s, %d, %d, %s", cmd, &rowNum, &colNum, wordCmd ) > 0 &&
          strcmp( cmd, "quit" ) != 0 ) {
    //lock        
    pthread_mutex_lock(&lock);

    if (strlen(wordCmd) > 0 && strncmp("across", cmd, 6) == 0) {
      //if given row and column number is not given or less than zero
      //it is invalid
      if (rowNum == -1 || colNum == -1 || rowNum < 0 || colNum < 0) {
        fprintf(fp, "Invalid command\n");
      }
      //if the row given is negative or bigger than the dimension of the board row
      //if the col given is negative or bigger than the dimension of the board column
      else if (rowNum > row || colNum > col) {
        fprintf(fp, "Invalid command\n");
      }
      //if the word is too long or there is no word
      else if (strlen(wordCmd) <= 0 || strlen(wordCmd) > 26);
      //if the command passes these initial checks
      else {
        //is 0 if error check fails, 1 if it passes
        int error = 1;
        //length of word given
        int length = strlen(wordCmd);
        //goes through 1 to 26 because it's the word limit
        int i;
        for (i = 0; i < length; i++) {
          //if the word is not in lower case, it is invalid
          if (!islower(wordCmd[i])) {
            error = 0;
            break;
          }
        }

        //if length of word is longer than column
        if (length > col) {
          fprintf(fp, "Invalid command\n");
          error = 0;
        }

		    //how many spaces are to the right of row/col space
		    int spaceLeft = col - colNum;
		
        //if word will be too big for board
        if (length > spaceLeft) {
          fprintf(fp, "Invalid command\n");
          error = 0;
        }
 
        //look at the spaces the word is being placed and if there is an interlap with
        //another word and the letter does not match at this spot, it is invalid
        int wordPointer = 0;
        for (int i = colNum; i < colNum + length - 1; i++) {
          //if space that corresponds to row and column i is not empty
          //check if the letter there is equal to the letter in the same spot
          //in the word
          if (board[rowNum][i] != '\0') {
            if (board[rowNum][i] != wordCmd[wordPointer]) {
              error = 0;
              break;
            }
          }
          wordPointer++;
        }
        
        //if the word will fit on the board, put it on the board
        if (error == 1) {
          wordPointer = 0;
          for (int i = colNum; i < colNum + length - 1; i++) {
            if (board[rowNum][i] == '\0') {
              board[rowNum][i] = wordCmd[wordPointer];
            }
            //increment pointer by one to see next letter in word
            wordPointer++;
          }
        }
        
      }
    }
    else if (strlen(wordCmd) > 0 && strncmp("down", cmd, 4) == 0) {
      
      //if given row and column number is not given or less than zero
      //it is invalid
      if (rowNum == -1 || colNum == -1 || rowNum < 0 || colNum < 0) {
        fprintf(fp, "Invalid command\n");
      }
      //if the row given is negative or bigger than the dimension of the board row
      //if the col given is negative or bigger than the dimension of the board column
      else if (rowNum > row || colNum > col) {
        fprintf(fp, "Invalid command\n");
      }
      //if the word is too long or there is no word
      else if (strlen(wordCmd) <= 0 || strlen(wordCmd) > 26);
      //if the command passes these initial checks
      else {

        //is 0 if error check fails, 1 if it passes
        int error = 1;
        //Length of word given
        int length = strlen(wordCmd);

        for (int i = 0; i < length; i++) {
          //if the word is not in lower case, it is invalid
          if (!islower(wordCmd[i])) {
            error = 0;
            break;
          }
        }

        //if length of word is longer than column
        if (length > row) {
          fprintf(fp, "Invalid command\n");
          error = 0;
        }

		    //how many spaces are below row/col space
		    int spaceLeft = row - rowNum;
		
        //if word will be too big for board
        if (length > spaceLeft) {
          fprintf(fp, "Invalid command\n");
          error = 0;
        }

        //look at the spaces the word is being placed and if there is an interlap with
        //another word and the letter does not match at this spot, it is invalid
        int wordPointer = 0;
        for (int i = rowNum; i < rowNum + length - 1; i++) {
          //if space that corresponds to row and column i is not empty
          //check if the letter there is equal to the letter in the same spot
          //in the word
          if (board[i][colNum] != '\0') {
            if (board[i][colNum] != wordCmd[wordPointer]) {
              error = 0;
              break;
            }
          }
          wordPointer++;
        }
        
        //if the word will fit on the board, put it on the board
        if (error == 1) {
          wordPointer = 0;
          for (int i = rowNum; i < rowNum + length - 1; i++) {
            if (board[i][colNum] == '\0') {
              board[i][colNum] = wordCmd[wordPointer];
            }
            //increment pointer by one to see next letter in word
            wordPointer++;
          }
        }
      
      }
    }
    else if (strlen(wordCmd) == 0 && strcmp("board", cmd) == 0) {
      //top border
      fprintf(fp, "+");
      for (int i = 0; i < col; i++) {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
  
      //content of game board
      for (int r = 0; r < row; r++ ) {
        fprintf(fp, "|");
        for (int c = 0; c < col; c++) {
          fprintf(fp, "%c", board[r][c]);
        }
        fprintf(fp, "|\n");
      }
  
      //bottom border
      fprintf(fp, "+");
      for (int i = 0; i < col; i++) {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
    }
    else if (strlen(wordCmd) == 0 && strcmp("quit", cmd) == 0) {
      //close( servSock );
      break;
    }
    else {
      fprintf(fp, "Invalid command\n");
    }
    //unlock
    pthread_mutex_unlock(&lock);


    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  //check if argv contain any non-number values or negative values
  if (!isdigit(argv[1]) || !isdigit(argv[2])) {
    fail("usage: scrabbleServer <rows> <cols>");
  }

  row = atoi(argv[1]) + 1;
  col = atoi(argv[2]) + 1;
  
  board = (char **) malloc (row * sizeof(char *));
  for (int i = 0; i < row; i++) {
    board[i] = (char *) malloc (col * sizeof(char));
  }
  
  for (int i = 0; i < row; i++) {
    for (int j = 0; j < col; j++) {
      board[i][j] = ' ';
    }
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_t thread;
    pthread_create(&thread, NULL, handleClient(sock), (void *) &sock);
    pthread_detach(thread);
    //handleClient( sock );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
