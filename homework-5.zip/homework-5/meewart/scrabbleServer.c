#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

// Compile with:
// gcc -Wall -g -std=gnu99 scrabbleServer.c -o scrabbleServer -lpthread

/** Port number used by my server */
#define PORT_NUMBER "26236"

/** Maximum word length */
#define WORD_LIMIT 26

/** Monitor for board */
pthread_mutex_t boardMonitor = PTHREAD_MUTEX_INITIALIZER;
/** Condition variable for acessing the board */
pthread_cond_t boardCond = PTHREAD_COND_INITIALIZER;

/** Socket for communication */
int sock;

typedef struct GameBoardStruct GameBoard;

struct GameBoardStruct {
  // Board state
  // board stored in one array
  // the last character of everly line is a new line char
  char *state;

  // Number of rows and columns in the board
  int rows;
  int cols;

  // Total number of rows and cols with the border and new lines
  int totalRows;
  int totalCols;
};

// Puts the given char at the given location
void setIndex(GameBoard *board, int row, int col, char c) {
  // the index where the row starts
  int rowStartingIndex = board->totalCols * row;

  // the index where the new char should be added
  int stateIndex = rowStartingIndex + col;

  board->state[stateIndex] = c;
}

// Gets the char at the given location
char getIndex(GameBoard *board, int row, int col) {
  // the index where the row starts
  int rowStartingIndex = board->totalCols * row;

  // the index where the new char should be added
  int stateIndex = rowStartingIndex + col;

  return board->state[stateIndex];
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient(void *threadArg) {
  // Cast void ptr to GameBoard ptr
  GameBoard *board = (GameBoard *) threadArg;

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );

  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // variables to hold arguments
  char cmd[7];
  int rowLoc = -1;
  int colLoc = -1;
  char word[WORD_LIMIT + 1];

  // Read in arguments
  int argsRead = fscanf(fp, "%6s", cmd);

  // while cmd is not quit
  while (strcmp( cmd, "quit" ) != 0) {

    bool invalidCmd = false;

    // Check if first arg was read
    if (argsRead < 1) {
      fprintf(fp, "Invalid command\n");
      invalidCmd = true;
    }

    // across command 
    if (!invalidCmd && strcmp(cmd, "across") == 0) {
      // Enter monitor
      pthread_mutex_lock(&boardMonitor);

      // read in the rest of the commands
      argsRead += fscanf(fp, "%d %d %26s", &rowLoc, &colLoc, word);

      // invalid if the arguments weren't parsed correctly
      // or the location is not on the board
      // or the word will not fit on the board
      if (argsRead != 4 ||
      rowLoc < 0 || rowLoc > board->rows - 1 ||
      colLoc < 0 || colLoc > board->cols - 1 ||
      colLoc + strlen(word) - 1 >= board->cols) {
        fprintf(fp, "Invalid command\n");
        invalidCmd = true;
      }

      // check that each char is valid
      if (!invalidCmd) {
        // for each char in word
        for (int i = 0; i < strlen(word); i++) {
          if (word[i] < 'a' || word[i] > 'z' ||
          (getIndex(board, rowLoc + 1, colLoc + 1 + i) != ' ' && word[i] != getIndex(board, rowLoc + 1, colLoc + 1 + i))) {
            fprintf(fp, "Invalid command\n");
            invalidCmd = true;
            break;
          }
        }
      }

      // place char on board
      if (!invalidCmd) {
        // for each char in word
        for (int i = 0; i < strlen(word); i++) {
          setIndex(board, rowLoc + 1, colLoc + 1+ i, word[i]);
        }
      }

      // Leave monitor
      pthread_mutex_unlock(&boardMonitor);
    }
    // down command
    else if (!invalidCmd && strcmp(cmd, "down") == 0) {
      // Enter monitor
      pthread_mutex_lock(&boardMonitor);

      // read in the rest of the commands
      argsRead += fscanf(fp, "%d %d %26s", &rowLoc, &colLoc, word);

      // invalid if 4 args weren't parsed
      // or the location is not on the board
      // or the word will not fit on the board
      if (argsRead != 4 ||
      rowLoc < 0 || rowLoc > board->rows - 1 ||
      colLoc < 0 || colLoc > board->cols - 1 ||
      rowLoc + strlen(word) - 1 >= board->rows) {
        fprintf(fp, "Invalid command\n");
        invalidCmd = true;
      }

      // check that each char is valid
      if (!invalidCmd) {
        // for each char in word
        for (int i = 0; i < strlen(word); i++) {
          if (word[i] < 'a' || word[i] > 'z' ||
          (getIndex(board, rowLoc + 1 + i, colLoc + 1) != ' ' && word[i] != getIndex(board, rowLoc + 1, colLoc + i + 1))) {
            fprintf(fp, "Invalid command");
            invalidCmd = true;
            break;
          }
        }
      }

      // place char on board
      if (!invalidCmd) {
        // for each char in word
        for (int i = 0; i < strlen(word); i++) {
          setIndex(board, rowLoc + 1 + i, colLoc + 1, word[i]);
        }
      }

      // Leave monitor
      pthread_mutex_unlock(&boardMonitor);
    } 
    // board command
    else if (!invalidCmd && strcmp(cmd, "board") == 0) {
      // Enter monitor
      pthread_mutex_lock(&boardMonitor);

      fprintf(fp, "%s", board->state);

      // Leave monitor
      pthread_mutex_unlock(&boardMonitor);
    }
    else {
      fprintf(fp, "Invalid command\n");
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );

    // Read in command
    argsRead = fscanf(fp, "%6s", cmd);
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  int boardRows = -1;
  int boardCols = -1;

  // Check command line arguments
  if (argc != 3 || sscanf(argv[1], "%d", &boardRows) != 1 || 
    sscanf(argv[2], "%d", &boardCols) != 1) {
    fail("usage: scrabbleServer <rows> <cols>");
  }

  // Create board
  GameBoard *board = (GameBoard *) malloc(sizeof(GameBoard));
  board->rows = boardRows;
  board->cols = boardCols;
  // board needs a border on each side
  // last col needs to be a new line
  board->totalRows = boardRows + 2;
  board->totalCols = boardCols + 3;
  board->state = (char *) malloc(((boardRows + 2) * (boardCols + 3) + 1) * sizeof(char));

  // Fill board with empty space and new lines and add borders
  // For each row
  for (int i = 0; i < board->totalRows; i++) {
    // For each col
    for (int j = 0; j < board->totalCols; j++) {
      // if in corner
      if ((i == 0 && j == 0) || (i == 0 && j == board->totalCols - 2) ||
      (i == board->totalRows - 1 && j == 0) || (i == board->totalRows - 1 && j == board->totalCols - 2)) {
        setIndex(board, i, j, '+');
      }
      // if not on top or bottom and on left or right border
      else if ((i > 0 && i < board->totalRows - 1) && (j == 0 || j == board->totalCols - 2)) {
        setIndex(board, i, j, '|');
      }
      // if on top or bottom border but not on left or right
      else if ((i == 0 || i == board->totalRows - 1) && (j > 0 && j < board->totalCols - 2)) {
        setIndex(board, i, j, '-');
      }
      // if in the last col
      else if (j == board->totalCols - 1) {
        setIndex(board, i, j, '\n');
      }
      else {
        setIndex(board, i, j, ' ');
      }
    }
  }
  // Add null terminator
  setIndex(board, board->totalRows, board->totalCols - 1, '\0');
  //printf("%s\n", board->state);

  while ( true  ) {
    // Accept a client connection.
    sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_t clientThread;

    // Create and detach thread
    pthread_create(&clientThread,NULL,handleClient, (void *) board);
    pthread_detach(clientThread);

    //handleClient(sock, board);
  }

  // Stop accepting client connections (never reached).
  close( servSock );

  // Free the game board
  free(board->state);
  free(board);
  
  return 0;
}
