/**
 * @file scrabbleServer.c
 * @author Rose Xiao
 * @brief A multi-threaded Unix client/server program in C using TCP/IP
sockets for communication. The server will let users view and and update two-dimensional game board
containing lower case letters (and blank spaces, like a scrabble board). A user will be able to add
words to the board, going vertically or horizontally, but letters of any new words must match existing
letters for words that have already been placed on the board
 * @version 0.1
 * @date 2022-11-11
 */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

 //cmds to run client nc
 //nc engr-ras-206.eos.ncsu.edu 26412
 //gcc -Wall -g -std=gnu99 scrabbleServer.c -o scrabbleServer -lpthread

 /** Port number used by my server */
#define PORT_NUMBER  "26412"
/** Maximum word length */
#define WORD_LIMIT 26

//command limit
#define CMD_LIMIT 11
//Invalid args
#define ARGC_CT 3

//the board containing the words
char** board;
//global var keeping track of the number of rows and columns of the board
int row, col;

// -----------
// the list containing the dictionary words
char** list;
//the length of the list
int listLen = 83179;
//flag for existence of words file
bool wordsFile = false;
//the count of invalid capital letters
int upperLetters = 19204;
//flag to indicate the words list exist
bool useWordsList = false;
//duplicate board for the EC exluding the boarders
char** ECboard;
// -----------

// Monitor used for locking and unlocking critical sections
static pthread_mutex_t mon;

/**
 * @brief Searches word using binary sort (divide and conquer algo)
 *
 * @param list the list the search through
 * @param left the lowest index of the range to search
 * @param right the highest index of the range to search
 * @param word the word to search for
 * @return int the position of word in the list. If it does not exists,, returns -1
 */
int binarySearch( char** list, int left, int right, char* word )
{
	if ( right >= left ) {
		int mid = left + ( right - left ) / 2;
		//return the found word
		if ( strcmp( list [ mid ], word ) == 0 ) {
			return mid;
		}
		//search the left half of the dictionary
		if ( strcmp( list [ mid ], word ) > 0 ) {
			return binarySearch( list, left, mid - 1, word );
		}
		//search the right half of the dictionary
		return binarySearch( list, mid + 1, right, word );
	}
	return -1;
}

/**
 * @brief Creates board for the EC. A replica of the board being played excluding the borders
 *
 * @param r the number of rows in the board
 * @param c the number of columns in the board
 */
void makeWordBoard( int r, int c )
{
	//creating the board with the given number of rows
	ECboard = malloc( row * sizeof( char* ) );

	//malloc the characters of the board
	for ( int i = 0; i < r; i++ ) {
		ECboard [ i ] = malloc( c * sizeof( char ) );
	}
	//sets each slot as a empty char
	for ( int i = 0; i < row; i++ ) {
		for ( int j = 0; j < col; j++ ) {
			ECboard [ i ][ j ] = ' ';
		}
	}
}

/**
 * @brief Checks the validity of all the rows and colums of the board. For the EC
 *
 * @return true if all the words can be found in the dictionary
 * @return false if at least one word cannot be found in the dictionary
 */
static bool validWords()
{


	//buffer to hold the words in the ros
	char rowBuff [ col + 1 ];
	//for each row,, check the validity
	for ( int i = 0; i < row; i++ ) {
		// strcpy( rowBuff, ECboard [ i ] );
		for ( int j = 0; j < col;j++ ) {
			rowBuff [ j ] = ECboard [ i ][ j ];
		}
		rowBuff [ col ] = '\0';
		char* pch = strtok( rowBuff, " " );
		while ( pch != NULL ) {
			//for each separate word in the row
			//check if in the dictionary
			int val = binarySearch( list, 0, listLen, pch );
			if ( val < 0 ) {
				return false;
			}
			pch = strtok( NULL, " " );
		}


	}

	//checking the columns,, need to transpose
	char colBuff [ row + 1 ];
	//THIS PART IS SEGGY FAULTING
	for ( int i = 0;i < col;i++ ) {
		for ( int j = 0;j < row;j++ ) {
			// printf( "%c", ECboard [ j ][ i ] );
			colBuff [ j ] = ECboard [ j ][ i ];
		}
		colBuff [ row ] = '\0';

		//checking validity for each column
		char* pch = strtok( colBuff, " " );
		while ( pch != NULL ) {
			int val = binarySearch( list, 0, listLen, pch );
			if ( val < 0 ) {
				return false;
			}
			pch = strtok( NULL, " " );

		}
	}
	return true;
}

/**
 * @brief Reads in the dictionary used to check the validity of the words. For the EC.
 *
 * @return true  if a dictionary file exists to be used
 * @return false if a disctionary file does not exist
 */
static bool readList()
{
	FILE* fp;
	// Opening file in reading mode
	fp = fopen( "words", "r" );
	if ( fp == NULL ) {
		return false;
	}

	list = calloc( listLen, sizeof( char* ) );
	//creates buffer for each row of the lists
	for ( int i = 0; i < listLen; i++ ) {
		list [ i ] = malloc( ( WORD_LIMIT + 1 ) * sizeof( char ) );
	}

	//buffer to discard the first half of the list which mostly contains capital letters
	char buff [ WORD_LIMIT + 1 ];
	for ( int i = 0; i < upperLetters; i++ ) {
		fscanf( fp, "%[^\n] ", buff );
	}

	//buffer to read in the lowercase letters
	for ( int i = 0; i < listLen; i++ ) {
		fscanf( fp, "%[^\n] ", list [ i ] );
	}

	fclose( fp );
	return true;
}

// Print out an error message and exit.
static void fail( char const* message )
{
	fprintf( stderr, "%s\n", message );
	exit( EXIT_FAILURE );
}

/**
 * @brief Prints the state of the board to the client. This is called when the user runs the "board" command.
 *
 * @param r the number of rows the board has
 * @param c the number of columns the board has
 */
void printBoard( int r, int c )
{
	//to account for the boarders
	int row = r + 2;
	int col = c + 2;

	for ( int i = 0; i < row; i++ ) {
		for ( int j = 0; j < col; j++ ) {
			printf( "%c", board [ i ][ j ] );
		}
		printf( "\n" );
	}
}

/**
 * @brief Creates the initial state of the board. It will create a border consisting of vertical bars on the left and right,, dashes along the top and bottom,, and plus signs in the corners.
 *
 * @param r the number of rows the board has
 * @param c the number of columns the board has
 */
void makeBoard( int r, int c )
{
	//to account for the boarders
	int row = r + 2;
	int col = c + 2;

	//creating the board with the given number of rows
	board = malloc( row * sizeof( char* ) );

	//malloc the characters of the board
	for ( int i = 0; i < row; i++ ) {
		board [ i ] = malloc( col * sizeof( char ) );
	}
	//fill up the board
	for ( int i = 0; i < row; i++ ) {
		for ( int j = 0; j < col; j++ ) {
			//if the top/bottom border
			if ( i == 0 || i == row - 1 ) {
				//if the corners
				if ( j == 0 || j == col - 1 ) {
					board [ i ][ j ] = '+';
				}
				else {
					board [ i ][ j ] = '-';
				}
			}
			//if the side border
			else if ( j == 0 || j == ( col - 1 ) ) {
				board [ i ][ j ] = '|';
			}
			//set it to an empty space
			else {
				board [ i ][ j ] = ' ';
			}
		}
	}

}

/**
 * @brief The left end of the word starts
at the given row, r, and column, c, on the board. Both row number and column number start
from zero (the top row and left column of the board). The given word must be a sequence of 1 to
26 lower-case letters. It is placed on the board, one character per location going right from the
starting location.
The command is invalid if the given location is off the board, if the word would extend beyond
the bounds of the board, if the word contains something other than lower-case letters or if the
one of the characters in the word disagrees with a character already placed on the board.
 *
 * @param r the row to start the word
 * @param c the column to start the word
 * @param word the word to place on the board
 * @return true if successfully placed the word
 * @return false if unsucessful when placing the word
 */
bool across( int r, int c, char* word )
{
	//if the given r is larger than the board across or if the given c is larger than the board down
//if the given parameters are negative values
	if ( r > row || c > col || r < 0 || c < 0 ) {
		return false;
	}
	pthread_mutex_lock( &mon );
	//word is too long for the given location
	if ( strlen( word ) + c > col ) {
		pthread_mutex_unlock( &mon );
		return false;
	}

	//incrementing by one to account for the border
	r += 1;
	c += 1;

	for ( int i = 0; i < strlen( word ); i++ ) {
		//word contains a non-lowercase letter 
		if ( !islower( word [ i ] ) || !isalpha( word [ i ] ) ) {
			pthread_mutex_unlock( &mon );
			return false;
		}
		//if space is occupied
		if ( board [ r ][ c + i ] != ' ' ) {
			//check to see if the characters are the same
			if ( board [ r ][ c + i ] != word [ i ] ) {
				pthread_mutex_unlock( &mon );
				return false;
			}
			continue;
		}
	}

	//use the valid words command if the words list exist
	if ( useWordsList ) {
		//save copy of row
		char* temp = ECboard [ r - 1 ];
		//set the word on the EC board
		for ( int i = 0; i < strlen( word ); i++ ) {
			ECboard [ r - 1 ][ c - 1 + i ] = word [ i ];
		}
		bool val = validWords();
		if ( !val ) {
			//reset the value
			for ( int i = 0; i < strlen( word ); i++ ) {
				ECboard [ r - 1 ][ c - 1 + i ] = temp [ i ];
			}
			pthread_mutex_unlock( &mon );
			return false;
		}
	}
	//set the word
	for ( int i = 0; i < strlen( word ); i++ ) {
		board [ r ][ c + i ] = word [ i ];
	}
	pthread_mutex_unlock( &mon );
	return true;
}

/**
 * @brief  down r c word
This command is like the across command, but it places a word going down from the given
starting location. It has the same rules for valid words and word placement on the board.
 *
 * @param r the row to start the word
 * @param c the column to start the word
 * @param word the word to place on the board
 * @return true if successfully placed the word
 * @return false if unsucessful when placing the word
 */
bool down( int r, int c, char* word )
{
	//if the given r is larger than the board across or if the given c is larger than the board down
//if the given parameters are negative values
	//if the given parameters are off the board or negatives
	if ( r > row || c > col || r < 0 || c < 0 ) {
		return false;
	}
	pthread_mutex_lock( &mon );
	//word is too long for the given location
	if ( strlen( word ) + r > row ) {
		pthread_mutex_unlock( &mon );
		return false;
	}

	//incrementing by one to account for the border
	r += 1;
	c += 1;

	for ( int i = 0; i < strlen( word ); i++ ) {
		//word contains a non-lowercase letter
		if ( !islower( word [ i ] ) || !isalpha( word [ i ] ) ) {
			pthread_mutex_unlock( &mon );
			return false;
		}

		//if space is occupied
		if ( board [ r + i ][ c ] != ' ' ) {
			//check to see if the characters are the same
			if ( board [ r + i ][ c ] != word [ i ] ) {
				//invalid
				pthread_mutex_unlock( &mon );
				return false;
			}
			continue;
		}

	}

	//use the valid words command if the words list exist
	if ( useWordsList ) {
		//save the col
		char temp [ row ];
		//set EC board
		for ( int i = 0; i < strlen( word ); i++ ) {
			temp [ i ] = ECboard [ r - 1 + i ][ c - 1 ];
			ECboard [ r - 1 + i ][ c - 1 ] = word [ i ];
		}
		//check if words vertically are valid
		bool val = validWords();
		//if not valid
		if ( !val ) {
			//reset EC board
			for ( int i = 0; i < strlen( word ); i++ ) {
				ECboard [ r - 1 + i ][ c - 1 ] = temp [ i ];
			}
			pthread_mutex_unlock( &mon );
			return false;
		}
	}

	//set the word
	for ( int i = 0; i < strlen( word ); i++ ) {
		board [ r + i ][ c ] = word [ i ];
		// printf( "%c ", board [ r + i ][ c ] );
	}
	pthread_mutex_unlock( &mon );
	return true;
}

/** handle a client connection, close it when we're done. */
void* handleClient( void* sock_C )
{

	int sock = *( ( int* )sock_C );
	free( sock_C );
	// Here's a nice trick, wrap a C standard IO FILE around the
	// socket, so we can communicate the same way we would read/write
	// a file.
	FILE* fp = fdopen( sock, "a+" );

	// Prompt the user for a command.
	fprintf( fp, "cmd> " );

	// Temporary values for parsing commands.
	char cmd [ CMD_LIMIT ];

	//while the user passed some command and it's not "quit"
	while ( fscanf( fp, "%10s", cmd ) == 1 && strcmp( cmd, "quit" ) != 0 ) {
		//if the client called the "across" command
		if ( strcmp( cmd, "across" ) == 0 ) {
			int r, c;
			//word must be less than or equal to the board across
			char word [ WORD_LIMIT + 1 ];
			//if more or less than the expected number of arguments were passed
			if ( fscanf( fp, "%d%d%s", &r, &c, word ) != ARGC_CT ) {
				fprintf( fp, "Invalid command\n" );
			}
			//allow the move to happen
			else {
				bool result = across( r, c, word );
				if ( !result ) {
					fprintf( fp, "Invalid command\n" );
				}
			}

		}
		//if the client called the "down" command
		else if ( strcmp( cmd, "down" ) == 0 ) {
			int r, c;
			//word must be less than or equal to the board across
			char word [ WORD_LIMIT + 1 ];
			//if more or less than the expected number of arguments were passed
			if ( fscanf( fp, "%d%d%s", &r, &c, word ) != ARGC_CT ) {
				fprintf( fp, "Invalid command\n" );
			}
			//allow the move to happen
			else {
				bool result = down( r, c, word );
				if ( !result ) {
					fprintf( fp, "Invalid command\n" );
				}
			}
		}
		//if client wants to print out the board
		else if ( strcmp( cmd, "board" ) == 0 ) {
			//if more or less than the expected number of arguments were passed
			// if ( fscanf( fp, "%[a-z0-9]") > 1 ) {
			// 	fprintf( fp, "Invalid command\n" );
			// }
			printBoard( row, col );
		}
		//invalid command was passed
		else {
			fprintf( fp, "Invalid command\n" );
		}

		// // // Just echo the command back to the client for now.
		// fprintf( fp, "%s\n", cmd );

		// Prompt the user for the next command.
		fprintf( fp, "cmd> " );
	}

	// Close the connection with this client.
	fclose( fp );
	return NULL;
}


int main( int argc, char* argv [ ] )
{
	//read in the two int values that will be used
	//if not an integer
	if ( sscanf( argv [ 1 ], "%d", &( row ) ) != 1 || sscanf( argv [ 2 ], "%d", &( col ) ) != 1 || argc != 3 ) {
		fprintf( stderr, "usage: scrabbleServer %d %d", row, col );
		exit( EXIT_FAILURE );
	}
	//if not a numeric value greater than 0
	if ( row < 1 || col < 1 ) {
		fprintf( stderr, "usage: scrabbleServer %d %d", row, col );
		exit( EXIT_FAILURE );
	}

	// Prepare a description of server address criteria.
	struct addrinfo addrCriteria;
	memset( &addrCriteria, 0, sizeof( addrCriteria ) );
	addrCriteria.ai_family = AF_INET;
	addrCriteria.ai_flags = AI_PASSIVE;
	addrCriteria.ai_socktype = SOCK_STREAM;
	addrCriteria.ai_protocol = IPPROTO_TCP;

	// Lookup a list of matching addresses
	struct addrinfo* servAddr;
	if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr ) )
		fail( "Can't get address info" );

	// Try to just use the first one.
	if ( servAddr == NULL )
		fail( "Can't get address" );

	// Create a TCP socket
	int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
		servAddr->ai_protocol );
	if ( servSock < 0 )
		fail( "Can't create socket" );

	// Bind to the local address
	if ( bind( servSock, servAddr->ai_addr, servAddr->ai_addrlen ) != 0 )
		fail( "Can't bind socket" );

	// Tell the socket to listen for incoming connections.
	if ( listen( servSock, 5 ) != 0 )
		fail( "Can't listen on socket" );

	// Free address list allocated by getaddrinfo()
	freeaddrinfo( servAddr );

	// Fields for accepting a client connection.
	struct sockaddr_storage clntAddr; // Client address
	socklen_t clntAddrLen = sizeof( clntAddr );

	//create the board
	makeBoard( row, col );
	pthread_mutex_init( &mon, NULL );
	//check if the dictionary exist
	useWordsList = readList();
	if ( useWordsList ) {
		//create the dictionary board
		makeWordBoard( row, col );
	}

	while ( true ) {
		// Accept a client connection.
		int sock = accept( servSock, ( struct sockaddr* )&clntAddr, &clntAddrLen );

		//allowing multithreading to happen
		pthread_t thread;
		int* client = malloc( sizeof( int ) );
		*client = sock;
		if ( pthread_create( &thread, NULL, handleClient, client ) != 0 ) {
			// Error in creating thread
			printf( "Failed to create thread\n" );
		}
		//detaching immediately after creation
		pthread_detach( thread );
	}

	//free the board
	free( board );
	//free the dictionary board if one was used
	if ( useWordsList ) {
		free( ECboard );
	}
	// Stop accepting client connections (never reached).
	close( servSock );
	return EXIT_SUCCESS;
}
