#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26398"

/** Maximum word length */
#define WORD_LIMIT 26


char *board = NULL;
int rowSize, colSize;
sem_t useBoard;

// struct arguments {
//   char operation;
//   int r;
//   int c;
//   char *word;
// }

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}


void usage() {
  fprintf(stderr, "%s\n", "usage: scrabbleServer <rows> <cols>");
}

void invalid(FILE *fp) {
  fprintf(fp, "Invalid command\n");
}

void printEnds(FILE *fp) {
  fprintf(fp, "+");
  for (int i = 0; i < colSize; i++) {
    fprintf(fp, "-");
  }
  fprintf(fp, "+\n");
}

void report(FILE *fp) {
  sem_wait(&useBoard);
  printEnds(fp);
  for (int i = 0; i < rowSize; i++) {
    fprintf(fp, "|");
    for (int j = 0; j < colSize; j++) {
      fprintf(fp, "%c", board[i * colSize + j]);
    }
    fprintf(fp, "|\n");
  }
  printEnds(fp);
  sem_post(&useBoard);
}

// bool placeLetter(int r, int c, char l) {
//   if (board[c][r] != ' ') return false;
//   if (!islower(l)) return false;
//   board[c * rowSize + r] = l;
//   return true;
// }


bool across(int r, int c, char *word, int length) {
  sem_wait(&useBoard);
  if (c + length - 1 > colSize - 1 || r >= rowSize) {
    sem_post(&useBoard);
    return false;
  }
  for (int i = 0; i < length; i++) {
    if ((board[r * colSize + c + i] != ' ' && board[r * colSize + c + i] != word[i]) || (!isalpha(word[i]) || !islower(word[i]))) {
      sem_post(&useBoard);
      return false;
    }
    
  }
  for (int i = 0; i < length; i++) {
    board[r * colSize + c + i] = word[i];
  }
  sem_post(&useBoard);
  return true;
}

bool down(int r, int c, char *word, int length) {
  sem_wait(&useBoard);
  if (r + length - 1 > rowSize - 1 || c >= colSize) {
    sem_post(&useBoard);
    return false;
  }
  for (int i = 0; i < length; i++) {
    // printf("%d %c %c\n", i, board[(r + i) * colSize + c], word[i]);
    if ((board[(r + i) * colSize + c] != ' ' && board[(r + i) * colSize + c] != word[i]) || (!isalpha(word[i]) || !islower(word[i]))) {
      // printf("2 %d %d %d %d\n", board[(r + i) * rowSize + c] != ' ', board[(r + i) * rowSize + c], !isalpha(word[i]), !islower(word[i]));
      sem_post(&useBoard);
      return false;
    }
  }
  for (int i = 0; i < length; i++) {
    board[(r + i) * colSize + c] = word[i];
    // printf("2 %c %c\n", board[(r + i) * rowSize + c], word[i]);
  }
  sem_post(&useBoard);
  return true;
}



/** handle a client connection, close it when we're done. */
void *handleClient( int sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );




  bool conti = true;
  while (conti) {
    int count = 0;
    // char first[5];
    char line[39];
    char c;

    do {
      c = fgetc(fp);
      // printf("c: %c\n", c);
      if (c != '\n') {
        line[count] = c;
      }
      count++;
      if (count > 38) {
        invalid(fp);
        break;
      }
    } while (c != '\n');
    for (int i = count; i < 39; i++) {
      line[i - 1] = '\0';
    }
    // line[count] = '\0';

    // printf("line: %s count: %d\n", line, count);
    char command[7];




    int count2 = 0;
    char e = line[count2++];
    int commandCount = 0;

    // printf("line: %s count: %d\n", line, count);


    while (e != ' ' && e != '\n' && commandCount < count) {
      // printf("e: %c\n", e);
      command[commandCount++] = e;
      e = line[count2++];
    }
    command[commandCount] = '\0';

    // printf("command: %s commandCount: %d\n", command, commandCount);

    

    // printf("count2 1: %d\n", count2);

    if (strcmp(command, "board") == 0) {
      // printf(command);
      report(fp);
    } else if (strcmp(command, "quit") == 0) {
      conti = false;
    } else if (strcmp(command, "across") == 0 || strcmp(command, "down") == 0) {
      // printf(command);
      int row, column;
      char word[27];
      
      int wordCount = 0;
        
      
      char tempNumber[4];
      int numCount = 0;
      e = line[count2++];

      while (e != ' ' && isdigit(e)) {
        tempNumber[numCount++] = e;
        e = line[count2++];
      }
      tempNumber[numCount] = '\0';
      row = atoi(tempNumber);

      // printf("count2 1: %d\n", count2);

      e = line[count2++];

      numCount = 0;
      char tempNumber2[4];
      while (e != ' ' && isdigit(e)) {
        tempNumber2[numCount++] = e;
        e = line[count2++];
      }
      tempNumber2[numCount] = '\0';
      column = atoi(tempNumber2);

      e = line[count2++];

      // printf("count2 1: %d\n", count2);

      while (e != '\0') {
        word[wordCount++] = e;
        // printf("%c %d %d\n", line[count2], wordCount, count2);
        e = line[count2++];
      }





      // printf("row: %d\n", row);
      // printf("col: %d\n", column);
      // printf("word?: %s\n", word);







      if (strcmp(command, "across") == 0) {
        
        if (!across(row, column, word, wordCount)) invalid(fp);
      } else if (strcmp(command, "down") == 0) {
        if (!down(row, column, word, wordCount)) invalid(fp);
      }
    } else {
      invalid(fp);
    }


    if (conti) fprintf(fp, "cmd> ");
  }


  // Close the connection with this client.
  fclose( fp );
  return NULL;
}



void *threadHandler(void *args) {
  int value = *(int *) args;
  handleClient(value);
  pthread_exit(NULL);
}

int main( int argc, char *argv[] ) {
  if (argc != 3) usage();
  if (atoi(argv[1]) <= 0 || atoi(argv[2]) <= 0) usage();
  rowSize = atoi(argv[1]);
  colSize = atoi(argv[2]);
  
  board = (char *)malloc(rowSize * colSize * sizeof(char));
  for (int i = 0; i < rowSize * colSize; i++) {
    board[i] = ' ';
  }

  sem_init(&useBoard, 0, 1);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_t tc;
    // pthread_create(&tc,NULL, handleClient, &sock);
    int *arg = malloc(sizeof(arg));
    *arg = sock;
    pthread_create(&tc, NULL, threadHandler, (void *)arg);
    pthread_detach(tc);
    // handleClient( sock );
  }

  // Stop accepting client connections (never reached).
  sem_destroy(&useBoard);
  free(board);
  close( servSock );
  
  return 0;
}
