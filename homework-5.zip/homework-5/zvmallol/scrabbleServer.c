#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26342"

/** Maximum word length */
#define WORD_LIMIT 26

pthread_mutex_t monitor;

char **board;

int rows;

int cols;

typedef struct {
  int socket;
} ArgStruct;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *arg ) {
  ArgStruct *astruct = (ArgStruct *) arg;
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( astruct->socket, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 28 ];
  while ( fscanf( fp, "%27s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0) {
    if(strcmp(cmd, "across") == 0) {
      int row, col;
      
      if(fscanf(fp, "%d %d", &row, &col) != 2) {
        goto INVALID;
      }
      char word[28];
      // If any conditions are invalid jump to invalid
      fscanf(fp, "%27s", word);
      if(strlen(word) > 26) {
        goto INVALID;
      }
      if(strlen(word) + col >= cols || col < 0) {
        goto INVALID;
      }
      if(row >= rows || row < 0) {
        goto INVALID;
      }
      // critical section (basically same for down)
      pthread_mutex_lock( &monitor );
      for(int i = 0; i < strlen(word); i++) {
        if(board[row][col + i] != ' ') {
          pthread_mutex_unlock(&monitor);
          goto INVALID;
        }
      }
      for(int i = 0; i < strlen(word); i++) {
        board[row][col + i] = word[i];
      }
      pthread_mutex_unlock(&monitor);
    }
    else if(strcmp(cmd, "down") == 0) {
      int row, col;
      
      if(fscanf(fp, "%d %d", &row, &col) != 2) {
        goto INVALID;
      }
      char word[WORD_LIMIT + 2];
      fscanf(fp, "%27s", word);
      if(strlen(word) > WORD_LIMIT) {
        goto INVALID;
      }
      if(strlen(word) + row >= rows || row < 0) {
        goto INVALID;
      }
      if(col >= cols || col < 0) {
        goto INVALID;
      }
      pthread_mutex_lock( &monitor );
      for(int i = 0; i < strlen(word); i++) {
        if(board[row + i][col] != ' ') {
          pthread_mutex_unlock(&monitor);
          goto INVALID;
        }
      }
      for(int i = 0; i < strlen(word); i++) {
        board[row + i][col] = word[i];
      }
      pthread_mutex_unlock(&monitor);
    }
    else if(strcmp(cmd, "board") == 0) {
      fprintf(fp, "+");
      for(int i = 0; i < cols; i++) {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
      for(int i = 0; i < rows; i++) {
        fprintf(fp, "|%s|\n", board[i]);
      }
      fprintf(fp, "+");
      for(int i = 0; i < cols; i++) {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
    }
    else {
      INVALID:
      fprintf(fp, "Invalid command\n");
    }
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  // check args
  if(argc != 3) {
    fail("usage: scrabbleServer <rows> <cols>");
  }

  if(sscanf(argv[1], "%d", &rows) != 1) {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  if(sscanf(argv[2], "%d", &cols) != 1) {
    fail("usage: scrabbleServer <rows> <cols>");
  }

  if(rows < 1 || cols < 1) {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  // allocate board
  board = malloc(rows * sizeof(char *));
  for(int i = 0; i < rows; i++) {
    board[i] = malloc(sizeof(char) * cols);
  }

  for(int i = 0; i < cols; i++) {
    for(int j = 0; j < rows; j++) {
      board[i][j] = ' ';
    }
  }
  // make monitor
  pthread_mutex_init(&monitor, NULL);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_t thread;
    ArgStruct *arg = (ArgStruct *) malloc(sizeof(ArgStruct));
    arg->socket = sock;

    // Make thread with socket as argument
    if(pthread_create( &thread, NULL, handleClient, arg ) != 0) {
      fail("Could not create thread.");
    }
    pthread_detach(thread);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
