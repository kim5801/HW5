#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26200"

/** Maximum word length */
#define WORD_LIMIT 26

/** Arbirtrary input length to measure buffer overflow */
#define DEFAULT_LENGTH 39


static char **board;
static int rowServer;
static int colServer;

//semaphore for changing the state
sem_t editing;


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}


//move accross command
bool moveAcross(int r, int c, char *word) {

  bool isMoved = true;
  //if the word goes off the board
  if ( (c + strlen(word) ) > colServer) {
    isMoved = false;
  }
  
  if (isMoved) {
    sem_wait(&editing);
    int idx = 0;
    for (int i = c; i < strlen(word) + c; i++) {
        board[r][i] = word[idx];
        idx++;
    }
    sem_post(&editing);
  }

  return isMoved;
}

//handles move down command
bool moveDown(int r, int c, char *word) {
  bool isMoved = true;
  //if the word goes off the board
  if ( (r + strlen(word) ) > rowServer) {
    isMoved = false;
  }

  if (isMoved) {
    sem_wait(&editing);
    int idx = 0;
    for (int i = r; i < strlen(word) + r; i++) {
      board[i][c] = word[idx];
      idx++;
    }
    sem_post(&editing);
  }
  

  return isMoved;
}



/** handle a client connection, close it when we're done. */
void *handleClient( void *sockTemp ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  //get proper type for sock
  int sock = *(int *)sockTemp;


  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );


  // Temporary values for parsing commands.
  char fullCmd[DEFAULT_LENGTH];
  while ( /*fscanf( fp, "%10s", cmd ) == 1*/ fgets(fullCmd, DEFAULT_LENGTH, fp) != '\0'  &&
          strcmp( fullCmd, "quit\n" ) != 0 ) {

    if (strlen(fullCmd) > WORD_LIMIT + 11) {
      fprintf(fp, "Invalid command\n");
    }
    else {

    }
    char command[7];
    int row = 0;
    int col = 0;
    char word[WORD_LIMIT];
    bool isLowerCase = true;
    bool isMoveValid = true;

    //number of commands parsed
    int argNum = sscanf(fullCmd, "%s %d %d %s", command, &row, &col, word);

    if (argNum == 4) {
      for (int i = 0; i < strlen(word); i++) {
        if (!islower(word[i])) {
          isLowerCase = false;
          break;
        }
      }
      if (isLowerCase) {
        if ( strcmp(command, "across") == 0 ) {
          //check if across move can happen
          int idx = 0;
          for (int i = col; i < strlen(word) + col; i++) {
            if (board[row][i] == ' ' || board[row][i] == word[idx]) {
              idx++;
            }
            else {
              isMoveValid = false;
            }
          }

          if (isMoveValid && strlen(word) <= WORD_LIMIT) {
            if(!moveAcross( row, col, word)) {
              fprintf(fp, "Invalid command\n");
            }
          }
          else {
            fprintf(fp, "Invalid command\n");
          }
        }
        else if ( strcmp(command, "down") == 0) {
          int idx = 0;
          //check if the move will be valid
          for (int i = row; i < strlen(word) + row; i++) {
            if (board[i][col] == ' ' || board[i][col] == word[idx]) {
              idx++;
            }
            else {
              isMoveValid = false;
            }
          }
          //if move can work
          if (isMoveValid && strlen(word) <= WORD_LIMIT) {
            if(!moveDown( row, col, word)) {
              fprintf(fp, "Invalid command\n");
            }
          }
          else {
            fprintf(fp, "Invalid command\n");
          }
        }
        else {
          fprintf(fp, "Invalid command\n");
        }
      }
      //if contains a capital letter
      else {
        fprintf(fp, "Invalid command\n");
      }
    }
    //if there is only 1 argument
    else if(argNum == 1) {
      if (strcmp(command, "board") == 0) {
        //print the top border
        for (int i = 0; i < colServer + 2; i++) {
          if (i == 0) {
            fprintf(fp, "+");
          }
          else if (i == colServer + 1) {
            fprintf(fp, "+\n");
          }
          else {
            fprintf(fp, "-");
          }
        }


        for (int i = 0; i < rowServer; i++) {
          fprintf(fp, "|");
          for (int j = 0; j < colServer; j++) {
            fprintf(fp, "%c", board[i][j]);
          }
          fprintf(fp, "|");
          fprintf(fp, "\n");
        }


        //print the bottom border
        for (int i = 0; i < colServer + 2; i++) {
          if (i == 0) {
            fprintf(fp, "+");
          }
          else if (i == colServer + 1) {
            fprintf(fp, "+\n");
          }
          else {
            fprintf(fp, "-");
          }
        }
      }
      //if the word is not board
      else {
      fprintf(fp, "Invalid command\n");
      }
    }
    //any other amount of input is an invalid command
    else {
      fprintf(fp, "Invalid command\n");
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}



int main( int argc, char *argv[] ) {
  sem_init(&editing, 0, 1);
  int row = atoi(argv[1]);
  int col = atoi(argv[2]);
  rowServer = row;
  colServer = col;

  // char board[row][col];
  board = (char **)malloc(rowServer * sizeof(char *));
  for(int i = 0; i < row; i++) {
    board[i] = (char *)malloc(colServer * sizeof(char));
  }

  for (int i = 0; i < rowServer; i++) {
    for (int j = 0; j < colServer; j++) {
      board[i][j] = ' ';
    }
  }

  
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);
  pthread_t thread;
  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    if (pthread_create(&thread, NULL, handleClient, (void *)&sock) != 0) {
      fail("could not create thread.");
    }
    pthread_detach(thread);
    // handleClient( sock, &board );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  free(board);
  
  return 0;
}
