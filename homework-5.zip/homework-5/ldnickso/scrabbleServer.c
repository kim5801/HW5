#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26250"

/** Maximum word length */
#define WORD_LIMIT 26

/** ASCII code for a */
#define ASCII_a 97

/** ASCII code for z */
#define ASCII_z 122

/** Rows in board */
int rows = 0;

/** Rows in board */
int cols = 0;

/** Scrabble board */
char *board;

// Anonymous semaphores for accessing globals and for uniterrupted execution
sem_t lock;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

//Print the exterior board
static void printBoard(FILE *fp) {
  //Print "+------...------+"
  fprintf(fp,"+");
  for(int i = 0; i < cols; i++) {
    fprintf(fp,"-");
  }
  fprintf(fp,"+\n");

  //Print internal board
  for(int i = 0; i < rows; i++) {
    fprintf(fp,"|");
    for( int j = 0; j < cols; j++) {
      fprintf(fp, "%c", board[(i * cols) + j]);
    }
    fprintf(fp,"|\n");
  }

  //Print "+------...------+"
  fprintf(fp,"+");
  for(int i = 0; i < cols; i++) {
    fprintf(fp,"-");
  }
  fprintf(fp,"+\n");
}

//Check to make sure the word can be placed, then place it if it can be
static void placeWord(char *word, int y, int x, bool isAcross, FILE *fp) {
  //Get the length of the word
  int len = strlen(word);
  bool isValid = true;
  //Do an across word
  if (isAcross) {
    //Check if the board is long enough
    if(x + len <= cols && y < rows) {
      //Check if the word overlaps with any other words
      for(int i = x; i < x + len; i++) {
        if(board[(y * cols) + i] != ' ' && board[(y * cols) + i] != word[i - x]) {
          isValid = false;
        }
      }
      //Change the board if the word is valid
      if(isValid) {
         for(int i = x; i < x + len; i++) {
          board[(y * cols) + i] = word[i - x];
        }
      }
      else {
        fprintf(fp,"Invalid command\n");
      }
    }
    else {
      fprintf(fp,"Invalid command\n");
    }
  }
  else {
    //Check if the board is long enough
    if(y + len <= rows && x < cols) {
      //Check if the word overlaps with any other words
      for(int i = y; i < y + len; i++) {
        if(board[(i * cols) + x] != ' ' && board[(i * cols) + x] != word[i - y]) {
          isValid = false;
        }
      }
      //Change the board if the word is valid
      if(isValid) {
         for(int i = y; i < y + len; i++) {
          board[(i * cols) + x] = word[i - y];
        }
      }
      else {
        fprintf(fp,"Invalid command\n");
      }
    }
    else {
      fprintf(fp,"Invalid command\n");
    }
  }
}

//Check to make sure the word we want to place is valid
bool checkWord(char * word) {
  //Is it too long?
  if (strlen(word) > 26) {
    return false;
  }

  //Check for non a-z characters
  for (int i = 0; i < strlen(word); i++) {
    if(word[i] < ASCII_a || word[i] > ASCII_z) {
      return false;
    }
  }
  
  //The word is valid
  return true;
}

/** handle a client connection, close it when we're done. */
void *handleClient( void * arg ) {
  int *sockPtr = (int *) arg;
  int sock = *sockPtr;
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    // // Just echo the command back to the client for now.
    // fprintf( fp, "%s\n", cmd );

    //Declare variables to store user input for "across" and "down" commandss
    int x;
    int y;
    char *word = (char *) malloc(sizeof(char) * WORD_LIMIT);
    int status;
    
    //Print the board if the command is issued
    if(strcmp(cmd, "board") == 0) {
      //Get in/out of lock as the board could be modified by another thread
      sem_wait(&lock);
      printBoard(fp);
      sem_post(&lock);
    }   
    //Make a move across if command is issued
    else if(strcmp(cmd, "across") == 0) {
      // printf("Was 'across'\n");
      status = fscanf(fp, "%d %d %27s", &y, &x, word);
      // printf("%d %d %s %d\n", y, x, word, status);
      //Get in/out of lock as the board could be modified by another thread
      sem_wait(&lock);
      if (status != 0 && status != EOF && checkWord(word) ) {
        placeWord(word, y, x, true, fp);
      }
      else{
        fprintf(fp,"Invalid command\n");
      }
      sem_post(&lock);
    }
    //Make a move down if command is issued
    else if(strcmp(cmd, "down") == 0) {
      // printf("Was 'down'\n");

      status = fscanf(fp, "%d %d %27s", &y, &x, word);
      // DEBUG
      // printf("%d %d %s %d\n", y, x, word, status);

      //Get in/out of lock as the board could be modified by another thread
      sem_wait(&lock);
      if (status != 0 && status != EOF && checkWord(word)) {
        placeWord(word, y, x, false, fp);
      }
      else{
        fprintf(fp,"Invalid command\n");
      }
      sem_post(&lock);
    }
    else {
      fprintf(fp,"Invalid command\n");
    }
    //Free the allocated word
    free(word);

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  //Make sure that there's the correct number of args
  if (argc != 3) {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  
  //Is rows valid?
  if (sscanf(argv[1], "%d", &rows) != 1 || rows < 0) {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  //Is cols valid?
  if (sscanf(argv[2], "%d", &cols) != 1 || cols < 0) {
    fail("usage: scrabbleServer <rows> <cols>");
  }

  //Create the game board
  board = (char *)malloc((rows) * (cols));

  //Fill the board with spaces
  for (int i = 0; i < (rows * cols); i++) {
    board[i] = ' ';
  }

  //Init the semaphore
  sem_init(&lock, 0, 1);

  //DEBUG, print rows and cols
  // printf("Rows: %d, Cols: %d\n", rows, cols);
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    pthread_t currentThread;
    if (pthread_create(&currentThread, NULL, &handleClient, &sock) != 0)
    {
      fail("Can't create a child thread");
    }
    pthread_detach(currentThread);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  free(board);
  
  return 0;
}