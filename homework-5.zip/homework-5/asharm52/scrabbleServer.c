/**
 * @file scrabbleServer.c
 * @author Arul Sharma (asharm52)
 * This program is the server for the scrabble program
 * accepts clients connections and updates game board as client gives commands
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26210"

/** Maximum word length */
#define WORD_LIMIT 26

/** Maximum command length*/
#define MAX_CMD_LENGTH 50

/** the number of rows in the board **/
int rows;

/** the number of cols in the board **/
int cols;

/** the 2d array that stores the board and its current state **/
char** board;

// Lock for access to the commands
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}


/**
 * handle a client connection, close it when we're done.
 * @param soc sock number, has to be casted to int due to the way passing args works with threads
 */
void *handleClient( void *soc ) {

  int sock = *((int *) soc);

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // cmd var is used to read in the full input from the user, this is later parsed
  char cmd[MAX_CMD_LENGTH];
  // while there is a valid line to read, keep on reading
  while (fgets(cmd, MAX_CMD_LENGTH, fp) != NULL) {
    // get rid of newline character at the end that is added by fgets
    cmd[strcspn(cmd, "\n")] = 0;
    // fprintf(fp, "%s\n", cmd);
    // if the user entered quit, quit the program
    if (strcmp( cmd, "quit" ) == 0) {
      break;
    }
    // enter code that can overwrite common data
    pthread_mutex_lock( &mon );

    // these variables are used when parsing cmd
    char command[MAX_CMD_LENGTH];
    int row;
    int col;
    char word[WORD_LIMIT + 1];

    memset(word, 0, sizeof(word));

    sscanf(cmd, "%[^ ] %d %d %s", command, &row, &col, word);
    // fflush(fp);
    // fprintf(fp, "command: %s , row %d , col: %d , word; %s\n", command, row, col, word);

    // if the command given by the user is board, print the current state of the board
    if (strcmp(command, "board") == 0) {
      fprintf(fp, "+");
      for (int j = 0; j < cols; j++) {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
      for (int k = 0; k < rows; k++) {
        fprintf(fp, "|");
        for (int m = 0; m < cols; m++) {
          if (board[k][m] == '\0') {
            fprintf(fp, " ");
          } else {
            fprintf(fp, "%c", board[k][m]);
          }
        }
        fprintf(fp, "|\n");
      }
      fprintf(fp, "+");
      for (int j = 0; j < cols; j++) {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
    // if the user want to put a word across
    } else if (strcmp(command, "across") == 0) {
      // boolean to see if word is valid
      bool cont = true;
      int len = strlen(word);
      // if the rows and cols given by the user are valid, then you can print the word
      if (row < 0 || col < 0 || strcmp(word, "\0") == 0 || row >= rows || col >= cols || (col + len) > cols) {
        fprintf( fp, "Invalid command\n");
      } else {
        int parseCol = col;
        for (int i = 0; i < len; i++) {
          if (word[i] < 'a' || word[i] > 'z') {
            fprintf( fp, "Invalid command\n");
            cont = false;
            break;
          }
          if (board[row][parseCol] != '\0') {
            if (board[row][parseCol] != word[i]) {
              fprintf( fp, "Invalid command\n");
              cont = false;
              break;
            }
          }
          parseCol++;
        }
        // if all is valid, go ahead and the new word to the board
        if (cont) {
          for (int i = 0; i < len; i++) {
            board[row][col] = word[i];
            col++;
          }
        }

        // reset all the variables before they are used again
        memset(cmd, 0, sizeof(cmd));
        memset(command, 0, sizeof(command));
        row = -1;
        col = -1;
        memset(word, 0, sizeof(word));
      }
    } else if (strcmp(command, "down") == 0) {
      // boolean value to check if word is valid
      bool cont = true;
      int len = strlen(word);
      // check to make sure that the bounds of rows and cols are valid
      if (row < 0 || col < 0 || strcmp(word, "\0") == 0 || row >= rows || col >= cols || (row + len) > rows) {
        fprintf( fp, "Invalid command\n");
      } else {
        int parseRow = row;
        for (int i = 0; i < len; i++) {
          if (word[i] < 'a' || word[i] > 'z') {
            fprintf( fp, "Invalid command\n");
            cont = false;
            break;
          }
          if (board[parseRow][col] != '\0') {
            if (board[parseRow][col] != word[i]) {
              fprintf( fp, "Invalid command\n");
              cont = false;
              break;
            }
          }
          parseRow++;
        }
        // if all is valid, go ahead and print the word to the board
        if (cont) {
          for (int i = 0; i < len; i++) {
            board[row][col] = word[i];
            row++;
          }
        }
        // reset all variables before they are used again
        memset(command, 0, sizeof(command));
        row = -1;
        col = -1;
        memset(word, 0, sizeof(word));
      }

    } else {
      // if no valid command is given by the user, print an error message
      fprintf( fp, "Invalid command\n");
    }
    

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
    pthread_mutex_unlock( &mon );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

/**
 * this method initializes the board as given by the user
 * @param rows the num of rows in the table
 * @param cols the num of cols in the table
 */
void initBoard(int rows, int cols) {

  board = (char**)malloc(rows * sizeof(char*));
  for (int i = 0; i < rows; i++)
    board[i] = (char*)malloc(cols * sizeof(char));

}

/**
 * main method initiates connections with clients and creates threads
 * @param argc the number of arguments given when the program is initially run
 * @param argv pointer to an array of all the arguments that were given by the user when running the program
 * @return int exit status
 */
int main( int argc, char *argv[] ) {

  // convert string arg to int
  rows = atoi(argv[1]);
  cols = atoi(argv[2]);
  // initialize the board
  initBoard(rows, cols);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    pthread_t thread;

    // create threads as needed
    if (pthread_create(&thread, NULL, handleClient, (void *) &sock) != 0)
      fail("Can't create a thread");
    
    pthread_detach(thread);
    // handleClient( sock );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  // free mem used for board
  for (int i = 0; i < rows; i++)
    free(board[i]);
  free(board); 

  return 0;
}
