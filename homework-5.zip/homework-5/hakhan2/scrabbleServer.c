#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26122"

/** Maximum word length */
#define WORD_LIMIT 26

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// ---------------------------------------------------------------------------------------------------------
// HANDLE ALL THE SYNCHRONIZATION LOGIC HERE

// create a global mutex
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

// This could be more efficient with logic to support the readers writer problem
// // create a global condition variable
// pthread_cond_t read = PTHREAD_COND_INITIALIZER;

// ---------------------------------------------------------------------------------------------------------
// HANDLE AlL THE SCRABBLE GAME LOGIC HERE

bool dictionary = false; // this is a flag to determine if the dictionary has been loaded (by default it wont be)
FILE *dict; 

// struct for the scrabble board
typedef struct {
  int rowSize; 
  int colSize;
  char *board;
} ScrabbleBoard;

// Global pointer to the scrabble board
ScrabbleBoard *scrabbleBoard;

// print the board 
void printBoard( FILE *filePointer, ScrabbleBoard *board ) {
  // extract row and col size ( to avoid dereferencing pointer )
  int rowSize = board->rowSize;
  int colSize = board->colSize;

  int i, j;

  // lock the board
  pthread_mutex_lock( &lock );

  // we need to add 1 to either side of row or col size to account for the border
  for (i = 0; i < rowSize + 2; i++) {
    for (j = 0; j < colSize + 2; j++) {
      // this handles printing per row for + or -
      if( i == 0 || i == rowSize + 1 ) {
        // need special printing for both the first and last row
        if( j == 0 || j == colSize + 1 ) {
          fprintf( filePointer, "+" );
        } else {
          fprintf( filePointer, "-" );
        }
      } 
      // this handles printing per col for | or the actual board
      else {
        // only need special printing for the ends of the columns
        if( j == 0 || j == colSize + 1 ) {
          fprintf( filePointer, "|" );
        } else {
          fprintf( filePointer, "%c", board->board[(i - 1) * colSize + (j - 1)] );
        }
      }
    }
    fprintf( filePointer, "\n" );
  }

  // unlock the board
  pthread_mutex_unlock( &lock );

}

// do a check to ensure no spaces are in the potential spaces for the word
bool acrossCheck( int row, int col, char *word ) {
  int wordLen = strlen( word );

  // ensures that a new letter is added to the board
  bool lettersAdded = false; 

  pthread_mutex_lock( &lock );


  for( int i = 0; i < wordLen; i++ ) {
    // return false if the space is not empty or contain the ith letter of the word
    char current = scrabbleBoard->board[row * scrabbleBoard->colSize + col + i];

    if( current != ' ' ) {
      if( current != word[i] ) {
        pthread_mutex_unlock( &lock );
        return false;
      }
    } 
    else if( current != word[i] ) {
      lettersAdded = true;
    }
  }
  pthread_mutex_unlock( &lock );

  return lettersAdded;
}
// do a check to ensure no spaces are in the potential spaces for the word
bool downCheck( int row, int col, char *word ) {
  int wordLen = strlen( word );

  // ensures that a new letter is added to the board
  bool lettersAdded = false;

  pthread_mutex_lock( &lock );


  for( int i = 0; i < wordLen; i++ ) {
    // return false if the space is not empty or contain the ith letter of the word
    char current = scrabbleBoard->board[(row + i) * scrabbleBoard->colSize + col];
    if( current != ' ' ) {
      if( current != word[i] ) {
        pthread_mutex_unlock( &lock );
        return false;
      }
    } 
    else if( current != word[i] ) {
      lettersAdded = true;
    }
  }

  pthread_mutex_unlock( &lock );

  return lettersAdded;
}

// checks to see if a word is in the dictionary
bool inDictionary( char *word ) {
    char buffer[ WORD_LIMIT + 1];
    while( fscanf( dict, "%26s", buffer ) != EOF ) {
      if( strcmp( buffer, word ) == 0 ) {
        rewind(dict);
        return true;
      }
    }

    // reset the file pointer
    rewind( dict );
    return false; 
}

bool rowWordCheck( ScrabbleBoard *board, int row ) {
  // create a buffer of the row size and copy over 
  char buffer[board->colSize + 1];

  
  // copy the words on the current row into the buffer
  for( int j = 0; j < board->colSize; j++ ) {
    buffer[j] = board->board[row * board->colSize + j];
  }

  // add the null terminator
  buffer[board->colSize] = '\0';

  // buffer for each word
  char word[WORD_LIMIT + 1];

  // parse through each word in the buffer
  // use the string tokenizer to parse through the buffer
  char *token = strtok( buffer, " " );
  while( token != NULL ) {
    // copy the token into the word buffer
    strncpy( word, token, WORD_LIMIT );

    // check if the word is in the dictionary
    if( !inDictionary( word ) ) {
      return false;
    }

    // get the next token
    token = strtok( NULL, " " );
  }

  return true;
}

bool colWordCheck( ScrabbleBoard *board, int col ) {
  // create a buffer of the row size and copy over 
  char buffer[board->rowSize + 1];

  // copy the words on the current row into the buffer
  for( int j = 0; j < board->rowSize; j++ ) {
    buffer[j] = board->board[j * board->colSize + col];
  }

  // add the null terminator
  buffer[board->rowSize] = '\0';

  // buffer for each word
  char word[WORD_LIMIT + 1];

  // parse through each word in the buffer
  // use the string tokenizer to parse through the buffer
  char *token = strtok( buffer, " " );
  while( token != NULL ) {
    // copy the token into the word buffer
    strncpy( word, token, WORD_LIMIT );

    // check if the word is in the dictionary
    if( !inDictionary( word ) ) {
      return false;
    }

    // get the next token
    token = strtok( NULL, " " );
  }

  return true;
}

// ensure every character in a word is a lowercase letter 
bool isValidWord( char *word ) {
  // get the length of the word to reduce overhead
  int wordLength = strlen( word );
  
  // iterate over each letter in the word
  for( int i = 0; i < wordLength; i++ ) {
    if( !islower( word[i] ) ) {
      return false;
    }
  }

  // check for word in dictionary
  if( dictionary ) {
    return inDictionary( word );
  }

  // return true if we get here
  return true;
}

bool canAdd( ScrabbleBoard *board, char *word, int row, int col, char direction ) {

  // temporary duplicate of the scrabble board
  ScrabbleBoard *tempBoard = malloc( sizeof( ScrabbleBoard ) );
  tempBoard->rowSize = board->rowSize;
  tempBoard->colSize = board->colSize;
  tempBoard->board = malloc( sizeof( char ) * board->rowSize * board->colSize );

  // copy the board
  memcpy( tempBoard->board, board->board, sizeof( char ) * board->rowSize * board->colSize );

  // length of the word
  int wordLength = strlen( word );

  // add the word to the board
  if( direction == 'a' ) {
    for( int i = 0; i < wordLength; i++ ) {
      tempBoard->board[row * tempBoard->colSize + col + i] = word[i];
    }
  }
  // otherwise the direction is down
  else {
    for( int i = 0; i < wordLength; i++ ) {
      board->board[ (row + i) * board->colSize + col ] = word[i];
    }
  }

  // check to see if the board is valid in the row direction and the column direction
  bool rowValid = rowWordCheck( tempBoard, row );
  bool colValid = colWordCheck( tempBoard, col ); 

  // free the memory in the temp board
  free( tempBoard->board );
  free( tempBoard );
  
  return rowValid && colValid; 
}

// handle adding letters across the board
bool addAcross( ScrabbleBoard *board, char *word, int row, int col ) {

  // get the length of the word
  int wordLength = strlen( word );

  // ensure row and col are within bounds
  if( row < 0 || row >= board->rowSize || col < 0 || col + wordLength > board->colSize || !acrossCheck( row, col, word ) ) {
    return false;
  }

  // if dictionary, ensure no invalid words are added
  if(dictionary && !canAdd( board, word, row, col, 'a' ) ) {
    return false;
  }

  pthread_mutex_lock( &lock );

  // add the word to the board
  for( int i = 0; i < wordLength; i++ ) {
    board->board[row * board->colSize + col + i] = word[i];
  }
  pthread_mutex_unlock( &lock );

  // if everything works, we can return true
  return true; 
}

// handle adding letters across the board
bool addDown( ScrabbleBoard *board, char *word, int row, int col ) {

  // get the length of the word
  int wordLength = strlen( word );
  

  // ensure row and col are within bounds
  if( row < 0 || row + wordLength > board->rowSize || col < 0 || col >= board->colSize || !downCheck( row, col, word ) ) {
    return false;
  }

  // if dictionary, ensure no invalid words are added
  if(dictionary && !canAdd( board, word, row, col, 'd' ) ) {
    return false;
  }

  // add the word to the board
  pthread_mutex_lock( &lock );

  for( int i = 0; i < wordLength; i++ ) {
    board->board[ (row + i) * board->colSize + col ] = word[i];
  }
  pthread_mutex_unlock( &lock );

  // if everything works, we can return true
  return true; 
}

// ---------------------------------------------------------------------------------------------------------

/** handle a client connection, close it when we're done. */
void *handleClient( void * sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( *((int *)sock), "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ WORD_LIMIT + 1 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {

      // across
      if( strcmp( cmd, "across" ) == 0 ) {
        // get the row, col, and word validly
        int row, col;
        char word[ WORD_LIMIT + 1 ];

        // checks for validity in the input ( this command can be given over multiple lines )
        if( fscanf( fp, "%d %d %26s", &row, &col, word ) == 0 || !isValidWord( word ) ) {
          fprintf( fp, "Invalid command\ncmd> " );
          continue;
        }

        // ready to add across ( error handling will occur within across function )
        if( !addAcross( scrabbleBoard, word, row, col ) ) {
          fprintf( fp, "Invalid command\ncmd> " );
          continue;
        };
        
      }
      // down
      else if ( strcmp( cmd, "down" ) == 0 ) {
        // get the row, col, and word validly
        int row, col;
        char word[ WORD_LIMIT + 1 ];

        // checks for validity in the input ( this command can be given over multiple lines )
        if( fscanf( fp, "%d %d %26s", &row, &col, word ) == 0 || !isValidWord( word ) ) {
          fprintf( fp, "Invalid command\ncmd> " );
          continue;
        }

        // ready to add across ( error handling will occur within across function )
        if( !addDown( scrabbleBoard, word, row, col ) ) {
          fprintf( fp, "Invalid command\ncmd> " );
          continue;
        };
      }
      // board
      else if ( strcmp( cmd, "board" ) == 0 ) {
        // print out the board
        printBoard( fp, scrabbleBoard );
      }
      else {
        fprintf( fp, "Invalid command\n" );
      }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

// Tell the server to stop running before from a signal interrupt
static bool running = true; 

// handle the signal interrupt
void terminationHandler( int serverSocket ) {
  // Free the board
  free( scrabbleBoard->board );
  free( scrabbleBoard );

  // set running to false
  running = false;

  // exit the program
  exit( EXIT_SUCCESS );
}

int main( int argc, char *argv[] ) {
  // use arguments to create size of board
  if( argc != 3 ) {
    fail( "usage: scrabbleServer <rows> <cols>" );
  }

  // read in the row and cols 
  int rows, cols; 
  if( sscanf( argv[1], "%d", &rows ) != 1 ) {
    fail( "usage: scrabbleServer <rows> <cols>" );
  }
  if( sscanf( argv[2], "%d", &cols ) != 1 ) {
    fail( "usage: scrabbleServer <rows> <cols>" );
  }

  // allocate two dimensional row x col array
  char *board = malloc( rows * cols * sizeof( char ) + 1);
  memset( board, ' ', rows * cols * sizeof( char ) );

  // create the scrabble board and set the parameters
  scrabbleBoard = (ScrabbleBoard *) malloc( sizeof( ScrabbleBoard ) );
  scrabbleBoard->rowSize = rows;
  scrabbleBoard->colSize = cols;
  scrabbleBoard->board = board;

  // Establish the interrupt handler 
  signal( SIGINT, terminationHandler );

  // Open the word list file
  if( (dict = fopen( "words.txt", "r" )) != NULL ) {
    
    dictionary = true; 
  }
  
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( running ) {
    // Accept a client connection.
    int *sock = malloc( sizeof( int * ) );
    *sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    // thread to handle the client
    pthread_t threadID;
    if ( pthread_create( &threadID, NULL, handleClient, sock ) != 0 )
      fail( "Could not start thread\n" );

    // detach the thread
    if ( pthread_detach( threadID ) != 0 )
      fail( "Could not detach thread\n" );
  }

  // close the server socket (never gets here)
  close( servSock );

  printf("Server shutting down\n");
  
  // This is never reached, everything is handled in the termination handler
  return EXIT_SUCCESS;
}
