#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26012"

/** invalid command */
#define INCMD "Invalid command\n"

/** Maximum word length */
#define WORD_LIMIT 26

/** the board */
char **board;

/** semaphore for the board */
sem_t sem;

/** row in the board */
int *row;

/** col in the board */
int *col;

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(EXIT_FAILURE);
}

/** handle a client connection, close it when we're done. */
void *handleClient(void *sock)
{
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int *newsock = sock;
  FILE *fp = fdopen(*newsock, "a+");

  // Prompt the user for a command.
  fprintf(fp, "cmd> ");

  // Temporary values for parsing commands.
  char whole[100];
  char cmd[11];
  int r = 0;
  int c = 0;
  char word[28];
  while (fscanf(fp, "%99[^\n]", whole) == 1)
  {
    int numMatch = sscanf(whole, "%10s%d%d%27s", cmd, &r, &c, word);
    if (strcmp(cmd, "quit") == 0)
    {
      break;
    }
    // check if command is valid
    if (strcmp(cmd, "across") == 0)
    {
      // invalid if its less than 4
      if (numMatch == 4)
      {
        // invalid if exceeds space on the board
        if (c < 0 || c + strlen(word) > *col)
        {
          fprintf(fp, INCMD);
        }
        // invalid if off the board(row)
        else if (r < 0 || r >= *row)
        {
          fprintf(fp, INCMD);
        }
        // invalid if the word is too long
        else if (strlen(word) == 27)
        {
          fprintf(fp, INCMD);
        }
        else
        {
          // check if user can successfully place this on the board
          sem_wait(&sem);
          int canPlace = 1;
          for (int k = 0; k < strlen(word); k++)
          {
            // invalid if the letter is not within a-z
            // invalid if the letter doesn't match what is currently on board
            if (word[k] < 'a' || word[k] > 'z' || (board[r][c + k] != ' ' && board[r][c + k] != word[k]))
            {
              canPlace = 0;
              break;
            }
          }
          if (canPlace == 0)
          {
            fprintf(fp, INCMD);
          }
          else
          {
            // places the word down on the board
            for (int k = 0; k < strlen(word); k++)
            {
              board[r][c + k] = word[k];
            }
          }
          sem_post(&sem);
        }
      }
      else
      {
        fprintf(fp, INCMD);
      }
    }
    else if (strcmp(cmd, "down") == 0)
    {
      // invalid if its less than 4
      if (numMatch == 4)
      {
        // invalid if exceeds space on the board
        if (r < 0 || r + strlen(word) > *row)
        {
          fprintf(fp, INCMD);
        }
        // invalid if off the board(col)
        else if (c < 0 || c >= *col)
        {
          fprintf(fp, INCMD);
        }
        // invalid if the word is too long
        else if (strlen(word) == 27)
        {
          fprintf(fp, INCMD);
        }
        else
        {
          // check if user can successfully place this on the board
          sem_wait(&sem);
          int canPlace = 1;
          for (int k = 0; k < strlen(word); k++)
          {
            // invalid if the letter is not within a-z
            // invalid if the letter doesn't match what is currently on board
            if (word[k] < 'a' || word[k] > 'z' || (board[r + k][c] != ' ' && board[r + k][c] != word[k]))
            {
              canPlace = 0;
              break;
            }
          }
          if (canPlace == 0)
          {
            fprintf(fp, INCMD);
          }
          else
          {
            // places the word down on the board
            for (int k = 0; k < strlen(word); k++)
            {
              board[r + k][c] = word[k];
            }
          }
          sem_post(&sem);
        }
      }
      else
      {
        fprintf(fp, INCMD);
      }
    }
    else if (strcmp(cmd, "board") == 0)
    {
      // prints the board
      sem_wait(&sem);
      fprintf(fp, "+");
      for (int i = 0; i < *col; i++)
      {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
      for (int i = 0; i < *row; i++)
      {
        fprintf(fp, "|");
        for (int j = 0; j < *col; j++)
        {
          fprintf(fp, "%c", board[i][j]);
        }
        fprintf(fp, "|\n");
      }
      fprintf(fp, "+");
      for (int i = 0; i < *col; i++)
      {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
      sem_post(&sem);
    }
    else
    {
      fprintf(fp, INCMD);
    }

    // Prompt the user for the next command.
    fprintf(fp, "cmd> ");
    // reset all the previous values
    for (int i = 0; i < 100; i++)
    {
      whole[i] = '\0';
    }
    for (int i = 0; i < 11; i++)
    {
      cmd[i] = '\0';
    }
    for (int i = 0; i < 28; i++)
    {
      word[i] = '\0';
    }
    r = 0;
    c = 0;
  }
  // Close the connection with this client.
  fclose(fp);
  return NULL;
}

int main(int argc, char *argv[])
{
  // error checking the arguments given
  if (argc != 3)
  {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  row = (int *)malloc(sizeof(int));
  col = (int *)malloc(sizeof(int));
  // rows
  *row = atoi(argv[1]);
  // columns
  *col = atoi(argv[2]);
  if (*row <= 0 || *col <= 0)
  {
    fail("usage: scrabbleServer <rows> <cols>");
  }
  // creating the board
  board = (char **)calloc(*row, sizeof(char *));
  for (int i = 0; i < *row; i++)
  {
    board[i] = (char *)calloc(*col, sizeof(char));
  }

  // initialize the board content to be all blank
  for (int i = 0; i < *row; i++)
  {
    for (int j = 0; j < *col; j++)
    {
      board[i][j] = ' ';
    }
  }

  // intializing semaphore for locking the board
  sem_init(&sem, 0, 1);
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if (getaddrinfo(NULL, PORT_NUMBER, &addrCriteria, &servAddr))
    fail("Can't get address info");

  // Try to just use the first one.
  if (servAddr == NULL)
    fail("Can't get address");

  // Create a TCP socket
  int servSock = socket(servAddr->ai_family, servAddr->ai_socktype,
                        servAddr->ai_protocol);
  if (servSock < 0)
    fail("Can't create socket");

  // Bind to the local address
  if (bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0)
    fail("Can't bind socket");

  // Tell the socket to listen for incoming connections.
  if (listen(servSock, 5) != 0)
    fail("Can't listen on socket");

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  // a growing list for each port
  int cap = 5;
  int *vList = (int *)malloc(cap * sizeof(int));
  int count = 0;

  while (true)
  {
    // Accept a client connection.
    int sock = accept(servSock, (struct sockaddr *)&clntAddr, &clntAddrLen);
    if (count == cap - 1)
    {
      cap *= 2;
      vList = (int *)realloc(vList, cap * sizeof(int));
    }
    count++;
    vList[count] = sock;
    pthread_t thread;
    pthread_create(&thread, NULL, handleClient, &vList[count]);
    pthread_detach(thread);
  }

  // Stop accepting client connections (never reached).
  close(servSock);

  // free the board
  for (int i = 0; i < *row; i++)
  {
    free(board[i]);
  }

  free(board);
  free(row);
  free(col);

  return 0;
}
