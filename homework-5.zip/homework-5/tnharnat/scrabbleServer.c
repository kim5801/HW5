/**
 * @file scrabbleServer.c
 * @author Teddy Harnatkiewicz (tnharnat@ncsu.edu)
 * @brief scrabble but there's no dictionary
 * @version 0.1
 * @date 2022-11-17
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26120"

/** Maximum word length */
#define WORD_LIMIT 26

char * board;
int rows;
int cols;
sem_t updateBoard;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/**
 * @brief draws the board for a client
 * 
 * @param fp file pointer
 */
void drawBoard(FILE * fp) {
  sem_wait(&updateBoard);
  fprintf(fp, "+");
  for(int i = 0; i < cols; i++) {
    fprintf(fp, "-");  
  }
  fprintf(fp, "+\n");
  for(int i = 0; i < rows; i++) {
    for(int j = -1; j < cols + 1; j++) {
      if(j == -1 || j == cols)
        fprintf(fp, "|");
      else
        fprintf(fp, "%c", *(board + j + cols * i));
    }
    fprintf(fp, "\n");
  }
  fprintf(fp, "+");
  for(int i = 0; i < cols; i++) {
    fprintf(fp, "-");  
  }
  fprintf(fp, "+\n");
  sem_post(&updateBoard);
}

/**
 * @brief check the word is all lowercase
 * 
 * @param word word to check
 * @return int 0 if false 1 if true
 */
int checkWord(char * word) {
  for(int i = 0; i < strlen(word); i++) {
    if(!islower(word[i]))
      return 0;
  }
  return 1;
}

/**
 * @brief check if the placement of the word is valid
 * 
 * @param word word to check
 * @param row row to start
 * @param col col to start
 * @param direction across or down
 * @return int 0 if fail 1 if success
 */
int checkPlacement(char * word, int row, int col, char direction) {
  if(direction == 'a') {
    for(int i = 0; i < strlen(word); i++) {
      if(board[col + cols * row + i] != ' ' && board[col + cols * row + i] != word[i])
        return 0;
    }
    return 1;
  } else if(direction == 'd') {
    for(int i = 0; i < strlen(word); i++) {
      if(board[col + cols * row + i * cols] != ' ' && board[col + cols * row + i * cols] != word[i])
        return 0;
    }
    return 1;
  }
  return 0;
}

/**
 * @brief actually update the board with the word
 * 
 * @param word word to play
 * @param row row to start at 
 * @param col col to start at
 * @param direction across or down (a or d)
 */
void playWord(char * word, int row, int col, char direction) {
  sem_wait(&updateBoard);
  if(direction == 'a') {
    for(int i = 0; i < strlen(word); i++) {
      board[col + cols * row + i] = word[i];
    }
  } else {
    for(int i = 0; i < strlen(word); i++) {
      board[col + cols * row + i * cols] = word[i];
    }
  }
  sem_post(&updateBoard);
}

/** handle a client connection, close it when we're done. */
void *handleClient( void * arg ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int sock = *(int *)arg;
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ] = {'\0'};
  while ( fscanf( fp, "%10s", cmd ) == 1 && strcmp( cmd, "quit" ) != 0 ) {
    
    if(strcmp(cmd, "across") != 0 && strcmp(cmd, "down") != 0 && strcmp(cmd, "board") != 0)
      fprintf(fp, "Invalid command\n");
    else if(strcmp(cmd, "board") == 0)
      drawBoard(fp);
    else if(strcmp(cmd, "across") == 0) {
      char word[WORD_LIMIT + 2] = {'\0'};
      int row;
      int col;
      if(fscanf(fp, "%d %d %27s", &row, &col, word) != 3 || row > rows - 1 || row < 0 || col > cols - 1 || col < 0) 
        fprintf(fp, "Invalid command\n");
      else if(word[WORD_LIMIT] != '\0' || strlen(word) > cols - col)
        fprintf(fp, "Invalid command\n");
      else if(checkWord(word) == 0)
        fprintf(fp, "Invalid command\n");
      else if(checkPlacement(word, row, col, 'a') == 0)
        fprintf(fp, "Invalid command\n");
      else
        playWord(word, row, col, 'a');
    } else {
      char word[WORD_LIMIT + 2] = {'\0'};
      int row;
      int col;
      if(fscanf(fp, "%d %d %27s", &row, &col, word) != 3 || row > rows - 1 || row < 0 || col > cols - 1 || col < 0) 
        fprintf(fp, "Invalid command\n");
      else if(word[WORD_LIMIT] != '\0' || strlen(word) > rows - row)
        fprintf(fp, "Invalid command\n");
      else if(checkWord(word) == 0)
        fprintf(fp, "Invalid command\n");
      else if(checkPlacement(word, row, col, 'd') == 0)
        fprintf(fp, "Invalid command\n");
      else
        playWord(word, row, col, 'd');
    }
    

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  if(sscanf(argv[1], "%d", &rows) != 1 || sscanf(argv[2], "%d", &cols) != 1 || argc != 3)
    fail("usage: scrabbleServer <rows> <cols>");
  board = (char *)malloc(rows * cols * sizeof(char));
  memset(board, ' ', rows * cols);
  sem_init(&updateBoard, 0, 1);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    pthread_t thread;
    if(pthread_create(&thread, NULL, handleClient, (void *)&sock) != 0)
      fail("Cannot Make Thread");
    pthread_detach(thread);
    
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  free(board);
  
  return 0;
}
