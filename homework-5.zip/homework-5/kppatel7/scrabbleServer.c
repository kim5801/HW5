#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26316"

/** Maximum word length */
#define WORD_LIMIT 26

// Print out an error message and exit.
static void fail(char const *message)
{
  fprintf(stderr, "%s\n", message);
  exit(EXIT_FAILURE);
}

/**
 *all error checks on the game when trying to make a move
 * @param row row to make move in
 * @param col col to make move in
 * @param userWord word to add to board
 * @param rowSize max row size
 * @param colSize max col size
 * @param board existing board
 * @param across bool representing orientation of the move
 * @return true if no error detected
 * @return false if error detected
 */
bool errorChecks(int row, int col, char userWord[], int rowSize, int colSize, char board[rowSize][colSize], bool across)
{
  // check to see if string is lowercase
  for (int i = 0; i < strlen(userWord); i++)
  {
    if (!islower(userWord[i]))
    {
      return false;
    }
  }

  // make sure the string doesn't go off the board
  if (row < 0 || row > rowSize - 1 || col < 0 || col > colSize - 1)
  {
    return false;
  }

  // error checks that are dependent on direction of move
  if (across)
  {
    // check to see if the command falls off the board going across
    if ((col + strlen(userWord)) > colSize)
    {
      return false;
    }

    // make sure that string are either blank or connect to an existing matching letter going across
    for (int i = col; i < col + strlen(userWord); i++)
    {
      if (board[row][i] != ' ' && board[row][i] != userWord[i - col])
      {
        return false;
      }
    }
  }
  else //error checks for making a move going down
  {
    // check to see if it falls off the board going down
    if ((row + strlen(userWord)) > rowSize)
    {
      return false;
    }

    // make sure that string are either blank or connect to an existing matching letter going down
    for (int i = row; i < row + strlen(userWord); i++)
    {
      if (board[i][col] != ' ' && board[i][col] != userWord[i - row])
      {
        return false;
      }
    }
  }

  return true;
}

/** handle a client connection, close it when we're done. */
void *handleClient(int sock, int row, int col, char board[row][col])
{
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen(sock, "a+");

  //intialize board to empty
  for (int i = 0; i < row; i++)
  {
    for (int j = 0; j < col; j++)
    {
      board[i][j] = ' ';
    }
  }

  // initial prompt for a command
  fprintf(fp, "cmd> ");

  // Temporary values for parsing commands.
  char cmd[11];
  while (fscanf(fp, "%10s", cmd) == 1 && strcmp(cmd, "quit") != 0)
  {

    // error check user command for uppercase letters
    for (int i = 0; i < strlen(cmd); i++)
    {
      if (!(islower(cmd[i])))
      {
        fprintf(fp, "Invalid command\n");
        goto repromt;
      }
    }

    // if command is across
    if (strcmp("across", cmd) == 0)
    {
      // read in moves and scrabble word
      int rowMove;
      int colMove;
      char scarbbleWord[WORD_LIMIT];
      fscanf(fp, "%d %d %s", &rowMove, &colMove, scarbbleWord);

      //check for valid move, if so change the board
      if (errorChecks(rowMove, colMove, scarbbleWord, row, col, board, true))
      {
  
        for (int i = colMove; i < colMove + strlen(scarbbleWord); i++)
        {
          board[rowMove][i] = scarbbleWord[i - colMove];
         
        }
        
      }
      else //if there is a error print error message and reprompt
      {
        fprintf(fp, "Invalid command\n");
        goto repromt;
      }
    }

    // if command is across
    if (strcmp("down", cmd) == 0)
    {
      // read in moves and string
      int rowMove;
      int colMove;
      char scarbbleWord[WORD_LIMIT];
      fscanf(fp, "%d %d %s", &rowMove, &colMove, scarbbleWord);
      //check if valid move , is so change board
      if (errorChecks(rowMove, colMove, scarbbleWord, row, col, board, false))
      {
        for (int i = rowMove; i < rowMove + strlen(scarbbleWord); i++)
        {
          board[i][colMove] = scarbbleWord[i - rowMove];
        }
        //fprintf(fp, "%d", rowMove);
      }
      else // invalid move
      {
        fprintf(fp, "Invalid command\n");
        goto repromt;
      }
    }

    // if command is board print board with the boarder
    if (strcmp("board", cmd) == 0)
    {

      // print top border line
      fprintf(fp, "+");
      for (int i = 0; i < col; i++)
      {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");

      // go through board and print the rows with  | symbols around them
      for (int i = 0; i < row; i++)
      {
        fprintf(fp, "|");
        for (int j = 0; j < col; j++)
        {
          fprintf(fp, "%c", board[i][j]);
        }
        // print new line for each row in grid
        fprintf(fp, "|");
        fprintf(fp, "\n");
      }

      // print bottom border line
      fprintf(fp, "+");
      for (int i = 0; i < col; i++)
      {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
    }


    //goto label to repromt user
    repromt:
    // Prompt the user for the next command.
    fprintf(fp, "cmd> ");
  }

  // Close the connection with this client.
  fclose(fp);
  return NULL;
}

int main(int argc, char *argv[])
{
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if (getaddrinfo(NULL, PORT_NUMBER, &addrCriteria, &servAddr))
    fail("Can't get address info");

  // Try to just use the first one.
  if (servAddr == NULL)
    fail("Can't get address");

  // Create a TCP socket
  int servSock = socket(servAddr->ai_family, servAddr->ai_socktype,
                        servAddr->ai_protocol);
  if (servSock < 0)
    fail("Can't create socket");

  // Bind to the local address
  if (bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0)
    fail("Can't bind socket");

  // Tell the socket to listen for incoming connections.
  if (listen(servSock, 5) != 0)
    fail("Can't listen on socket");

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while (true)
  {
    // Accept a client connection.
    int sock = accept(servSock, (struct sockaddr *)&clntAddr, &clntAddrLen);

    int rowMax = atoi(argv[1]);
    int colMax = atoi(argv[2]);
    char board[rowMax][colMax];

    handleClient(sock, rowMax, colMax, board);
  }

  // Stop accepting client connections (never reached).
  close(servSock);

  return 0;
}
