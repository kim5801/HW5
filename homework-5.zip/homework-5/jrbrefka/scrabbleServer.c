#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26184"

/** Maximum word length */
#define WORD_LIMIT 26

/** The representation of the scrabble board */
char **board;

/** The number of rows in the board */
int rows;

/** The number of columns in the board*/
int cols;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

sem_t boardSem;

/** handle a client connection, close it when we're done. */
void *handleClient( void *arg ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int sock = *((int *)arg);
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
            
    if ( strcmp( "across", cmd ) == 0 ) {
      int r = -1;
      int c = -1;
      char word[ WORD_LIMIT + 1 ] = "";
      if ( fscanf( fp, "%d %d %26s", &r, &c, word ) != 3 ) {
        fprintf( fp, "Invalid command\n" );
      } else {
        sem_wait( &boardSem );
        int wordLen = strlen( word );
        bool valid = true;
        //check if word is out of bounds
        if ( r < 0 || c < 0 || c + wordLen > cols || r >= rows ) {
          valid = false;
        } else {
          //check if word has non lower case letters or disagrees with board
          for ( int i = 0; i < wordLen; i++ ) {
            if ( !( word[ i ] >= 'a' && word[ i ] <= 'z' ) || ( board[ r ][ c + i ] != '\0' && board[ r ][ c + i ] != word[ i ] ) )
              valid = false;
          }
        }
        
        //update board if command is valid
        if ( valid ) {
          for ( int i = 0; i < wordLen; i++ ) {
            board[ r ][ c + i ] = word[ i ];
          }
        } else {
          fprintf( fp, "Invalid command\n" );
        }
        sem_post( &boardSem );
      }
    } else if ( strcmp( "down", cmd ) == 0 ) {
      int r = -1;
      int c = -1;
      char word[ WORD_LIMIT + 1 ] = "";
      if ( fscanf( fp, "%d %d %26s", &r, &c, word ) != 3 ) {
        fprintf( fp, "Invalid command\n" );
      } else {
        sem_wait( &boardSem );
        int wordLen = strlen( word );
        bool valid = true;
        //check if word is out of bounds
        if ( r < 0 || c < 0 || r + wordLen > rows || c >= cols ) {
          valid = false;
        } else {
          //check if word has non lower case letters or disagrees with board
          for ( int i = 0; i < wordLen; i++ ) {
            if ( !( word[ i ] >= 'a' && word[ i ] <= 'z' ) || ( board[ r + i ][ c ] != '\0' && board[ r + i ][ c ] != word[ i ] ) )
              valid = false;
          }
        }
        
        //update board if command is valid
        if ( valid ) {
          for ( int i = 0; i < wordLen; i++ ) {
            board[ r + i ][ c ] = word[ i ];
          }
        } else {
          fprintf( fp, "Invalid command\n" );
        }
        sem_post( &boardSem );
      }
    } else if ( strcmp( "board", cmd ) == 0 ) {
      sem_wait( &boardSem );
      
      fprintf( fp, "+" );
      for ( int i = 0; i < cols; i++ ) {
        fprintf( fp, "-" );
      }
      fprintf( fp, "+\n" );
      for ( int i = 0; i < rows; i++ ) {
        fprintf( fp, "|" );
        for ( int j = 0; j < cols; j++ ) {
          if ( board[ i ][ j ] == '\0' ) {
            fprintf( fp, " " );
          } else {
            fprintf( fp, "%c", board[ i ][ j ] );
          }
        }
        fprintf( fp, "|\n" );
      }
      fprintf( fp, "+" );
      for ( int i = 0; i < cols; i++ ) {
        fprintf( fp, "-" );
      }
      fprintf( fp, "+\n" );
      
      sem_post( &boardSem );
    } else {
      fprintf( fp, "Invalid command\n" );
    }
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;
  
  sem_init( &boardSem, 0, 1 );
  
  rows = atoi( argv[ 1 ] );
  cols = atoi( argv[ 2 ] );
  if ( rows == 0 || cols == 0 || argc != 3 )
    fail( "usage: scrabbleServer <rows> <cols>" );
  
  board = (char **)malloc( rows * sizeof( char * ) );
  for ( int i = 0; i < rows; i++ ) {
    board[ i ] = (char *)malloc( sizeof( char ) * cols );
  }
  
  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  int sock[ 1 ];
  while ( true  ) {
    // Accept a client connection.
    sock[ 0 ] = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_t thread;
    pthread_create( &thread, NULL, handleClient, sock );
    pthread_detach( thread );
    //handleClient( sock );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
