/**
  @file scrabbleServer.c
  @author Erin Grouge
  @author Dr. Sturgill
  This program simulates a game of scrabble using client and server communication.
*/
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26132"

/** Maximum word length */
#define WORD_LIMIT 26

/** The number of rows on the board */
int rows;
/** The number of columns on the board */
int cols;
/** The pointer to the board 2D array */
char **board;
/** The string used to print the border more efficiently */
char *border;
/** The lock used for synchronization */
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out an uasge and exit.
static bool usage() {
  fprintf( stderr, "usage: scrabbleServer <rows> <cols>\n" );
  exit( EXIT_FAILURE );
}

/** 
  Performs the across play if the input is valid
  @param r the row for the play
  @param c the column for the play
  @param word the word for the play
  @return success true if the play was successfully made, false if not
*/
static bool across(int r, int c, char * word){
  // Checks if row and col are in bounds
  if(r < 0 || r >= rows || c < 0 || c >= cols){
    return false;
  }
  // Checks if row + word length goes out of bounds
  if(c + strlen(word) > cols){
    return false;
  }
  // Checks for invalid characters
  for(int i = 0; i < strlen(word); i++){
    if((word[i] - 'a') < 0 || (word[i] - 'a') > 25){
      return false;
    }
  }
  // Checks if it agrees with other words on board
  for(int i = 0; i < strlen(word); i++){
    if(!(board[r][c + i] == ' ' || board[r][c + i] == word[i])){
      return false;
    }
  }

  // If all checks passed, add word to board
  for(int i = 0; i < strlen(word); i++){
    board[r][c + i] = word[i];
  }
  return true;
}

/** 
  Performs the down play if the input is valid
  @param r the row for the play
  @param c the column for the play
  @param word the word for the play
  @return success true if the play was successfully made, false if not
*/
static bool down(int r, int c, char * word){
  // Checks if row and col are in bounds
  if(r < 0 || r >= rows || c < 0 || c >= cols){
    return false;
  }
  // Checks if row + word length goes out of bounds
  if(r + strlen(word) > rows){
    return false;
  }
  // Checks for invalid characters
  for(int i = 0; i < strlen(word); i++){
    if((word[i] - 'a') < 0 || (word[i] - 'a') > 25){
      return false;
    }
  }
  // Checks if it agrees with other words on board
  for(int i = 0; i < strlen(word); i++){
    if(!(board[r + i][c] == ' ' || board[r + i][c] == word[i])){
      return false;
    }
  }

  // If all checks passed, add word to board
  for(int i = 0; i < strlen(word); i++){
    board[r + i][c] = word[i];
  }
  return true;
}

/** 
  Prints the current status of the board
  @param fp the file pointer to print to 
*/
static void printBoard(FILE *fp){
  // Print top border
  fprintf(fp, "%s\n", border);

  // Print board
  for(int i = 0; i < rows; i++){
      fprintf(fp, "|");
      fprintf(fp, "%s", board[i]);
      fprintf(fp, "|\n");
  }

  // Print bottom border
  fprintf(fp, "%s\n", border);
}

/** 
  Handle a client connection, close it when we're done. 
  @param arg the socket used for communication
*/
void *handleClient( void *arg ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int * sock = (int *)arg;
  FILE *fp = fdopen( *sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];

  // While the client has entered a command and has not yet quit,
  // perform that operation.
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    
    // Acquire lock before performing operation
    pthread_mutex_lock(&mon);
    // Used to report invalid commands
    bool success = true;
    // If cmd equals board, print board
    if(strcmp(cmd, "board") == 0){
      // Check to make sure there is no more input
      if(fgetc(fp) != '\n'){
        success = false;
      } else { 
        printBoard(fp);
      }
    } 
    // If cmd equals across, add word across
    else if(strcmp(cmd, "across") == 0){
      // Scan in the row and column
      int r;
      int c;
      // If unsuccessful, set flag
      if(fscanf(fp, "%d %d", &r, &c) != 2){
        success = false;
      } 
      // Else, read in the word and perfom the play
      else {
        // Allocate space for the word and scan it in 
        char *word = (char *)malloc(WORD_LIMIT * sizeof(char) + 1);
        // If unsuccessful, set flag
        if(fscanf(fp, "%26s", word) != 1){
          success = false;
        } 
        // Else, perform across operation
        else {
          // Check for extra args
          if(fgetc(fp) != '\n'){
            success = false;
          } else { 
            success = across(r, c, word);
          }
        }
        free(word);
      }
    } else if(strcmp(cmd, "down") == 0){
      // Scan in the row and column
      int r;
      int c;
      // If unsuccessful, set flag
      if(fscanf(fp, "%d %d", &r, &c) != 2){
        success = false;
      } 
      // Else, read in the word and perfom the play
      else {
        // Allocate space for the word and scan it in 
        char *word = (char *)malloc(WORD_LIMIT * sizeof(char) + 1);
        // If unsuccessful, set flag
        if(fscanf(fp, "%26s", word) != 1){
          success = false;
        } 
        // Else, perform across operation
        else {
          // Check for extra args
          if(fgetc(fp) != '\n'){
            success = false;
          } else { 
            success = down(r, c, word);
          }
        }
        free(word);
      }
    } 
    // If cmd is anything else, report invalid command
    else {
      fprintf(fp, "Invalid command\n");
    }
    // If any operations were unsuccessful, report invalid command.
    if(!success){
      fprintf(fp, "Invalid command\n");
    }
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
    
    // Release lock
    pthread_mutex_unlock(&mon);
  }

  // Close the connection with this client and exit
  fclose( fp );
  pthread_exit(NULL);
}
/**
  Starting point of the program. It initializes and updates all necessary variables and 
  data structures and establishes the client server connection to perform scrabble.
  @param argc the number of arguments
  @param argv the list of arguments
  @return exit status
  Citation: https://www.geeksforgeeks.org/dynamically-allocate-2d-array-c/
*/
int main( int argc, char *argv[] ) {
  // Check for correct number of args
  if(argc != 3){
    usage();
  }
  // Parse the rows and columns to ints
  rows = atoi(argv[1]);
  cols = atoi(argv[2]);
  // If invalid, print usage
  if(rows <= 0 || cols <= 0){
    usage();
  }

  // Initialize board - dynamically allocate 2d array and set to blank space
  // Referenced https://www.geeksforgeeks.org/dynamically-allocate-2d-array-c/ 
  // for help in finding the best way to allocate the 2D board array.
  board = (char **)malloc(rows * sizeof(char *));
  for(int i = 0; i < rows; i++){
    board[i] = (char *)malloc(cols * sizeof(char));
    for(int j = 0; j < cols; j++){
        board[i][j] = ' ';
    }
  }
  // Create border for board() to make printing easier.
  border = (char *)malloc((cols + 3) * sizeof(char));
  border[0] = '+';
  for(int i = 1; i <= cols; i++){
    border[i] = '-';
  }
  border[cols + 1] = '+';
  border[cols + 2] = '\0';
  
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  // While running, accept connections and make a new thread to handle the client
  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    // Create thread to handle client then detach.
    pthread_t thread;
    pthread_create(&thread, NULL, handleClient, (void *) &sock);
    pthread_detach(thread);
  }

  // Stop accepting client connections (never reached).
  close( servSock );

  // Free allocated memory
  free(border);
  for(int i = 0; i < rows; i++){
    free(board[i]);
  }
  free(board);

  // Exit successfully...
  return 0;
}
