/**
* A file that lets people play scrabble over the internet
* @file scrabbleServer.c
* @author Jaden Abrams (jlabrams), David Sturgill (dbsturgi)
*/
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26130"
// the board that holds the words
char ** board = NULL;
// the header when displaying the board
char *headFoot = NULL;
// the board dimensions
int r, c;
// allows threads to see if the board is in use
bool inUse = false;
/** Maximum word length */
#define WORD_LIMIT 26
// monitor for synchronizing the threads
pthread_mutex_t mon = PTHREAD_MUTEX_INITIALIZER;
// condition variable so threads can wait for their turn
pthread_cond_t waitForBoard = PTHREAD_COND_INITIALIZER;
/**
* Print out a failure message to stderr and exit
*/
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}
/**
* Usage function
*/
static void usage() {
  printf("usage: scrabbleServer <rows> <cols>\n");
  exit( EXIT_FAILURE);
}
/**
* allocates and initializes the space for the board and header/footer
* @param row how many rows to make
* @param col how many columns to make
*/
static void makeBoard(int row, int col) {
  board = (char **) malloc(row * sizeof(char*)); // make the outer part of the board so it is indexable just like a 2d array
  for(int i = 0; i < row; i++) { // allocate inner space for every row of the array
    board[i] = (char *) malloc((col) * sizeof(char));
  }
  if(board == NULL) { // check that the allocatioon was successful
    fail("Can't make board!");
  }
  headFoot = (char *) malloc((col + 3) * sizeof(char)); // allocate the header/footer
  headFoot[0] = '+'; // fill in the header/footer so it looks pretty
  for(int i = 1; i < col + 1; i++) {
    headFoot[i] = '-';
  }
  headFoot[col + 1] = '+';
  headFoot[col + 2] = 0;
  for(int i = 0; i < row; i++) {// fill in board with blanks
    for(int j = 0; j < col; j++) {
        board[i][j] = ' ';
    }
  }
}

/**
* put the word across as long as it doesn't interfere with other words
* or goes off the board
* @param row the row to start the word
* @param col the column to start the word
* @param word the word to put
* @return if successfull, -1 otherwise
*/
static int putAcross(int row, int col, char *word) {
  int resStatus = -1;// default status is failure
  pthread_mutex_lock(&mon); // enter the monitor
  while(inUse) {// if the board is in use, wait for another thread to finish with it and signal
    pthread_cond_wait(&waitForBoard, &mon);
  }
  inUse = true; // say that you're using the board
  int wLen = strlen(word); // you can proceed if (row, col) is within bounds
                           // and the word is within bounds as well
  if(row < r && row > -1 && col < c && col > -1 && (col + wLen) <= c) {
    resStatus = 0; // set the status to valid and i to row to simplify later logic
    int i = row;
    for(int j = col; j < col + wLen; j++) {
      if(board[i][j] != ' ' && board[i][j] != word[j - col]) {
        resStatus = -1; // set status to fail and break if there is a conflict with another word
        break;
      }
    }
    if(!resStatus) { // we don't conflict with another word, so put the word on the board
      for(int j = col; j < col + wLen; j++) {
        board[i][j] = word[j - col];
      }
    }
  }
  inUse = false; // let other threads use the board by letting go of it and wake up waiting threads
  pthread_cond_signal(&waitForBoard);
  pthread_mutex_unlock(&mon);
  return resStatus;
}

/**
* put the word down as long as it doesn't interfere with other words
* or goes off the board
* @param row the row to start the word at
* @param col the column to start the word at
* @param word the word to put
* @param 0 if successful, -1 if othewise
*/
static int putDown(int row, int col, char *word) {
  int resStatus = -1; // default status is failure
  pthread_mutex_lock(&mon); // enter the monitor
  while(inUse) {// if another thread is using the board, wait till its available again
    pthread_cond_wait(&waitForBoard, &mon);
  }
  inUse = true; // make the board unavailable to others
  int wLen = strlen(word); // check that (row, col) is in bounds and the word is in bounds
  if(row < r && row > -1 && col < c && col > -1 && (row + wLen) <= r) {
    resStatus = 0; // this command is valid, for now...
    int j = col; // set j to column to make code easier to understand
    for(int i = row; i < row + wLen; i++) { // if we have a word conflict, mark status as failure and break
      if(board[i][j] != ' ' && board[i][j] != word[i - row]) {
        resStatus = -1;
        break;
      }
    }
    if(!resStatus) {// we don't have a conflict, so put the word on the board
      for(int i = row; i < row + wLen; i++) {
        board[i][j] = word[i - row];
      }
    }
  }
  // make the board available for other threads and let them know its available
  inUse = false;
  pthread_cond_signal(&waitForBoard);
  pthread_mutex_unlock(&mon);
  return resStatus;
}

/**
* send the board to the client
* @param fp the socket (as a file descriptor) to write to
*/
static void sendBoard(FILE *fp) {
  // enter the monitor and wait for the board to be available
  pthread_mutex_lock(&mon);
  while(inUse) {
    pthread_cond_wait(&waitForBoard, &mon);
  }
  inUse = true; // make the board unavailable to others
  fprintf(fp, "%s\n", headFoot);
  for(int i = 0; i < r; i++) { // print out the board
    // we have to print it out the board one character at a time
    // because fprintf doesn't like strings with just spaces :/
    fputc('|', fp);
    fputs(board[i], fp);
    fputs("|\n", fp);
  }
  fprintf(fp, "%s\n", headFoot);
  inUse = false; // make the board available to others and let waiting threads know
  pthread_cond_signal(&waitForBoard);
  pthread_mutex_unlock(&mon);
}

/** 
* handle a client connection, close it when we're done.
* @param arg a pointer to the socket
* @return NULL 
*/
static void *handleClient( void *arg ) {

  int *sockPtr = (int *) arg;
  int sock = *sockPtr;
  free(arg);
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // values for controlling dynamically allocated command string to stop buffer overflow
  int cmdLen = 0;
  int cmdCap = 10;
  char *cmd;
  while ( 1 ) {
    // use this flag to prevent double frees
    bool errorInAOrD = false;
    // use calloc to make sure that the command is null terminated, no matter what
    cmd = (char *) calloc(cmdCap, sizeof(char));
    cmdLen = 0;
    // put user input into the command string, one character at a time
    char ch = fgetc(fp);
    while(ch != EOF && ch != '\n') {
      if(cmdLen == cmdCap) {
        cmdCap = cmdCap * 2;
        cmd = (char *) realloc(cmd, cmdCap);
      }
      cmd[cmdLen] = ch;
      cmdLen++;
      ch = fgetc(fp);
    }
    // put root of the command into maincmd
    char maincmd[11];
    int row, col; // row and column for commands go in here 
    char word[28]; // we have a fixed length word, so make this a bit bigger so we can see if its just too big
    int matches = sscanf(cmd, "%10s %d %d %27s", maincmd, &row, &col, word);
    if(!strcmp("across", maincmd)) {
      // process across command
      if(matches != 4) { // check for malformed across commands
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        free(cmd);
        errorInAOrD = true;
        continue;
      }
      if(strlen(word) > 26) { // check if the word is too long
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        free(cmd);
        errorInAOrD = true;
        continue;
      }
      for(int i = 0; i < strlen(word); i++) { // check if the word has any invalid characters
        if(!islower(word[i])) {
          fprintf(fp, "Invalid command\n");
          fprintf( fp, "cmd> " );
          free(cmd);
          errorInAOrD = true;
          break;
        }
      }
      if(errorInAOrD) { // make sure we don't print words with invalid characters
        continue;
      }
      if(putAcross(row, col, word)) { // give the parameters to putAcross and see if it puts it in
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        free(cmd);
        errorInAOrD = true;
        continue;
      }
    }
    else if(!strcmp("down", maincmd)) {
      // process down command
      if(matches != 4) { // check for malformed down commands
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        free(cmd);
        errorInAOrD = true;
        continue;
      }
      if(strlen(word) > 26) { // check if the word is too long
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        free(cmd);
        errorInAOrD = true;
        continue;
      }
      for(int i = 0; i < strlen(word); i++) { // check if the word has any invalid characters
        if(!islower(word[i])) {
          fprintf(fp, "Invalid command\n");
          fprintf( fp, "cmd> " );
          free(cmd);
          errorInAOrD = true;
          break;
        }
      }
      if(errorInAOrD) { // make sure we don't print words with invalid characters
        continue;
      }
      if(putDown(row, col, word)) { // give the parameters to putDown and see if it accepts them
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        free(cmd);
        continue;
      }
    }
    else if(!strcmp("board", maincmd)) { // we got the board, so send the user the board
      // process board command
      sendBoard(fp);
    }
    else if(!strcmp("quit", maincmd)) { // we got quit, so terminate the thread
      fprintf( fp, "%s\n", cmd );
      free(cmd);
      break;
    }
    else { // we got something wonky, so let the user know, ask for more input, and move on
      fprintf(fp, "Invalid command\n");
      fprintf( fp, "cmd> " );
      free(cmd);
      continue;
    }

    // Prompt the user for the next command.
    if(!errorInAOrD) { // ask for more input and reset cmd ONLY if we got 
      fprintf( fp, "cmd> " );
      //free(word);
      free(cmd);
    }
    
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

/**
* The main function for the server. This sets up the board,
* listens for and establishes connections, and give them to
* delegator threads that interact with the client
* @param argc the number of arguments given
* @param argv the arguments given
* @return program exit status
*/
int main( int argc, char *argv[] ) {

  // check if we got invalid number of arguments
  if(argc != 3) {
    usage();
  }

  // parse the board dimensions and check that they're actually numbers
  if(!sscanf(argv[1], "%d", &r)) {
    usage();
  }
  if(!sscanf(argv[2], "%d", &c)) {
    usage();
  } // check that the dimensions we got are valid
  if(r < 1 || c < 1) {
    usage();
  }
  // create the board
  makeBoard(r, c);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    int *sockPtr = (int *) malloc(sizeof(int));
    *sockPtr = sock;
    pthread_t clientThread;
    if(pthread_create(&clientThread, NULL, handleClient, (void *) sockPtr) != 0) {
      fail("Couldn't make client thread");
    }
    if(pthread_detach(clientThread) != 0) {
      fail("Couldn't detach client thread");
    }
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
