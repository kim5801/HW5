#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26226"

/** Maximum word length */
#define WORD_LIMIT 26

/** Number of rows in gameboard */
int r;

/** Number of columns in gameboard */
int c;

/** GameBoard state */
char** gameBoard;

/** Lock access to game board */
static pthread_mutex_t mon;

/** Prints the current state if the board for the client */
void board(FILE *fileP) {

  // Prints top of border
  fprintf(fileP, "+");
  for (int i = 0; i < c; i++) {
    fprintf(fileP, "-");
  }
  fprintf(fileP, "+");
  fprintf(fileP, "\n");

  // Prints border sides and state
  for (int i = 0; i < r; i++) {
    fprintf(fileP, "|");
    for (int j = 0; j < c; j++) {
      fprintf(fileP, "%c", gameBoard[i][j]);
    }
    fprintf(fileP, "|");
    fprintf(fileP, "\n");
  }

  // Prints bottom of border
  fprintf(fileP, "+");
  for (int i = 0; i < c; i++) {
    fprintf(fileP, "-");
  }
  fprintf(fileP, "+");
  fprintf(fileP, "\n");
}

/** Places a new word on the board going horizontally right from starting location */
void across(int row, int col, char *word, FILE *fileP) {
  int len = strlen(word);

  // Invalid command if location is off the board
  if ((row < 0 || row > r - 1) || (col < 0 || col > c - 1)) {
    fprintf(fileP, "Invalid command\n");
    return;
  }

  // Invalid command if word extends beyond the bounds of the board
  if (col + len > c) {
    fprintf(fileP, "Invalid command\n");
    return;
  }

  // Invalid command if word does not consist of 1 of 26 lowercased letters and does not conflict with already placed words
  for (int i = 0; i < len; i++) {
    if (word[i] < 97 || word[i] > 122) {
      fprintf(fileP, "Invalid command\n");
      return;
    }

    if (gameBoard[row][col + i] != ' ' && gameBoard[row][col + i] != word[i]) {
      fprintf(fileP, "Invalid command\n");
      return;
    }
  }

  // Update game state
  for (int i = 0; i < len; i++) {
    gameBoard[row][col + i] = word[i];
  }
}

/** Places a new word on the board going vertically down from starting location */
void down(int row, int col, char *word, FILE *fileP) {
  int len = strlen(word);

  // Invalid command if location is off the board
  if ((row < 0 || row > r - 1) || (col < 0 || col > c - 1)) {
    fprintf(fileP, "Invalid command\n");
    return;
  }

  // Invalid command if word extends beyond the bounds of the board
  if (row + len > r) {
    fprintf(fileP, "Invalid command\n");
    return;
  }

  // Invalid command if word does not consist of 1 of 26 lowercased letters and does not conflict with already placed words
  for (int i = 0; i < len; i++) {
    if (word[i] < 97 || word[i] > 122) {
      fprintf(fileP, "Invalid command\n");
      return;
    }

    if (gameBoard[row + i][col] != ' ' && gameBoard[row + i][col] != word[i]) {
      fprintf(fileP, "Invalid command\n");
      return;
    }
  }

  // Update game state
  for (int i = 0; i < len; i++) {
    gameBoard[row + i][col] = word[i];
  } 
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *socket ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.

  int sock = *(int*)socket;
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // User command parameters
  char *commandLine = (char *)malloc(65 * sizeof(char));
  char *comm = (char *)malloc(9 * sizeof(char));
  char *word = (char *)malloc((WORD_LIMIT + 1) * sizeof(char));
  char *invalid = (char *)malloc(2 * sizeof(char));
  char ch = ' ';

  // While there's still user input
  while ( fscanf( fp, "%c", &ch) == 1 && ch != EOF) {

    // Invalid command if the user enters a blank command. i.e just presses enter again
    if (ch == '\n') {
      fprintf(fp, "Invalid command\n");
      fprintf( fp, "cmd> " );
      continue;
    }

    commandLine[0] = ch;
    int size = 1;

    // Parse in user command
    while(fscanf(fp, "%c", &ch) == 1 && ch != '\n' && ch != EOF && size < 64) {
      commandLine[size++] = ch;
    }

    commandLine[size] = '\0';
    int pos = 0;
    sscanf(commandLine, "%8s%n", comm, &pos);
    int row = 0;
    int col = 0;

    // If user enters the "board" command
    if (strcmp( comm, "board") == 0) {

      // Invalid command if the board command has an extra argument
      if (sscanf(commandLine + pos, "%1s", invalid) > 0) {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }

      // Lock access to gameboard
      pthread_mutex_lock(&mon);
      board(fp);
      // Unlock access to gameboard
      pthread_mutex_unlock(&mon);

      // If user enters the "across" command
    } else if (strcmp( comm, "across") == 0) {

      // Invalid command if the across command has extra/too few arguments or the word argument is too long
      if (sscanf(commandLine + pos, "%15d%15d%27s%1s", &row, &col, word, invalid) != 3 || strlen(word) > WORD_LIMIT) {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }

      // Lock access to gameboard
      pthread_mutex_lock(&mon);
      across(row, col, word, fp);
      // Unlock access to gameboard
      pthread_mutex_unlock(&mon);

      // If user enters the "down" command
    } else if (strcmp( comm, "down") == 0) {

      // Invalid command if the down command has extra/too few arguments or the word argument is too long
      if (sscanf(commandLine + pos, "%15d%15d%27s%1s", &row, &col, word, invalid) != 3 || strlen(word) > WORD_LIMIT) {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }

      // Lock access to gameboard
      pthread_mutex_lock(&mon);
      down(row, col, word, fp);
      // Unlock access to gameboard
      pthread_mutex_unlock(&mon);

      // If user enters the "quit" command
    } else if (strcmp( comm, "quit") == 0) {

      // Invalid command if the quit command has an extra argument
      if (sscanf(commandLine + pos, "%1s", invalid) > 0) {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }
      break;

      // If user does not enter any of the previous 4 commands
    } else {
      fprintf(fp, "Invalid command\n");
    }
   
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Free parameter memory
  free(comm);
  free(word);
  free(commandLine);
  free(invalid);

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  // Check for valid command-line arguments
  if (argc != 3) {
    printf("usage: scrabbleServer <rows> <cols>\n");
    exit(EXIT_FAILURE);
  }
  if ((r = atoi(argv[1])) < 1 || (c = atoi(argv[2])) < 1) {
    printf("usage: scrabbleServer <rows> <cols>\n");
    exit(EXIT_FAILURE);
  }

  // Malloc memory for game board
  gameBoard = (char**)malloc(r * sizeof(char*) );
  for (int i = 0; i < r; i++) {
    gameBoard[i] = (char*)malloc(c * sizeof(char));
  }

  // Initialize game board
  for (int i = 0; i < r; i++) {
    for (int j = 0; j < c; j++) {
      gameBoard[i][j] = ' ';
    }
  }

  // Initialize mutex monitor
  pthread_mutex_init( &mon, NULL);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    // Create a new thread for each client connection
    pthread_t thread;
    pthread_create(&thread, NULL, handleClient, &sock);
    pthread_detach(thread);
  }

  // Free allocated gameboard memory
  for (int i = 0; i < r; i++) {
    free(gameBoard[i]);
  }
  free(gameBoard);

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
