#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26396"

/** Maximum word length */
#define WORD_LIMIT 26

/** Represents the maximum length a command should be without overflowing */
#define CMD_LIMIT WORD_LIMIT + 16

/** Represents expected number of command-line arguments */
#define CMD_ARGS 3

/** Character representation of an empty space in the board */
#define EMPTY_SPACE ' '

/** Character to be used on left and right of the game board as a border */
#define VERTICAL_BORDER "|"

/** Global variable for the game board to use while playing scrabble */
char board[ WORD_LIMIT ][ WORD_LIMIT ];

// Represents the number of rows and columns in the game board
int rows = 0, cols = 0;
// Semaphore used to prevent a race condition and indicate when a move is done
sem_t move;

// Print out an error message and exit.
static void fail( char const *message ) {
    fprintf( stderr, "%s\n", message );
    exit( EXIT_FAILURE );
}

/** 
 * Prints board with a border around the edge consisting of vertical bars on the left and right, dashes
 * along the top and bottom and plus signs in the corners 
 */
static void reportBoard( FILE *fp ) {
    sem_wait( &move );

    for( int i = 0; i < rows; i++ ) {
        fprintf( fp, "%s", VERTICAL_BORDER );
        for( int j = 0; j < cols; j++ ) {
            if( board[ i ][ j ] == '\0' )
                fprintf( fp, "%c", EMPTY_SPACE );
            else 
                fprintf( fp, "%c", board[ i ][ j ] );
        }
        fprintf( fp, "%s\n", VERTICAL_BORDER );
    }
    
    sem_post( &move );
}

/** Checks if provided numbers are out of bounds for the board */
static bool outofbound( int row, int col ) {
    if( row < 0 || row >= rows || col < 0 || col >= cols ) {
        return true;
    }
    return false;
}

/** Checks if provided word does not match existing letters on the board */
static bool invalidWord( char *word ) {
    for( int i = 0; i < strlen( word ); i++ )
        if( word[ i ] < 'a' || word[ i ] > 'z' )
            return true;

    return false;
}

/** Places provided word starting at the indicated row and column and moving right */
static bool putAcross( int row, int col, char *word ) {
    sem_wait( &move );
    // If anything is invalid (word length, position, letters)
    if( invalidWord( word ) || outofbound( row, col ) || strlen( word ) < 1 || 
                                            strlen( word ) + col > cols ) {
        sem_post( &move );
        return false;
    }
    
    int currIdx = 0;
    // check if any indexes don't match a letter and aren't empty
    for( int i = col; i < strlen( word ) + col; i++ ) {
        if( board[ row ][ i ] != EMPTY_SPACE && board[ row ][ i ] != word[ currIdx ] ) {
            sem_post( &move );
            return false;
        }
        currIdx++;
    }

    // reset current index of word
    currIdx = 0;
    for( int i = col; i < strlen( word ) + col; i++ ) {
        char curr = board[ row ][ i ];
        
        if( curr == EMPTY_SPACE )
            board[ row ][ i ] = word[ currIdx ];
        currIdx++;
    }
    sem_post( &move );
    return true;
}

/** Places provided word starting at the indicated row and column and moving down */
static bool putDown( int row, int col, char *word ) {
    sem_wait( &move );
    // If anything is invalid (word length, position, letters)
    if( invalidWord( word ) || outofbound( row, col ) || strlen( word ) < 1 || 
                                            strlen( word ) + row > rows ) {
        sem_post( &move );
        return false;
    }
    
    int currIdx = 0;

    //check if any indexes don't match a letter and aren't empty
    for( int i = row; i < strlen( word ) + row; i++ ) {
        if( board[ i ][ col ] != EMPTY_SPACE && board[ i ][ col ] != word[ currIdx ] ) {
            sem_post( &move );
            return false;
        }
        currIdx++;
    }

    // reset current index of word
    currIdx = 0;
    for( int i = row; i < strlen( word ) + row; i++ ) {
        char curr = board[ i ][ col ];

        if( curr == EMPTY_SPACE )
            board[ i ][ col ] = word[ currIdx ];
        currIdx++;
    }

    sem_post( &move );
    return true;
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *sock ) {
    // Here's a nice trick, wrap a C standard IO FILE around the
    // socket, so we can communicate the same way we would read/write
    // a file.
    int *iSock = ( int * ) sock;
    FILE *fp = fdopen( *iSock, "a+" );

    // Prompt the user for a command.
    fprintf( fp, "cmd> " );
    // flag for whether or not the given command was completed successfully
    bool success = false;

    // Temporary values for parsing commands.
    char cmd[ WORD_LIMIT + WORD_LIMIT ];
    while ( fscanf( fp, "%10s", cmd ) == 1 &&
            strcmp( cmd, "quit" ) != 0 ) {
        if( strlen( cmd ) > CMD_LIMIT ) {
            success = false;
            goto failed;
        }
        if( strcmp( cmd, "board" ) == 0 ) { // user prompts to print board
            // print border at top of board
            for( int i = 0; i <= cols + 1; i++ ) {
                if( i == 0 || i == cols + 1 ) 
                    fprintf( fp, "+" );
                else 
                    fprintf( fp, "-" );
            }
            fprintf( fp, "\n" );
            reportBoard( fp );
            // print border at bottom of board
            for( int i = 0; i <= cols + 1; i++ ) {
                if( i == 0 || i == cols + 1 ) 
                    fprintf( fp, "+" );
                else 
                    fprintf( fp, "-" );
            }
            fprintf( fp, "\n" );
            success = true;
        } else if( strstr( cmd, "down" ) ) { // user prompts to play "down" 
            // represents the row and column to place word
            int r = 0, c = 0;
            char word[ WORD_LIMIT + 1 ];
            fscanf( fp, "%d %d %s", &r, &c, word );
            success = putDown( r, c, word );
        } else if( strstr( cmd, "across" ) ) { // user prompts to play "across"
            // represents the row and column to place word
            int r = 0, c = 0;
            char word[ WORD_LIMIT + 1 ];
            fscanf( fp, "%d %d %s", &r, &c, word );
            // printf("r:%d c:%d, r: %d c: %d\n", rows, cols, r, c );
            success = putAcross( r, c, word );
        }

        if( success ) {
            // Just echo the command back to the client for now.
            fprintf( fp, "%s\n", cmd );
        } else {
            failed:
                fprintf( fp, "Invalid command\n" );
        }
        
        // Prompt the user for the next command.
        fprintf( fp, "cmd> " );
    }

    // Close the connection with this client.
    fclose( fp );
    return NULL;
}

int main( int argc, char *argv[] ) {
    
    // checks that a correct number of command-line arguments and valid integers
    //   are provided
    if ( argc != CMD_ARGS || atoi( argv[ 1 ] ) < 0 || atoi( argv[ 2 ] ) < 0 ) {
        fail( "usage: scrabbleServer <rows> <cols>" );
    }
    if( strcmp( argv[ 0 ], "./scrabbleServer" ) == 0 ) {
        // represents length of rows in board
        rows = atoi( argv[ 1 ] );
        // represents the length of columns in board
        cols = atoi( argv[ 2 ] );
        // initialize board to have only empty spaces
        for( int i = 0; i < rows; i++ )
            for( int j = 0; j < cols; j++ )
                board[ i ][ j ] = EMPTY_SPACE;
    }

    // Prepare a description of server address criteria.
    struct addrinfo addrCriteria;
    memset(&addrCriteria, 0, sizeof(addrCriteria));
    addrCriteria.ai_family = AF_INET;
    addrCriteria.ai_flags = AI_PASSIVE;
    addrCriteria.ai_socktype = SOCK_STREAM;
    addrCriteria.ai_protocol = IPPROTO_TCP;

    // Lookup a list of matching addresses
    struct addrinfo *servAddr;
    if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
        fail( "Can't get address info" );

    // Try to just use the first one.
    if ( servAddr == NULL )
        fail( "Can't get address" );

    // Create a TCP socket
    int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                            servAddr->ai_protocol);
    if ( servSock < 0 )
        fail( "Can't create socket" );

    // Bind to the local address
    if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
        fail( "Can't bind socket" );
    
    // Tell the socket to listen for incoming connections.
    if ( listen( servSock, 5 ) != 0 )
        fail( "Can't listen on socket" );

    // Free address list allocated by getaddrinfo()
    freeaddrinfo(servAddr);

    // Fields for accepting a client connection.
    struct sockaddr_storage clntAddr; // Client address
    socklen_t clntAddrLen = sizeof(clntAddr);

    // initialize semaphore to be used to prevent race conditions
    sem_init( &move, 0, 1 );

    // represents thread to be used to create multi-threaded process
    pthread_t thread;

    while ( true ) {
        // Accept a client connection.
        int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
        
        // create and run the thread
        pthread_create( &thread, NULL, handleClient, ( void * ) &sock );
        pthread_detach( thread );
    }

    // Stop accepting client connections (never reached).
    close( servSock );
    
    return 0;
}
