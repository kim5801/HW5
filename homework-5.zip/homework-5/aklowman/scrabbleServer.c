#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>
/**
* @file scrabbleServer.c
* @author Annie Lowman aklowman
*
* File created a port to be used by a remote server, and then uses it to
* remotely connect to a client and accept commands from the client to use
* the game board in different ways, either place a new word, or print out
* the current state of the game
*/

/** Port number used by my server */
#define PORT_NUMBER "26050"

/** Maximum word length */
#define WORD_LIMIT 26

// semaphore for creating synchornization for accessing the game board
sem_t boardAccess;

// game board for keeping track of the current words on the boards
char **board;

// number of rows in the game board
int row; 
// numbers of columns in the game board
int col;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( int sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  //int *sock = (int *) arg;
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
      // handle across
      if ( strcmp( cmd, "across" ) == 0 ) {
          int newRow;
          int newCol;
          // read in the numbers given
          if ( fscanf( fp, "%d %d", &newRow, &newCol ) != 2 ) {
              fprintf( fp, "Invalid command\n");
              fprintf( fp, "cmd> " );
              continue;
          }
          // read in the command
          char word[ 27 ];
          if (fscanf( fp, "%26s", word ) != 1 ) {
              fprintf( fp, "Invalid command\n");
              fprintf( fp, "cmd> " );
              continue;
          }/*
          // check for excess
          char excess[11];
          if (scanf("%10s", excess ) == 1 ) {
              fprintf( fp, "Invalid command\n");
              fprintf( fp, "cmd> " );
              continue;
          }*/
          // check bounds of the numbers given
          if ( newRow < 1 || newRow < 1 || newRow >= row || newCol >= col) {
              fprintf( fp, "Invalid command\n");
              fprintf( fp, "cmd> " );
              continue;
          }
          // check length of the word given
          int len = strlen(word);
          if ( len + newCol > col ) {
              fprintf( fp, "Invalid command\n");
              fprintf( fp, "cmd> " );
              continue;
          }
          // check the valididty of the characters in given word, and if it matches up with the present game board
          bool valid = true;
          for ( int i = 0; i < len; i++ ) {
              if ( word[i] < 'a' || word[i] > 'z' ) {
                  valid = false;
              }
              if ( board[newRow][ i + newCol] != ' ' ) {
                  if ( board[newRow][i + newCol] != word[i] ) {
                      valid = false;
                  }
              }
          }
          
          if ( !valid ) {
              fprintf( fp, "Invalid command\n");
              fprintf( fp, "cmd> " );
              continue;
          }
          // place word if everything is valid
          for ( int i = 0; i < len; i++ ) {
              board[newRow][ i + newCol] = ' ';
          }
      }
      // handle down
      else if ( strcmp( cmd, "down" ) == 0 ) {
          int newRow;
          int newCol;
          // get the row and column
          if ( fscanf( fp, "%d %d", &newRow, &newCol ) != 2 ) {
              fprintf( fp, "Invalid command\n");
              fprintf( fp, "cmd> " );
              continue;
          }
          // get the word to be placing
          char word[ 27 ];
          if (fscanf( fp, "%26s", word ) != 1 ) {
              fprintf( fp, "Invalid command\n");
              fprintf( fp, "cmd> " );
              continue;
          }/*
          // check for excess
          char excess[11];
          if (scanf("%10s", excess ) == 1 ) {
              fprintf( fp, "Invalid command\n");
              fprintf( fp, "cmd> " );
              continue;
          }*/
          // check bound of the given number
          if ( newRow < 1 || newRow < 1 || newRow >= row || newCol >= col) {
              fprintf( fp, "Invalid command\n");
              fprintf( fp, "cmd> " );
              continue;
          }
          // check the length of the word
          int len = strlen(word);
          if ( len + newRow > row ) {
              fprintf( fp, "Invalid command\n");
              fprintf( fp, "cmd> " );
              continue;
          }
          // check the characters in the given word, as well as the characters already on the game board
          bool valid = true;
          for ( int i = 0; i < len; i++ ) {
              if ( word[i] < 'a' || word[i] > 'z' ) {
                  valid = false;
              }
              if ( board[i + newRow][newCol] != ' ' ) {
                  if ( board[i + newRow][newCol] != word[i] ) {
                      valid = false;
                  }
              }
          }
          if ( !valid ) {
              fprintf( fp, "Invalid command\n");
              fprintf( fp, "cmd> " );
              continue;
          }
          // place word if everything lookds good
          for ( int i = 0; i < len; i++ ) {
              board[i + newRow][newCol] = ' ';
          }
          
          
      }
      // handle board
      else if ( strcmp( cmd, "board" ) == 0 ) {
          // print out the game board
          for ( int i = 0; i < row + 2; i++ ) {
              for ( int j = 0; j < col + 2; j++ ) {
                  if ( i == 0 && j == 0 ) {
                      fprintf( fp, "+" );
                  }
                  else if ( i == 0 && j == col + 1 ) {
                      fprintf( fp, "+" );
                  }
                  else if ( i == row + 1 && j == 0 ) {
                      fprintf( fp, "+" );
                  }
                  else if ( i == row + 1 && j == col + 1 ) {
                      fprintf( fp, "+" );
                  }
              
                  else if ( i == 0 || i == row + 1 ) {
                      fprintf( fp, "-" );
                  }
                  else if ( j == 0 || j == col + 1 ) {
                      fprintf( fp, "|" );
                  }
                  else {
                      fprintf( fp, "%c", board[ i - 1][j - 1] );
                  }
              }
          }
      }
      // handle error
      else {
          fprintf( fp, "Invalid command\n");
      }
  
      fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);
  
  //intalize the semaphore for synchonizing access to the game board
  sem_init( &boardAccess, 0, 1 );
  // check number of command line arguments
  if ( argc != 3 ) {
      fail( "usage: scrabbleServer <rows> <cols>" );
  } // check actual arguments given 
  if (sscanf( argv[1], "%d", &row) != 1 ) {
      fail("usage: scrabbleServer <rows> <cols>");
  }
  if (sscanf( argv[2], "%d", &col) != 1 ) {
      fail("usage: scrabbleServer <rows> <cols>");
  }
  if ( row <= 0 || col <= 0 ) {
      fail("usage: scrabbleServer <rows> <cols>");
  }
  // create the game board and fill it in with spaces
  board = (char **) malloc( row * sizeof(char *) );
  for ( int i = 0; i < row; i ++ ) {
      board[i] = (char * ) malloc( col * sizeof(char) );
      for ( int j = 0; j < col; j++ ) {
          board[i][j] = ' ';
      }
  }
  

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    /*
    // create new thread for that client connection
    pthread_t worker;
    
    pthread_create( &worker, NULL, handleClient, (void *) sock );
    // detatch the thread so it can terminate when it's done
    pthread_detach( worker );
    
    */
    handleClient( sock );
    
    
  }
    
  sem_destroy( &boardAccess );
  // Stop accepting client connections (never reached).
  close( servSock );
  
  // destroy the sempahore
  //sem_destroy( &access );
  
  return 0;
}
