#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>
/**
 * @author Jack Benton (jnbenton)
 * @file scrabbleServer.c
 * This serves as a server for a scrabble game that clients can connect to play.
 */

/** Port number used by my server */
#define PORT_NUMBER "26378"

/** Maximum word length */
#define WORD_LIMIT 26

/** New ScrabbleBoard struct*/
typedef struct ScrabbleBoard {
    char *board;
    int rows;
    int cols;
} ScrabbleBoard;

/** Board for scrabble*/
struct ScrabbleBoard scrabbleBoard;

/** POSIX semaphore for synchronization when handling clients*/
sem_t lock;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// called when invalid command is inputed by client
static void invalidCommand(FILE *fp) {
    fprintf(fp, "Invalid command\n");
    fprintf( fp, "cmd> " );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int socket = *(int *)sock;
  FILE *fp = fdopen( socket, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {

    sem_wait(&lock);
    if (strcmp(cmd, "board") == 0) {
      fprintf(fp, "+");
      for (int i = 0; i < scrabbleBoard.cols; i++) {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n|");
      for (int i = 0; i < scrabbleBoard.rows; i++) {
        for (int j = 0; j < scrabbleBoard.cols; j++) {
          fprintf(fp, "%c", scrabbleBoard.board[(i * scrabbleBoard.cols) + j]);
        }
        if (i == scrabbleBoard.rows - 1) {
          fprintf(fp, "|\n+");
        } else {
          fprintf(fp, "|\n|");
        }
      }
      for (int i = 0; i < scrabbleBoard.cols; i++) {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
    } else {
      int row;
      if (fscanf(fp, "%d", &row) != 1 || row < 0 || row >= scrabbleBoard.rows) {
        invalidCommand(fp);
        sem_post(&lock);
        continue;
      }

      int col;
      if (fscanf(fp, "%d", &col) != 1 || col < 0 || col >= scrabbleBoard.cols) {
        invalidCommand(fp);
        sem_post(&lock);
        continue;
      }

      char word[WORD_LIMIT];
      if (fscanf(fp, "%26s", word) == 0) {
        invalidCommand(fp);
        sem_post(&lock);
        continue;
      }

      bool cap = false;
      for (int i = 0; i < strlen(word); i++) {
        if (word[i] >= 'A' && word[i] <= 'Z') {
          cap = true;
          break;
        }
      }
      if (cap) {
        invalidCommand(fp);
        sem_post(&lock);
        continue;
      }

      if (strcmp(cmd, "across") == 0) {
        if ((strlen(word) + col) > scrabbleBoard.cols) {
          invalidCommand(fp);
          sem_post(&lock);
          continue;
        }
      

        int idx = 0;
        bool inval = false;
        int startIdx = (row * scrabbleBoard.cols) + col;
        if (*(scrabbleBoard.board + (startIdx - 1)) != ' ') {
          invalidCommand(fp);
          sem_post(&lock);
          continue;
        }
        for (int i = startIdx; i < startIdx + strlen(word); i++) {
          if (*(scrabbleBoard.board + i) == ' ') {
            *(scrabbleBoard.board + i) = word[idx];
          } else if (*(scrabbleBoard.board + i) != word[idx]) {
            inval = true;
            // clear board
            for (int j = startIdx; j < i; j++) {
              *(scrabbleBoard.board + j) = ' ';
            }
            break;
          }
          idx++;
        }

        if (inval) {
          invalidCommand(fp);
          sem_post(&lock);
          continue;
        }
      } else  if (strcmp(cmd, "down") == 0) {
        if ((strlen(word) + row) > scrabbleBoard.rows) {
          invalidCommand(fp);
          sem_post(&lock);
          continue;
        }
        
        int idx = 0;
        bool inval = false;
        int startIdx = (row * scrabbleBoard.cols) + col;
        int sentinelIdx = ((row + strlen(word)) * scrabbleBoard.cols) + col;
        for (int i = startIdx; i < sentinelIdx; i = i + scrabbleBoard.cols) {
          if (*(scrabbleBoard.board + i) == ' ') {
            *(scrabbleBoard.board + i) = word[idx];
          } else if (*(scrabbleBoard.board + i) != word[idx]) {
            inval = true; 
            // clear board
            for (int j = startIdx; j < i; j++) {
              *(scrabbleBoard.board + j) = ' ';
            }
            break;
          }
          idx++;
        }

        if (inval) {
          invalidCommand(fp);
          sem_post(&lock);
          continue;
        }
      }
    }
    // Just echo the command back to the client for now.
    // fprintf( fp, "%s\n", cmd );

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
    // exit code
    sem_post(&lock);
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Checking for valid arguments
  if (argc != 3 || atoi(argv[1]) <= 0 || atoi(argv[2]) <= 0) {
    printf("usage: scrabbleServer %d %d\n", atoi(argv[1]), atoi(argv[2]));
    exit(1);
  }
  int rows = atoi(argv[1]);
  int cols = atoi(argv[2]);
  // Create Scrabble board struct
  scrabbleBoard.board = malloc(rows * cols * sizeof(char));
  scrabbleBoard.rows = rows;
  scrabbleBoard.cols = cols;
  for (int i = 0; i < rows; i++) {
    for (int j = 0; j < cols; j++) {
      *(scrabbleBoard.board + i*cols + j) = ' ';
    }
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  // initialize array of thread
  pthread_t thread[WORD_LIMIT];
  int ct = 0;

  //Initialize semaphore to one
  sem_init(&lock, 0, 1);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    int *sockPt = &sock;
    
    // create new thread for this client
    pthread_create(thread + ct, NULL, handleClient, sockPt);
    pthread_detach(thread[ct]);


    ct++;
    // handleClient( sock );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  free(scrabbleBoard.board);

  return 0;
}
