#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26124"

/** Maximum word length */
#define WORD_LIMIT 26

/** Maximum number of english words in the word list */
#define VALID_WORD_COUNT 102401

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out the usage message and exit
static void usage() {
  printf("usage: scrabbleServer <rows> <cols>\n");
  exit(1);
}

// Board type that represents a scrabble board
typedef struct BoardStruct {
  // The number of rows in the board
  int rows;

  // The number of cols in the board
  int cols;

  // The representation of characters in the board
  char *chars;

  // A temporary storage of characters in the board (to check for validity)
  char *backup;
} Board;

// The global board struct
static Board *board;

// The lock for modifying the board
static sem_t lock;

// The list of valid english words users can play
char validWords[VALID_WORD_COUNT][WORD_LIMIT + 1];
int validWordCount = 0;

// Verify that only valid words exist on a given row/column
bool verify(int index, bool isRow) {
  // Change offset, increment, and max based upon if this is a row or column
  int offset, increment, max;
  if (isRow) {
    // Index is a row
    max = board->cols;
    offset = index * board->cols;
    increment = 1;
  } else {
    // Index is a column
    max = board->rows;
    offset = index;
    increment = board->cols;
  }

  // The string to compare against
  char str[max + 1];
  int count = 0;

  // Loop through every index in the row/column
  for (int i = 0; i <= max; i++) {
    if (board->chars[offset + i * increment] == ' ' || i == max) {
      // If the character is a space, try to validate the current word
      str[count] = '\0';

      // If there is only one character, don't check anything
      if (count <= 1) {
        count = 0;
        continue;
      }
      count = 0;

      // Check if this word equals any valid word
      bool verified = false;
      for (int i = 0; i < validWordCount; i++) {
        if (strcmp(validWords[i], str) == 0) {
          verified = true;
          break;
        }
      }

      // If there are no matches, return false (word is not valid)
      if (!verified) {
        return false;
      }
    } else {
      // If the character is not a space, add it to the current string
      str[count++] = board->chars[offset + i * increment];
    }
  }

  return true;
}

// Validate that given arguments are allowed for this program
bool validateArgs(int row, int col, char *word, bool isAcross) {
  int len = strlen(word);
  int rows = board->rows;
  int cols = board->cols;

  // Check for valid row/column/length
  if (len == 0 || row < 0 || col < 0 ||
      row >= rows || col >= cols ||
      len > rows || len > cols) {
    return false;
  }

  // Check if the word will fit on the board
  if ((!isAcross && row + len > rows) ||
      (isAcross && col + len > cols)) {
    return false;
  }

  // Check that the word contains only lowercase letters
  int count;
  for (count = 0; word[count]; count++) {
    if (word[count] < 'a' || word[count] > 'z') {
      return false;
    }
  }

  // Make sure the word is less than the word limit
  return count <= WORD_LIMIT;
}

// Place a new word on the board going horizontally (returns true on success, false on error)
bool across(int row, int col, char *word) {
  // Get information from the board
  int len = strlen(word);
  int cols = board->cols;
  int rows = board->rows;
  int offset = row * cols + col;

  // Check all spaces to make sure they don't collide with the word
  for (int i = 0; i < strlen(word); i++) {
    if (board->chars[offset + i] != ' ' && board->chars[offset + i] != word[i]) {
      return false;
    }
  }

  // Make a temporary backup
  for (int i = 0; i < rows * cols; i++) {
    board->backup[i] = board->chars[i];
  }

  // Update the characters
  for (int i = 0; i < strlen(word); i++) {
    board->chars[offset + i] = word[i];
  }

  // Check if the added word creates only valid English words
  bool valid = verify(row, true);
  for (int i = col; i < col + len; i++) {
    valid &= verify(i, false);
  }

  // Revert to backup if there are invalid words
  if (!valid) {
    for (int i = 0; i < rows * cols; i++) {
      board->chars[i] = board->backup[i];
    }
    return false;
  }

  return true;
}

// Place a new word on the board going vertically (returns true on success, false on error)
bool down(int row, int col, char *word) {
  // Get information from the board
  int len = strlen(word);
  int cols = board->cols;
  int rows = board->rows;
  int offset = row * cols + col;

  // Check all spaces to make sure they don't collide with the word
  for (int i = 0; i < strlen(word); i++) {
    if (board->chars[offset + cols * i] != ' ' && board->chars[offset + cols * i] != word[i]) {
      return false;
    }
  }

  // Make a temporary backup
  for (int i = 0; i < rows * cols; i++) {
    board->backup[i] = board->chars[i];
  }

  // Update the characters
  for (int i = 0; i < strlen(word); i++) {
    board->chars[offset + cols * i] = word[i];
  }

  // Check if the added word creates only valid English words
  bool valid = verify(col, false);
  for (int i = row; i < row + len; i++) {
    valid &= verify(i, true);
  }

  // Revert to backup if there are invalid words
  if (!valid) {
    for (int i = 0; i < rows * cols; i++) {
      board->chars[i] = board->backup[i];
    }
    return false;
  }

  return true;
}

// Update a given string with the current board format
char *printBoard() {
  int rows = board->rows;
  int cols = board->cols;

  // Allocate memory for the string
  char *str = (char *) malloc(sizeof(char) * ((rows + 2) * (cols + 2)));
  int count = 0;

  // Write the header line
  str[count++] = '+';
  for (int i = 0; i < cols; i++) {
    str[count++] = '-';
  }
  str[count++] = '+';
  str[count++] = '\n';

  // Write the board lines
  for (int row = 0; row < rows; row++) {
    str[count++] = '|';

    for (int col = 0; col < cols; col++) {
      str[count++] = board->chars[row * cols + col];
    }

    str[count++] = '|';
    str[count++] = '\n';
  }

  // Write the ending line
  str[count++] = '+';
  for (int i = 0; i < cols; i++) {
    str[count++] = '-';
  }
  str[count++] = '+';
  str[count++] = '\n';

  return str;
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *input ) {
  int *sockPtr = (int *) input;
  int sock = *sockPtr;

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );

  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  int row = 0, col = 0;
  char word[WORD_LIMIT];

  // Continuously parse commands
  while ( fscanf( fp, "%10s", cmd ) == 1 && strcmp( cmd, "quit") != 0 ) {
    // Acquire the lock on the board
    sem_wait(&lock);

    if (strcmp(cmd, "board") == 0) {
      // If the user wants to print the board, send it to them
      char *str = printBoard();
      fprintf(fp, "%s", str);
      free(str);

    } else if (strcmp(cmd, "across") == 0) {
      // If the user wants to put a word across, parse the arguments, check them, and then place the word
      if (fscanf(fp, "%9d %9d %26s", &row, &col, word) != 3 || !validateArgs(row, col, word, true) || !across(row, col, word)) {
        fprintf(fp, "Invalid command\n");
      }

    } else if (strcmp(cmd, "down") == 0) {
      // If the user wants to put a word down, parse the arguments, check them, and then place the word
      if (fscanf(fp, "%9d %9d %26s", &row, &col, word) != 3 || !validateArgs(row, col, word, false) || !down(row, col, word)) {
        fprintf(fp, "Invalid command\n");
      }

    } else {
      // Otherwise, the user sent an invalid command
      fprintf(fp, "Invalid command\n");
    }

    // Release the lock on the board
    sem_post(&lock);

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  if (argc != 3) {
    usage();
  }

  // Parse the command line arguments to get the dimension for the board
  int rows = 0, cols = 0;
  if (sscanf(argv[1], "%d", &rows) < 0 || sscanf(argv[2], "%d", &cols) < 0) {
    usage();
  } else if (rows < 0 || cols < 0) {
    usage();
  }

  // Create the new board
  board = (Board *) malloc(sizeof(Board));
  board->rows = rows;
  board->cols = cols;

  board->backup = (char *) malloc(rows * cols * sizeof(char));

  board->chars = (char *) malloc(rows * cols * sizeof(char));
  for (int i = 0; i < rows * cols; i++) {
    board->chars[i] = ' ';
  }

  // Open the file of valid English words
  FILE *file = fopen("words", "r");
  if (file != NULL) {
    // Read in each word line by line
    int n = 0;
    while (fscanf(file, "%26s %n", validWords[validWordCount], &n) != EOF) {
      validWords[validWordCount++][n] = '\0';
    }
  }

  // Initialize the semaphore lock
  if (sem_init(&lock, 0, 1) == -1) {
    fail("Failed to initialize lock");
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
      servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );

  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    // Create and detach from a new pthread that will handle the client's connection
    pthread_t thread;
    if (pthread_create(&thread, NULL, handleClient, &sock) != 0 || pthread_detach(thread) != 0) {
      fail("Failed to construct a thread");
    }
  }

  // Stop accepting client connections (never reached).
  close( servSock );

  // Free the board (never reached)
  free(board->chars);
  free(board->backup);

  return 0;
}
