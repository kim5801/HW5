#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>
#include <pthread.h>
#include <stdint.h>

/** Port number used by my server */
#define PORT_NUMBER "26264"

/** Maximum word length */
#define WORD_LIMIT 26

/** Number of rows in the board */
static int rows = 0;  

/** Number of columns in the board */
static int cols = 0; //Number of columns in the board

/** The game board */
char *board;

/** Used to lock the board. */
sem_t lock;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: scrabbleServer <rows> <cols>" );
  exit( 1 );
}

static int getBoardIndex(int x, int y) {
    return cols * x + y;
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *arg ) {
    
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  //int sock = (int) arg;
  
  FILE *fp = fdopen(*((int *)arg), "a+" );
  if (fp == NULL) {
    perror("File error");
  }
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 150 ];
  while ( fscanf( fp, "%[^\n]s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {
    char *words[50];
    int wordCount = 0;
    char *cmdWord;
    bool overflow = false;
    cmdWord = strtok(cmd, " ");
    while (cmdWord != NULL) {
        if (strlen(cmdWord) > 50) {
            overflow = true;
            break;
        }
        words[wordCount] = cmdWord;
        cmdWord = strtok(NULL, " ");
        wordCount++;

    }

    //Parse commands.
    bool across = false;
    bool down = false;
    bool pBoard = false;
    bool quit = false;
    int rowNum = 0;
    int colNum = 0;
    char word[100];
    int len = 0;
    if (strcmp( words[0], "across") == 0 && !overflow) {
        rowNum = atoi(words[1]);
        colNum = atoi(words[2]);
        if (rowNum < 0 || rowNum > (rows - 1) || colNum < 0 || colNum > (cols - 1)) {
            fprintf(fp, "Invalid command.\n");
        } else {
            strcpy(word, words[3]);
            len = strlen(word);
            across = true;
        }
    } else if (strcmp(words[0], "down") == 0  && !overflow) {
        rowNum = atoi(words[1]);
        colNum = atoi(words[2]);
        if (rowNum < 0 || rowNum > (rows - 1) || colNum < 0 || colNum > (cols - 1)) {
            fprintf(fp, "Invalid command.\n");
        } else {
            strcpy(word, words[3]);
            len = strlen(word);
            down = true;
        }
    } else if (strcmp(words[0], "board") == 0 && !overflow) {
        pBoard = true;
    } else if (strcmp(words[0], "quit") == 0 && !overflow) {
        quit = true;
    } else {
        fprintf(fp, "Invalid command.\n");
    }
    
    if (across) {
        int col = 0;
        bool badInput = false;
        if (len > 26) {
            badInput = true;
        }
        for (int i = 0; i < len; i++) { //Check if the word will fit
            col = colNum + i;
            int idx = getBoardIndex(rowNum, col);
            if (idx > rows * cols || col > cols || (board[getBoardIndex(rowNum, col)] != word[i] && board[getBoardIndex(rowNum, col)] != '\0') || word[i] < 'a' || word[i] > 'z') {
                fprintf(fp, "Invalid command.\n");
                badInput = true;
                break;
            }
        }
        if (!badInput) {
            for (int i = 0; i < len; i++) {
                board[getBoardIndex(rowNum, colNum + i)] = word[i];
            }
        }
    }
    if (down) {
        int row = 0;
        bool badInput = false;
        if (len > 26) {
            badInput = true;
        }
        for (int i = 0; i < len; i++) { //Check if the word will fit
            row = rowNum + i;
            int idx = getBoardIndex(row, colNum);
            if (idx > rows * cols || row > rows || (board[getBoardIndex(row, colNum)] != word[i] && board[getBoardIndex(row, colNum)] != '\0') || word[i] < 'a' || word[i] > 'z') {
                fprintf(fp, "Invalid command.\n");
                badInput = true;
                break;
            }
        }
        if (!badInput) {
            for (int i = 0; i < len; i++) {
                board[getBoardIndex(rowNum + i, colNum)] = word[i];
            }
        }
    }
    if (pBoard) {
        fprintf(fp, "+");
        for (int i = 0; i < cols; i++) {
            fprintf(fp, "-");
        }
        fprintf(fp, "+");
        fprintf(fp, "\n");
        for (int i = 0; i < rows; i++) {
            fprintf(fp, "|");
            for (int j = 0; j < cols; j++) {
                //printf("idx: %d", getBoardIndex(i, j));
                char pt = board[getBoardIndex(i, j)];
                if (pt == '\0') {
                    fprintf(fp, " ");
                } else {
                    fprintf(fp, "%c", pt);
                }
            }
            fprintf(fp, "|");
            fprintf(fp, "\n");
        }
        fprintf(fp, "+");
        for (int i = 0; i < cols; i++) {
            fprintf(fp, "-");
        }
        fprintf(fp, "+");
        fprintf(fp, "\n");
    } 
    if (quit) {
        break;
    }
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  //Process commandline arguments
  if ( argc != 3 )
    usage();
  
  
  if ( sscanf( argv[ 1 ], "%d", &rows ) != 1 || rows < 1 )
    usage();
  if ( sscanf( argv[ 2 ], "%d", &cols ) != 1 || cols < 1 )
    usage();

  //Make the board
  board = (char *) calloc(rows * cols + 1, sizeof(char));
  board[rows * cols] = '\0';

  //Initialize semaphore
  if (sem_init(&lock, 1, 1) < 0)
    fail( "Problem with semaphore" );

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    perror( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  pthread_t player;
  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    
    sem_wait(&lock);
    if (pthread_create(&player, NULL, handleClient, (void *) &sock))
        perror("Thread creation failed: ");
    pthread_detach(player);
    sem_post(&lock);
  }
  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
