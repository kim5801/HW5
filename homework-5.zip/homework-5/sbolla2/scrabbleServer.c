/**
 * The scrabble game server creates the board game and is able to put words on the board by being
 * in communication with clients (threads).
 * Words are put on the scrabble board based on whether there is space for the word and the letters of the word
 * don't conflict with other words already on the board.
 * @file scrabbleServer.c
 * @author Sania Bolla (sbolla2)
 * @date 2022-11-17
 * 
 * Using my pingpong.c exercise for inspiration on threads and sempahores
 * Using lightsout as inpiration for 2D array
 * 
 */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26394"

/** Maximum word length */
#define WORD_LIMIT 26

/** Semaphore to make sure two threads don't access scrabble board at once */
sem_t lock;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** Scrabble 2D Board */
char **boardObj;
/**  Row and Column with boarders attached */
int row = 0;
int column = 0;
/**  Row and Column without boarders attached */
int realRow = 0;
int realCol = 0;

/**
 * @brief Method used for writing a word across the scrabble board
 * 
 * @param r the left most row index of the new word
 * @param c the top most column index of the new word
 * @param word is the new word to add to the scrabble board
 * @param fp is the file pointer
 */
void across (int r, int c, char* word, FILE *fp) {
  int size = strlen(word);
  int distance = c + size;
  int wordCounter = 0;
  bool invalid = false;
  // Checking to make sure that none of the letters of the new word conflict with letters already on the board
  for (int i = c; i < distance; i++) {
    if (boardObj[r][i] != word[wordCounter] && boardObj[r][i] != ' ') {
      fprintf( fp, "%s\n", "Invalid command" );
      invalid = true;
      break;
    }
    wordCounter++;
  }
  // Only write to the board if the word is not invalid
  if (!invalid) {
    wordCounter = 0;
    for (int i = c; i < distance; i++) {
      boardObj[r][i] = word[wordCounter];
      wordCounter++;
    }
  }
}

/**
 * @brief Method used for writing a word down the scrabble board
 * 
 * @param r the left most row index of the new word
 * @param c the top most column index of the new word
 * @param word is the new word to add to the scrabble board
 * @param fp is the file pointer
 */
void down (int r, int c, char* word, FILE *fp) {
  int size = strlen(word);
  int distance = (r + size);
  int wordCounter = 0;
  bool invalid = false;
  // Checking to make sure that none of the letters of the new word conflict with letters already on the board
  for (int i = r; i < distance; i++) {
    if (boardObj[i][c] != word[wordCounter] && boardObj[i][c] != ' ') {
      fprintf( fp, "%s\n", "Invalid command" );
      invalid = true;
      break;
    }
    wordCounter++;
  }
  // Only write to the board if the word is not invalid
  if (!invalid) {
    wordCounter = 0;
    for (int i = r; i < distance; i++) {
      boardObj[i][c] = word[wordCounter];
      wordCounter++;
    }
  }
}

/**
 * @brief Method used to print out the scrabble board
 * 
 * @param fp is the file pointer
 */
void board(FILE *fp) {
  for (int i = 0; i < row; i++) {
    for (int j = 0; j < column; j++) {
      fprintf(fp, "%c", boardObj[i][j]);
    }
    fprintf(fp, "\n");
  }
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *args ) {
  int *realSock = (int*) args;
  int sock = *realSock;
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  int rowVal;
  int colVal;
  char word[100];
  //int matches = fscanf( fp, "%s %d %d %s", action, &row, &col, word);
  //fprintf(fp, "%d\n", matches);

  // Getting the row, column and word from the file stream
  int action = fgetc(fp);
  int ch = fgetc(fp);
  while (ch != ' ' && ch != '\n') {
    ch = fgetc(fp);
  }
  // Only needs to be done for across and down because board does not need row, column and word value
  if (ch != '\n') {
    ch = fgetc(fp);
    rowVal = (ch - '0') + 1;
    ch = fgetc(fp);
    ch = fgetc(fp);
    colVal = (ch - '0') + 1;
    ch = fgetc(fp);
    ch = fgetc(fp);
    int wordLoc = 0;
    while (ch != '\n') {
      word[wordLoc] = ch;
      ch = fgetc(fp);
      wordLoc++;
      // Prevent buffer overflow
      if (wordLoc > 26) {
        break;
      }
    }
    word[wordLoc] = 0;
  }
  // Check to make sure a word greater than 26 letters hasn't been passed in and that the word does
  // not contain capital letters
  bool invalid = false;
  if (strlen(word) > WORD_LIMIT) {
    invalid = true;
  } else {
    for (int i = 0; i < strlen(word); i++) {
      if (word[i] < 'a' || word[i] > 'z') {
        invalid = true;
      }
    }
  }

  // Keep prompting the user until they input the input quit
  while (action != 'q') {
    // Making sure the word isn't invalid and doesn't go off the board
    if (invalid || rowVal > realRow || colVal > realCol) {
      fprintf( fp, "%s\n", "Invalid command" );
      invalid = false;
    }
    // Making sure word doesn't go off the board while writing a word down
    else if ((strlen(word) + (rowVal - 1) > realRow ) && action == 'd') {
      fprintf( fp, "%s\n", "Invalid command" );
    }
    // Making sure word doesn't go off the board while writing a word across
    else if ((strlen(word) + (colVal - 1) > realCol ) && action == 'a') {
      fprintf( fp, "%s\n", "Invalid command" );
    }
    // If board action is specified use the semaphore to make sure no thread is accessing the board at the same time
    else if (action == 'b') {
      sem_wait( &lock );
      board(fp);
      sem_post( &lock );
    }
    // If across action is specified use the semaphore to make sure no thread is accessing the board at the same time
    else if (action == 'a') {
      sem_wait( &lock );
      across(rowVal, colVal, word, fp);
      sem_post( &lock );
    }
    // If down action is specified use the semaphore to make sure no thread is accessing the board at the same time
    else if (action == 'd') {
      sem_wait( &lock );
      down(rowVal, colVal, word, fp);
      sem_post( &lock );
    } else {
      fprintf( fp, "%s\n", "Invalid command" );
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
    // Getting the row, column and word from the file stream
    action = fgetc(fp);
    int ch = fgetc(fp);
    while (ch != ' ' && ch != '\n') {
      ch = fgetc(fp);
    }
    // Only needs to be done for across and down because board does not need row, column and word value
    if (ch != '\n') {
      ch = fgetc(fp);
      rowVal = (ch - '0') + 1;
      ch = fgetc(fp);
      ch = fgetc(fp);
      colVal = (ch - '0') + 1;
      ch = fgetc(fp);
      ch = fgetc(fp);
      int wordLoc = 0;
      while (ch != '\n') {
        word[wordLoc] = ch;
        ch = fgetc(fp);
        wordLoc++;
        // Prevent buffer overflow
        if (wordLoc > 26) {
          break;
        }
      }
      word[wordLoc] = 0;
    }
    // Check to make sure a word greater than 26 letters hasn't been passed in and that the word does
    // not contain capital letters
    if (strlen(word) > WORD_LIMIT) {
      invalid = true;
    } else {
      for (int i = 0; i < strlen(word); i++) {
        if (word[i] < 'a' || word[i] > 'z') {
          invalid = true;
        }
      }
    }
  }
  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

/**
 * @brief Creates the server client relationship using sockets
 * 
 * @param argc is the number of command line arguments
 * @param argv is the array of command line arguments
 * @return int is the return status
 */
int main( int argc, char *argv[] ) {
  if (argc != 3 || argv[1] < 0 || argv[2] < 0) {
    fail( "usage: scrabbleServer <rows> <cols>" );
  }

  // Initializing the semaphore to 1
  sem_init(&lock, 0, 1);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  // Converting the row string passed from command line to an integer
  row = argv[1][0] - '0';
  for (int i = 1; i < strlen(argv[1]); i++) {
    row *= 10;
    row += argv[1][i] - '0';
  }
  // Converting the column string passed from command line to an integer
  column = argv[2][0] - '0';
  for (int i = 1; i < strlen(argv[2]); i++) {
    column *= 10;
    column += argv[2][i] - '0';
  }

  realRow = row;
  realCol = column;

  // Adding space for the borders
  row = row + 2;
  column = column + 2;

  // Allocate space for the 2D board.
  // Need to malloc so that it can be a global variable
  boardObj = (char **) malloc(row * sizeof(char*));
  for (int i = 0; i < row; i++) {
    boardObj[i] = (char*)malloc(column * sizeof(char));
  }
  // Putting the entire boarder into the array and filling the center with spaces (whitespace)
  // Putting in the '+' signs
  boardObj[0][0] = '+';
  boardObj[0][column - 1] = '+';
  boardObj[row - 1][0] = '+';
  boardObj[row - 1] [column - 1] = '+';
  // Putting in the '|' signs
  for (int i = 1; i < row - 1; i++) {
    boardObj[i][0] = '|';
    boardObj[i][column - 1] = '|';
  }
  // Putting in the '-' signs
  for (int i = 1; i < column - 1; i++) {
    boardObj[0][i] = '-';
    boardObj[row - 1][i] = '-';
  }
  // Putting in the ' ' signs
  for (int i = 1; i < row - 1; i++) {
    for (int j = 1; j < column - 1; j++) {
      boardObj[i][j] = ' ';
    }
  }

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    // Multithreading
    pthread_t myThread;
    if (pthread_create( &myThread, NULL, handleClient, &sock) != 0) {
      fail( "Can't create a child thread\n" );
    }
    pthread_detach(myThread);

    //handleClient(sock);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  // Destroy the semaphore
  sem_destroy(&lock);
  
  return 0;
}
