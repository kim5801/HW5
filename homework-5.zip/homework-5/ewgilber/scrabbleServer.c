#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26026"

/** Maximum word length */
#define WORD_LIMIT 26

pthread_mutex_t lock;

typedef struct {
  int sock;
} SockStruct;

typedef struct Board{
  int row;
  int col;
  char gameState[1000][1000];
} Board;

//Instance of the game board
Board game;

//First word has been placed
bool firstWord = true;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

//Helper for uppercase
static bool isUpper(char c) {
  return c >= 'A' && c <= 'Z';
}

//Adds a word horizontally to the game board
void across(int r, int c, char *word) {
  pthread_mutex_lock( &lock );
  int wordSize = sizeof(word);
  int j = 0;

  //adding word
  for(int i = c; i < wordSize + c; i++) {
    game.gameState[r][i] = word[j++];
  }
  pthread_mutex_unlock( &lock );
}

//Adds a word vertically to the game board
void down(int r, int c, char *word) {
  pthread_mutex_lock( &lock );
  int wordSize = sizeof(word);
  int j = 0;

  //adding word
  for(int i = r; i < wordSize + r; i++) {
    game.gameState[i][c] = word[j++];
  }
  pthread_mutex_unlock( &lock );
}
//Prints current board state
void board(FILE *file) {
  pthread_mutex_lock( &lock );
  
  fprintf(file, "+");
  for(int i = 0; i < game.col; i++) {
    fprintf(file, "-");
  }
  fprintf(file, "+\n");
  for(int i = 0; i < game.row; i++) {
    fprintf(file, "|");    
    fprintf(file, game.gameState[i]);
    fprintf(file, "|\n");
  }
  fprintf(file, "+");
  for(int i = 0; i < game.col; i++) {
    fprintf(file, "-");
  }
  fprintf(file, "+\n");
  pthread_mutex_unlock( &lock );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  SockStruct *sockStruct = ( SockStruct * ) sock;
  FILE *fp = fdopen( sockStruct->sock, "a+" );

  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {

            if(strcmp( cmd, "across") == 0) {
              int row;
              int col;
              char word[WORD_LIMIT];
              fscanf( fp, "%d", &row);
              fscanf( fp, "%d", &col);
              fscanf( fp, "%99s", word);
              int wordSize = strlen(word);
              //Check for upper case letters
              bool hasUpper = false;
              for(int i = 0; i < wordSize; i++) {
                if(isUpper(word[i])) {
                    hasUpper = true;
                }
              }
              if(hasUpper) {
                fprintf( fp, "Invalid command\n" );
                fprintf( fp, "cmd> " );
                continue;
              }

              //Check for starts off board
              if(row > game.row - 1 || col > game.col - 1) {
                fprintf( fp, "Invalid command\n" );
                fprintf( fp, "cmd> " );
                continue;
              }

              //Check for off the edge
             if (game.col < wordSize + col) {
                fprintf( fp, "Invalid command\n" );
                fprintf( fp, "cmd> " );
                continue;
            }

              //check for word that doesn't match an existing character
            if(firstWord == false) { 
              bool hasLetter = false;
              int j = 0;
              for(int i = col; i < wordSize + col; i++) {
                if(game.gameState[row][i] == word[j++]) {
                  hasLetter = true;
                }
              }
              if(!hasLetter) {
                fprintf( fp, "Invalid command\n" );
                fprintf( fp, "cmd> " );
                continue;
              }
            }

              //else call across method
                across(row, col, word);
                firstWord = false;

            } else if( strcmp( cmd, "down") == 0 ) {
                int row;
              int col;
              char word[WORD_LIMIT];
              fscanf( fp, "%d", &row);
              fscanf( fp, "%d", &col);
              fscanf( fp, "%99s", word);
              int wordSize = strlen(word);
              //Check for upper case letters
              bool hasUpper = false;
              for(int i = 0; i < wordSize; i++) {
                if(isUpper(word[i])) {
                    hasUpper = true;
                }
              }
              if(hasUpper) {
                fprintf( fp, "Invalid command\n" );
                fprintf( fp, "cmd> " );
                continue;
              }

              //Check for starts off board
              if(row > game.row - 1 || col > game.col - 1) {
                fprintf( fp, "Invalid command\n" );
                fprintf( fp, "cmd> " );
                continue;
              }

              //Check for off the edge
            if (game.row < wordSize + row) {
                fprintf( fp, "Invalid command\n" );
                fprintf( fp, "cmd> " );
                continue;
            }

              //check for word that doesn't match an existing character
            if(firstWord == false) { 
              bool hasLetter = false;
              int j = 0;
              for(int i = col; i < wordSize + col; i++) {
                if(game.gameState[row][i] == word[j++]) {
                  hasLetter = true;
                }
              }
              if(!hasLetter) {
                fprintf( fp, "Invalid command\n" );
                fprintf( fp, "cmd> " );
                continue;
              }
            }

              //else call across method
                down(row, col, word);
                firstWord = false;
            } 
            else if( strcmp( cmd, "board") == 0 ) {
              board(fp);
            } else {
              fprintf( fp, "Invalid command\n" );
              fprintf( fp, "cmd> " );
              continue;
            }
    fprintf( fp, "cmd> " );
    fflush(fp);
  }

  // Close the connection with this client.
  fclose( fp );
  free(sockStruct);
  return NULL;
}

int main( int argc, char *argv[] ) {
  
  //Taking user input for game board size
  int row = atoi(argv[1]);
  int col = atoi(argv[2]);
  if(row < 0 || col < 0) {
    printf("usage: scrabbleServer <rows> <cols>\n");
    exit(1);
  }
  game.row = row;
  game.col = col;

  //Filling game board with empty spaces
  for(int i = 0; i < game.row; i++) {
    for(int j = 0; j < game.col; j++) {
      game.gameState[i][j] = ' ';
    }
  }


  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  if( pthread_mutex_init( &lock, NULL ) != 0 ) {
        printf( "Lock not initialized" );
        close( servSock );
        return EXIT_FAILURE;
    }

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    SockStruct *sockStruct = (SockStruct *) malloc (sizeof(SockStruct));
    sockStruct->sock = sock;

    //Creating thread
    pthread_t thread;
    if( pthread_create( &thread, NULL, handleClient, sockStruct ) != 0 ) {
            fail("Could not create thread\n");
    }
    pthread_detach( thread );

  }
  pthread_mutex_destroy( &lock );
  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
