/**
 * @file scrabbleServer.c
 * @author Daniel Wenger (dlwenger@ncsu.edu)
 * Server for the scrabble game.
 *
 */
#define _GNU_SOURCE
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netdb.h>
#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

/** Port number used by my server */
#define PORT_NUMBER "26104"

/** Maximum word length */
#define WORD_LIMIT 26
/* monitor for the server */
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
/** Struct containing info about the board. */
typedef struct {
    int rows;
    int cols;
    char **board;
} ScrabbleBoard;
/* The struct object that will hold the board */
ScrabbleBoard *sboard;
/* Indicates whether word checking will happen */
bool wordChecking;
/* Pointer to the words file */
FILE *wordDict;
/**
 * Creates the ScrabbleBoard to be used during the lifetime of the server
 *
 * @param rows the number of rows of the board
 * @param cols the number of columns for the board
 * @return ScrabbleBoard* the board object
 */
ScrabbleBoard *createBoard(int rows, int cols)
{
    ScrabbleBoard *b = (ScrabbleBoard *)malloc(sizeof(ScrabbleBoard));
    b->rows = rows;
    b->cols = cols;
    b->board = (char **)malloc(rows * sizeof(char *));
    for (int i = 0; i < rows; i++) {
        b->board[i] = (char *)malloc((cols + 1) * sizeof(char));
        memset(b->board[i], ' ', cols * sizeof(char));
        b->board[i][cols] = '\0';
    }
    return b;
}
/**
 * frees the board 2D array
 *
 * @param b the board 2D array
 * @param rows number of rows in the array
 */
void freeBoard(char **b, int rows)
{
    for (int i = 0; i < rows; i++) {
        free(b[i]);
    }
    free(b);
}

// Print out an error message and exit.
static void fail(char const *message)
{
    fprintf(stderr, "%s\n", message);
    exit(EXIT_FAILURE);
}
/**
 * Prints out the state of the board to the client
 *
 * @param fp the file representation for the connection
 */
void printBoard(FILE *fp)
{
    fputc('+', fp);
    for (int i = 0; i < sboard->cols; i++)
        fputc('-', fp);
    fprintf(fp, "+\n");
    for (int i = 0; i < sboard->rows; i++) {
        fprintf(fp, "|%s|\n", sboard->board[i]);
    }
    fputc('+', fp);
    for (int i = 0; i < sboard->cols; i++)
        fputc('-', fp);
    fprintf(fp, "+\n");
}
/**
 * Copies a board from sboard. Used to see if a new word is valid for extra credit
 *
 * @param isDown indicates whether operation is down or across
 * @param row the row the word is inserted at
 * @param col the column the word is inserted at
 * @param word the word
 * @param board the board
 * @return char** a 2d array representing the board
 */
char **copyBoard(bool isDown, int row, int col, char *word, char **board)
{
    int wordLen = strlen(word);
    // board = (char **)malloc(sboard->rows * sizeof(char *));
    for (int i = 0; i < sboard->rows; i++) {
        board[i] = (char *)malloc((sboard->cols + 1) * sizeof(char));
        for (int j = 0; j < sboard->cols; j++) {
            board[i][j] = sboard->board[i][j];
        }
        board[i][sboard->cols] = '\0';
    }
    if (isDown) {
        for (int rowIdx = row; rowIdx < row + wordLen; rowIdx++) {
            board[rowIdx][col] = word[rowIdx - row];
        }
    }
    else {
        for (int colIdx = col; colIdx < col + wordLen; colIdx++) {
            board[row][colIdx] = word[colIdx - col];
        }
    }
    return board;
}
/**
 * Checks to see if a word is in the list of valid words
 *
 * @param word word to be checked
 * @return true if the word is in the list
 * @return false if the word isn't in the list
 */
bool wordChecker(char *word)
{
    char scannedWord[27];
    bool isWord = false;
    rewind(wordDict);
    while (fscanf(wordDict, "%s", scannedWord) == 1 && !isWord) {
        if (strcmp(word, scannedWord) == 0) {
            isWord = true;
        }
    }
    return isWord;
}
/**
 * Checks that adding a word is valid and doesn't create non-words on the board
 *
 * @param isDown indicates whether operation is down or across
 * @param row the row the word is inserted at
 * @param col the column the word is inserted at
 * @param word the word
 * @return true if the word can be added
 * @return false if the word cannot be added
 */
bool boardChecker(bool isDown, int row, int col, char *word)
{
    if (!wordChecking)
        return true;
    char **copy;
    copy = (char **)malloc(sboard->rows * sizeof(char *));
    ;
    copyBoard(isDown, row, col, word, copy);
    for (int i = 0; i < sboard->rows; i++) {
        char tempWord[sboard->cols];
        int pos = 0;
        int startIdx = 0;
        while (sscanf(copy[i] + startIdx, "%s%n", tempWord, &pos) == 1) {
            startIdx += pos;
            if (strlen(tempWord) == 1) {
                continue;
            }
            if (!wordChecker(tempWord)) {
                freeBoard(copy, sboard->rows);
                return false;
            }
        }
    }
    for (int i = 0; i < sboard->cols; i++) {
        char tempCol[sboard->rows + 1];
        char tempWord[sboard->rows];
        for (int j = 0; j < sboard->rows; j++) {
            tempCol[j] = copy[j][i];
        }
        tempCol[sboard->rows] = '\0';
        int pos = 0;
        int startIdx = 0;
        while (sscanf(tempCol + startIdx, "%s%n", tempWord, &pos) == 1) {
            startIdx += pos;
            if (strlen(tempWord) == 1) {
                continue;
            }
            if (!wordChecker(tempWord)) {
                freeBoard(copy, sboard->rows);
                return false;
            }
        }
    }
    freeBoard(copy, sboard->rows);
    return true;
}
/**
 * Adds the word at the position horizontally
 *
 * @param row starting row
 * @param col starting column
 * @param word word that will be added
 * @param fp file pointer representing the connection
 */
void runAcross(int row, int col, char *word, FILE *fp)
{
    int wordLen = strlen(word);
    if (row >= 0 && row < sboard->rows && col >= 0 && col + wordLen <= sboard->cols) {
        for (int colIdx = col; colIdx < col + wordLen; colIdx++) {
            if ((sboard->board[row][colIdx] != ' ' && sboard->board[row][colIdx] != word[colIdx - col]) || (word[colIdx - col] < 'a' || word[colIdx - col] > 'z')) {
                fprintf(fp, "Invalid command\n");
                return;
            }
        }
        bool check = boardChecker(false, row, col, word);
        if (!check) {
            fprintf(fp, "Invalid command\n");
            return;
        }
        for (int colIdx = col; colIdx < col + wordLen; colIdx++) {
            sboard->board[row][colIdx] = word[colIdx - col];
        }
    }
    else {
        fprintf(fp, "Invalid command\n");
    }
}
/**
 * Adds the word at the position vertically
 *
 * @param row starting row
 * @param col starting column
 * @param word word that will be added
 * @param fp file pointer representing the connection
 */
void runDown(int row, int col, char *word, FILE *fp)
{
    int wordLen = strlen(word);
    if (col >= 0 && col < sboard->cols && row >= 0 && row + wordLen <= sboard->rows) {
        for (int rowIdx = row; rowIdx < row + wordLen; rowIdx++) {
            if ((sboard->board[rowIdx][col] != ' ' && sboard->board[rowIdx][col] != word[rowIdx - row]) || (word[rowIdx - row] < 'a' || word[rowIdx - row] > 'z')) {
                fprintf(fp, "Invalid command\n");
                return;
            }
        }
        if (!boardChecker(true, row, col, word)) {
            fprintf(fp, "Invalid command\n");
            return;
        }
        for (int rowIdx = row; rowIdx < row + wordLen; rowIdx++) {
            sboard->board[rowIdx][col] = word[rowIdx - row];
        }
    }
    else {
        fprintf(fp, "Invalid command\n");
    }
}

/** handle a client connection, close it when we're done. */
void *handleClient(void *socket)
{
    // Here's a nice trick, wrap a C standard IO FILE around the
    // socket, so we can communicate the same way we would read/write
    // a file.
    int sock = *((int *)socket);
    FILE *fp = fdopen(sock, "a+");

    // Prompt the user for a command.
    fprintf(fp, "cmd> ");

    // Temporary values for parsing commands.
    char cmd[11];
    while (fscanf(fp, "%10s", cmd) == 1 && strcmp(cmd, "quit") != 0) {
        pthread_mutex_lock(&lock);
        if (strcmp(cmd, "across") == 0 || strcmp(cmd, "down") == 0) {
            int col, row;
            char word[27] = {};
            if (fscanf(fp, "%d", &row) == 1 && fscanf(fp, "%d", &col) == 1 && fscanf(fp, "%26s", word) == 1) {
                char c = fgetc(fp);
                while (c != '\n') {
                    if (c != ' ') {
                        fprintf(fp, "Invalid command\n");
                    }
                    c = fgetc(fp);
                }

                if (word[26] != '\0' && strlen(word) >= 26) {
                    fprintf(fp, "Invalid command\n");
                }
                if (strcmp(cmd, "across") == 0) {
                    runAcross(row, col, word, fp);
                }
                else {
                    runDown(row, col, word, fp);
                }
            }
            else {
                fprintf(fp, "Invalid command\n");
            }
        }
        else if (strcmp(cmd, "board") == 0) {
            printBoard(fp);
        }
        else {
            fprintf(fp, "Invalid command\n");
        }
        pthread_mutex_unlock(&lock);

        // Prompt the user for the next command.
        fprintf(fp, "cmd> ");
    }

    // Close the connection with this client.
    fclose(fp);
    return NULL;
}

int main(int argc, char *argv[])
{
    if (argc != 3 || atoi(argv[1]) <= 0 || atoi(argv[2]) <= 0) {
        fail("usage: scrabbleServer <rows> <cols>");
    }

    sboard = createBoard(atoi(argv[1]), atoi(argv[2]));

    wordDict = fopen("words", "r");
    wordChecking = wordDict != NULL ? true : false;

    // Prepare a description of server address criteria.
    struct addrinfo addrCriteria;
    memset(&addrCriteria, 0, sizeof(addrCriteria));
    addrCriteria.ai_family = AF_INET;
    addrCriteria.ai_flags = AI_PASSIVE;
    addrCriteria.ai_socktype = SOCK_STREAM;
    addrCriteria.ai_protocol = IPPROTO_TCP;

    // Lookup a list of matching addresses
    struct addrinfo *servAddr;
    if (getaddrinfo(NULL, PORT_NUMBER, &addrCriteria, &servAddr))
        fail("Can't get address info");

    // Try to just use the first one.
    if (servAddr == NULL)
        fail("Can't get address");

    // Create a TCP socket
    int servSock = socket(servAddr->ai_family, servAddr->ai_socktype,
                          servAddr->ai_protocol);
    if (servSock < 0)
        fail("Can't create socket");

    // Bind to the local address
    if (bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0)
        fail("Can't bind socket");

    // Tell the socket to listen for incoming connections.
    if (listen(servSock, 5) != 0)
        fail("Can't listen on socket");

    // Free address list allocated by getaddrinfo()
    freeaddrinfo(servAddr);

    // Fields for accepting a client connection.
    struct sockaddr_storage clntAddr; // Client address
    socklen_t clntAddrLen = sizeof(clntAddr);
    void *(*fp)(void *);
    fp = handleClient;
    while (true) {
        // Accept a client connection.
        int sock = accept(servSock, (struct sockaddr *)&clntAddr, &clntAddrLen);
        pthread_t clientThread;
        if (pthread_create(&clientThread, NULL, fp, (void *)&sock) != 0) {
            fail("Failed to create threads.");
        }
        pthread_detach(clientThread);
    }
    freeBoard(sboard->board, sboard->rows);
    free(sboard);
    // Stop accepting client connections (never reached).
    close(servSock);

    return 0;
}
