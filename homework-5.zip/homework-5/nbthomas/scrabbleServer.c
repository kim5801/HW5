/** 
 * @file scrabbleServer.c
 * @author Noah Thomas (nbthomas)
 * scrabbleServer implements the game of scrabble and allows clients to connect to the server to to put input words,
 * display the board, and quit. Connections are managed with semaphore synchronization to prevent multiple clients
 * from modifying the board at the same time.
 */
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26360"

/** Maximum word length */
#define WORD_LIMIT 26

/** semaphore to manage board modification */
sem_t wrdInsrt;
/** current rows in the board */
int rows;
/** current columns of the board*/
int cols;
/** pointer to the boards as a 2d char array*/
char **board;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *socks ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int sock = *((int *)socks);
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 7 ];
  cmd[6] = '\0';
  while ( fscanf( fp, "%s", cmd) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) { // get initial command until user decides to quit
    if(cmd[6] != '\0') { //command is too long
      fprintf(fp, "Invalid command.\n"); 
      fprintf( fp, "cmd> " );
      continue;
    }

    if(strcmp(cmd, "across") == 0 || strcmp(cmd, "down") == 0) { //combines functionality for across and down commands
      sem_wait(&wrdInsrt); //acquire lock

      bool invalid = false; //indicates an error where we can't continue with the current command
      int r; //row location
      int c; //column location
      char wrd[WORD_LIMIT + 1]; //word given
      wrd[WORD_LIMIT] = '\0';

      if(fscanf(fp, "%d %d %s", &r, &c, wrd) != 3) { //need invalid command check if they don't give enough/correct arguments
        fprintf(fp, "Invalid command.\n"); 
        fprintf( fp, "cmd> " );
        sem_post(&wrdInsrt);
        continue;
      }

      if(wrd[WORD_LIMIT] != '\0') {
        fprintf(fp, "Invalid command.\n"); 
        fprintf( fp, "cmd> " );
        sem_post(&wrdInsrt);
        continue;
      }

      if(r < 0 || c < 0 || c >= cols || r >= rows) { //check the location is valid
        fprintf(fp, "Invalid command.\n"); 
        fprintf( fp, "cmd> " );
        sem_post(&wrdInsrt);
        continue;
      }

      int wrdlength = strlen(wrd); //word length

      for(int wr = 0; wr < wrdlength; wr++) { //check word is all lowercase
        if(wrd[wr] < 'a' || wrd[wr] > 'z') {
          fprintf(fp, "Invalid command.\n");
          invalid = true;
          break;
        }
      }

      if(invalid) { //if invalid, provide prompt and continue
        fprintf( fp, "cmd> " );
        sem_post(&wrdInsrt);
        continue;
      }

      if(strcmp(cmd, "across") == 0) { //across specific steps
        if(c + wrdlength - 1 >= cols) { //see if the word would extends beyond the board boundaries
          fprintf(fp, "Invalid command.\n"); 
          fprintf( fp, "cmd> " );
          sem_post(&wrdInsrt);
          continue;
        } else {
          for(int w = c; w < (c + wrdlength); w++) { //see if the spaces it will fill are empty or match the word
            if(board[r][w] != ' ' && board[r][w] != wrd[w - c]) {
              fprintf(fp, "Invalid command.\n");
              invalid = true;
              break;
            }
          }
          
          if(invalid) { //if invalid, provide prompt and continue
            fprintf( fp, "cmd> " );
            sem_post(&wrdInsrt);
            continue;
          }

          for(int w = c; w < (c + wrdlength); w++) { //put word on the board
            board[r][w] = wrd[w - c];
          }
        }        
      } else { //down specific operations
        if(r + wrdlength - 1 >= rows) { //check if word goes beyond board bounds
          fprintf(fp, "Invalid command.\n"); 
          fprintf( fp, "cmd> " );
          sem_post(&wrdInsrt);
          continue;
        } else {
          for(int w = r; w < (r + wrdlength); w++) { //check if spaces it will fill in are empty or match the word given
            if(board[w][c] != ' ' && board[w][c] != wrd[w - r]) {
              fprintf(fp, "Invalid command.\n");
              invalid = true;
              break;
            }
          }

          if(invalid) { //if invalid, provide prompt and continue
            fprintf( fp, "cmd> " );
            sem_post(&wrdInsrt);
            continue;
          }

          for(int w = r; w < (r + wrdlength); w++) { //add word
            board[w][c] = wrd[w - r];
          }
        }
      }

      sem_post(&wrdInsrt); //release semaphore
    } else if(strcmp(cmd, "board") == 0) { //print board contents
      char brd[((rows + 2) * (cols + 3)) + 1]; //reformat the board 2d array as one string which can be sent and formatted by the client
      brd[(rows + 2) * (cols + 2)] = '\0';

      strncpy(brd, board[0], cols + 2);
      strcat(brd, "\n");
      for(int b = 1; b < rows + 2; b++) {
        strncat(brd, board[b], cols + 2);
        strcat(brd, "\n");
      }

      fprintf(fp, "%s", brd); //send to client via socket
    } else { //other commands
      fprintf(fp, "Invalid command.\n"); 
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  if(argc != 3) { //check amount of arguments
    fail("usage: scrabbleServer <rows> <cols>\n");
  }

  rows = atoi(argv[1]); //collect board rows
  cols = atoi(argv[2]); //collect board columns

  if(rows < 1 || cols < 1) { //checks if row and columns are positive integers
    fail("usage: scrabbleServer <rows> <cols>\n");
  }

  sem_init(&wrdInsrt, 0, 1); //initalize anonymous semaphore

  board = (char **)malloc((rows + 2) * sizeof(char *)); //allocate memory for each row of the board

  for(int b = 0; b < cols + 2; b++) { //allocate the columns and null terminate the last column
    board[b] = (char *)malloc((cols + 3) * sizeof(char *));
    board[b][cols + 2] = '\0';
  }

  //board corners
  board[0][0] = '+'; 
  board[0][cols+1] = '+';
  board[rows+1][0] = '+';
  board[rows+1][cols+1] = '+';

  //board vertical borders
  for(int r = 1; r < rows + 1; r++) {
    board[r][0] = '|';
    for(int co = 1; co < cols+1; co++) {
      board[r][co] = ' ';
    }
    board[r][cols+1] = '|';
  }

  //board horizontal borders
  for(int c = 1; c < cols + 1; c++) {
    board[0][c] = '-';
    board[rows+1][c] = '-';
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    pthread_t client;

    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    pthread_create(&client, NULL, handleClient, &sock); //run thread to handle the client connection

    pthread_detach(client); //detach thread once client has finished
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
