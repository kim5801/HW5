#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26096"

/** Maximum word length */
#define WORD_LIMIT 26

/** the number of rows for the current board*/
int rows;
/**
 * @brief Number of columns for the current board
 */
int cols;
/**
 * @brief Semaphore to get rid
 * of race condition of modifying the board at the same tiem
 */
sem_t boardLock;

/**
 * @brief Declaration of the board used
 * for the scrabble game
 */
char **board;


// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/**
 * @brief Takes in the file pointer and 
 * prints out the board, adding the border
 * @param fp the file pointer or socket for this server
 */
static void printBoard(FILE *fp) {
  fputc('+', fp);
  for (int i = 0; i < cols; i++) { //border
    fputc('-', fp);
  }
  fputc('+', fp);
  fputc('\n', fp);
  for (int i = 0; i < rows; i++) {
    fputc('|', fp);
    for (int j = 0; j < cols; j++) { //actually printing the rows adnd cols
      fprintf(fp, "%c", board[i][j]);
    }
    fputc('|', fp);
    fputc('\n', fp);
  }
  fputc('+', fp);
  for (int i = 0; i < cols; i++) { //more border stuff
    fputc('-', fp);
  }
  fputc('+', fp);
  fputc('\n', fp);
}

/**
 * @brief Checks if the passed in word is a valid word
 * 
 * @param check the word to check
 * @return true true if it is a valid word
 * @return false false if it is a bad word
 */
static bool checkWord(char* check) {
  for (int i = 0; i < strlen(check); i++) {
    if (isupper(check[i])) { //checks if it is uppper case
      return false;
    }
    if (!isalpha(check[i])) { //or if it is not an alphabet character
      return false;
    }
  }
  return true;
}

/**
 * @brief Checks that putting the word on the board will work for across,
 * making sure that the word and location you want to put
 * will have at least one matching letter
 * 
 * @param word the word to place
 * @param across the column to start the word
 * @param down the row to start the word
 * @return true if it is a valid placement and word
 * @return false if it s a not valid placement and word
 */
static bool checkPutAcross(char *word, int across, int down) {
  //look at the space where want to put word, see if there is a character there,
  //write down index that it is at
  //then go through word and check that letter found in the word
  //return true if okay, return false if not okay
  char ch = 0;
  int index = 0;

  for (int i = across; i < across + strlen(word); i++) //go through where it might be placed
  {
    if (isalpha(board[down][i])) //check if there is a letter already there to connect to
    {
      index = i;
      ch = board[down][i];
      break;
    }
  }
  bool haveChar = false;
  for (int i = 0; i < strlen(word); i++) //and then see if the charcter that is already placed is in the new word
  {
    if (word[i] == ch)
    {
      haveChar = true;
    }
  }

  if (!haveChar && index != 0) //if they do not share a letter and it's not just spaces
  {
    return false; //invalid
  }
  return true; //valid
}

/**
 * @brief Does error checking, then locks the board and then actually places
 * the word at the spot you want on the board
 * @param word the word you want to palce
 * @param across the column 
 * @param down the row
 * @return true placing worked
 * @return false there was an erro
 */
static bool putAcross(char *word, int across, int down)
{

  //if there is already a char at that spot, make sure it has common starting word
  //if not throw error, if all good, then put

  if (!checkPutAcross(word, across, down)) {
    return false;
  }
  int count = 0;
  for (int i = across; i < across + strlen(word); i++) // place the word
  {
    if (isalpha(board[down][i]))
    {
      count++;
    }
  }

  if (count > 1)
  {
    return false;
  }

  sem_wait(&boardLock); //lock the board
  int index = 0;
  for (int i = across; i < across + strlen(word); i++) { //put the word
    board[down][i] = word[index];
    index++;
  }
  sem_post(&boardLock); //unlock the board
  return true;
}

/**
 * @brief Checks that putting the word on the board will work for down,
 * making sure that the word and location you want to put
 * will have at least one matching letter
 *
 * @param word the word to place
 * @param across the column to start the word
 * @param down the row to start the word
 * @return true if it is a valid placement and word
 * @return false if it s a not valid placement and word
 */
static bool checkPutDown(char *word, int across, int down)
{
  int index = 0;
  char ch = 0;
  for (int i = down; i < down + strlen(word); i++) //find letter already plaved
  {
    if (isalpha(board[i][across]))
    {
      index = i;
      ch = board[i][across];
      break;
    }
  }
  bool haveChar = false;
  for (int i = 0; i < strlen(word); i++) { //check if exist in the want word
    if (word[i] == ch) {
      haveChar = true;
    }
  }

  if (!haveChar && index != 0)
  {
    return false;
  }
  return true;
}

/**
 * @brief Does error checking, then locks the board and then actually places
 * the word at the spot you want on the board
 * @param word the word you want to palce
 * @param across the column
 * @param down the row
 * @return true placing worked
 * @return false there was an erro
 */
static bool putDown(char *word, int across, int down)
{
  if (!checkPutDown(word, across, down)) { //check that it can be placed
    return false;
  }
  int count = 0;

  for (int i = down; i < down + strlen(word); i++) //place the word
  {
    if (isalpha(board[i][across]))
    {
      count++;
    }
  }
  
  if (count > 1) {
    return false;
  }

  sem_wait(&boardLock); //lock the board
  int index = 0;
  for (int i = down; i < down + strlen(word); i++) //place the word
  {
    board[i][across] = word[index];
    index++;
  }
  sem_post(&boardLock); //unlock the board
  return true;
}

/** handle a client connection, close it when we're done. */
void *handleClient( void  *sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int *open = (int *)sock; //pass in int as void pointer for handing argument passing to pthread, so cast it to int

  FILE *fp = fdopen( *open, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  char cmd[11];
  char word[30]; //declare variables to use
  char rest[40];
  int across = 0;
  int down = 0;
  char across_S[2];
  char down_S[2];
  while ( fscanf(fp, "%10s", cmd) == 1 && strcmp(cmd, "quit") != 0) //while you are getting commands, and that command is not qiuit
  {
    // go to right after the command
    fseek(fp, strlen(cmd), SEEK_SET);

    if (strcmp("across", cmd) == 0) { //if command is across
      fscanf(fp, "%40[^\n]", rest); //get the entire line

      char *token = strtok(rest, " ");
      int count = 0;
      while (token) //break it up into the right parts
      {
        if (count == 0) {
          strcpy(down_S, token);
          down = atoi(down_S);
        } else if (count == 1) {
          strcpy(across_S, token);
          across = atoi(across_S);
        } else if (count == 2) {
          strcpy(word, token);
        } else {
          fprintf(fp, "Invalid command\n"); //if there is more, then invalid command
          goto end;
        }
        
        token = strtok(NULL, " ");
        count++;
      }

      if (strlen(word) > WORD_LIMIT)
      { // do a bunch of error checking
        fprintf(fp, "Invalid command\n");
        goto end;
      }

      if (!checkWord(word)) {
        fprintf(fp, "Invalid command\n");
        goto end;
      }

      if (across >= cols || across < 0) {
        fprintf(fp, "Invalid command\n");
        goto end;
      }

      if (down >= rows || down < 0) {
        fprintf(fp, "Invalid command\n");
        goto end;
      }

      if (strlen(word) + across > cols) {
        fprintf(fp, "Invalid command\n");
        goto end;
      }

      if (!putAcross(word, across, down)) {
        fprintf(fp, "Invalid command\n");
        goto end;
      }

    } else if (strcmp("down", cmd) == 0) { //if down

      fscanf(fp, "%38[^\n]", rest); // get all the other values

      char *token = strtok(rest, " ");
      int count = 0;
      while (token)
      {
        if (count == 0)
        {
          strcpy(down_S, token);
          down = atoi(down_S);
        }
        else if (count == 1)
        {
          strcpy(across_S, token);
          across = atoi(across_S);
        }
        else if (count == 2)
        {
          strcpy(word, token);
        }
        else
        {
          fprintf(fp, "Invalid command\n");
          goto end;
        }

        token = strtok(NULL, " ");
        count++;
      }

      if (strlen(word) > WORD_LIMIT)
      { // do a bunch of error checking
        fprintf(fp, "Invalid command\n");
        goto end;
      }

      if (!checkWord(word))
      {
        fprintf(fp, "Invalid command\n");
        goto end;
      }

      if (across >= cols || across < 0)
      {
        fprintf(fp, "Invalid command\n");
        goto end;
      }

      if (down >= rows || down < 0)
      {
        fprintf(fp, "Invalid command\n");
        goto end;
      }

      if (strlen(word) + down > rows)
      {
        fprintf(fp, "Invalid command\n");
        goto end;
      }

      if (!putDown(word, across, down))
      {
        fprintf(fp, "Invalid command\n");
        goto end;
      }
    } else if (strcmp("board", cmd) == 0) {
      printBoard(fp); //print the board
    } else if (strcmp("quit", cmd) == 0) { //extra exit check just to make sure it doesn't run forever
      exit(EXIT_SUCCESS);
    } 
    else 
      {
      fprintf(fp, "Invalid command\n"); //if not any of the above, then invalid 
    }

    //reset the values for the next command
    end:
    memset(cmd, ' ', sizeof(cmd));
    memset(word, ' ', sizeof(word));
    memset(down_S, ' ', sizeof(down_S));
    memset(across_S, ' ', sizeof(across_S));
    across = 0;
    down = 0;

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }
  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  //check arguments of starting server
  if (argc != 3) {
    fail("usage: scrabbleServer <rows> <cols>");
  }

  //get the rows and cols of the board
  rows = atoi(argv[1]);
  cols = atoi(argv[2]);

  //create the semaphore
  sem_init(&boardLock, 0, 1);

  //mallocs the board
  board = malloc( rows * sizeof(char *));

  for (int i = 0; i < cols; i++) {
    board[i] = malloc(cols * sizeof(char));
  }

  //clears the board out
  for (int i = 0; i < rows; i++) {
    for (int j = 0; j < cols; j++) {
      board[i][j] = ' ';
    }
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    //create thread and and pass it the handleClient with the socket
    pthread_t thread;
    if (pthread_create(&thread, NULL, handleClient, (void*) &sock) != 0)
      fail("Can't create a client thread");

    //detatch the thread from the main thread
    pthread_detach(thread);
  }

  // Stop accepting client connections and all the frees (never reached).
  close( servSock );
  for (int i = 0; i < cols; i++) {
    free(board[i]);
  }
  free(board);
  sem_destroy(&boardLock);
  
  return 0;
}
