#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26400"

/** Maximum word length */
#define WORD_LIMIT 26

/** buffer overflow length check */
#define MAX_LENGTH 100
/** semaphore for access to the board */
sem_t editing;

// typedef struct {
//   char **board;
//   int sock;
//   int r;
//   int c;

// }boardState;

static char **board;
static int rowClient;
static int colClient;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

static void usage() {

  printf("usage: scrabbleServer <rows> <cols>\n");
  exit(EXIT_FAILURE);

}




/** handle a client connection, close it when we're done. */
void *handleClient( void *sockTemp ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  // boardState *state = (boardState *)sockTemp;
  int sock = *(int *)sockTemp;
  // int sock = state->sock;
 

  FILE *fp = fdopen( sock, "a+" );

  // Prompt the user for a command.
  fprintf( fp, "cmd> " );
  // Temporary values for parsing commands.
  char cmd[ 11 ];
  char wholeCommand[MAX_LENGTH];
  int startRow;
  int startCol;
  char word[WORD_LIMIT + 11];
  // char coordinateWord[WORD_LIMIT + 5];
  while ( fgets( wholeCommand, MAX_LENGTH, fp ) != NULL) {
    // Just echo the command back to the client for now.
    // fprintf(fp, "%s", wholeCommand);
    int found = sscanf(wholeCommand, "%s %d %d %s", cmd, &startRow, &startCol, word);
    bool valid = true;
    int wordLength = strlen(word);
    for(int i = 0; i < wordLength; i++) {
      if(!islower(word[i])) {
        valid = false;
      }
    }
    if((strcmp(cmd, "across") == 0 && (wordLength + startCol) > colClient) || (strcmp(cmd, "down") == 0 && (wordLength + startRow) > rowClient)) {
      valid = false;
    }
    // if(found != 4) {
    //   valid = false;
    // }
    if(wordLength > WORD_LIMIT) {
      valid = false;
    }
    if(!valid) {
      fprintf(fp, "Invalid command\n");
      
      
    }else if(strcmp(cmd, "board") == 0 ) {

      for(int i = 0; i < colClient + 2; i++) {
        if (i == 0 || i == colClient + 1) {
          fprintf(fp, "+");
          if(i == colClient + 1) {
            fprintf(fp, "\n");
          }
        } else {
          fprintf(fp, "-");
        }
      }
      for(int i = 0; i < rowClient; i++) {
        fprintf(fp, "|");
        for(int j  = 0; j < colClient; j++) {
          fprintf(fp, "%c", board[i][j]); 
        }
        fprintf(fp, "|");
        fprintf(fp, "\n");
      }


        for(int i = 0; i < colClient + 2; i++) {
        if (i == 0 || i == colClient + 1) {
          fprintf(fp, "+");
          if(i == colClient + 1) {
            fprintf(fp, "\n");
          }
        } else {
          fprintf(fp, "-");
        }
      }
    } else if (strcmp(cmd, "across") == 0 && found == 4) {
        sem_wait(&editing);
        int idx = 0;
        bool validated = true;
        // fprintf(fp, "%d", wordLength);
        for(int i = startCol; i < wordLength + startCol; i++) {
          
          if(board[startRow][i] == ' ' || board[startRow][i] == word[idx]) {
            // board[startRow][i] = word[idx];
            idx++;
          } else {
            fprintf(fp, "Invalid command\n");
            validated = false;
          }
          
        }
        if(validated) {
          idx = 0;
          for(int i = startCol; i < wordLength + startCol; i++) {
            board[startRow][i] = word[idx];
            idx++;
          }
        }

        sem_post(&editing);
    } else if (strcmp(cmd, "down") == 0 && found == 4) {
        sem_wait(&editing);
        int idx = 0;
        bool validated = true;
        for(int i = startRow; i < wordLength + startRow; i++) {
          if(board[i][startCol] == ' ' || board[i][startCol] == word[idx]) {
            // board[i][startCol] = word[idx];
            idx++;
          } else {
            fprintf(fp, "Invalid command\n");
            validated = false;
          }
        }
        
        if(validated) {
          idx = 0;
          for(int i = startRow; i < wordLength + startRow; i++) {
         
            board[i][startCol] = word[idx];
            idx++;
        }
        }
        sem_post(&editing);

    } else if (strcmp(cmd, "quit") == 0) {
        break;
    } else {
      fprintf(fp,"Invalid command\n");
    }
    
    
    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
   
  sem_init(&editing, 0 , 1);
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  if(argc < 3 || argc > 3) {
    usage();
  }

  int row = atoi(argv[1]);
  int col = atoi(argv[2]);

  if(row < 1 || col < 1) {
    usage();
  }

  rowClient = row;
  colClient = col;

  // boardState *temp = (boardState *)malloc(sizeof(boardState));
  board = (char **)malloc(row * sizeof(char *));
  for(int i = 0; i < row; i++) {
    board[i] = (char*)malloc(col * sizeof(char));
  }
 
  // temp->r = row;
  // temp->c = col;
  for(int i = 0; i < row; i++) {
    for(int j  = 0; j < col; j++) {
      board[i][j] = ' ';
      
      
    }
    
  }

  
  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);
  pthread_t thread_worker;
  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    // temp->sock = sock;
    if(pthread_create(&thread_worker, NULL, handleClient, (void *)&sock) != 0) {
      fail( "Can't create a child thread" );
    }
    pthread_detach(thread_worker);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  free(board);
  
  return 0;
}
