#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26158"

/** Maximum word length */
#define WORD_LIMIT 26

// Upper boundary ASCII value
#define ASCII_UP 57

// Lower boundary ASCII value
#define ASCII_LOW 48

// Rows and columns of board
int rows = 0;
int cols = 0;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// Print out a usage message, then exit.
static void usage() {
  printf( "usage: scrabbleServer <rows> <cols>\n" );
  exit( 1 );
}

// Parse string as int
int stringToInt( char string[] ) {
  // Iterate through string to take each digit and add it to value
  int value = 0, currDigit = 0, i = 0;
  while ( string[i] != '\0' ) {
    // Not a numerical digit (0-9)
    if ( string[i] < ASCII_LOW || string[i] > ASCII_UP ) {
        return -1;
    }

    currDigit = string[i] - ASCII_LOW;
    value = currDigit + ( value * 10 );

    i++;
  }

  return value;
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *args ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int *sock = ( int * ) args;
  FILE *fp = fdopen( *sock, "a+" );

  // Create board of appropriate size
  char board[ rows ][ cols ];

  // Create 2D board of spaces (empty board)
  for ( int i = 0; i < rows; i++ ) {
    for ( int j = 0; j < cols; j++ ) {
      board[ i ][ j ] = ' ';
    }
  }
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 5 ][ 11 ];
  int i = 0;
  bool validWord = true;
  while ( fscanf( fp, "%10s", cmd[ i ] ) == 1 &&
          strcmp( cmd[ i ], "quit" ) != 0 ) {
    
    // Check for horizontal word placement
    if ( strcmp( cmd[ i ], "across" ) == 0 ) {
      i++; // Increment i to get row number
      fscanf( fp, "%10s", cmd[ i ] );
      int row = stringToInt( cmd[ i ] );
      i++; // Increment i to get col number
      fscanf( fp, "%10s", cmd[ i ] );
      int col = stringToInt( cmd[ i ] );

      // Scan in word
      i++;
      fscanf( fp, "%10s", cmd[ i ] );
      char *word = cmd[ i ];
      validWord = true;

      if ( strlen( word ) > WORD_LIMIT ) {
        validWord = false;
        write( *sock, "Invalid command.\n", 17);
      }
      // Check if word will fit
      else if ( ( col + strlen( word ) )  > cols ) {
        validWord = false;
        write( *sock, "Invalid command.\n", 17);
      }
      else {
        // Make sure letters in place already agree
        for ( int j = col; j < strlen( word ); j++ ) {
          if ( board[ row ][ j ] != word[ j - col ] ) {
            if ( board[ row ][ j ] != ' ' ) {
              validWord = false;
              write( *sock, "Invalid command.\n", 17 );
              j = strlen( word );
            }
          }
        }
      }

      // All good, place word
      if ( validWord ) {
        for ( int j = col; j < strlen( word ); j++ ) {
          board[ row ][ j ] = word[ j - col ];
        }
      }

    }
    // Check for horizontal word placement
    else if ( strcmp( cmd[ i ], "down" ) == 0 ) {
      i++; // Increment i to get row number
      fscanf( fp, "%10s", cmd[ i ] );
      int row = stringToInt( cmd[ i ] );
      i++; // Increment i to get col number
      fscanf( fp, "%10s", cmd[ i ] );
      int col = stringToInt( cmd[ i ] );

      // Scan in word
      i++;
      fscanf( fp, "%10s", cmd[ i ] );
      char *word = cmd[ i ];
      validWord = true;

      if ( strlen( word ) > WORD_LIMIT ) {
        validWord = false;
        write( *sock, "Invalid command.\n", 17);
      }
      // Check if word will fit
      else if ( ( row + strlen( word ) )  > rows ) {
        validWord = false;
        write( *sock, "Invalid command.\n", 17);
      }
      else {
        // Make sure letters in place already agree
        for ( int j = row; j < strlen( word ); j++ ) {
          if ( board[ j ][ col ] != word[ j - row ] ) {
            if ( board[ j ][ col ] != ' ' ) {
              validWord = false;
              write( *sock, "Invalid command.\n", 17 );
            }
          }
        }
      }

      // All good, place word
      if ( validWord ) {
        for ( int j = row; j < strlen( word ); j++ ) {
          board[ j ][ col ] = word[ j - row ];
        }
      }

    }
    else if ( strcmp( cmd[ i ], "board" ) == 0 ) {

      // Write header template
      write( *sock, "+", 1 );
      for ( int i = 0; i < cols; i++ ) {
        write( *sock, "-", 1 );
      }
      write( *sock, "+\n", 2 );

      // Write board contents
      for ( int i = 0; i < cols; i++ ) {
        write( *sock, "|", 1 );
        write( *sock, board[ i ], rows );
        write( *sock, "|\n", 2 );
      }

      // Write footer template
      write( *sock, "+", 1 );
      for ( int i = 0; i < cols; i++ ) {
        write( *sock, "-", 1 );
      }
      write( *sock, "+\n", 2 );

    }
    else {
      write( *sock, "Invalid command.\n",  17 );
    }

    // Prompt the user for the next command.
    i = 0;
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Read inputs and create Scrabble board
  if ( argc != 3 ) { // Better have three arguments
    usage();
  }
  // Read row and col values from input
  rows = stringToInt( argv[ 1 ] );
  cols = stringToInt( argv[ 2 ] );

  // Make sure inputted values aren't negative
  if ( rows < 0 || cols < 0 ) {
    fail( "Invalid command." );
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    
    handleClient( &sock );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
