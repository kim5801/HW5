#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26270"

/** Maximum word length */
#define WORD_LIMIT 26

/** Maximum command length */
#define MAX_COMMAND 8

/** Number to add to row and column to make room for border */
#define BORDER 2

/** The number of rows */
int finalRow;
/** The number of columns */
int finalCol;
/** The board */
char **board;
/** Allows the game to keep asking for commands */
bool keepItGoing;
/** Semaphore to prevent race conditions between threads */
sem_t holdIt;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

//Handles the signal user gives when it wants to stop running program
void freeBeforeLeave(int signal) {
  for (int i = 0; i < finalRow + BORDER; ++i) {
    free(board[i]);
  }
  free(board);

  keepItGoing = false;
}

//creates the border around the board
void makeBoard(int row, int col) {
  finalRow = row;
  finalCol = col;

  board = (char **)malloc((finalRow + BORDER) * sizeof(char *));

  for (int i = 0; i < finalRow + BORDER; ++i) {
    board[i] = (char *)malloc((finalCol + BORDER + 1) * sizeof(char));
  }

  //creating the top and bottom and corner border
  for (int i = 0; i < finalCol + BORDER; ++i) {
    if (i == 0 || i == finalCol + 1) {
      board[0][i] = '+';
      board[finalRow + 1][i] = '+';
    }
    else {
      board[0][i] = '-';
      board[finalRow + 1][i] = '-';
    }
  }
  board[0][finalCol + BORDER] = '\0';
  board[finalRow + 1][finalCol + BORDER] = '\0';

  //creating the side borders
  for (int i = 1; i < finalRow + BORDER; ++i) {
    if (i != finalRow + 1 && i != 0) {
      board[i][0] = '|';
      board[i][finalCol + 1] = '|'; 
    } 
    board[i][finalCol + BORDER] = '\0';
  }

  //filling in the board space with spaces
  for (int i = 1; i <= finalRow; ++i) {
    for (int j = 1; j <= finalCol; ++ j) {
      board[i][j] = ' ';
    }
  }
}

//prints the current state of the board
void showBoard(FILE *fp) {
  sem_wait(&holdIt);


  for (int i = 0; i < finalRow + BORDER; ++i) {
    fprintf(fp, "%s\n", board[i]);
  }

  sem_post(&holdIt);
}

/**
 * Adds the given word to the board going horizontally
 * 
 * @param row the row where the word will start
 * @param col the column where the word will start
 * @param word the word to be added
 * @return true if able to be added
 * @return false if not able to be added
 */
bool goAcross(int row, int col, char const *word) {
  sem_wait(&holdIt);
  //checking if word will fit into board
  if (strlen(word) > (finalCol - col)) {
    sem_post(&holdIt);
    return false;
  }
  if (strlen(word) > WORD_LIMIT) {
    sem_post(&holdIt);
    return false;
  }
  //checking if the word only contains lowercase letters
  for (int i = 0; i < strlen(word); ++i) {
    if (word[i] < 'a' || word[i] > 'z') {
      sem_post(&holdIt);
      return false;
    }
  }

  //current letter of the word
  int num = 0;
  //checking if there are any letters already on the board
  for (int i = col + 1; i < col + strlen(word) + 1; ++i) {
    //if there is a letter on the board, it must be the same letter as where the letter of the word
    //would land
    if (board[row + 1][i] != ' ' && board[row + 1][i] != word[num]) {
      sem_post(&holdIt);
      return false;
    }
    ++num;
  }

  num = 0;

  //everything checks out so word can be put on the board
  for (int i = col + 1; i < col + strlen(word) + 1; ++i) {
    board[row + 1][i] = word[num];
    ++num;
  }  

  sem_post(&holdIt);
  return true;
}

/**
 * Adds the given word to the board going vertically
 * 
 * @param row the row where the word will start
 * @param col the column where the word will start
 * @param word the word to be added
 * @return true if able to be added
 * @return false if not able to be added
 */
bool goDown(int row, int col, char const *word) {
  sem_wait(&holdIt);
  //checking if word will fit into board
  if (strlen(word) > (finalRow - row)) {
    sem_post(&holdIt);
    return false;
  }
  if (strlen(word) > WORD_LIMIT) {
    sem_post(&holdIt);
    return false;
  }
  //checking if the word only contains lowercase letters
  for (int i = 0; i < strlen(word); ++i) {
    if (word[i] < 'a' || word[i] > 'z') {
      sem_post(&holdIt);
      return false;
    }
  }

  //current letter of the word
  int num = 0;
  //checking if there are any letters already on the board
  for (int i = row + 1; i < row + strlen(word) + 1; ++i) {
    //if there is a letter on the board, it must be the same letter as where the letter of the word
    //would land
    if (board[i][col + 1] != ' ' && board[i][col + 1] != word[num]) {
      sem_post(&holdIt);
      return false;
    }
    ++num;
  }

  num = 0;

  //everything checks out so word can be put on the board
  for (int i = row + 1; i < row + strlen(word) + 1; ++i) {
    board[i][col + 1] = word[num];
    ++num;
  }  

  sem_post(&holdIt);
  return true;
}

/** handle a client connection, close it when we're done. */
void *handleClient(void *sock) {
  int new_sock = *((int *)sock);
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( new_sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // The entire command from the user.
  char fullCmd[1024];
  // What command it is
  char cmd[MAX_COMMAND];
  // The word to add to the board
  char word[WORD_LIMIT + BORDER];
  // The row where the word will start
  int row;
  // The column where the word will start
  int col;
  fscanf(fp, "%[^\n]s", fullCmd);
  // Number of commands 
  int numCommand = sscanf(fullCmd, "%7s %d %d %27s", cmd, &row, &col, word); 
  keepItGoing = true;
  while (keepItGoing) {
    //QUIT COMMAND
    if (strcmp(cmd, "quit") == 0) {
      if (numCommand != 1) {
        fprintf(fp, "Invalid command\n");
        continue;
      }
      break;
    }
    //BOARD COMMAND
    else if (strcmp(cmd, "board") == 0) {
      if (numCommand != 1) {
        fprintf(fp, "Invalid command\n");
        continue;
      }
      showBoard(fp);
    }
    //ACROSS COMMAND
    else if (strcmp(cmd, "across") == 0) {
      if (numCommand != 4) {
        fprintf(fp, "Invalid command\n");
        continue;
      }
      if (!goAcross(row, col, word)) {
        fprintf(fp, "Invalid command\n");
      }
    }
    //DOWN COMMAND
    else if (strcmp(cmd, "down") == 0) {
      if (numCommand != 4) {
        fprintf(fp, "Invalid command\n");
        continue;
      }
      if (!goDown(row, col, word)) {
        fprintf(fp, "Invalid command\n");
      }
    }
    //INVALID COMMANDS
    else {
      fprintf(fp, "Invalid command\n");
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
    fscanf(fp, "%[^\n]s", fullCmd);
    numCommand = sscanf(fullCmd, "%7s %d %d %27s", cmd, &row, &col, word);
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  //how many rows the user wants the board to have
  int row;
  //how many columns the user wants the board to have
  int col;

  //there must be 2 commands after starting program
  if (argc != 3) {
    fail("usage: scrabbleServe <rows> <cols>");
  }

  //trying to get number of rows and columns
  if (sscanf(argv[1], "%d", &row) != 1 || sscanf(argv[2], "%d", &col) != 1) {
    fail("usage: scrabbleServe <rows> <cols>");
  }
  //rows and columns must both be integers greater than 0
  if (row <= 0 || col <= 0) {
    fail("usage: scrabbleServe <rows> <cols>");
  }

  //create the board after checking for invalid commands
  makeBoard(row, col);

  //signal handling so the board can be freed
  //code from HW1 in server
  struct sigaction act;
  act.sa_handler = freeBeforeLeave;
  sigemptyset(&(act.sa_mask));
  act.sa_flags = 0;
  sigaction(SIGINT, &act, 0);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  //initialize semaphore
  sem_init(&holdIt, 0, 1);

  while ( true  ) {
    pthread_t thread;
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    if (pthread_create(&thread, NULL, handleClient, &sock) != 0) {
      fprintf(stderr, "Could not create thread\n");
    }
 
    pthread_detach(thread);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
