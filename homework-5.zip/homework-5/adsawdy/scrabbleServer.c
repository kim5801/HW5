#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26036"

/** Maximum word length */
#define WORD_LIMIT 26

// monitor lock
pthread_mutex_t lock;

// whether to check words
bool checkWords = false;

// dictionary file if applicable
FILE *dict;

typedef struct {
  // pointer to 2D integer array board
  int *board;
  // number of rows
  int rows;
  // number of columns
  int cols;
} Crabble;

// local variable of my very own Crabble board tm
Crabble crab;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** helps get index of "2D" array */
int getIndex(int r, int c) {
  return c + r * crab.cols;
}

/**
 * breaks the line into
 * individual words, adds null termination between the words so each word is a separate string, and
 * it fills in a pointer in the words array to point to the start of each word. from hw 1
 * @param line user input
 * @param words additional command elements, at least 513 elements in length (1024-character input line)
 * @return the number of words found in the given line
 */
int parseCommand( char *line, char *words[] )
{
  int wordIdx = 0;
  bool inspace = true;
  for (char *i = line; *i; i++) {
    if (isspace(*i)) {
       if (!inspace) {
         *i = '\0';
         inspace = true;
       }
    } else {
      if (inspace) {
        words[wordIdx] = i;
        wordIdx++;
        inspace = false;
      }
    }
  }
  return wordIdx;
}

/** prints game board */
void printBoard(FILE *fp) {
  // top of board
  fprintf(fp, "+");
  for (int i = 0; i < crab.cols; i++) {
    fprintf(fp, "-");
  }
  fprintf(fp, "+\n");
  // middle of board, contents of board + rim
  for (int i = 0; i < crab.rows; i++) {
    fprintf(fp, "|");
    for (int j = 0; j < crab.cols; j++) {
       size_t index = getIndex(i, j);
       fprintf(fp, "%c", crab.board[index]);
    }
    fprintf(fp, "|\n");
  }
  // bottom of board
  fprintf(fp, "+");
  for (int i = 0; i < crab.cols; i++) {
    fprintf(fp, "-");
  }
  fprintf(fp, "+\n");
}

bool across(int r, int c, FILE *fp, char *words, bool toplace) {
  char newWord[ WORD_LIMIT + 1];
  memset(newWord, 0, WORD_LIMIT + 1);
  // "CHECK" word
  int len = strlen(words);
  bool checked = true;
  if (len > WORD_LIMIT) {
    checked = false;
    return false;
  }
  if (len + c - 1 >= crab.cols) {
    checked = false;
    return false;
  }
  
  char *checkWord = words;
  for (int i = 0; i < len; i++) {
    char ch = checkWord[i];
    if (ch < 'a' || ch > 'z') {
      checked = false;
      return false;
    }
  }
  
  if (checked) {
    // "GET" word
    int i = r;
    size_t index;
    // goes "across" columns
    // find "beginning" col
    int first = c;
    for (int j = c - 1; j >= 0; j--) {
      index = getIndex(i, j);
      char ch = crab.board[index];
      if (ch == ' ') {
        break;
      } else {
        first = j;
      }
    }
    for (int j = first; j < c; j++) {
      index = getIndex(i, j);
      char ch = crab.board[index];
      strncat(newWord, &ch, 1);
      
      //fprintf(fp, "%c", crab.board[index]);
    }
    
    //fprintf(fp, "\nafter finding first = i: %d > j: %d + str: %s\nc: %d r: %d\n", i, first, newWord, c, r);
    
    bool valid = true; // false if conflicting characters
    size_t count = 0;
    char *thisWord = words;
    for (int j = c; j < c + len; j++) {
      index = getIndex(i, j);
      char ch = crab.board[index];
      if (ch != ' ' && thisWord[count] != ch) {
        valid = false;
        return false;
      } else {
        char x = thisWord[count];
        strncat(newWord, &x, 1);
      }
      count++;
    }
    
    //fprintf(fp, "begin+mid str: %s\n", newWord);
    
    for (int j = c + len; j < crab.cols; j++) {
      index = getIndex(i, j);
      char ch = crab.board[index];
      if (ch == ' ') {
        break;
      } else {
        strncat(newWord, &ch, 1);
      }
    }
    
    
    if (valid) {
    
      if (toplace == false && strlen(newWord) == 1) {
        return true;
      }
    
      // "LOOKUP" word (opt)
      fseek(dict, 0, SEEK_SET);
      bool place = true;
      if (checkWords) {
        // something
        place = false;
        char line[50];
        while(fscanf(dict, "%s", line) != EOF) {
          if (strcmp(line, newWord) == 0) {
            place = true;
            break;
          }
        }
      }
      if (place == false) {
        return false;
      }
    
      if (place && toplace) {
        // "PLACE" word
        int nCount = 0;
        for (int j = first; j < c + len; j++) {
          index = getIndex(i, j);
          crab.board[index] = newWord[nCount];
          nCount++;
        }
      }
    }
  }
  return true;
}

bool down(int r, int c, FILE *fp, char *words, bool toplace) {
  char newWord[ WORD_LIMIT + 1];
  memset(newWord, 0, WORD_LIMIT + 1);
  // "CHECK" word
  int len = strlen(words);
  bool checked = true;
  if (len > WORD_LIMIT) {
    checked = false;
    return false;
  }
  if (len + r - 1 >= crab.rows) {
    checked = false;
    return false;
  }
  
  char *checkWord = words;
  for (int i = 0; i < len; i++) {
    char ch = checkWord[i];
    if (ch < 'a' || ch > 'z') {
      checked = false;
      return false;
    }
  }
  
  if (checked) {
    // "GET" word
    int j = c;
    size_t index;
    // goes "down" rows
    // find "beginning" row
    int first = r;
    for (int i = r - 1; i >= 0; i--) {
      index = getIndex(i, j);
      char c = crab.board[index];
      if (c == ' ') {
        break;
      } else {
        first = i;
      }
    } // reached
    for (int i = first; i < r; i++) {
      index = getIndex(i, j);
      char ch = crab.board[index];
      strncat(newWord, &ch, 1);
      
      //fprintf(fp, "%c", crab.board[index]);
    }
    
    //fprintf(fp, "\nafter finding first = i: %d > j: %d + str: %s\nc: %d r: %d\n", i, first, newWord, c, r);
    
    bool valid = true; // false if conflicting characters
    size_t count = 0;
    char *thisWord = words;
    for (int i = r; i < r + len; i++) {
      index = getIndex(i, j);
      char ch = crab.board[index];
      if (ch != ' ' && thisWord[count] != ch) {
        valid = false;
        return false;
      } else {
        char x = thisWord[count];
        strncat(newWord, &x, 1);
      }
      count++;
    } //reached
    
    //fprintf(fp, "begin+mid str: %s\n", newWord);
    
    for (int i = r + len; i < crab.rows; i++) {
      index = getIndex(i, j);
      char ch = crab.board[index];
      if (ch == ' ') {
        break;
      } else {
        strncat(newWord, &ch, 1);
      }
    }
    
    
    
    if (valid) {
    
      if (toplace == false && strlen(newWord) == 1) {
        return true;
      }
      
      // "LOOKUP" word (opt)
      fseek(dict, 0, SEEK_SET);
      bool place = true;
      if (checkWords) {
        // something
        place = false;
        char line[50];
        while(fscanf(dict, "%s", line) != EOF) {
          if (strcmp(line, newWord) == 0) {
            place = true;
            break;
          }
        }
      }
      if (place == false) {
        return false;
      }
    
      if (place && toplace) {
        // "PLACE" word
        int nCount = 0;
        for (int i = first; i < r + len; i++) {
          index = getIndex(i, j);
          crab.board[index] = newWord[nCount];
          nCount++;
        }
      }
    }
  }

  return true;
}

/** handle a client connection, close it when we're done. */
void *handleClient( int sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // remember: fprintf will flush unread input
  
  // simplest synchronization: simply make commands that rely on the board happen within a monitor
  // thereby forcing different clients to take turns executing those commands
  
  // parse terminal line
  int i = 0;
  char line[ 1025 ];
  char* words[513];
  while (true) {
    
    // Prompt the user for a command.
    fprintf( fp, "cmd> " );
    
    memset(words, 0, 513);
    // grabs 1024 characters to prevent overflow
    fgets(line, 1024, fp);
    
    i = parseCommand(line, words);
    
    if ( i <= 0 || (i > 1 && i < 4) || i > 4 ) { // invalid length
      fprintf(fp, "Invalid command\n");
    } else if ( i == 1 ) { // check == board / quit
      if ( strcmp( words[0], "board" ) == 0 ) {
        
        // BOARD
        pthread_mutex_lock( &lock ); // enter monitor 
        printBoard(fp);
        pthread_mutex_unlock( &lock ); // exit monitor
        
      } else if ( strcmp( words[0], "quit" ) == 0 ) {
        
        // QUIT
        break; // exit while loop, terminate thread
        
      } else {
        fprintf(fp, "Invalid command\n");
      }
    } else if ( i == 4) { // check == across / down
      // check 2nd, 3rd argument are numbers within bounds
      int r = -1;
      int c = -1;
      if ( (sscanf( words[1], "%d", &r ) == 1) && r >= 0 && r <= crab.rows - 1 &&
           (sscanf( words[2], "%d", &c ) == 1) && c >= 0 && c <= crab.cols - 1 ) {
        if ( strcmp( words[0], "across" ) == 0 ) {
          
          pthread_mutex_lock( &lock ); // enter monitor
          
          // ACROSS
          //fprintf(fp, "attempt across w/ r: %d c: %d : word: %s\n", r, c, words[3]);
          
          
          
          char *word = words[3];
          char ch[2] = {word[0], '\0'};
          
          if (down(r, c, fp, ch, false) == true) {
            if (across(r, c, fp, word, true) == false) {
              fprintf(fp, "Invalid command\n");
            }
          } else {
            fprintf(fp, "Invalid command\n");
          }
          
          pthread_mutex_unlock( &lock ); // exit monitor
          
        } else if ( strcmp( words[0], "down" ) == 0 ) {
          
          pthread_mutex_lock( &lock ); // enter monitor
          //DOWN
          //fprintf(fp, "attempt down w/ r: %d c: %d : word: %s\n", r, c, words[3]);
          
          
          char *word = words[3];
          char ch[2] = {word[0], '\0'};
          
          if (across(r, c, fp, ch, false) == true) {
            if (down(r, c, fp, word, true) == false) {
              fprintf(fp, "Invalid command\n");
            }
          } else {
            fprintf(fp, "Invalid command\n");
          }
          
          pthread_mutex_unlock(&lock); // exit monitor
          
        } else {
          fprintf(fp, "Invalid command\n");
        }
      } else {
        fprintf(fp, "Invalid command\n");
      }
    }
    
    
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

/** Start routine for each thread. Passes argument is a socket */
void *threadRoutine( void *arg ) {
  int * pSock = (int*)arg;
  // handle client with the integer pointed to by pSock as the socket
  return handleClient (*pSock);
}

int main( int argc, char *argv[] ) {
  // initialize scrabble structure based on arguments
  if (argc != 3) {
    fail("incorrect number of arguments");
  }
  int r = 0;
  int c = 0;
  // if arguments are integers + within bounds, create game board
  if ((sscanf( argv[ 1 ], "%d", &r ) == 1) && r > 0 &&
      (sscanf( argv[ 2 ], "%d", &c ) == 1) && c > 0) {
    crab.rows = r;
    crab.cols = c;
    crab.board = (int*)malloc(crab.rows * crab.cols * sizeof(int));
  } else {
    fail("provide integer within board boundaries");
  }
  
  //printf("rows: %d\ncols: %d\n", crab.rows, crab.cols);
  
  // initialize scrabble to be "empty"
  for (int i = 0; i < crab.rows; i++) {
    for (int j = 0; j < crab.cols; j++) {
       size_t index = getIndex(i, j);
       crab.board[index] = ' ';
       //crab.board[index] = 'a' + i;
       //printf("%d,%d : %d : %c\n", i, j, (int)index, crab.board[index]);
    }
  }
  
  //FILE* fout = stdout;
  //printBoard(fout);
  
  // dictionary if applicable
  dict = fopen("./words", "r");
  if (dict != NULL) {
    checkWords = true;
    //printf("dict open\n\n");
  }
  

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);
  
  // each client will have its own thread
  // threads are not joined with when done, simply told to detach with pthread_detach
  // this means the threads do not need to be kept up with and can handle, free themselves when done
  // each thread uses handleClient, and some commands clients call can cause race conditions when multi-threaded
  // threads are passed a socket as their argument
  
  // initialize monitor's main lock, to be entered when parsing + executing commands
  if (pthread_mutex_init( &(lock), NULL ) != 0)
    fail("failed to initialize monitor mutex/lock");

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    
    // create a thread per client
    pthread_t thread;
    if ( pthread_create( &thread, NULL, threadRoutine, &sock ) != 0 ) {
      fail( "can't create thread" );
    }
    if ( pthread_detach(thread) != 0 ) { // tell thread to free itself when it terminates
      fail( "detach thread err" );
    }
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  free(crab.board);
  return 0;
}
