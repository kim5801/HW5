#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26348"

/** Maximum word length */
#define WORD_LIMIT 26
/** the board */
char **board;
/** number of rows */
int row = -1;
/** number of columns */
int col = -1;

sem_t boardSem;

/** prints out the usage error*/
void usageError() {
  printf("usage: scrabbleServer <rows> <cols>\n");
  exit(1);
}
/**
 * This method is used to convert the numbers given in move 
 * This method was pulled from hw 0 from my previous submission
 * 
 * @param input 
 * @return int 
 */
int atoiTej(char input[]) {
    // the counter for index in the while loop of input
    int i = 0;
    //the output number
    int number = 0;
    // if first value is negative, switch the value to negative one so we can multiply that value at the end to convert the value to a negative number
    while (input[i] != '\0') {
        if (input[i] < '0' || input[i] > '9') {
            //error message if the string contains any non integers and exits
            usageError();
        }
        //operation to add the consecutive digits of the number (first part multiplies the existing number by 10 to clear a space in the ones space)
        // second part converts the input number into an ascii value and adds it to the existing number (filling the number in the ones place)
        number = number * 10 + (input[i] - '0');
        i++;
    }
    return number;
}

/**
* reads the line from the file pointer
*/
char *readLine(FILE *fp) 
{
    
    int capacity = 10;
    char *line = ( char * ) malloc( capacity * sizeof( char ) );
    int len = 0;
    int currChar = fgetc(fp);
    if (currChar == EOF) {
        free(line);
        return NULL;
    }
    while ( currChar != EOF && currChar != '\n'  ) {
        if ( len >= capacity ) {
            capacity *= 2;
            line = (char *)realloc( line, capacity * sizeof( char ) );
        }
        line[len++] = currChar;
        currChar = fgetc(fp);
    }
    if ( len >= capacity ) {
        capacity *= 2;
        line = (char *)realloc( line, capacity * sizeof( char ) );
    }
    line[len] = 0;
    return line;
}
/**
* sets up the board based on the row and column numbers given to the server
*/
void setup() {
  // the following code allocates the memory for the board (given rows and columns)
  board = (char**)malloc(sizeof(char*) * (row + 2));
  for(int i = 0; i < row + 2; i++) {
    board[i] = (char*)malloc(sizeof(char) * (col + 2));
  }
  // the double for loop sets up the boarders and the spaces within the board
  for (int r = 0; r < row + 2; r++) {
    for(int c = 0; c < col + 2; c++) {
      if(r == 0 || r == row + 1) {
        if(c == 0 || c == col + 1) {
          board[r][c] = '+';
        }
        else {
          board[r][c] = '-';
        }
      }
      else if (c == 0 || c == col + 1) {
        board[r][c] = '|';
      }
      else {
        board[r][c] = ' ';
      }
    }
  }
}
/**
* prints the board
*/
void printBoard(FILE *fp) {
  sem_wait(&boardSem);
  for (int i = 0; i < row + 2; i++) {
    fprintf(fp, "%s\n", board[i]);
  }
  sem_post(&boardSem);
}

/***
* puts word across given word, column num and row num. prints out invalid command to fp if invalid
*
*/
void across(int rowNum, int colNum, char* word, FILE *fp) {
  int wordLen = strlen(word);
  // if word is greater than 27 characters, word is not allowed
  if (wordLen > 27) {
    fprintf(fp, "Invalid command\n");
    return;
  }
  // if row number is greater than number of rows
  if (rowNum > row) {
    fprintf(fp, "Invalid command\n");
    return;
  }
  // if column number is greater than number of columns
  if (colNum > col) {
    fprintf(fp, "Invalid command\n");
    return;
  }
  // if the word cannot fit at the given position
  if (!(col - colNum >= wordLen)) {
    fprintf(fp, "Invalid command\n");
    return;
  }
  // if word has any letters that aren't lowercase letters
  for (int i = 0; i < wordLen; i++) {
    if (word[i] < 'a' || word[i] > 'z') {
      fprintf(fp, "Invalid command\n");
      return;
    }
  }
  // if word cannot fit on the board given the current words on the board
  int index = 0;
  for (int i = colNum + 1; i < col + 1; i++ ) {
    if (board[rowNum + 1][i] != ' ' &&  board[rowNum + 1][i] != word[index]) {
      fprintf(fp, "Invalid command\n");
      return;
    }
    index++;
  }
  // filling the board with the word
  sem_wait(&boardSem);
  for (int i = colNum + 1; i < col + 1; i++ ) {
    board[rowNum + 1][i] = word[i - (colNum + 1)];
  }
  sem_post(&boardSem);
}

/***
* puts word down on board given word, column num and row num. prints out invalid command to fp if invalid
*
*/
void down(int rowNum, int colNum, char* word, FILE *fp) {
  int wordLen = strlen(word);
  // if word is greater than 27 characters, word is not allowed
  if (wordLen > 27) {
    fprintf(fp, "Invalid command\n");
    return;
  }
  // if row number is greater than number of rows
  if (rowNum > row) {
    fprintf(fp, "Invalid command\n");
    return;
  }
  // if column number is greater than number of columns
  if (colNum > col) {
    fprintf(fp, "Invalid command\n");
    return;
  }
  // if the word cannot fit at the given position
  if (!(row - rowNum >= wordLen)) {
    fprintf(fp, "Invalid command\n");
    return;
  }
  // if word has any letters that aren't lowercase letters
  for (int i = 0; i < wordLen; i++) {
    if (word[i] < 'a' || word[i] > 'z') {
      fprintf(fp, "Invalid command\n");
      return;
    }
  }
  // if word cannot fit on the board given the current words on the board
  int index = 0;
  for (int i = rowNum + 1; i < row + 1; i++ ) {
    if (board[i][colNum + 1] != ' ' && board[i][colNum + 1] != word[index]) {
      fprintf(fp, "Invalid command\n");
      return;
    }
    index++;
  }
  // filling the board with the word
  sem_wait(&boardSem);
  for (int i = rowNum + 1; i < row + 1; i++ ) {
    board[i][colNum + 1] = word[i - (rowNum + 1)];
  }
  sem_post(&boardSem);
}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *args ) {
  int *argptr = (int *) args;
  int sock = *argptr;
  // Here's a nice trick, wrap a C standard IO FILE 
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  while (true) {
    fprintf( fp, "cmd> " );
    // reads in the line from the file
    char *line = readLine(fp);
    int r;
    int c;
    char move[10];
    char word[WORD_LIMIT + 10];
    // checks the command
    int matches = sscanf(line, "%s %d %d %27s", move, &r, &c, word);
    // checks the match if it only has one
    if(matches == 1 ) {
      if (strcmp(move, "board") == 0) {
        printBoard(fp);
      }
      else if (strcmp(move, "quit") == 0) {
        break;
      }
      else {
        fprintf(fp, "Invalid command\n");
        continue;
      }
    }
    // if it has 4 matches, checks if the first word is down or across
    else if (matches == 4) {
      if (strcmp(move, "across") == 0) {
        across(r, c, word, fp);
      }
      else if (strcmp(move, "down") == 0) {
        down(r, c, word, fp);
      }
      // if none of the commands are matched, than it prints Invalid command
      else {
        fprintf(fp, "Invalid command\n");
        continue;
      }
    }

  }
  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  if(argc != 3) {
    printf("usage: scrabbleServer <rows> <cols>");
    exit(1);
  }
  if (sem_init(&boardSem, 0, 1) != 0 ) {
    fail("sem1 not working");
  }
  row = atoiTej(argv[1]);
  col = atoiTej(argv[2]);
  setup();

  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_t currThread;
    if ( pthread_create( &currThread, NULL, handleClient, &sock ) != 0 ) 
      fail( "Can't create a child thread\n" );
    pthread_detach(currThread);
  }
  if (sem_destroy(&boardSem) != 0 ) {
    fail("sem1 not working");
  }
  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
