#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26080"

/** Maximum word length */
#define WORD_LIMIT 26

// global pointer to the 2D array of the board
char** boardLayout;

// number of rows
int rows;

// number of columns
int cols;

// monitor to control access to boardLayout to make sure one thread doesn't write while another reads
pthread_mutex_t monitor;

// holds an array of valid words
char** words = NULL;

// flag to determine if we are spell checking
bool spellChecking = false;

// holds the size of the words array
int wordsSize = 0;

// holds the number of words in words
int numWords = 0;

// print out a usage message and exit
static void usage() {
  
  printf("usage: scrabbleServer <rows> <cols>\n");
  exit(EXIT_FAILURE);

}

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

// check if a string consists of digits 0-9
// returns true if the string is an invalid number
bool isInvalidNum(char* nums) {

  // make sure each element in argv[1] and argv[2] is a number
  bool someNonNumber = false;

  for(int i = 0; i < strlen(nums) && !someNonNumber; i++) {
    
    if(nums[i] < 48 || nums[i] > 57) {
        someNonNumber = true;
    }

  }

  return someNonNumber;

}

char** makeLocalBoard() {

  char** boardLayoutLocal = (char**) malloc(rows * sizeof(char*));
  for(int i = 0; i < rows; i++) {
    boardLayoutLocal[i] = (char*) malloc(cols * sizeof(char));
  }

  for(int i = 0; i < rows; i++) {

    for(int j = 0; j < cols; j++) {

      boardLayoutLocal[i][j] = boardLayout[i][j];

    }

  }

  return boardLayoutLocal;

}

void freeLocalBoard(char** boardLayoutLocal) {

  for(int i = 0; i < rows; i++) {
    free(boardLayoutLocal[i]);
  }

  free(boardLayoutLocal);

}

bool checkBoardSpelling(char** board) {

  // for all rows
  for(int i = 0; i < rows; i++) {

    int currentWordIdx = 0;

    // longest word in a row could be size cols
    char currentWord[cols + 1];

    for(int j = 0; j < cols; j++) {

      currentWord[currentWordIdx++] = board[i][j];

    }
    
    // add NULL terminator
    currentWord[cols] = '\0';
    
    // make the word (blank spots in the board are spaces)
    char* beingChecked = strtok(currentWord, " ");

    // if(beingChecked == NULL) {
    //   printf("beingChecked is NULL\n");
    // }
    // else {
    //   printf("%s\n", beingChecked);
    // }

    // if the word being checked is not NULL and its length is at least 2
    while(beingChecked != NULL && strlen(beingChecked) >= 2) {

      // flag to see if a word being inspected has any matches to a known word
      bool anyMatches = false;

      // compare to all words
      for(int i = 0; i < numWords; i++) {

        if(strcmp(words[i], beingChecked) == 0) {
          anyMatches = true;
        }

      }

      if(!anyMatches) {
        return false;
      }

      beingChecked = strtok(NULL, " ");

    }

  }

  // for all columns
  for(int i = 0; i < cols; i++) {

    int currentWordIdx = 0;

    // longest word in a col could be size rows
    char currentWord[rows + 1];

    for(int j = 0; j < rows; j++) {

      currentWord[currentWordIdx++] = board[j][i];

    }

    // add NULL terminator
    currentWord[rows] = '\0';

    // make the word (blank spots in the board are spaces)
    char* beingChecked = strtok(currentWord, " ");

    // if(beingChecked == NULL) {
    //   printf("beingChecked is NULL\n");
    // }
    // else {
    //   printf("%s\n", beingChecked);
    // }

    // if the word being checked is not NULL and its length is at least 2
    while(beingChecked != NULL && strlen(beingChecked) >= 2) {

      // flag to see if a word being inspected has any matches to a known word
      bool anyMatches = false;

      // compare to all words
      for(int i = 0; i < numWords; i++) {

        if(strcmp(words[i], beingChecked) == 0) {
          anyMatches = true;
        }

      }

      if(!anyMatches) {
        return false;
      }

      beingChecked = strtok(NULL, " ");

    }

  }


  return true;

}

/** handle a client connection, close it when we're done. */
void *handleClient( int sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // // make sure socket was successfully transferred
  // printf("%d\n", sock);
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // the longest possible input would consists of across rows cols 26-letter word
  // so, to have a formula:
  // longest possible input = 6 (across) + 1(s1) + 1(s2) + 1(s3) + 26 + length of rows + length of cols
  // = 35 + length of rows + length of cols
  
  // find the longest possible input for the given number of rows and coulmns

  int lengthOfRows = 0;

  // if there are 10 rows, the row should be 0-9
  int localRows = rows - 1;

  while(localRows > 0) {

    localRows = localRows / 10;
    lengthOfRows++;

  }

  int lengthOfCols = 0;
  
  // if there are 10 cols, the col should be 0-9
  int localCols = cols - 1;

  while(localCols > 0) {

    localCols = localCols / 10;
    lengthOfCols++;

  }

  int longestCommandLength = 35 + lengthOfRows + lengthOfCols;

  // create a string that could hold the largest possible input (an additional + 1 for the '\n' that should be read in / the '\0' terminator)
  char longestCommand[longestCommandLength + 1];

  // // Temporary values for parsing commands.
  // char cmd[ longestCommandLength ];
  
  // will be updated to false if the user quits
  bool hasNotQuit = true;

  while ( hasNotQuit ) {
    // // Just echo the command back to the client for now.
    // fprintf( fp, "%s\n", longestCommand );

    bool gotNewLine = false;

    // read in 1 character at a time to prevent buffer overflow
    for(int i = 0; i < longestCommandLength && !gotNewLine; i++) {

      fscanf(fp, "%c", &longestCommand[i]);
      
      if(longestCommand[i] == '\n') {
        gotNewLine = true;
      }

    }

    // the last character read in "should" be a newline, replace this newline with the null terminator (this will not cover the longestPossibleCommand, but the preceding check will)
    bool foundNL = false;
    for(int i = 0; i < longestCommandLength && !foundNL; i++) {
      if(longestCommand[i] == '\n') {
        longestCommand[i] = '\0';
        foundNL = true;
      }
    }

    // if foundNL is false, either the input was bad or the maximum length possible command was entered, set the last character to be \0 regardless
    if(!foundNL) {
      longestCommand[longestCommandLength] = '\0';
    }
    
    // // make sure command string was properly created
    // fprintf(fp, "%s\n", longestCommand);

    // check for quit
    if(strcmp("quit", longestCommand) == 0) {
      hasNotQuit = false;
    }

    // check for board
    else if(strcmp("board", longestCommand) == 0) {

      // acquire a lock on the monitor
      pthread_mutex_lock(&monitor);

      // build the strings
      
      // top / bottom border
      // length needs to be 2 greater than the number of cols (for +s) and an additional + 1 for the null terminator
      char topAndBotBorder[cols + 2 + 1];
      for(int i = 1; i < cols + 1; i++) {
        topAndBotBorder[i] = '-';
      }

      // add static characters
      topAndBotBorder[0] = '+';
      topAndBotBorder[cols + 1] = '+';
      topAndBotBorder[cols + 2] = '\0';
      
      // print out the top border
      fprintf(fp, "%s\n", topAndBotBorder);

      // going to create and print the non-top and bottom lines at the same time
      for(int i = 0; i < rows; i++) {

        // middle strings still have the same length
        char middle[cols + 2 + 1];
        
        // index j in middle is index j - 1 in board for the current column
        for(int j = 1; j < cols + 1; j++) {

          middle[j] = boardLayout[i][j-1];

        }
        
        // add static characters
        middle[0] = '|';
        middle[cols + 1] = '|';
        middle[cols + 2] = '\0';
        
        // print out the ith middle row
        fprintf(fp, "%s\n", middle);

      }

      // print out the bottom border
      fprintf(fp, "%s\n", topAndBotBorder);

      // release the lock on the monitor
      pthread_mutex_unlock(&monitor);

    }

    // check for across or down (goes ahead and checks for the space that should follow either)
    // Citing help from https://stackoverflow.com/questions/15098936/simple-way-to-check-if-a-string-contains-another-string-in-c
    // for finding an efficient way to check for one string existing within another
    else if (strstr(longestCommand, "across ") != NULL || strstr(longestCommand, "down ") != NULL) {

      // used to hold the count of the number of spaces
      int countSpaces = 0;

      // count the number of spaces
      for(int i = 0; i < strlen(longestCommand); i++) {

        if(longestCommand[i] == ' ') {
          countSpaces++;
        }

      }

      // number of spaces should be 3

      // if the number of spaces is 3
      if(countSpaces == 3) {
        
        // Citing help from https://www.tutorialspoint.com/c_standard_library/string_h.htm and https://www.tutorialspoint.com/c_standard_library/c_function_strtok.htm
        // for determing how to break up a string

        // break the string into token separated by spaces

        // get sections of the string as tokens
        char* action = strtok(longestCommand, " ");

        char* rowString = strtok(NULL, " ");

        char* colString = strtok(NULL, " ");

        char* wordString = strtok(NULL, " ");
        
        // // make sure input string is properly broken up
        // fprintf(fp, "%s\n", action);
        // fprintf(fp, "%s\n", rowString);
        // fprintf(fp, "%s\n", colString);
        // fprintf(fp, "%s\n", word);

        // go ahead and check to make sure rowsString, colsString, and wordString are valid
        bool rowOrColStringIsInvalid = isInvalidNum(rowString) || isInvalidNum(colString);

        bool wordStringIsInvalid = false;

        // all characters in wordString MUST be lowercase alphabet characters
        for(int i = 0; i < strlen(wordString); i++) {
          if(wordString[i] < 97 || wordString[i] > 122) {
            wordStringIsInvalid = true;
          }
        }

        // if rowsString, colsString, or wordString is invalid, the command is invalid
        if(rowOrColStringIsInvalid || wordStringIsInvalid) {
          fprintf(fp, "Invalid command\n");
        }

        else {

          // go ahead and get the row and colum, they will be used regardless of if the command was across or down
          int rowCommand = atoi(rowString);
          int colCommand = atoi(colString);

          // similar story with the length of wordString
          int wordLength = strlen(wordString);

          // if the command is across
          if(strcmp("across", action) == 0) {

            bool doesNotFitInFrame = false;

            // if there are 5 columns, colCommand + wordLength <= 5
            if(colCommand + wordLength > cols) {
              doesNotFitInFrame = true;
            }

            // if there are 5 rows, rowCommand should be <= 4
            if(!doesNotFitInFrame && rowCommand >= rows) {
              doesNotFitInFrame = true;
            }

            if(doesNotFitInFrame) {
              fprintf(fp, "Invalid command\n");
            }

            if(!doesNotFitInFrame) {
              // will be updated to true if any character of wordString disagress with a character already on the board
              bool characterDisagreement = false;

              // about to read the board state, lock the monitor
              pthread_mutex_lock(&monitor);

              for(int i = 0; i < wordLength && !characterDisagreement; i++) {

                // across all works on the same row
                // if the character on the board is not space and the characters don't agree we have a character disagreement
                if(boardLayout[rowCommand][colCommand + i] != ' ' && boardLayout[rowCommand][colCommand + i] != wordString[i]) {
                  characterDisagreement = true;
                }

              }

              // done reading the board state, unlock the monitor
              pthread_mutex_unlock(&monitor);

              // if there is not a character disagreement, add the character to the board
              if(!characterDisagreement) {

                // about to edit the board state, lock the monitor
                pthread_mutex_lock(&monitor);

                // for(int i = 0; i < wordLength; i++) {

                //   boardLayout[rowCommand][colCommand + i] = wordString[i];

                // }

                // make a local version of the board to update to see if the change works
                char** boardLayoutLocal = makeLocalBoard();

                // update the local board
                for(int i = 0; i < wordLength; i++) {

                  boardLayoutLocal[rowCommand][colCommand + i] = wordString[i];

                }

                bool spellingOK = checkBoardSpelling(boardLayoutLocal);

                // if there were no spelling problems, go ahead and update the board
                if(spellingOK) {
                  for(int i = 0; i < wordLength; i++) {

                    boardLayout[rowCommand][colCommand + i] = wordString[i];

                  }
                }

                // if there were spelling problems, the addition was invalid
                else {
                  fprintf(fp, "Invalid command\n");
                }

                freeLocalBoard(boardLayoutLocal);

                // done editing the board, unlock the monitor
                pthread_mutex_unlock(&monitor);

              }

              // if there is a character disgreement, the input is invalid
              else {
                fprintf(fp, "Invalid command\n");
              }
            }
          }

          // if the command is down
          else {
            
            bool doesNotFitInFrame = false;

            // if there are 5 rows, rowCommand + wordLength <= 5
            if(rowCommand + wordLength > rows) {
              doesNotFitInFrame = true;
            }

            // if there are 5 cols, colCommand should be <= 4
            if(!doesNotFitInFrame && colCommand >= cols) {
              doesNotFitInFrame = true;
            }

            if(doesNotFitInFrame) {
              fprintf(fp, "Invalid command\n");
            }

            if(!doesNotFitInFrame) {
              // will be updated to true if any character of wordString disagress with a character already on the board
              bool characterDisagreement = false;

              // about to read the board state, lock the monitor
              pthread_mutex_lock(&monitor);

              for(int i = 0; i < wordLength && !characterDisagreement; i++) {

                // down all works on the same column
                // if the character on the board is not space and the characters don't agree we have a character disagreement
                if(boardLayout[rowCommand + i][colCommand] != ' ' && boardLayout[rowCommand + i][colCommand] != wordString[i]) {
                  characterDisagreement = true;
                }

              }

              // done reading the board state, unlock the monitor
              pthread_mutex_unlock(&monitor);

              // if there is not a character disagreement, add the character to the board
              if(!characterDisagreement) {

                // about to edit the board state, lock the monitor
                pthread_mutex_lock(&monitor);

                // for(int i = 0; i < wordLength; i++) {

                //   boardLayout[rowCommand + i][colCommand] = wordString[i];

                // }

                // make a local version of the board to update to see if the change works
                char** boardLayoutLocal = makeLocalBoard();

                // update the local board
                for(int i = 0; i < wordLength; i++) {

                  boardLayout[rowCommand + i][colCommand] = wordString[i];

                }

                bool spellingOK = checkBoardSpelling(boardLayoutLocal);

                // if there were no spelling problems, go ahead and update the board
                if(spellingOK) {
                  for(int i = 0; i < wordLength; i++) {

                    boardLayout[rowCommand + i][colCommand] = wordString[i];

                  }
                }

                // if there were spelling problems, the addition was invalid
                else {
                  fprintf(fp, "Invalid command\n");
                }

                freeLocalBoard(boardLayoutLocal);

                // done editing the board, unlock the monitor
                pthread_mutex_unlock(&monitor);

              }

              // if there is a character disgreement, the input is invalid
              else {
                fprintf(fp, "Invalid command\n");
              }
            }
          }

        }


      }

      // if the number of spaces is not 3, print out invalid message and reprompt for a command
      else {

        fprintf(fp, "Invalid command\n");

      }

    }

    // the command was not quit, board, across, or down
    else {

      fprintf(fp, "Invalid command\n");

    }

    // Prompt the user for the next command.
    // if they have not quit
    if(hasNotQuit) {
      fprintf( fp, "cmd> " );
    }

  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

void* threadRunner(void* arg) {
  
  // brutally get the argument from threadRunner
  int* argPointer = (int*) arg;

  int socket = *argPointer;
  
  // // make sure socket was successfully transferred
  // printf("%d\n", socket);

  handleClient(socket);

  return NULL;

}

int main( int argc, char *argv[] ) {
  
  // check to make sure arguments are valid
  if(argc < 3 || argc > 3) {
    usage();
  }

  // check to see if argv[1] and argv[2] are valid numbers
  // isInvalidNum returns true if the string is not a number, so ORing the results will cover all 3 possible cases:
  // 1. both are valid
  // 2. one is invalid
  // 3. both are invalid
  bool oneIsInvalid = isInvalidNum(argv[1]) || isInvalidNum(argv[2]);

  // call usage if there is some character that is not a number
  if(oneIsInvalid) {
    usage();
  }
  
  // initialize the rows and columns
  rows = atoi(argv[1]);
  cols = atoi(argv[2]);

  // make the board state

  // Citing help from https://www.geeksforgeeks.org/dynamically-allocate-2d-array-c/
  // Number 3: Using a pointer to a pointer
  boardLayout = (char**) malloc(rows * sizeof(char*));
  for(int i = 0; i < rows; i++) {
    boardLayout[i] = (char*) malloc(cols * sizeof(char));
  }
  
  // char stringyBoy[rows + 1];

  // for(int i = 0; i < cols; i++) {

  //   for(int j = 0; j < rows; j++) {

  //     boardLayout[i][j] = 'a';

  //     stringyBoy[j] = boardLayout[i][j];

  //   }

  //   stringyBoy[cols] = '\0';

  //   printf("%s\n", stringyBoy);

  // }

  // initialize all board spaces to ' '
  for(int i = 0; i < rows; i++) {

    for(int j = 0; j < cols; j++) {

      boardLayout[i][j] = ' ';

    }

  }

  // read in words
  FILE* wordsFile = fopen("words", "r");

  // there is no words file in the directory
  if(wordsFile == NULL) {

    spellChecking = false;

  }

  // there is a words file in the directory
  else {

    spellChecking = true;

  }
  
  // temporary string used to see if the file contains any characters
  char temp[27] = {'\0'};

  // flag to see if words is empty
  bool wordsIsEmpty = false;
  
  // if the file is empty, this will return EOF and temp will have a length of 0
  if(fscanf(wordsFile, "%s", temp) == EOF) {
    
    if(strlen(temp) == 0) {
      wordsIsEmpty = true;
    }

  }

  if(wordsIsEmpty) {
    spellChecking = false;
  }
  
  // if spellChecking, read in the list of words
  if(spellChecking) {

    words = malloc(sizeof(char**));

    words[numWords++] = malloc(27 * sizeof(char*));

    strcpy(words[numWords - 1], temp);

    do {

      // check to see if the array needs to grow
      if(numWords == wordsSize) {

        words = realloc(words, (1 + wordsSize) * 2 * sizeof(char**));

        wordsSize = (1 + wordsSize) * 2;

      }

      // maximum length is 26 letters (27 for null terminator)
      words[numWords] = malloc(27 * sizeof(char*));

    } while(fscanf(wordsFile, "%s", words[numWords++]) != EOF);

  }

  // subtract 1 from numWords since it is incorrecetly incremented when EOF is reached
  numWords--;

  // for(int i = 0; i < numWords; i++) {
  //   printf("%s\n", words[i]);
  // }

  // printf("%d\n", numWords);

  fflush(stdout);

  // initialize the monitor
  pthread_mutex_init(&monitor, NULL);

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    
    // // make sure socket was successfully transferred
    // printf("%d\n", sock);

    // malloc some memory to hold this sock so the thread can access it when it needs it
    int* sockPointer = malloc(sizeof(int));

    *sockPointer = sock;
    
    // create the thread for the current request and detach from it (i.e., do not wait on the thread, it will do its job then terminate)
    pthread_t currentThread;

    pthread_create(&currentThread, NULL, threadRunner, sockPointer);

    pthread_detach(currentThread);



  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
