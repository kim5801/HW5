#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

/** Port number used by my server */
#define PORT_NUMBER "26038"

/** Maximum word length */
#define WORD_LIMIT 26
/** ASCII to decimal value conversion for numbers */
#define CHAR_TO_DEC 48

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** Pointer to board */
char *board;
/** Mutex lock for editing and accessing the board */
pthread_mutex_t client;
/** Rows on the board */
int rows = 0;
/** Columns on the board */
int cols = 0;

/** handle a client connection, close it when we're done. */
void *handleClient( void * arg ) { 
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int sock = *((int *)arg);
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char line[ 50 ];
  while ( fgets( line, 50, fp ) != NULL ) {
    int pos = 0;
    char boardArray[ rows + 2 ][ cols + 2 ];
    for ( int i = 0; i < rows + 2; i++ ) {
      for ( int j = 0; j < cols + 2; j++ ) {
        boardArray[ i ][ j ] = board[pos++];
      }
    }
    pthread_mutex_lock( &client );
    char cmd[ 7 ];
    pos = 0;
    int offset = 0;
    // Grabs command from user input
    sscanf( line, "%s%n", cmd, &pos );
    offset += pos;
    // Checks for "quit command"
    if ( strcmp( cmd, "quit" ) == 0 && strlen( line ) == 5 ) {
      break;
    }
    // Checks for "board" command
    if ( strcmp( cmd, "board" ) == 0 && strlen( line ) == 6 ) {
      for ( int i = 0; i < rows + 2; i++ ) {
        for ( int j = 0; j < cols + 2; j++ ) {
          fprintf( fp, "%c", boardArray[ i ][ j ] );
        }
        fprintf( fp, "\n" );
      }
    } else if ( strcmp( cmd, "across" ) == 0 || strcmp( cmd, "down" ) == 0 ) {
      int row;
      int column;
      char word[ 27 ];
      char buffer[2];
      bool validArgs = false;
      // Pasrses all of the user's input to ensure the command is valid
      if ( sscanf( line + offset, "%d%n", &row, &pos ) == 1 ) {
        offset += pos;
        if ( sscanf( line + offset, "%d%n", &column, &pos ) == 1 ) {
          offset += pos;
          if ( sscanf( line + offset, "%26s%n", word, &pos ) == 1 ) {
            offset += pos;
            // Additional check for extra input that would create an invalid command
            if ( sscanf( line + offset, "%s%n", buffer, &pos ) <= 0 ) {
              validArgs = true;
              // Checks that the word is only made up of lowercase letters
              for ( int i = 0; i < strlen( word ); i++ ) {
                if ( word[ i ] < 97 || word[ i ] > 122 ) {
                  validArgs = false;
                }
              }
              // Row and column input incremented to take border into account 
              row++;
              column++;
            }
          }
        }
      }
      // Carries out command once it's determined that user input was valid
      if ( validArgs ) {
        if ( strcmp( cmd, "across" ) == 0 ) {
          bool validPos = true;
          int count = 0;
          // Checks if word can be placed in the specific position
          for ( int i = column; i < column + strlen( word ); i++ ) {
            // Checks for an empty space or matching letter for the word being placed on board
            if ( boardArray[ row ][ i ] != ' ' && boardArray[ row ][ i ] != word[ count ] ) {
              validPos = false;
            }
            count++;
          }

          count = 0;
          // Adds word to board
          if ( validPos ) {
            for ( int i = column; i < column + strlen( word ); i++ ) {
              boardArray[ row ][ i ] = word[ count++ ];
            }
            // Updates global board for all threads to access
            pos = 0;
            for ( int i = 0; i < rows + 2; i++ ) {
              for ( int j = 0; j < cols + 2; j++ ) {
                board[pos++] = boardArray[ i ][ j ];
              }
            }
          } else {
            fprintf( fp, "Invalid command\n" );
          }
        }
        // Carries out command once it's determined that user input was valid
        else if ( strcmp( cmd, "down" ) == 0 ) {
          bool valid = true;
          int count = 0;
          // Checks if word can be placed in the specific position
          for ( int i = row; i < row + strlen( word ); i++ ) {
            // Checks for an empty space or matching letter for the word being placed on board
            if ( boardArray[ i ][ column ] != ' ' && boardArray[ i ][ column ] != word[ count ] ) {
              valid = false;
            }
            count++;
          }

          count = 0;
          // Adds word to board
          if ( valid ) {
            for ( int i = row; i < row + strlen( word ); i++ ) {
              boardArray[ i ][ column ] = word[ count++ ];
            }
            // Updates global board for all threads to access
            pos = 0;
            for ( int i = 0; i < rows + 2; i++ ) {
              for ( int j = 0; j < cols + 2; j++ ) {
                board[pos++] = boardArray[ i ][ j ];
              }
            }
          } else {
            fprintf( fp, "Invalid command\n" );
          }
        }
      } else {
        fprintf( fp, "Invalid command\n" );
      }
    } else {
      fprintf( fp, "Invalid command\n" );
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
    // Allows another client to give command
    pthread_mutex_unlock( &client );
    
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  // Error checking for command line args
  if ( argc < 3 || argc > 3 ) {
    fail( "usage: scrabbleServer <rows> <cols>" );
  }

  // Determines decimal value for row
  int val = 1;
  for ( int i = strlen( argv[ 1 ] ) - 1; i > -1  ; i-- ) {
    rows += ( argv[ 1 ][ i ] - CHAR_TO_DEC ) * val;
    val *= 10;
  }

  // Determines decimal value for column
  val = 1;
  for ( int i = strlen( argv[ 2 ] ) - 1; i > -1  ; i-- ) {
    cols += ( argv[ 2 ][ i ] - CHAR_TO_DEC ) * val;
    val *= 10;
  }

  if ( rows < 0 || cols < 0 ) {
    fail( "usage: scrabbleServer <rows> <cols>" );
  }

  // Fills board with whitespace
  char sBoard[ rows + 2 ][ cols + 2 ];
  for ( int i = 1; i <= rows; i++ ) {
    for (int j = 1; j <= cols; j++ ) {
      sBoard[ i ][ j ] = ' ';
    }
  }
  // Creates the outer border
  sBoard[ 0 ][ 0 ] = '+';
  sBoard[ rows + 1 ][ 0 ] = '+';
  sBoard[ 0 ][ cols + 1 ] = '+';
  sBoard[ rows + 1 ][ cols + 1 ] = '+';
  for ( int i = 1; i <= cols; i++ ) {
    sBoard[ 0 ][ i ] = '-';
    sBoard[ rows + 1 ][ i ] = '-';
  }
  for ( int i = 1; i <= rows; i++ ) {
    sBoard[ i ][ 0 ] = '|';
    sBoard[ i ][ cols + 1 ] = '|';
  }

  // Copies board over to malloced array
  board = (char *)malloc( (rows + 2) * (cols + 2) * sizeof( char ) );
  int pos = 0;
  for ( int i = 0; i < rows + 2; i++ ) {
    for ( int j = 0; j < cols + 2; j++ ) {
      board[pos++] = sBoard[ i ][ j ];
    }
  }

  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;
  
  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  // Initializes lock for perofrming commands on board
  pthread_mutex_init( &client, NULL );
  
  while ( true ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    // Create new thread to handle interaction
    void *ptr = &sock;
    pthread_t sockThread;
    pthread_create( &sockThread, NULL, handleClient, ptr );
    pthread_detach( sockThread );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
