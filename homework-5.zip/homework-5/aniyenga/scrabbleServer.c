#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>

#define WORD 26
pthread_mutex_t mon;

char **grid;

int x;

int y;


/** Port number used by my server */
#define PORT_NUMBER "26292"

/** Maximum word length */
#define WORD_LIMIT 26

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}


// void board() {
// 
// 
// }
// void down(int row, int col, char *word) {
// 	pthread_mutex_lock(&mon);
// 	int wordLength = strlen(word);
// 	for(int i = 0; word[i]; i++) {
// 		if(isupper(word[i])) {
// 			printf("Invalid command");
// 			return;
// 		}
// 	}
// 	if((wordLength + col) > y) {
// 			printf("Invalid command");
// 			return;
// 	}
// 	pthread_mutex_unlock(&mon);
// }
// 
// void across(int row, int col, char *word) {
// 
// 	pthread_mutex_lock(&mon);
// 	int wordLength = strlen(word);
// 	for(int i = 0; word[i]; i++) {
// 		if(isupper(word[i])) {
// 			printf("Invalid command");
// 			return;
// 		}
// 	}
// 	if(c) {
// 		printf("Invalid command");
// 		return;
// 	}
// 
// 	pthread_mutex_unlock(&mon);
// }

/** handle a client connection, close it when we're done. */
void *handleClient( void *args ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  int sock = *(int *) args;
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1 &&
          strcmp( cmd, "quit" ) != 0 ) {

    int row;
    int col;
    char word[WORD_LIMIT];
    if(strcmp(cmd, "across") == 0) {
    
    	if(fscanf(fp, "%d %d %s", &row, &col, word) != 3) {
    		fprintf(fp, "Invalid command\n");
    		goto label;
    	}
    	
    	pthread_mutex_lock(&mon);
    	int wordLength = strlen(word);
		for(int i = 0; word[i]; i++) {
			if(isupper(word[i])) {
				fprintf(fp, "Invalid command\n");
				pthread_mutex_unlock(&mon);
				goto label;
			}
		}
		if((wordLength + col) > y) {
			fprintf(fp, "Invalid command\n");
			pthread_mutex_unlock(&mon);
			goto label;
		}
		for(int i = 0; i < wordLength; i++) {
			if(grid[row][col + i] == '.') {
				grid[row][col + i] = word[i];
			} else if (grid[row][col + i] != word[i]){
				fprintf(fp, "Invalid command\n");
				pthread_mutex_unlock(&mon);
				goto label;
			}
			
		}
		pthread_mutex_unlock(&mon);

    	
    }
    else if(strcmp(cmd, "down") == 0) {
    	if(fscanf(fp, "%d %d %s", &row, &col, word) != 3) {
    		fprintf(fp, "Invalid command\n");
    		goto label;
    	}
    	pthread_mutex_lock(&mon);
    	int wordLength = strlen(word);
		for(int i = 0; word[i]; i++) {
			if(isupper(word[i])) {
				fprintf(fp, "Invalid command\n");
				pthread_mutex_unlock(&mon);
				goto label;
			}
		}
		if((wordLength + row) > x) {
			fprintf(fp, "Invalid command\n");
			pthread_mutex_unlock(&mon);
			goto label;
		}
		for(int i = 0; i < wordLength; i++) {
			if(grid[row + i][col] == '.') {
				grid[row + i][col] = word[i];
			} else if (grid[row + i][col] != word[i]){
				fprintf(fp, "Invalid command\n");
				pthread_mutex_unlock(&mon);
				goto label;
			}
			
		}
		pthread_mutex_unlock(&mon);

    } else if(strcmp(cmd, "board") == 0) {
    	pthread_mutex_lock(&mon);
		fprintf(fp, "+------------+\n");
		for(int i = 0; i < x; i++) {
			fprintf(fp, "|");
			for(int j = 0; j < y; j++) {
				if(grid[i][j] == '.') {
					fprintf(fp, " ");
				} else {
					fprintf(fp, "%c", grid[i][j]);
				}
			}
			fprintf(fp, "|\n");
		}
	fprintf(fp, "+------------+\n");
	
	pthread_mutex_unlock(&mon);
    } else {
    	fprintf(fp, "Invalid command");
    	//goto label;
    }
//      Just echo the command back to the client for now.
//     fprintf( fp, "%s\n", cmd );
    // Prompt the user for the next command.
    label:
    fprintf( fp, "cmd> " );
  }
   
  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

int main( int argc, char *argv[] ) {

  pthread_mutex_init(&mon, NULL);
    
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);
  


  x = atoi(argv[1]);
  y = atoi(argv[2]);
  if(x < 1) {
  	printf("usage: scrabbleServer <rows> <cols>\n");
  	exit(1);
  }
  
  if(y < 1) {
  	printf("usage: scrabbleServer <rows> <cols>\n");
  	exit(1);
  }
  grid = (char **)malloc(sizeof(char *) * x);
  for(int i = 0; i < x; i++) {
  	grid[i] = (char *)malloc(sizeof(char) * y);
  }
  for(int i = 0; i < x; i++) {
  	for(int j = 0; j < y; j++) {
  		grid[i][j] = '.';
  		
  	}
  }
//   for(int i = 0; i < x; i++) {
// //   	printf("%s", grid[i]);
// //   }
  while ( true  ) {
  	pthread_t client;
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    //handleClient( sock );
    pthread_create(&client, NULL, handleClient, &sock);
    
    pthread_detach(client);
    
    
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
