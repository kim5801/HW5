#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26262"

/** Maximum word length */
#define WORD_LIMIT 26

/** Semaphore to protect access to critical section. */
sem_t lock;

//Board Variable
static char *boardG;
static int rowG = 0;
static int colG = 0;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/** handle a client connection, close it when we're done. */
void *handleClient( int sock ) {
    // Here's a nice trick, wrap a C standard IO FILE around the
    // socket, so we can communicate the same way we would read/write
    // a file.

    FILE *fp = fdopen( sock, "a+" );

    // Prompt the user for a command.
    fprintf( fp, "cmd> " );

    // Temporary values for parsing commands.
    char cmd[ 11 ];
    // will quit if command is quit
    while ( fscanf( fp, "%10s", cmd ) == 1 && strcmp( cmd, "quit" ) != 0 ) {

        //semaphore to lock critical section
        sem_wait(&lock);
        //across command
        if(strcmp(cmd, "across") == 0){

            // initialize variables
            int r = 0;
            int c = 0;
            char word[WORD_LIMIT + 2];

            // fill out 26 letter word with blanks
            for(int i = 0; i < WORD_LIMIT + 2; i++){
                word[i] = ' ';
            }
            //scan word for length max + 1
            if(fscanf( fp, "%d%d%27s", &r, &c, word) == 3){

                //checks for max length
                int length = strlen(word);
                if(length <= 26){
                    for(int j = 0; j < length; j++){
                        if(word[j] >= 'a' && word[j] <= 'z'){
                            //do nothing
                        }
                        else{
                            goto invalidcmd;
                        }
                    }
                    // checks if row and column is past max
                    if( c >= colG || r >= rowG){
                        goto invalidcmd;
                    }
                    // check if column + length goes past max
                    if( c + length > colG){
                        goto invalidcmd;
                    }
                    // checks for occupied slots
                    else{
                        for(int i = 0; i < length; i++){
                            if(i == 0){
                                if(boardG[r * colG + c] == word[0]
                                   || boardG[r * colG + c] == ' '){
                                    //do nothing
                                }
                                else{
                                    goto invalidcmd;
                                }
                            }
                            else{
                                if(boardG[r * colG + c + i] == ' '
                                    || boardG[r * colG + c + i] == word[i]){
                                    //do nothing
                                }
                                else{
                                    goto invalidcmd;
                                }
                            }
                        }
                        //fills with word
                        for(int j = 0; j < length; j++){
                            boardG[colG * r + c + j] = word[j];
                        }
                    }
                }
                else{
                    goto invalidcmd;
                }
            }
            else{
                goto invalidcmd;
            }
        }
        else if(strcmp(cmd, "down") == 0){

            // initialize variables
            int r = 0;
            int c = 0;
            char word[WORD_LIMIT + 2];

            // fill out 26 letter word with blanks
            for(int i = 0; i < WORD_LIMIT + 2; i++){
                word[i] = ' ';
            }
            //scan word for length max + 1
            if(fscanf( fp, "%d%d%27s", &r, &c, word) == 3){

                //checks for max length
                int length = strlen(word);
                if(length <= 26){
                    for(int j = 0; j < length; j++){
                        if(word[j] >= 'a' && word[j] <= 'z'){
                            //do nothing
                        }
                        else{
                            goto invalidcmd;
                        }
                    }
                    // checks if row and column is past max
                    if( c >= colG || r >= rowG){
                        goto invalidcmd;
                    }
                    // check if row + length goes past max
                    if( r + length > rowG){
                        goto invalidcmd;
                    }
                    // checks for occupied slots
                    else{
                        for(int i = 0; i < length; i++){
                            if(i == 0){
                                if(boardG[r * colG + c] == word[0]
                                   || boardG[r * colG + c] == ' '){
                                    //do nothing
                                }
                                else{
                                    goto invalidcmd;
                                }
                            }
                            else{
                                if(boardG[(r + i) * colG + c] == ' ' ||
                                   boardG[(r + i) * colG + c] == word[i]){
                                    //do nothing
                                }
                                else{
                                    goto invalidcmd;
                                }
                            }
                        }
                        //fills with word
                        for(int j = 0; j < length; j++){
                            boardG[(r + j) * colG + c] = word[j];
                        }
                    }
                }
                else{
                    goto invalidcmd;
                }
            }
            else{
                goto invalidcmd;
            }
        }
        //prints the board
        else if(strcmp(cmd, "board") == 0){
            //prints first line +-----+
            fprintf( fp, "+");
            for(int i = 0; i < colG; i++){
                fprintf( fp, "-");
            }
            fprintf( fp, "+\n");

            //prints the board
            for(int i = 0; i < rowG; i++){
                fprintf( fp, "|");
                for(int j = 0; j < colG; j++){
                    char resultString[2] = "\0";
                    resultString[0] = boardG[(i * colG) + j];
                    fprintf(fp, resultString);
                }
                fprintf( fp, "|\n");
            }

            //prints last line +-----+
            fprintf( fp, "+");
            for(int i = 0; i < colG; i++){
                fprintf( fp, "-");
            }
            fprintf( fp, "+\n");

        }
        else{
            //prints invalid command and re prompt, and release semaphore
            invalidcmd:
            fprintf( fp, "Invalid Command\n");
            fprintf( fp, "cmd> " );
            sem_post(&lock);
            continue;
        }

        // Prompt the user for the next command. and release semaphore
        fprintf( fp, "cmd> " );
        sem_post(&lock);
    }

    // Close the connection with this client.
    fclose( fp );
    return NULL;
}

//routine for thread
void* routine(void* arg){
    //parses arg and handles client
    int sock = *(int *) arg;
    handleClient( sock );
    return NULL;
}

int main( int argc, char *argv[] ) {
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );
  // checks for args, board input
  if (argc != 3){
      fail("usage: scrabbleServer <rows> <cols>");
  }

  //parses inputs
  int rowInput = atoi(argv[1]);
  int colInput = atoi(argv[2]);
  rowG = rowInput;
  colG = colInput;

  // creates and initializes board
  boardG = malloc(rowInput * colInput * sizeof(char));

  for(int i = 0; i < rowInput; i++){
      for(int j = 0; j < colInput; j++){
          boardG[i * colG + j] = ' ';
      }
  }
  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  // creates resizable array of ints
  size_t size = 0;
  int *arr = malloc((size + 1) * sizeof( *arr));

  sem_init( &lock, 0, 1 );

  while ( true ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);

    //resizes array
    int *temp = realloc(arr, (size + 1) * sizeof( *arr));
    arr = temp;
    arr[size++] = sock;

    //creates thread for every input
    pthread_t thread;
    if ( pthread_create( &thread, NULL, routine, &arr[size - 1] ) != 0 )
        fail( "Can't create a child thread\n" );

    //detaches and lets it run
    pthread_detach(thread);

  }


  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}
