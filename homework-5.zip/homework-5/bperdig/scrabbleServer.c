#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26276"

/** Maximum word length */
#define WORD_LIMIT 26

/** Maximum command length */
#define COMMAND_LIMIT 64

// Print out an error message and exit.
static void fail(char const *message) {
    fprintf(stderr, "%s\n", message);
      exit(EXIT_FAILURE);
}

// 2D struct that represents the board to be used in the game.
// Has a field to represent the board itself, and its x and y lengths.
typedef struct {
    char **grid;
    int rows;
    int columns;
} Board;

// Global board
Board *b;

/** The semaphore that controls the synchronization of the program. */
sem_t lock;

/**
 * Static function to print the current board.
 */
static void printBoard(Board *b) {
    printf("+");
    for (int i = 0; i < b->columns; i++) {
        printf("-");
    }
    printf("+\n");

    for (int i = 0; i < b->rows; i++) {
        printf("|");
        for (int j = 0; j < b->columns; j++) {
            printf("%c", b->grid[i][j]);
        }
        printf("|\n");
    }
    printf("+");
    for (int i = 0; i < b->columns; i++) {
        printf("-");
    }
    printf("+\n");
}

/** handle a client connection, close it when we're done. */
void *handleClient(int sock, Board *b) {
    // Here's a nice trick, wrap a C standard IO FILE around the
    // socket, so we can communicate the same way we would read/write
    // a file.
    FILE *fp = fdopen(sock, "a+");

    // Prompt the user for a command.
    fprintf(fp, "cmd> ");

    // Array to store the command typed by the user
    char cmd[COMMAND_LIMIT];
    // Array to store the command in case an across or down instruction is typed in
    char finalCommand[WORD_LIMIT];
    // Array to store the word to be put in the board
    char word[WORD_LIMIT];
    // Count to assist in reading the command from the user
    int count = 0;
    // Auxiliary count to read extra things from the command string
    int aux = 0;
    // Numbers that gets the starting row of a word to be put in the board
    int row = -1;
    // Numbers that gets the starting column of a word to be put in the board
    int column = -1;

    while (fgets(cmd, COMMAND_LIMIT, fp) != NULL && strcmp(cmd, "quit\n") != 0) {
        // Prints the board if the command is "board"
        if (strcmp(cmd, "board\n") == 0) {
            sem_wait(&lock);
            printBoard(b);
        }

        else {
            // Extracts the command from the large command string
            while (count < strlen(cmd) && cmd[count] != ' ') {
                finalCommand[count] = cmd[count];
                count++;
            }
            finalCommand[count] = '\0';

            // Checks if there is more input
            if (cmd[count] == ' ' && count <= strlen(cmd)) {
                // Start reading from the next character in the large command string
                count++;

                if (strcmp(finalCommand, "across") == 0 || strcmp(finalCommand, "down") == 0) {
                    // Gets the row from the large string
                    while (count < strlen(cmd) && cmd[count] != ' ') {
                        word[aux] = cmd[count];
                        count++;
                        aux++;
                    }
                    word[aux] = '\0';
                    row = atoi(word);

                    // Checks if there is more input
                    if (cmd[count] == ' ' && count <= strlen(cmd) && row < b->rows) {
                        // Start reading from the next character in the large command string
                        count++;
                        aux = 0;

                        // Gets the column from the large string
                        while (count < strlen(cmd) && cmd[count] != ' ') {
                            word[aux] = cmd[count];
                            count++;
                            aux++;
                        }
                        word[aux] = '\0';
                        column = atoi(word);

                        // Checks if there is more input
                        if (cmd[count] == ' ' && count <= strlen(cmd) && column < b->columns) {
                            count ++;
                            aux = 0;

                            // Gets the word from the large string
                            while (count < strlen(cmd) && cmd[count] != ' ' && cmd[count] != '\n') {
                                word[aux] = cmd[count];
                                count++;
                                aux++;
                            }
                            word[aux] = '\0';

                            // Checks if there is more input (there should be none)
                            if (aux < WORD_LIMIT && cmd[count] == '\n') {
                                sem_wait(&lock);
                                // Flag to assist in avoiding changes to the grid in case of invalid word
                                bool valid = true;

                                for (int i = 0; i < strlen(word); i++) {
                                    if (word[i] - 'a' < 0 || word[i] - 'z' > 0)
                                        valid = false;
                                }

                                // Determine behavior for the word if the command is to put it across (horizontally)
                                if (strcmp(finalCommand, "across") == 0) {
                                    if (aux + column <= b->columns) {
                                        for (int i = 0; i < aux && valid; i++) {
                                            if (b->grid[row][column + i] != ' ') {
                                                if (b->grid[row][column + i] != word[i]) {
                                                    valid = false;
                                                }
                                            }
                                        }

                                        if (valid) {
                                            for (int i = 0; i < aux; i++)
                                                b->grid[row][column + i] = word[i];
                                        }
                                        else
                                            printf("Invalid command\n");
                                    }
                                    else
                                        printf("Invalid command\n");
                                }

                                // Determine behavior for the word if the command is to put it down (vertically)
                                else {
                                    if (aux + row <= b->rows) {
                                        for (int i = 0; i < aux && valid; i++) {
                                            if (b->grid[row + i][column] != ' ') {
                                                if (b->grid[row + i][column] != word[i]) {
                                                    valid = false;
                                                }
                                            }
                                        }

                                        if (valid) {
                                            for (int i = 0; i < aux; i++)
                                                b->grid[row + i][column] = word[i];
                                        }
                                        else
                                            printf("Invalid command\n");
                                    }
                                    else
                                        printf("Invalid command\n");
                                }
                            }
                            else
                                printf("Invalid command\n");
                        }
                        else
                            printf("Invalid command\n");
                    }
                    else
                        printf("Invalid command\n");
                }
                else
                    printf("Invalid command\n");
            }
            else
                printf("Invalid command\n");
        }
    // Prompt the user for the next command.
    fprintf(fp, "cmd> ");

    // Resets the helper variables
    strcpy(finalCommand, "");
    strcpy(word, "");
    count = 0;
    aux = 0;
    row = -1;
    column = -1;

    // Releases the semaphore
    sem_post(&lock);
    }

    // Close the connection with this client.
    for (int i = 0; i < b->rows; i++)
        free(b->grid[i]);
    free(b);
    fclose(fp);
    return NULL;
}

void *threadFunc (void *arg) {
    int sock = *(int *) arg;
    handleClient(sock, b);
    return NULL;
}

int main(int argc, char *argv[]) {

    // Initializes the board using the information provided by the client.
    b = (Board*) malloc(sizeof(Board));

    // Server must have 2 command arguments (+1 that is automatically stored)
    if (argc == 3) {
        b->rows = atoi(argv[1]);
        b->columns = atoi(argv[2]);

        b->grid = (char **) malloc(b->rows * sizeof(char *));
        for (int i = 0; i < b->rows; i++)
            b->grid[i] = (char *) malloc(b->columns * sizeof(char));

        for (int i = 0; i < b->rows; i++) {
            for (int j = 0; j < b->columns; j++) {
                b->grid[i][j] = ' ';
            }
        }
    }

    else {
        free(b);
        fail("usage: scrabbleServer <rows> <cols>");
    }


    // Prepare a description of server address criteria.
    struct addrinfo addrCriteria;
    memset(&addrCriteria, 0, sizeof(addrCriteria));
    addrCriteria.ai_family = AF_INET;
    addrCriteria.ai_flags = AI_PASSIVE;
    addrCriteria.ai_socktype = SOCK_STREAM;
    addrCriteria.ai_protocol = IPPROTO_TCP;

    // Lookup a list of matching addresses
    struct addrinfo *servAddr;
    if (getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr)) {
        for (int i = 0; i < b->rows; i++)
            free(b->grid[i]);
        free(b);
        fail("Can't get address info");
    }


    // Try to just use the first one.
    if (servAddr == NULL) {
        for (int i = 0; i < b->rows; i++)
            free(b->grid[i]);
        free(b);
        fail("Can't get address");
    }


    // Create a TCP socket
    int servSock = socket(servAddr->ai_family, servAddr->ai_socktype, servAddr->ai_protocol);
    if (servSock < 0) {
        for (int i = 0; i < b->rows; i++)
            free(b->grid[i]);
        free(b);
        fail("Can't create socket");
    }


    // Bind to the local address
    if (bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0) {
        for (int i = 0; i < b->rows; i++)
            free(b->grid[i]);
        free(b);
        fail("Can't bind socket");
    }

    // Tell the socket to listen for incoming connections.
    if (listen(servSock, 5) != 0) {
        for (int i = 0; i < b->rows; i++)
            free(b->grid[i]);
        free(b);
        fail("Can't listen on socket");
    }
    // Free address list allocated by getaddrinfo()
    freeaddrinfo(servAddr);

    // Fields for accepting a client connection.
    struct sockaddr_storage clntAddr; // Client address
    socklen_t clntAddrLen = sizeof(clntAddr);

    // Initializes the semaphore
    sem_init(&lock, 0, 1);

    while (true) {
        // Accept a client connection.
        int sock = accept(servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
        pthread_t thread;
        if (pthread_create( &thread, NULL, threadFunc, &sock) != 0)
            fail( "Can't create a child thread" );
        pthread_detach(thread);
  }

    // Stop accepting client connections (never reached).
    close(servSock);
    sem_destroy(&lock);

  return 0;
}
