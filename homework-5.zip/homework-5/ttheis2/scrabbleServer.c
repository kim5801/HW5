#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26072"

/** Maximum word length */
#define WORD_LIMIT 26

//board representation
char *board;

//number of rows on the board
int rows;

//number of cols on the board
int cols;

//Used to keep multiple clients from accessing the board at the same time
sem_t getBoard;

typedef struct {
  int x; // Parameter for the thread.
} ArgStruct;

//semaphore to make sure two threads don't accidentally use the same socket
//sem_t getSock;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

static bool across(char *word, int row, int col, int length) {
  if(col + length > cols) {
    return false;
  }
  int start = (row * cols) + col;
  for(int i = start; i < (start + length); i++) {
    if(board[i] == ' ') {
      continue;
    }
    if(board[i] != word[i - start]) {
      return false;
    }
  }
  for(int i = start; i < (start + length); i++) {
    board[i] = word[i - start];
  }
  return true;
}

static bool down(char *word, int row, int col, int length) {
  if((rows - row) < length) return false;
  int start = (row * cols) + col;
  int i = start;
  int j = 0;
  while(word[j]) {
    if(board[i] == ' ') {
      j++;
      i += cols;
      continue;
    }
    if(board[i] != word[j]) {
      return false;
    }
    i += cols;
    j++;
  }
  j = 0;
  i = start;
  while(word[j]) {
    board[i] = word[j];
    i += cols;
    j++;
  }
  return true;
}

/** handle a client connection, close it when we're done. */
void *handleClient( int sock ) {
  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( sock, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  // Temporary values for parsing commands.
  char cmd[ 11 ];
  while ( fscanf( fp, "%10s", cmd ) == 1) {
//     // Just echo the command back to the client for now.
//     fprintf( fp, "%s\n", cmd );

    if(strcmp( cmd, "across" ) == 0 || strcmp( cmd, "down" ) == 0) {
      //do across command
      int row;
      int col;
      int length = 0;
      char word[27];
      char temp;
      
      temp = fgetc(fp);
      if(temp != ' ') {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }
      
      temp = fgetc(fp);
      if(temp < '0' || temp > '9') {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }
      ungetc(temp, fp);
      
      if(fscanf(fp, "%d", &row) != 1) {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }
      
      temp = fgetc(fp);
      if(temp != ' ') {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }
      
      temp = fgetc(fp);
      if(temp < '0' || temp > '9') {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }
      ungetc(temp, fp);
      
      if(fscanf(fp, "%d", &col) != 1) {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }
      
      temp = fgetc(fp);
      if(temp != ' ') {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }
      
      temp = fgetc(fp);
      if(temp < 'a' || temp > 'z') {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }
      ungetc(temp, fp);
      
      bool small = false;
      for(int i = 0; i < 26; i++) {
        temp = fgetc(fp);
        if(temp == '\n') {
          small = true;
          break;
        }
        word[i] = temp;
        length++;
      }
      
      if(!small) {
        temp = fgetc(fp);
        if(temp != '\n') {
          fprintf(fp, "Invalid command\n");
          fprintf( fp, "cmd> " );
          continue;
        }
      }
      word[length] = '\0';
      int i = 0;
      while(word[i]) {
        if(word[i] < 'a' || word[i] > 'z') {
          fprintf(fp, "Invalid command\n");
          break;
        }
        i++;
      }
      
      if(row >= rows || col >= cols) {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }
      
      //call logic helper function for across/down words
      //helper functions will check if words go over the board or don't mach 
      //words already on the board
      
      if(strcmp( cmd, "across" ) == 0) {
        sem_wait(&getBoard);
        bool a = across(word, row, col, length);
        sem_post(&getBoard);
        if(!a) {
          fprintf(fp, "Invalid command\n");
          fprintf( fp, "cmd> " );
          continue;
        }
      }

      if(strcmp( cmd, "down" ) == 0) {
        sem_wait(&getBoard);
        bool a = down(word, row, col, length);
        sem_post(&getBoard);
        if(!a) {
          fprintf(fp, "Invalid command\n");
          fprintf( fp, "cmd> " );
          continue;
        }
      }
      
      //printf("It worked %d %d %s\n", row, col, word);
    } else if(strcmp( cmd, "board" ) == 0) {
      char temp;
      
      temp = fgetc(fp);
      if(temp != '\n') {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }
      sem_wait(&getBoard);
      fprintf(fp, "+");
      for(int i = 0; i < cols; i++) {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
      for(int i = 0; i < rows; i++) {
        fprintf(fp, "|");
        for(int j = 0; j < cols; j++) {
          fprintf(fp, "%c", board[j + (i * cols)]);
        }
        fprintf(fp, "|\n");
      }
      fprintf(fp, "+");
      for(int i = 0; i < cols; i++) {
        fprintf(fp, "-");
      }
      fprintf(fp, "+\n");
      sem_post(&getBoard);
    } else if(strcmp( cmd, "quit" ) == 0) {
      char temp;
      
      temp = fgetc(fp);
      if(temp != '\n') {
        fprintf(fp, "Invalid command\n");
        fprintf( fp, "cmd> " );
        continue;
      }
      break;
    } else {
      fprintf(fp, "Invalid command\n");
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

void *threadFunc(void *arg) {
  ArgStruct *astruct = (ArgStruct *)arg;
  handleClient(astruct->x);
  free(astruct);
  pthread_exit(0);
  return NULL;
}

int main( int argc, char *argv[] ) {

  if(argc != 3) {
    printf("usage: scrabbleServer <rows> <cols>\n");
    exit(1);
  }
  
  rows = atoi(argv[1]);
  cols = atoi(argv[2]);
  
  if(rows <= 0 || cols <= 0) {
    printf("usage: scrabbleServer <rows> <cols>\n");
    exit(1);
  }

  board = malloc((rows * cols) * sizeof(char));
  
  for(int i = 0; i < (rows * cols); i++) {
    board[i] = ' ';
  }
  
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);
  
  //initialize my sempaphore for synchronization
  sem_init(&getBoard, 0, 1);
  
  while ( true  ) {
    // Accept a client connection.
    int sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    
    // Make a new argument structure for this thread.
    ArgStruct *astruct = (ArgStruct *)malloc( sizeof( ArgStruct ) );
    astruct->x = sock;
    
    pthread_t thread;
    if ( pthread_create( &thread, NULL, threadFunc, astruct ) != 0 ) {
      free(astruct);
      fail( "Can't create a child thread\n" );
    }
    pthread_detach(thread);
    //handleClient( sock );
  }

  // Stop accepting client connections (never reached).
  close( servSock );
  
  return 0;
}