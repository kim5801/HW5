#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26136"

/** Maximum word length */
#define WORD_LIMIT 26

/** longest command name length (11) + word limit + null terminator (1) */
#define MAX_COMMAND_LENGTH 60

/** Max number of rows/colums */
#define MAX_DIMENSION 999

/** Length of alphabet we are using */
#define ALPHABET_LENGTH 26

/**initial array size for words array*/
#define INIT_ARRAY_SIZE 10

//game board and fields related to it
int numRows;
int numCols;
char **gameBoard;

//semaphore to create mutual exclusion
sem_t lock;

//stores all words in 26 rows, where the columns are elements that are strings
char **words;
int wordsLength;
int wordsMaxLength;

// Print out an error message and exit.
static void fail( char const *message ) {
  fprintf( stderr, "%s\n", message );
  exit( EXIT_FAILURE );
}

/// @brief Determines if word is made up of only lowercase letters
/// @param word the word to check
/// @return true if all lowercase, otherwise false
bool isOnlyLower(char *word) {
  for (char *c = word; *c; c++) {
    if (*c < 'a' || *c > 'z') {
      return false;
    }
  }
  return true;
}

/// @brief adds the parameter word to words data structure
/// @param word the word to add
void addToWords(char *word) {
  if (wordsLength == wordsMaxLength) {
    //time to double size of array
    wordsMaxLength *= 2;
    words = realloc(words, sizeof(*words) * wordsMaxLength);
    for (int i = wordsLength; i < wordsMaxLength; i++) {
      words[i] = calloc(WORD_LIMIT + 1, sizeof(char));
    }
  }
  //copy word over to its spot
  strcpy(words[wordsLength++], word);
}

/// @brief Returns true if the words array contains word
/// @param word the word to check for
/// @return true if the words array contains word, otherwise false
bool wordsContainsWord(char *word) {
  for (int i = 0; i < wordsLength; i++) {
    if (strcmp(words[i], word) == 0) {
      return true;
    }
  }
  return false;
}

/// @brief frees words array
void freeWords() {
  for (int i = 0; i < wordsMaxLength; i++) {
    free(words[i]);
  }
  free(words);
}

void parseWordsFile() {
  FILE *fp = fopen("words", "r");

  words = (char **)calloc(INIT_ARRAY_SIZE, sizeof(char*));
  for (int i = 0; i < INIT_ARRAY_SIZE; i++) {
    words[i] = (char *)calloc(WORD_LIMIT + 1, sizeof(char));
  }
  wordsLength = 0;
  wordsMaxLength = INIT_ARRAY_SIZE;

  bool isTmpBufNull = false;
  do {
    char tmpBuf[WORD_LIMIT + 1];
    fgets(tmpBuf, WORD_LIMIT, fp);

    //if buffer is null (reached end of file), continue and let the while loop condition stop the loop. 
    if (tmpBuf == NULL || tmpBuf[0] == '\0') {
      isTmpBufNull = true;
      continue;
    }

    //if the string has characters that are not lowercase letters, skip that word
    int len = strlen(tmpBuf);
    tmpBuf[len - 1] = '\0'; //change trailing \n character to an end of string character
    if (!isOnlyLower(tmpBuf)) {
      continue;
    }

    addToWords(tmpBuf);
  } while (!isTmpBufNull);
  fclose(fp);
}

/// @brief dynamically allocates gameboard
void initGameBoard() {
  gameBoard = (char **)calloc(numRows, sizeof(char*));
  for (int i = 0; i < numRows; i++) {
    gameBoard[i] = (char *)calloc(numCols, sizeof(char));
  }
}

/// @brief frees gameboard
void freeGameBoard() {
  for (int i = 0; i < numRows; i++) {
    free(gameBoard[i]);
  }
  free(gameBoard);
}

/// @brief prints the gameboard to the specified file
/// @param fp the file to print to
void printGameBoard(FILE *fp) {
  //print top border
  fprintf(fp, "+");
  for (int i = 0; i < numCols; i++) {
    fprintf(fp, "-");
  }
  fprintf(fp, "+\n");

  //print middle rows
  
  for (int i = 0; i < numRows; i++) {
    fprintf(fp, "|");
    for (int j = 0; j < numCols; j++) {
      if (gameBoard[i][j] == '\0') {
        fprintf(fp, " ");
      } else {
        fprintf(fp, "%c", gameBoard[i][j]);
      }
    }
    fprintf(fp, "|\n");
  }

  //print bottom border
  fprintf(fp, "+");
  for (int i = 0; i < numCols; i++) {
    fprintf(fp, "-");
  }
  fprintf(fp, "+\n");
}

/// @brief Converts a string to an int. Sets the success flag if it parsed successfully (copied from my hw2 implementation)
/// @param str the string to parse
/// @param success the success of the conversion
/// @return the integer if the parsing was successful, otherwise -1
int strToInt(char *str, bool *success) {
  char *endPtr = NULL;
  int retVal = strtol(str, &endPtr, 10);
  //check that errno is not set, that the string is not empty, and that the whole string was parsed
  if (errno == 0 && (str != endPtr) && *endPtr == '\0') {
    *success = true;
    return retVal;
  } else {
    *success = false;
    return -1;
  }
}

bool acrossCmd(char *word, int wordLength, int r, int c) {
  if (c + wordLength > numCols)
    return false;

  //this keeps track of which chars where temporarily inserted in case they are invalid and need to be removed
  int insertedCharColIndices[WORD_LIMIT];
  int numCharsInserted;

  //condition to check if the user is inserting any new characters. This means that one spot needs to be '\0'
  bool insertingNewChar = false;

  for (int i = 0; i < wordLength; i++) {
    char charInGB = gameBoard[r][c + i];
    if (charInGB != '\0' && charInGB != word[i]) {
      for (int i = 0; i < numCharsInserted; i++) {
        gameBoard[r][insertedCharColIndices[i]] = '\0';
      }
      return false; // trying to insert a char into a spot that already has a different char
    } else if (charInGB == '\0') {
      insertingNewChar = true;
      //temporarily insert character and save which column it was inserted in in case it doesn't work out
      insertedCharColIndices[numCharsInserted++] = c + i;
      gameBoard[r][c + i] = word[i];
    }
  }
  if (!insertingNewChar)
    return false; //not inserting any new chars


  /** now, if word was inserted make sure that in every direction for every letter everything is still a word */
  
  //find first char of word across
  int checkCol = c;
  while (checkCol >= 0 && gameBoard[r][checkCol] != '\0') {
    checkCol--;
  }
  checkCol++; //go back right one to the start of words (because the while loop would end you off on '\0')

  //see if going right is a word
  char checkRightWord[WORD_LIMIT + 1];
  int checkRightWordSize = 0;
  while (checkCol < numCols && checkRightWordSize <= WORD_LIMIT && gameBoard[r][checkCol] != '\0') {
    checkRightWord[checkRightWordSize++] = gameBoard[r][checkCol++];
  }
  checkRightWord[checkRightWordSize] = '\0';

  if (!wordsContainsWord(checkRightWord)) {
    //remove word if it doesn't fit in gameboard and return false
    for (int i = 0; i < numCharsInserted; i++) {
      gameBoard[r][insertedCharColIndices[i]] = '\0';
    }
    return false;
  }
  

  //check if for every letter down it is a word
  for (int i = c; i < c + wordLength; i++) {
    int checkRow = r;
    while (checkRow >= 0 && gameBoard[checkRow][c] != '\0') {
      checkRow--;
    }
    checkRow++; //go back down one to the start (because the while loop would end you off on '\0')

    //see if going down is a word
    char checkDownWord[WORD_LIMIT + 1];
    int checkDownWordSize = 0;
    while (checkRow < numRows && checkDownWordSize <= WORD_LIMIT && gameBoard[checkRow][i] != '\0') {
      checkDownWord[checkDownWordSize++] = gameBoard[checkRow++][i];
    }
    checkDownWord[checkDownWordSize] = '\0';

    if (!wordsContainsWord(checkDownWord)) {
      //remove word if it doesn't fit in gameboard and return false
      for (int j = 0; j < numCharsInserted; j++) {
        gameBoard[r][insertedCharColIndices[j]] = '\0';
      }
      return false;
    }
  }
  return true;
}

bool downCmd(char *word, int wordLength, int r, int c) {
  //Necessary conditions to fulfill:
  //check that the user is not putting down an exact word that already exists
  //make sure that the word that the user makes in the end is a word that exists in the dictionary
  //make sure that none of the letters intersect if they are not the same letter
  //the word will not extend past the dimensions of the gameboard (the starting row/col is already checked before this function)

  if (r + wordLength > numRows)
    return false; //word extends past gameboard

  //this keeps track of which chars where temporarily inserted in case they are invalid and need to be removed
  int insertedCharRowIndices[WORD_LIMIT];
  int numCharsInserted;

  //condition to check if the user is inserting any new characters. This means that one spot needs to be '\0'
  bool insertingNewChar = false;

  for (int i = 0; i < wordLength; i++) {
    char charInGB = gameBoard[r + i][c];
    if (charInGB != '\0' && charInGB != word[i]) {
      for (int i = 0; i < numCharsInserted; i++) {
        gameBoard[insertedCharRowIndices[i]][c] = '\0';
      }
      return false; // trying to insert a char into a spot that already has a different char
    } else if (charInGB == '\0') {
      insertingNewChar = true;
      //temporarily insert character and save which row it was inserted in in case it doesn't work out
      insertedCharRowIndices[numCharsInserted++] = r + i;
      gameBoard[r + i][c] = word[i];
    }
  }
  if (!insertingNewChar)
    return false; //not inserting any new chars


  /** now, if word was inserted make sure that in every direction for every letter everything is still a word */
  
  //find first char of word going up:
  int checkRow = r;
  while (checkRow >= 0 && gameBoard[checkRow][c] != '\0') {
    checkRow--;
  }
  checkRow++; //go back down one to the start (because the while loop would end you off on '\0')

  //see if going down is a word
  char checkDownWord[WORD_LIMIT + 1];
  int checkDownWordSize = 0;
  while (checkRow < numRows && checkDownWordSize <= WORD_LIMIT && gameBoard[checkRow][c] != '\0') {
    checkDownWord[checkDownWordSize++] = gameBoard[checkRow++][c];
  }
  checkDownWord[checkDownWordSize] = '\0';

  if (!wordsContainsWord(checkDownWord)) {
    //remove word if it doesn't fit in gameboard and return false
    for (int i = 0; i < numCharsInserted; i++) {
      gameBoard[insertedCharRowIndices[i]][c] = '\0';
    }
    return false;
  }

  //check if for every letter across it is a word
  for (int i = r; i < r + wordLength; i++) {
    //find first char of word across
    int checkCol = c;
    while (checkCol >= 0 && gameBoard[i][checkCol] != '\0') {
      checkCol--;
    }
    checkCol++; //go back right one to the start of words (because the while loop would end you off on '\0')

    //see if going right is a word
    char checkRightWord[WORD_LIMIT + 1];
    int checkRightWordSize = 0;
    while (checkCol < numCols && checkRightWordSize <= WORD_LIMIT && gameBoard[i][checkCol] != '\0') {
      checkRightWord[checkRightWordSize++] = gameBoard[i][checkCol++];
    }
    checkRightWord[checkRightWordSize] = '\0';

    if (!wordsContainsWord(checkRightWord)) {
      //remove word if it doesn't fit in gameboard and return false
      for (int j = 0; j < numCharsInserted; j++) {
        gameBoard[insertedCharRowIndices[j]][c] = '\0';
      }
      return false;
    }
  }

  return true;
}

/// @brief Runs acrossCmd or downCmd. This function expects that strtok_r was used before
/// @param isAcross if this is true, run across command, otherwise run down command
/// @return whether or not this was successful (including parsing)
bool runAcrossOrDownCmd(bool isAcross, char *strtokrContext) {
  bool strToIntSuccess;

  //parse row integer from input
  int row = strToInt(strtok_r(NULL, " ", &strtokrContext), &strToIntSuccess);
  if (!strToIntSuccess || row < 0 || row >= numRows) { //condition to break**
    return false;
  }

  //parse col integer from input
  int col = strToInt(strtok_r(NULL, " ", &strtokrContext), &strToIntSuccess);
  if (!strToIntSuccess || col < 0 || col >= numCols) { //condition to break**
    return false;
  }

  //parse word from input
  char *word = strtok_r(NULL, " ", &strtokrContext);
  bool isWordLower = isOnlyLower(word);
  int wordLength = strlen(word);

  //check that word is all lowercase and the wordLength.
  if (!isWordLower || word == NULL || wordLength > WORD_LIMIT) { //condition to break**
    return false;
  }

  //if there is extra input, fail
  if (strtok_r(NULL, " ", &strtokrContext) != NULL) { //condition to break**
    return false;
  }

  //depending on whether the cmd word was "across" or "down" do something
  bool ranSuccessfully = false;
  if (isAcross)
    ranSuccessfully = acrossCmd(word, wordLength, row, col);
  else
    ranSuccessfully = downCmd(word, wordLength, row, col);

  if (!ranSuccessfully)
    return false;
  return true;
}

/** handle a client connection, close it when we're done. */
void *handleClient( void *sock ) {
  int socket = *(int *)sock;

  // Here's a nice trick, wrap a C standard IO FILE around the
  // socket, so we can communicate the same way we would read/write
  // a file.
  FILE *fp = fdopen( socket, "a+" );
  
  // Prompt the user for a command.
  fprintf( fp, "cmd> " );

  char fullCmd[MAX_COMMAND_LENGTH]; 
  char *strtokrContext;
  while ( fgets(fullCmd, MAX_COMMAND_LENGTH, fp) != NULL ) {
    
    //used to determine in first part of if statement if the cmd name is across or down
    bool isAcross;

    int len = strlen(fullCmd);
    fullCmd[len - 1] = '\0'; //change trailing \n character to an end of string character

    char *cmdName = strtok_r(fullCmd, " ", &strtokrContext);
    
    if ((isAcross = strcmp(cmdName, "across") == 0) || strcmp(cmdName, "down") == 0) {
      
      sem_wait(&lock);
      bool ranSuccessfully = runAcrossOrDownCmd(isAcross, strtokrContext);
      sem_post(&lock);
      if (!ranSuccessfully) {
        fprintf(fp, "Invalid command\n");
      }

    } else if (strcmp(cmdName, "board") == 0) {

      //if there is extra input, fail
      if (strtok_r(NULL, " ", &strtokrContext) != NULL) {
        fprintf(fp, "Invalid command\n");
      } else {
        sem_wait(&lock);
        printGameBoard(fp);
        sem_post(&lock);
      }
    } else if (strcmp(cmdName, "quit") == 0) {
      //if there is extra input, fail
      if (strtok_r(NULL, " ", &strtokrContext) != NULL) {
        fprintf(fp, "Invalid command\n");
      } else {
        break;
      }
    } else {
      fprintf(fp, "Invalid command\n");
    }

    // Prompt the user for the next command.
    fprintf( fp, "cmd> " );
  }

  //free dynamically allocated sock
  free(sock);

  // Close the connection with this client.
  fclose( fp );
  return NULL;
}

void runServer() {
  // Prepare a description of server address criteria.
  struct addrinfo addrCriteria;
  memset(&addrCriteria, 0, sizeof(addrCriteria));
  addrCriteria.ai_family = AF_INET;
  addrCriteria.ai_flags = AI_PASSIVE;
  addrCriteria.ai_socktype = SOCK_STREAM;
  addrCriteria.ai_protocol = IPPROTO_TCP;

  // Lookup a list of matching addresses
  struct addrinfo *servAddr;
  if ( getaddrinfo( NULL, PORT_NUMBER, &addrCriteria, &servAddr) )
    fail( "Can't get address info" );

  // Try to just use the first one.
  if ( servAddr == NULL )
    fail( "Can't get address" );

  // Create a TCP socket
  int servSock = socket( servAddr->ai_family, servAddr->ai_socktype,
                         servAddr->ai_protocol);
  if ( servSock < 0 )
    fail( "Can't create socket" );

  // Bind to the local address
  if ( bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0 )
    fail( "Can't bind socket" );
  
  // Tell the socket to listen for incoming connections.
  if ( listen( servSock, 5 ) != 0 )
    fail( "Can't listen on socket" );

  // Free address list allocated by getaddrinfo()
  freeaddrinfo(servAddr);

  // Fields for accepting a client connection.
  struct sockaddr_storage clntAddr; // Client address
  socklen_t clntAddrLen = sizeof(clntAddr);

  while ( true  ) {
    // Accept a client connection.
    int *sock = malloc(sizeof(int));
    *sock = accept( servSock, (struct sockaddr *) &clntAddr, &clntAddrLen);
    pthread_t thread;
    pthread_create(&thread, NULL, handleClient, sock);
    pthread_detach(thread);
  }

  // Stop accepting client connections (never reached).
  close( servSock );
}

//handler for ctrl+c
void sigintHandler() {
  freeGameBoard();
  freeWords();
  sem_destroy(&lock);
  printf("\n");
  exit(0);
}

int main( int argc, char *argv[] ) {
  //next dozen or so lines are basic error checking
  if (argc != 3)
    fail("usage: scrabbleServer <rows> <cols>");

  bool success;
  numRows = strToInt(argv[1], &success);
  if (!success || numRows <= 0 || numRows > MAX_DIMENSION)
    fail("usage: scrabbleServer <rows> <cols>");

  numCols = strToInt(argv[2], &success);
  if (!success || numCols <= 0 || numCols > MAX_DIMENSION)
    fail("usage: scrabbleServer <rows> <cols>");

  //initialize semaphore
  sem_init(&lock, 0, 1);

  //parse dictionary file "words" for extra credit
  parseWordsFile();
  
  //initialize game board
  initGameBoard();

  //either ctrl+c will be pressed which will cause sigintHandler to run, 
  //or runServer fails to bind socket, the function exits and comes back here where the rest of main executes
  signal(SIGINT, sigintHandler);

  //run server, this will create detached threads
  runServer();

  //gameboard and word data structure
  freeGameBoard();

  freeWords();

  //destroy sem
  sem_destroy(&lock);

  return 0;
}
