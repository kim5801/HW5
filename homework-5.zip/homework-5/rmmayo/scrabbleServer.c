#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <signal.h>
#include <errno.h>
#include <semaphore.h>

/** Port number used by my server */
#define PORT_NUMBER "26402"

/** Maximum word length */
#define WORD_LIMIT 26

// Semaphore to lock the board
sem_t lock;
// The server socket
int servSock;
// The malloced board
char **board;
// Rows of the board
static int rows;
// Collumns of the board
static int cols;
// Print out an error message and exit.
static void fail(char const *message)
{
	fprintf(stderr, "%s\n", message);
	exit(EXIT_FAILURE);
}

/** handle a client connection, close it when we're done. */
void *handleClient(void *sock)
{
	// Here's a nice trick, wrap a C standard IO FILE around the
	// socket, so we can communicate the same way we would read/write
	// a file.

	FILE *fp = fdopen(*((int *)sock), "a+");

	// Prompt the user for a command.
	fprintf(fp, "cmd> ");

	// Temporary values for parsing commands.
	char cmd[40];
	while (fscanf(fp, "%10s", cmd) == 1 &&
		   strcmp(cmd, "quit") != 0)
	{

		int row, col = 0;
		char word[27];
		// Handle the across command
		if (strncmp(cmd, "across", 6) == 0)
		{
			sem_wait(&lock);
			// Get the rest of the input
			if(fscanf(fp, "%d %d %26s", &row, &col, word) != 3) {
				fprintf(fp, "Invalid command\n");
			}

			else{
				// Make sure the word doesn't fall of the board
			if (strlen(word) + col > cols)
			{
				fprintf(fp, "Invalid command\n");
			}
			else if (row < 0 || col < 0)
			{
				fprintf(fp, "Invalid command\n");
			}
			else
			{ // Make sure the word has no capital letters and the characters match if they need to
				bool flag = false;
				int len = strlen(word);
				for (int i = 0; i < len; i++)
				{
					if (board[row][col + i] != ' ' && board[row][col + i] != word[i])
					{
						flag = true;
					}
					if (!(word[i] >= 'a' && word[i] <= 'z'))
					{
						flag = true;
					}
				}

				if (flag)
				{
					fprintf(fp, "Invalid command\n");
				}
				else
				{ // Add the word to the board
					int len = strlen(word);
					for (int i = 0; i < len; i++)
					{
						board[row][col + i] = word[i];
					}
				}
			}
			}
			sem_post(&lock);
		}
		// Handle the down command
		else if (strncmp(cmd, "down", 4) == 0)
		{
			sem_wait(&lock);
			// get the rest of the input
			fscanf(fp, "%d %d %26s", &row, &col, word);
			// make sure the word doesnt fall off the board
			if (strlen(word) + row > rows)
			{
				fprintf(fp, "Invalid command\n");
			}
			else if (row < 0 || col < 0)
			{
				fprintf(fp, "Invalid command\n");
			}
			else
			{
				// make sure the word has no capital letters and that it matches any characters currently on the board it crosses with
				bool flag = false;
				int len = strlen(word);
				for (int i = 0; i < len; i++)
				{
					if (board[row + i][col] != ' ' && board[row + i][col] != word[i])
					{
						flag = true;
					}
					if (!(word[i] >= 'a' && word[i] <= 'z'))
					{
						flag = true;
					}
				}

				if (flag)
				{
					fprintf(fp, "Invalid command\n");
				}
				else
				{ // Add the word to the board
					int len = strlen(word);
					for (int i = 0; i < len; i++)
					{
						board[row + i][col] = word[i];
					}
				}
			}
			sem_post(&lock);
		}
		// Print out the state of the board on client host
		else if (strcmp(cmd, "board") == 0)
		{
			sem_wait(&lock);
			fputc('+', fp);
			for (int i = 0; i < cols; i++)
			{
				fputc('-', fp);
			}
			fputc('+', fp);
			fputc('\n', fp);
			for (int i = 0; i < rows; i++)
			{
				fputc('|', fp);
				for (int j = 0; j < cols; j++)
				{
					fputc(board[i][j], fp);
				}
				fputc('|', fp);
				fputc('\n', fp);
			}

			fputc('+', fp);
			for (int i = 0; i < cols; i++)
			{
				fputc('-', fp);
			}
			fputc('+', fp);
			fputc('\n', fp);

			sem_post(&lock);
		}

		else
		{
			fprintf(fp, "Invalid Command\n");
		}

		// Prompt the user for the next command and release the lock on the board.
		fprintf(fp, "cmd> ");
	}

	// Close the connection with this client.
	fclose(fp);

	return NULL;
}
// Interupt handler for ^C. Frees the board and closes the socket.
void closeServer()
{
	for (int i = 0; i < rows; i++)
	{
		free(board[i]);
	}
	free(board);
	close(servSock);
	exit(EXIT_SUCCESS);
}

int main(int argc, char *argv[])
{
	signal(SIGINT, closeServer);
	sem_init(&lock, false, 1);

	// make the board
	if (argc != 3)
	{
		fail("usage: scrabbleServer <rows> <cols>");
	}

	rows = atoi(argv[1]);
	cols = atoi(argv[2]);
	if (rows <= 0 || cols <= 0)
	{
		fail("usage: scrabbleServer <rows> <cols>");
	}

	board = (char **)malloc(rows * sizeof(char *));
	for (int i = 0; i < rows; i++)
	{
		board[i] = (char *)malloc(cols * sizeof(char));
	}

	for (int i = 0; i < rows; i++)
		for (int j = 0; j < cols; j++)
			board[i][j] = ' ';

	// Prepare a description of server address criteria.
	struct addrinfo addrCriteria;
	memset(&addrCriteria, 0, sizeof(addrCriteria));
	addrCriteria.ai_family = AF_INET;
	addrCriteria.ai_flags = AI_PASSIVE;
	addrCriteria.ai_socktype = SOCK_STREAM;
	addrCriteria.ai_protocol = IPPROTO_TCP;

	// Lookup a list of matching addresses
	struct addrinfo *servAddr;
	if (getaddrinfo(NULL, PORT_NUMBER, &addrCriteria, &servAddr))
		fail("Can't get address info");

	// Try to just use the first one.
	if (servAddr == NULL)
		fail("Can't get address");

	// Create a TCP socket
	servSock = socket(servAddr->ai_family, servAddr->ai_socktype,
					  servAddr->ai_protocol);
	if (servSock < 0)
		fail("Can't create socket");

	// Bind to the local address
	if (bind(servSock, servAddr->ai_addr, servAddr->ai_addrlen) != 0)
		fail("Can't bind socket");

	// Tell the socket to listen for incoming connections.
	if (listen(servSock, 5) != 0)
		fail("Can't listen on socket");

	// Free address list allocated by getaddrinfo()
	freeaddrinfo(servAddr);

	// Fields for accepting a client connection.
	struct sockaddr_storage clntAddr; // Client address
	socklen_t clntAddrLen = sizeof(clntAddr);

	while (true)
	{
		// Accept a client connection.
		int sock = accept(servSock, (struct sockaddr *)&clntAddr, &clntAddrLen);
		// create the thread
		pthread_t thread;

		pthread_create(&thread, NULL, handleClient, (void *)&sock);
		// detach the thread
		pthread_detach(thread);
	}

	// Stop accepting client connections (never reached).
	// close( servSock );

	return EXIT_SUCCESS;
}
